/*
 inet.h

 Date Created: Wed Feb 24 17:48:12 2010
 Author:       Simon Leinen  <simon.leinen@switch.ch>
 */

extern void init_hints_from_preferences (struct addrinfo *, const struct samplicator_context *);
