#!/bin/sh

VERSION=`cat version.h | awk '{print $3}'`

CP=`which cp`
CHMOD=`which chmod`
CHOWN=`which chown`
CHGRP=`which chgrp`
MKDIR=`which mkdir`
SYSTEM=`uname -sr`
SED=`which sed`
LN=`which ln`
RM=`which rm`

SERVICE_DESC="Osiris Host Integrity Monitor"

INTERACTIVE=1
PACKAGE_MODE=0
NO_USER_ADDED=0

# Common settings
SBIN_DIR="/usr/local/sbin"
INSTALL_DIR="${DESTDIR}${SBIN_DIR}"
ROOT_USER=root
ROOT_GROUP=wheel

# Osiris CLI settings
INSTALL_CLI=0

# Osiris agent settings
INSTALL_OSIRISD=0
OSIRIS_DIR="/usr/local/osiris"
OSIRISD_RC="osirisd.in"
AGENT_USER=osiris
AGENT_GROUP=${AGENT_USER}

# Osiris management daemon settings
INSTALL_OSIRISM=0
OSIRISMD_DIR="/usr/local/osiris"
OSIRISMD_CONF_DIR="/usr/local/osiris"
OSIRISMD_RC="osirismd.in"
MD_USER=osiris
MD_GROUP=${MD_USER}


# ---------------------------------------------------------------------------
# FUNCTION: create_user_and_group
#
# Param 1: The username to add
# Param 2: The primary group
# Param 3: The home directory
# Param 4: The UID to use (only used on Darwin)
# ---------------------------------------------------------------------------
create_user_and_group()
{
    USERNAME=$1
    GROUP=$2
    HOME=$3
    NEW_UID=$4

    echo "==> creating user and group (${USERNAME}, ${GROUP})."
    case `uname -s`  in
Linux|OpenBSD)

    # Add group, must be first.
    if ! /usr/sbin/groupadd ${GROUP}; then
        echo "==> error: unable to add group '${GROUP}'!"
        exit 1
    fi

    # Add user.
    if ! /usr/sbin/useradd -g ${GROUP} -d ${HOME} \
      -s /sbin/nologin -c "${SERVICE_DESC}" ${USERNAME}
    then
        echo "==> error: unable to add user '${USERNAME}'!"
        /usr/sbin/groupdel ${GROUP}
        exit 1
    fi
    ;;

NetBSD)

    # Add group, must be first.
    if ! /usr/sbin/groupadd ${GROUP}; then
        echo "==> error: unable to add group '${GROUP}'!"
        exit 1
    fi

    if [ -d ${HOME} ]; then
        OPTS=""
    else
        OPTS="-m"
    fi

    # add user.
    if ! /usr/sbin/useradd -g ${GROUP} -d ${HOME} ${OPTS} \
        -s /sbin/nologin -c "${SERVICE_DESC}" ${USERNAME}
    then
        echo "==> error: unable to add user '${USERNAME}'!"
        /usr/sbin/groupdel ${GROUP}
        exit 1
    fi
    ;;

FreeBSD)

    # Add group, must be first.
    if ! /usr/sbin/pw groupadd ${GROUP}; then
        echo "error: unable to add group '${GROUP}'!"
        exit 1
    fi

    # Add user.
    if ! /usr/sbin/pw useradd ${USERNAME} -g ${GROUP} -h - \
        -d ${HOME} -s /sbin/nologin -c "${SERVICE_DESC}"
    then
        echo "error: unable to add user '${USERNAME}'!"
        /usr/sbin/groupdel ${GROUP}
        exit 1 
    fi
    ;;

SunOS*)

    # Add group, must be first.
    if groupadd ${GROUP}; then
        echo ""
    else
        echo "error: unable to add group '${GROUP}'!"
        exit 1
    fi

    # Add user.
    if useradd -g ${GROUP} -d ${HOME} -c "${SERVICE_DESC}" ${USERNAME}; then
        echo ""
    else
        echo "error: unable to add user '${USERNAME}'!"
        groupdel ${GROUP}
        exit 1
    fi
    ;;

AIX*)
    # Add group, must be first.
    if ! mkgroup ${GROUP}; then
        echo "error: unable to add group '${GROUP}'!"
        exit 1
    fi

    # Add user.
    if ! mkuser pgrp=${GROUP} home=${HOME} ${USER}; then
        echo "error: unable to add osiris user!"
        rmgroup ${GROUP}
        exit 1
    fi
    ;;
        
Darwin)

    echo "==> creating Osiris user and group with uid/gid ${NEW_UID}."

    niutil -create / //users/${USERNAME}
    niutil -createprop / //users/${USERNAME} uid ${NEW_UID}
    niutil -createprop / //users/${USERNAME} realname "${SERVICE_DESC}"
    niutil -createprop / //users/${USERNAME} shell "/dev/null"
    niutil -createprop / //users/${USERNAME} gid ${NEW_UID}
    niutil -createprop / //users/${USERNAME} passwd "*" 
    niutil -createprop / //users/${USERNAME} _writers_passwd ${USERNAME}
    niutil -createprop / //users/${USERNAME} home $HOME
    niutil -createprop / //users/${USERNAME} expire 0
    niutil -createprop / //users/${USERNAME} change 0

    niutil -create / //groups/${GROUP}
    niutil -createprop / //groups/${GROUP} gid ${NEW_UID}
    ;;

*)
    echo "Unrecognized host type, no user and group installed for "
    echo "the osiris agent/console, you will need to set this up "
    echo "manually."
    return
    ;;
esac

echo "==> group '$GROUP' added."
echo "==> user '$USERNAME' added."
}

# ---------------------------------------------------------------------------
# FUNCTION: create_users_and_groups
# ---------------------------------------------------------------------------
create_users_and_groups()
{
    if [ ${PACKAGE_MODE} -eq 1 ]; then
        echo "==> Skipping user/group creation."
        return
    fi

    # Create user/group for scan agent.
    if user_exists ${AGENT_USER}; then
        echo "==> using existing Osiris user."
    else
        case `uname -s`  in
        Linux|*BSD|SunOS*|AIX*)
            create_user_and_group ${AGENT_USER} ${AGENT_GROUP} ${OSIRIS_DIR}
            ;;
        Darwin)
            create_user_and_group ${AGENT_USER} ${AGENT_GROUP} /dev/null $AGENT_NEXT_ID
            ;;
        *)
            NO_USER_ADDED=1
            ;;
        esac
    fi

    # Create user/group for management console.
    if user_exists ${MD_USER}; then
        echo "==> using existing Osiris management console user."
    else
        case `uname -s`  in
        Linux|*BSD|SunOS*|AIX*)
            create_user_and_group ${MD_USER} ${MD_GROUP} ${OSIRISMD_DIR}
            ;;
            
        Darwin)
            create_user_and_group ${MD_USER} ${MD_GROUP} /dev/null $MD_NEXT_ID
            ;;
        *)
            NO_USER_ADDED=1
            ;;
        esac
    fi

    # give user a chance to bail and create user if we couldn't.

    if [ ${NO_USER_ADDED} -eq 1 ]; then

        default="y"
        prompt="
*******************************************************************
We don't know how to create a user on this system, this
is very important in order to run Osiris with the proper privs. 
*******************************************************************

Do you want to stop this script and create an 'osiris' user and
group now? (y/n) [${default}] "
        ask "$prompt"

        if [ -z "${answer}" ] ; then
            answer=$default
        fi

        case "$answer" in
            y* | Y*)
        echo ""
        echo ""
        echo "create 'osiris' user and group and run 'make install again'."
        exit 0
        ;;
        *)
        echo "your permissions may be not what you want ;)"
        ;;
        esac
    fi
}

# ---------------------------------------------------------------------------
# FUNCTION: set_permissions
# ---------------------------------------------------------------------------
set_permissions()
{
    if [ ${PACKAGE_MODE} -eq 1 ]; then
	echo "==> Skipping permission setting."
	return
    fi

    case `uname -s` in
    Linux*)
        ROOT_GROUP=`getent group 0 | head -n 1 | cut -d: -f1`
        ;;
    SunOS*)
        ROOT_GROUP=other
        ;;
    AIX*)
        ROOT_GROUP=system
        ;;
    IRIX*)
        # we don't have a user add for this platform.

        if [ ${NO_USER_ADDED} ]; then
            AGENT_USER=root
            AGENT_GROUP=sys
            MD_USER=root
            MD_GROUP=sys
        fi

        ROOT_GROUP=sys
        ;;
    esac

    if [ `uname -s` = 'SunOS' ]; then
        ${CHOWN} ${AGENT_USER}  ${OSIRIS_DIR}
        ${CHGRP} ${AGENT_GROUP} ${OSIRIS_DIR}
    else
        ${CHOWN} -R ${AGENT_USER}:${AGENT_GROUP} ${OSIRIS_DIR}
        if [ ${AGENT_USER} != ${MD_USER} ];then
            ${CHOWN} -R ${MD_USER}:${MD_GROUP} ${OSIRISMD_DIR}
        fi
    fi

    if [ -f ${INSTALL_DIR}/osiris ]; then
        ${CHOWN} ${ROOT_USER}  ${INSTALL_DIR}/osiris
        ${CHGRP} ${ROOT_GROUP} ${INSTALL_DIR}/osiris
        ${CHMOD} 755 ${INSTALL_DIR}/osiris
        echo "==> change owner and  permissions on ${INSTALL_DIR}/osiris"
        ls -la ${INSTALL_DIR}/osiris
    fi

    if [ -f ${INSTALL_DIR}/osirisd ]; then
        ${CHOWN} ${ROOT_USER}  ${INSTALL_DIR}/osirisd
        ${CHGRP} ${ROOT_GROUP} ${INSTALL_DIR}/osirisd
        ${CHMOD} 755 ${INSTALL_DIR}/osirisd
        echo "==> change owner and permissions on ${INSTALL_DIR}/osirisd"
        ls -la ${INSTALL_DIR}/osirisd
    fi

    if [ -f ${INSTALL_DIR}/osirismd ]; then
        ${CHOWN} ${MD_USER}  ${INSTALL_DIR}/osirismd
        ${CHGRP} ${MD_GROUP} ${INSTALL_DIR}/osirismd
        ${CHMOD} 4755 ${INSTALL_DIR}/osirismd
        echo "==> change owner permissions on ${INSTALL_DIR}/osirismd"
        ls -la ${INSTALL_DIR}/osirismd
    fi
}

# ---------------------------------------------------------------------------
# FUNCTION: user_exists
#
# Param:  User name
# Output: None
# Return: 0 if the user exists
# ---------------------------------------------------------------------------
user_exists()
{
    USERNAME=$1

case `uname -s`  in
Linux)

    getent passwd "${USERNAME}" > /dev/null 2>&1
    RC=$?
    ;;

OpenBSD|NetBSD|SunOS*|AIX*)

    ENTRY=`cat /etc/passwd | grep "^${USERNAME}:"`
    if [ "${ENTRY}" != "" ]; then
        RC=0
    else
        RC=1
    fi
    ;;

IRIX*)

    ENTRY=`cat /etc/passwd | grep "^${USERNAME}:"`
    if [ "${ENTRY}" = "" ]; then
        YPCAT=`whereis ypcat`

        if [ "${YPCAT}" != "ypcat:" ]; then
            ENTRY=`ypcat passwd | grep ${USERNAME}`
        fi
    fi

    if [ "${ENTRY}" != "" ]; then
        RC=0
    else
        RC=1
    fi
    ;;

FreeBSD)

    pw user show "${USERNAME}" 2>/dev/null
    RC=$?
    ;;

Darwin)

    USER_EXISTS=`nireport / /users name | grep ${USERNAME}`
    if [ "$USER_EXISTS" = "" ]; then
        RC=1
    else
        RC=0
    fi

    # Display the UID that will be used for Darwin systems.
    LAST_ID=`nireport / /users uid | grep "5[0123456789][0123456789]"|tail -n 1`

    AGENT_NEXT_ID=`expr ${LAST_ID} + 1`
    LAST_ID=$AGENT_NEXT_ID

    MD_NEXT_ID=`expr ${LAST_ID} + 1`
    LAST_ID=$MD_NEXT_ID
    ;;

MINGW*)

    echo "Install with the NSIS installer file, not this script!"
    exit 1
    ;;

*)

    echo "Unsupported platform for installation, please forward this error"
    echo "to: osiris-devel@lists.shmoo.com."
    platform=`uname -a`
    echo ""
    echo "${platform}"
    echo ""
    exit 1
    ;;

esac

    return $RC
}

# ---------------------------------------------------------------------------
# FUNCTION: copy_binaries.
# ---------------------------------------------------------------------------
copy_binaries()
{
    if [ ! -d ${INSTALL_DIR} ]; then
        echo "Installation directory doesn't exist, creating."
        ${MKDIR} -p ${INSTALL_DIR}
    fi

    # CLI management app.
    if [ $INSTALL_CLI -eq 1 ]; then
        ${CP} ./osiris ${INSTALL_DIR}
        echo "==> installed osiris CLI: ${INSTALL_DIR}/osiris"
    fi

    # Scanning agent.
    if [ $INSTALL_OSIRISD -eq 1 ]; then
        if [ ! -d ${DESTDIR}${OSIRIS_DIR} ]; then
            echo "Osiris scan agent root directory doesn't exist, creating."
            ${MKDIR} -p ${DESTDIR}${OSIRIS_DIR}
        fi

        ${CP} ./osirisd ${INSTALL_DIR}
        echo "==> installed scan agent: ${INSTALL_DIR}/osirisd"
    fi

    # Management console.
    if [ $INSTALL_OSIRISM -eq 1 ]; then
        if [ ! -d ${DESTDIR}${OSIRISMD_DIR} ]; then
            echo "Osiris management console root directory doesn't exist, creating."
            ${MKDIR} -p ${DESTDIR}${OSIRISMD_DIR}
        fi

        if [ ! -d ${DESTDIR}${OSIRISMD_CONF_DIR} ]; then
            echo "Osiris management console configuration directory doesn't exist, creating."
            ${MKDIR} -p ${DESTDIR}${OSIRISMD_CONF_DIR}
        fi

        ${CP} ./osirismd ${INSTALL_DIR}
        echo "==> installed management console ${INSTALL_DIR}/osirismd"

        # if the configs directory is here, we make sure the
        # osiris root direcotry and configs dir exists
        # and then copy over the default configs.
        if [ -d ./configs ]; then

            ${MKDIR} -p ${DESTDIR}${OSIRISMD_DIR}/configs
            cfs=`ls ${DESTDIR}${OSIRISMD_DIR}/configs`

            if [ "${cfs}" != "" ] ; then
                ${MKDIR} -p ${DESTDIR}${OSIRISMD_DIR}/configs/old
                ${CP} -rf ${DESTDIR}${OSIRISMD_DIR}/configs/default.* ${DESTDIR}${OSIRISMD_DIR}/configs/old
            fi

            ${CP} -rf ./configs/default.* ${DESTDIR}${OSIRISMD_DIR}/configs
            echo "==> installed default scan configs."
        fi

        # look for old default-configs directory.  If it is here, we just 
        # print a warning to the user to inform them that it is no longer
        # used by the management console.
        if [ -d ${OSIRIS_DIR}/default-configs ]; then
           echo "!! warning: the 'default-configs' directory is present.  This is"
           echo "            from an older version of the Osiris management console"
           echo "            that is not used anymore.  Default configs have been  "
           echo "            installed in the 'configs' directory.  You will need  "
           echo "            to manually update them if you had modified defaults. "
           echo "            Otherwise, ignore this message."
        fi
    fi
}

# ---------------------------------------------------------------------------
# FUNCTION: pre_install
# ---------------------------------------------------------------------------
pre_install()
{
    default="y"
    prompt="Continue with installation? (y/n) [${default}] "
    ask "$prompt"

    if [ -z "${answer}" ] ; then
        answer=$default
    fi

    case "$answer" in
    y* | Y*)
    ;;
    *)
    echo "Osiris installation aborted."
    exit 0
    ;;
    esac

    # in case this script is not run from make.

    if [ -f ../osirismd/osirismd ]; then
        ${CP} ../osirismd/osirismd .
    fi

    if [ -f ../osirisd/osirisd ]; then
        ${CP} ../osirisd/osirisd .
    fi

    if [ -f ../cli/osiris ]; then
        ${CP} ../cli/osiris .
    fi

    if [ -d ../configs ]; then
        ${CP} -r ../configs .
    fi

    echo "Osiris Scanning Daemon Version $VERSION for $SYSTEM"
    echo "Copyright (c) 2006 Brian Wotring. All Rights Reserved."
    echo ""
    echo ""
    echo "This installation was configured and built to run as osiris"
    echo "     agent user name: osiris"
    echo "management user name: osiris"
    echo ""
    echo "This installation was configured and built to use osiris"
    echo "     agent root directory: /usr/local/osiris"
    echo "management root directory: /usr/local/osiris"
    echo ""
    echo "The username and directory will be created during the"
    echo "installation process if they do not already exist."
    echo ""
    echo "By installing this product you agree that you have read the"
    echo "LICENSE file and will comply with its terms. "
    echo ""
    echo "---------------------------------------------------------------------"
    echo ""

    trap 'echo; echo " ! installation aborted! "; exit 1' 1 2 3 15
}


# ---------------------------------------------------------------------------
# FUNCTION: post_install
# ---------------------------------------------------------------------------
post_install()
{
    if [ ${PACKAGE_MODE} -eq 1 ]; then
        echo "==> Skipping post install."
        return
    fi

# now give some instructions on how to start daemons for those that need it.

echo ""
echo "=================================================================="
echo "Osiris has been installed, but is not currently running.  Startup "
echo "scripts have been installed so that the necessary services will "
echo "be started on boot."
echo ""

if [ $INSTALL_OSIRISM != 0 -a -f ${INSTALL_DIR}/osirismd ]; then

    default="y"
    prompt="Start management console now? (y/n) [${default}] "
	ask "$prompt"

    if [ -z "${answer}" ] ; then
        answer=$default
    fi

    case "$answer" in
   y* | Y*)
       ${INSTALL_DIR}/osirismd -r ${OSIRISMD_DIR}
    ;;
  *)
        echo " --> to start management console, run: ${INSTALL_DIR}/osirismd"
    ;;
    esac
fi

default="y"
prompt="Start scan agent now? (y/n) [${default}] "
ask "$prompt"

    if [ -z "${answer}" ] ; then
        answer=$default
    fi

    case "$answer" in
   y* | Y*)
       ${INSTALL_DIR}/osirisd -r ${OSIRIS_DIR}
    ;;
  *)
        echo " --> to start the scan agent, do sudo ${INSTALL_DIR}/osirisd"
    ;;
esac


echo ""
echo "Documentation is included with this source and available online at:"
echo "    http://www.hostintegrity.com/osiris"
echo ""
echo ""
echo "(c) 2006 - Brian Wotring"
echo ""

}

# ---------------------------------------------------------------------------
# FUNCTION: ask
# ---------------------------------------------------------------------------
ask()
{
    prompt=$1
    printf "%s" "$prompt "
    if [ $INTERACTIVE -eq 1 ]; then
        read answer
    else
        echo
        answer=''
    fi
}

# ---------------------------------------------------------------------------
# FUNCTION: prompts
# ---------------------------------------------------------------------------
prompts()
{
    if [ -f ./osirisd ]; then
        default="y"
        prompt="Install osiris agent? (y/n) [${default}] "
        ask "$prompt"

        if [ -z "${answer}" ] ; then
            answer=$default
        fi

        case "$answer" in
        y* | Y*)
        INSTALL_OSIRISD=1
        ;;
        *)
        INSTALL_OSIRISD=0
        ;;
        esac
    fi

    if [ -f ./osirismd ]; then
        default="y"
        prompt="Install management console? (y/n) [${default}] "
        ask "$prompt"

        if [ -z "${answer}" ] ; then
            answer=$default
        fi

        case "$answer" in
        y* | Y*)
        INSTALL_OSIRISM=1
        ;;
        *)
        INSTALL_OSIRISM=0
        ;;
        esac
    fi

    if [ -f ./osiris ]; then
        default="y"
        prompt="Install CLI? (y/n) [${default}] "
        ask "$prompt"

        if [ -z "${answer}" ] ; then
            answer=$default
        fi

        case "$answer" in
        y* | Y*)
        INSTALL_CLI=1
        ;;
        *)
        INSTALL_CLI=0
        ;;
        esac
    fi

    if [ $INSTALL_OSIRISD = 0 -a $INSTALL_OSIRISM = 0 -a $INSTALL_CLI = 0 ]; then
        echo 'Nothing selected for install!'
        exit 3
    fi

    # Prompt user for installation directory.
    prompt="Installation directory for binaries: [$INSTALL_DIR]"
	ask "$prompt"

    # Read and remove any trailing slash.
    INSTALL_DIR=`expr "${INSTALL_DIR}" : '\(.*[^/]\)/*$'`

    if [ "$answer" != "" ]; then
        INSTALL_DIR=$answer
    fi
}

# ---------------------------------------------------------------------------
# FUNCTION: create_startup_scripts
# ---------------------------------------------------------------------------
create_startup_scripts()
{
RC_DESC="==> installing rc startup for daemon(s)."
AGENT_DESC="==> installing StartupItem for the Osiris Scan Agent."

case `uname -s`  in

Linux)

    echo ${RC_DESC}

    # Determine Linux distribution.
    case `uname -s` in 
    Linux*) 
        DISTRO=""
        if [ "${DISTRO}" = "" ]; then
            if [ -e /proc/version ]; then
#             DISTRO=`cat /proc/version | grep -oi -e 'suse' -e 'red hat' -e 'redhat' -e 'debian' -e 'gentoo' | tr A-Z a-z | head -n 1`

            DISTRO=`cat /proc/version | tr A-Z a-z | sed -e 's/\(suse\|debian\|gentoo\|red hat\|redhat\)/xxx\0yyy/' -e 's/^.*xxx//' -e 's/yyy.*$//' -e 's/ *//g' | head -n 1`

             if [ "${DISTRO}" = "red hat" ]; then
                 DISTRO="redhat"
             fi

             if [ "${DISTRO}" = "" ]; then
                 DISTRO="unknown"
             fi

             if [ -f linux/osirisd.${DISTRO} ]; then
               OSIRISD_RC="osirisd.${DISTRO}"
               OSIRISMD_RC="osirismd.${DISTRO}"
             fi
            fi
        fi
        echo "Linux Distribution: ${DISTRO}"
        ;;
    esac

    if [ -d /etc/rc.d/init.d ]; then
        INIT_D="${DESTDIR}/etc/rc.d/init.d"
    elif [ -d /etc/init.d ]; then
        INIT_D="${DESTDIR}/etc/init.d"
    elif [ -d /etc/rc.d ]; then
        INIT_D="${DESTDIR}/etc/rc.d"
    else
        INIT_D=""
    fi

    if [ -d /etc/rc.d/rc3.d ]; then
        RC_D="${DESTDIR}/etc/rc.d"
    elif [ -d /etc/rc3.d ]; then
        RC_D="${DESTDIR}/etc"
    elif [ -f "/etc/rc.d/rc.sysvinit" ]; then
        RC_D="${DESTDIR}/etc/rc.d"

        for runlevel in 2 3 4 5 ; do
            dir="${RC_D}/rc${runlevel}.d"
            if [ ! -d "$dir" ]; then
                ${MKDIR} "$dir"
                ${CHMOD} 0755 "$dir"
            fi
        done

    else
        RC_D=""
    fi

    if [ $INSTALL_OSIRISD -eq 1 ]; then
        ${MKDIR} -p ${INIT_D}
        ${SED} "s#@INSTALLDIR@#${SBIN_DIR}#;s#@OSIRISDIR@#${OSIRIS_DIR}#" \
			< ./linux/${OSIRISD_RC} > ${INIT_D}/osirisd
        ${CHMOD} 555 ${INIT_D}/osirisd

        if [ ${PACKAGE_MODE} -eq 1 -o ${DISTRO} = "gentoo" ]; then
            echo "==> Skipping osirisd symlink creation."
        else
            ${RM} -rf ${RC_D}/rc2.d/S80osirisd
            ${RM} -rf ${RC_D}/rc3.d/S80osirisd
            ${RM} -rf ${RC_D}/rc4.d/S80osirisd
            ${RM} -rf ${RC_D}/rc5.d/S80osirisd
            ${LN} -s ${INIT_D}/osirisd ${RC_D}/rc2.d/S80osirisd
            ${LN} -s ${INIT_D}/osirisd ${RC_D}/rc3.d/S80osirisd
            ${LN} -s ${INIT_D}/osirisd ${RC_D}/rc4.d/S80osirisd
            ${LN} -s ${INIT_D}/osirisd ${RC_D}/rc5.d/S80osirisd
        fi

        if [ ${DISTRO} = "gentoo" ]; then
            /sbin/rc-update add osirisd default
        fi
    fi

    if [ $INSTALL_OSIRISM -eq 1 ]; then
        ${SED} -e "s#@INSTALLDIR@#${SBIN_DIR}#;s#@OSIRISDIR@#${OSIRIS_DIR}#" \
               -e "s#@OSIRISMDDIR@#${OSIRISMD_DIR}#;s#@OSIRISMDCONF@#${OSIRISMD_CONF_DIR}#" \
	       -e "s#@OSIRISMDUSER@#${MD_USER}#" \
            < ./linux/${OSIRISMD_RC} > ${INIT_D}/osirismd
        ${CHMOD} 555 ${INIT_D}/osirismd

        if [ ${PACKAGE_MODE} -eq 1 -o ${DISTRO} = "gentoo" ]; then
            echo "==> Skipping osirismd symlink creation."
        else
            ${RM} -rf ${RC_D}/rc2.d/S80osirismd
            ${RM} -rf ${RC_D}/rc3.d/S80osirismd
            ${RM} -rf ${RC_D}/rc4.d/S80osirismd
            ${RM} -rf ${RC_D}/rc5.d/S80osirismd
            ${LN} -s ${INIT_D}/osirismd ${RC_D}/rc2.d/S80osirismd
            ${LN} -s ${INIT_D}/osirismd ${RC_D}/rc3.d/S80osirismd
            ${LN} -s ${INIT_D}/osirismd ${RC_D}/rc4.d/S80osirismd
            ${LN} -s ${INIT_D}/osirismd ${RC_D}/rc5.d/S80osirismd
        fi

        if [ ${DISTRO} = "gentoo" ]; then
            /sbin/rc-update add osirismd default
        fi
    fi
    ;;

OpenBSD)

    echo ${RC_DESC}

    OSIRISD_CONF_ENTRY="# Osiris Scan Agent\nif [ X\"\${osirisd}\" == X\"YES\" -a -x ${INSTALL_DIR}/osirisd ]; then\n    echo -n \" osirisd\"; ${INSTALL_DIR}/osirisd\nfi"

    OSIRISMD_CONF_ENTRY="# Osiris Management Console\nif [ X\"\${osirismd}\" == X\"YES\" -a -x ${INSTALL_DIR}/osirismd ]; then\n    echo -n \" osirismd\"; ${INSTALL_DIR}/osirismd\nfi"

    if [ ! -f /etc/rc.conf.local ]; then
        echo "==> creating /etc/rc.conf.local"
        touch /etc/rc.conf.local
        ${CHMOD} 644 /etc/rc.conf.local
    fi

    if [ ! -f /etc/rc.conf.local ]; then
        echo "unable to create /etc/rc.conf.local!!"
        exit 1
    fi

    if [ -f ./osirisd ]; then

        OSIRISD_ENTRY=`cat /etc/rc.conf.local | grep osirisd`

        if [ "${OSIRISD_ENTRY}" = "" ]; then
            echo "==> adding osirisd to /etc/rc.conf.local"
            echo "osirisd=YES" >> /etc/rc.conf.local
        else
            echo "::osirismd already in /etc/rc.conf.local"
        fi

        OSIRISD_ENTRY=`cat /etc/rc.local | grep osirisd`

        if [ "${OSIRISD_ENTRY}" = "" ]; then
            echo "==> adding osirisd to /etc/rc.local"
            echo "${OSIRISD_CONF_ENTRY}" >> /etc/rc.local
        else
            echo "==> osirisd already in rc.local"
        fi
    fi

    if [ $INSTALL_OSIRISM != 0 -a -f ./osirismd ]; then

        OSIRISMD_ENTRY=`cat /etc/rc.conf.local | grep osirismd`

        if [ "${OSIRISMD_ENTRY}" = "" ]; then
            echo "==> adding osirismd to /etc/rc.conf.local"
            echo "osirismd=YES" >> /etc/rc.conf.local
        else
            echo "::osirismd already in /etc/rc.conf.local"
        fi

        OSIRISMD_ENTRY=`cat /etc/rc.local | grep osirismd`

        if [ "${OSIRISMD_ENTRY}" = "" ]; then
            echo "==> adding osirismd to /etc/rc.local"
            echo "${OSIRISMD_CONF_ENTRY}" >> /etc/rc.local
        else
            echo "::osirismd already in rc.local"
        fi
    fi
    ;;

IRIX*)
    echo ${RC_DESC}

    INIT_D=/etc/init.d/
    RC_D=/etc/rc2.d/

    if [ -f ./osirisd ]; then

    ${SED} "s#@INSTALLDIR@#${INSTALL_DIR}#" < ./irix/osirisd.in > ${INIT_D}/osirisd.tmp
    ${SED} "s#@OSIRISDIR@#${OSIRIS_DIR}#" < ${INIT_D}/osirisd.tmp > ${INIT_D}/osirisd

        ${CHMOD} 555 ${INIT_D}/osirisd
        ${RM} ${INIT_D}/osirisd.tmp
        ${RM} -rf ${RC_D}/S95osirisd
        ${LN} -s ${INIT_D}/osirisd ${RC_D}/S95osirisd
        chkconfig -f osirisd on
    fi

    if [ $INSTALL_OSIRISM != 0 -a -f ./osirismd ]; then

        ${SED} "s#@INSTALLDIR@#${INSTALL_DIR}#" < ./irix/osirismd.in > ${INIT_D}/osirismd.tmp
${SED} "s#@OSIRISDIR@#${OSIRIS_DIR}#" < ${INIT_D}/osirismd.tmp > ${INIT_D}/osirismd
        ${CHMOD} 555 ${INIT_D}/osirismd

        ${RM} ${INIT_D}/osirismd.tmp
        ${RM} -rf ${RC_D}/S95osirismd
        ${LN} -s ${INIT_D}/osirismd ${RC_D}/S95osirismd
        chkconfig -f osirismd on
    fi

    ;;

FreeBSD)

    echo ${RC_DESC}

    if [ -f ./osirisd ]; then
        DEST=/usr/local/etc/rc.d/osirisd.sh
        ${SED} "s#@INSTALLDIR@#${INSTALL_DIR}#" < ./freebsd/osirisd.in > ${DEST}.tmp
        ${SED} "s#@OSIRISDIR@#${OSIRIS_DIR}#" < ${DEST}.tmp > ${DEST}
        ${CHMOD} 555 ${DEST}
        echo "==> installed rc startup script: ${DEST}"

        ${RM} ${DEST}.tmp

        EXISTS=`grep osirisd /etc/rc.conf`        
        if [ "${EXISTS}" = "" ]; then
            echo "osirisd_enable=\"YES\"" >> /etc/rc.conf   
            echo "==> updated: /etc/rc.conf --> osirisd_enable=YES"
        fi
    fi

    if [ $INSTALL_OSIRISM != 0 -a -f ./osirismd ]; then
        DEST=/usr/local/etc/rc.d/osirismd.sh
        ${SED} "s#@INSTALLDIR@#${INSTALL_DIR}#" < ./freebsd/osirismd.in > ${DEST}.tmp
        ${SED} "s#@OSIRISDIR@#${OSIRIS_DIR}#" < ${DEST}.tmp > ${DEST}
        ${CHMOD} 555 ${DEST}
        echo "==> installed rc startup script: ${DEST}"

        ${RM} ${DEST}.tmp

        EXISTS=`grep osirismd /etc/rc.conf`
        if [ "${EXISTS}" = "" ]; then
            echo "osirismd_enable=\"YES\"" >> /etc/rc.conf
            echo "==> updated: /etc/rc.conf --> osirismd_enable=YES"
        fi
    fi
    ;;

NetBSD)

    echo ${RC_DESC}

    if [ -f ./osirisd ]; then
        DEST=/etc/rc.d/osirisd
        ${SED} "s#@INSTALLDIR@#${INSTALL_DIR}#" < ./netbsd/osirisd.in > ${DEST}.tmp
        ${SED} "s#@OSIRISDIR@#${OSIRIS_DIR}#" < ${DEST}.tmp > ${DEST}
        ${CHMOD} 555 ${DEST}
        echo "==> installed rc startup script: ${DEST}"

        ${RM} ${DEST}.tmp

        EXISTS=`grep osirisd /etc/rc.conf`
        if [ "${EXISTS}" = "" ]; then
            echo "osirisd_enable=\"YES\"" >> /etc/rc.conf
            echo "==> updated: /etc/rc.conf --> osirisd_enable=YES"
        fi
    fi

    if [ $INSTALL_OSIRISM != 0 -a -f ./osirismd ]; then
        DEST=/etc/rc.d/osirismd
        ${SED} "s#@INSTALLDIR@#${INSTALL_DIR}#" < ./netbsd/osirismd.in > ${DEST}.tmp
        ${SED} "s#@OSIRISDIR@#${OSIRIS_DIR}#" < ${DEST}.tmp > ${DEST}
        ${CHMOD} 555 ${DEST}
        echo "==> installed rc startup script: ${DEST}"

        ${RM} ${DEST}.tmp

        EXISTS=`grep osirismd /etc/rc.conf`
        if [ "${EXISTS}" = "" ]; then
            echo "osirismd_enable=\"YES\"" >> /etc/rc.conf
            echo "==> updated: /etc/rc.conf --> osirismd_enable=YES"
        fi
    fi
    ;;

AIX*)

    echo ${RC_DESC}

   if [ -f ./osirisd ]; then
        DEST=/etc/rc.osirisd
        ${SED} "s#@INSTALLDIR@#${INSTALL_DIR}#" < ./aix/osirisd.in > ${DEST}.tmp
        ${SED} "s#@OSIRISDIR@#${OSIRIS_DIR}#" < ${DEST}.tmp > ${DEST}
        ${CHMOD} 555 ${DEST}
        echo "==> installed rc startup script: ${DEST}"

        ${RM} ${DEST}.tmp

        EXISTS=`grep osirisd /etc/rc.local`
        if [ "${EXISTS}" = "" ]; then
            echo "#start osiris scan agent" >> /etc/rc.local
            echo "/etc/rc.osirisd start" >> /etc/rc.local
            echo "==> updated: /etc/rc.local --> /etc/rc.osirisd"
        fi
    fi

    if [ $INSTALL_OSIRISM != 0 -a -f ./osirismd ]; then
        DEST=/etc/rc.osirismd
        ${SED} "s#@INSTALLDIR@#${INSTALL_DIR}#" < ./aix/osirismd.in > ${DEST}.tmp
        ${SED} "s#@OSIRISDIR@#${OSIRIS_DIR}#" < ${DEST}.tmp > ${DEST}
        ${CHMOD} 555 ${DEST}
        echo "==> installed rc startup script: ${DEST}"

        ${RM} ${DEST}.tmp
        EXISTS=`grep osirismd /etc/rc.local`

        if [ "${EXISTS}" = "" ]; then
            echo "#start osiris management console" >> /etc/rc.local
            echo "/etc/rc.osirismd start" >> /etc/rc.local
            echo "==> updated: /etc/rc.local --> /etc/rc.osirismd"
        fi
    fi

    ;;

SunOS*)

    echo ${RC_DESC}

    INIT_D=/etc/init.d/
    RC_D=/etc/rc2.d/

    if [ -f ./osirisd ]; then

    ${SED} "s#@INSTALLDIR@#${INSTALL_DIR}#" < ./sunos/osirisd.in > ${INIT_D}/osirisd.tmp
    ${SED} "s#@OSIRISDIR@#${OSIRIS_DIR}#" < ${INIT_D}/osirisd.tmp > ${INIT_D}/osirisd

        ${CHMOD} 555 ${INIT_D}/osirisd
        ${RM} ${INIT_D}/osirisd.tmp
        ${RM} -rf ${RC_D}/S95osirisd
        ${LN} -s ${INIT_D}/osirisd ${RC_D}/S95osirisd
    fi

    if [ $INSTALL_OSIRISM != 0 -a -f ./osirismd ]; then

        ${SED} "s#@INSTALLDIR@#${INSTALL_DIR}#" < ./sunos/osirismd.in > ${INIT_D}/osirismd.tmp
${SED} "s#@OSIRISDIR@#${OSIRIS_DIR}#" < ${INIT_D}/osirismd.tmp > ${INIT_D}/osirismd
        ${CHMOD} 555 ${INIT_D}/osirismd

        ${RM} ${INIT_D}/osirismd.tmp
        ${RM} -rf ${RC_D}/S95osirismd
        ${LN} -s ${INIT_D}/osirismd ${RC_D}/S95osirismd
    fi

    ;;
Darwin)

    # now add to hostconfig file if not there.

    EXISTS=`grep OSIRISSERVER /etc/hostconfig`
    if [ "${EXISTS}" = "" ]; then
        echo "OSIRISSERVER=-YES-" >> /etc/hostconfig
        echo "==> updated: /etc/hostconfig --> OSIRISSERVER=-YES-"
    fi

    # now create the startup item and install it.

    echo ${AGENT_DESC}

    DEST=/System/Library/StartupItems/Osiris/Osiris

    ${MKDIR} -p /System/Library/StartupItems/Osiris
    ${SED} "s#@INSTALLDIR@#${INSTALL_DIR}#" < ./darwin/Osiris.in > ${DEST}.tmp
    ${SED} "s#@OSIRISDIR@#${OSIRIS_DIR}#" < ${DEST}.tmp > ${DEST}

    ${CP} ./darwin/StartupParameters.plist /System/Library/StartupItems/Osiris/
    ${RM} ${DEST}.tmp
    ${CHMOD} 755 ${DEST}

    echo "==> installed ${DEST}"

    ;;
*)
    echo "unrecognized host type, no startup options installed for "
    echo "the osiris agent/console, you will need to set this up "
    echo "by hand."
    ;;
esac
}


# ---------------------------------------------------------------------------
# Call installer functions.
# ---------------------------------------------------------------------------

 # look for interactive mode argument.

if [ -z "${1}" ] ; then
    INTERACTIVE=1
else
    INTERACTIVE=0
fi

# Change behaviour if we are creating packages.
if [ -n "$DESTDIR" ]; then
    PACKAGE_MODE=1
    INTERACTIVE=0
fi

pre_install
create_users_and_groups
prompts
copy_binaries
create_startup_scripts
set_permissions
post_install

exit 0
