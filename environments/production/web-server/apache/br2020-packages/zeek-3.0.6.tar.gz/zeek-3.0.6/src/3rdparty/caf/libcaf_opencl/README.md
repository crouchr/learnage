OpenCL Actors
=============

This module eases the use of OpenCL with CAF. See our [Wiki page](https://github.com/actor-framework/actor-framework/wiki/OpenCL-Actors) for details.
