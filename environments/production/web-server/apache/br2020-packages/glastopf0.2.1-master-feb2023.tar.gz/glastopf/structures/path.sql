CREATE TABLE IF NOT EXISTS `path` (
  `id` int(11) NOT NULL auto_increment,
  `vicpath` varchar(255) NOT NULL default '',
  `attime` datetime NOT NULL default '0000-00-00 00:00:00',
  `count` int(11) NOT NULL default '1',
  `lastseen` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `vicpath` (`vicpath`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=latin1;