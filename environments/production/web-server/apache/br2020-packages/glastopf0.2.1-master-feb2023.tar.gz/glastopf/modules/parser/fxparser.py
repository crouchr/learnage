import re
import cgi
import random

def parse(line):
    """ Parses FeeLCoMz IDs. """
    # Extracting the ID
    if re.search("ID",line) and not re.search("UID",line):
        line = cgi.escape(line.partition("\"")[2].rpartition("\"")[0]
                          .replace("\",\"",": ").replace("\".\"","")) + "<br>"
        return line
    # SaveMode response
    elif re.search("SAFE",line):
        line = "SAFE: OFF<br>"
        return line
    # Operating system response
    elif re.search("OS",line):
        line = "OS: Linux<br>"
        return line
    # Uname response
    elif re.search("UNAME",line):
        uname = ["Linux debian 2.6.8 Tue Dec 12 12:58:25 UTC 2007 i686 " \
                 "GNU/Linux","Linux my.leetserver.com 2.6.18-6-k7 #1 SMP " \
                 "Fri Jun 6 22:56:53 UTC 2008 i686 GNU/Linux"]
        line = "UNAME: " + random.choice(uname) + "<br>"
        return line
    # Empty server response
    elif re.search("SERVER",line):
        line = "SERVER: <br>"
        return line
    # User is root
    elif re.search("USER",line):
        line = "USER: root<br>"
        return line
    # Random UIG and GID
    elif re.search("UID",line):
        id = str(random.randint(30,70))
        uid = random.choice(["www-data","webserver","server","user","apache",
                             "www","data"])
        line = "UID: uid=" + id + "(" + uid + ") gid=" + id + "(" + uid + \
                ") groups=" + id + "(" + uid + ")<br>"
        return line
    # Webroot
    elif re.search("DIR",line):
        dir = ["/var/www/httpdocs","/var/www/server","/var/www/",
               "/var/www/http","/var/www/webserver"]
        line = "DIR: " + random.choice(dir) + "<br>"
        return line
    # Permission set to read and write
    elif re.search("PERM",line):
        line = "PERM: [RW]<br>"
        return line
    # Total random disk stats
    elif re.search("HDD",line):
        used = random.randint(30,120)
        free = random.randint(30,70)
        total = used + free
        line = "HDD: Used: " + str(used) + " GB Free: " + str(free) + \
                " GB Total: " + str(total) + " GB<br>"
        return line
    # Empty disfunc response
    elif re.search("DISFUNC",line):
        line = "DISFUNC: <br>"
        return line
    else:
        if re.search("<br>",line):
            line.replace("<br>","\n")
        return cgi.escape(line)