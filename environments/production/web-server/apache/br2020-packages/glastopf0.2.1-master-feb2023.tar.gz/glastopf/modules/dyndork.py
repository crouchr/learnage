import ConfigParser
import logger
import MySQLdb
import threading
import time

from os import sep

config = ConfigParser.ConfigParser()
config.read("conf/glastopf.cfg")

dyndork_opts = {
    "dyndork" : config.get("dyndork", "dyndork"),
    "dorktime" : config.get("dyndork", "dorktime")
    }

mysql_opts = {
    "host" : config.get("mysql", "host"),
    "port" : config.get("mysql", "port"),
    "user" : config.get("mysql", "user"),
    "pass" : config.get("mysql", "pass"),
    "db" : config.get("mysql", "db")
    }

def genlist():
    try:
        # Connect to the MySQL Server
        mysql = MySQLdb.connect(mysql_opts["host"],
                                mysql_opts["user"],
                                mysql_opts["pass"],
                                mysql_opts["db"],
                                int(mysql_opts["port"]))
        mysql.threadsafety = 2
        cursor = mysql.cursor()
        # Query to get all paths from the database
        cursor.execute("""
            SELECT vicpath FROM path;
            """
            )
        return cursor
    except MySQLdb.Error, e:
        print "Error %d: %s" % (e.args[0], e.args[1])
        cursor = ""
        return cursor

def dyndorkthread():
    while True:
        try:
            try:
                if dyndork_opts["dorktime"][-1] == "h":
                    schneewittchen = int(dyndork_opts["dorktime"][0:-1])*60*60
                elif dyndork_opts["dorktime"][-1] == "m":
                    schneewittchen = int(dyndork_opts["dorktime"][0:-1])*60
                else:
                    schneewittchen = 2*60*60
                # Connect to the MySQL Server
                mysql = MySQLdb.connect(mysql_opts["host"],
                                        mysql_opts["user"],
                                        mysql_opts["pass"],
                                        mysql_opts["db"],
                                        int(mysql_opts["port"]))
                mysql.threadsafety = 2
                cursor = mysql.cursor()
                #Query to get all dorks from the database
                cursor.execute("""
                    SELECT vicpath FROM path;
                    """
                    )
                dyndorks = open("res" +  sep + "dyndorks", 'w+')
                for dork in cursor:
                    # Write all dorks to file
                    dyndorks.write(dork[0] + " <br />" + "\n")
                dyndorks.close()
                logger.writelog("Dynamic googledorks list written to disk","info")
                time.sleep(schneewittchen)
            except MySQLdb.Error, e:
                print "Error %d: %s" % (e.args[0], e.args[1])
                print "MySQL error while trying to generate the dynamic dork list!"
                time.sleep(schneewittchen)
        except KeyboardInterrupt:
            break

if dyndork_opts["dyndork"] == "True":          
    print "Dynamic dork list module loaded"
    time.sleep(1)
    if dyndork_opts["dorktime"] != "live":
        dyndorkthread = threading.Thread(target=dyndorkthread)
        dyndorkthread.start()