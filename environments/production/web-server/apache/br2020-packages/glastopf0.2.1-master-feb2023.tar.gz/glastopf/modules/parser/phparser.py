import re
import urllib

import lineparser

def pecho(line):
    """Prepares the lines for the vulnerability emulator. """
    # Turns for example %22 into (
    line = urllib.unquote(line)
    # This was seen in FeeLCoMz files
    line = line.replace("\",\"","").replace("\".\"","")
    # Look for Safe Mode strings
    if re.search("Safe Mode",line):
        line = "Safe Mode of this Server is : SafemodeOFF<br>"
        return line
    # Handle multiple echos in one line
    elif line.count("echo") > 1:
        echolist = re.split("echo", line)
        line = ""
        for echopiece in echolist:
            if re.search("\"", echopiece):
                echopiece = echopiece.partition("\"")[2].partition("\"")[0]
                line += lineparser.parse(echopiece)
        return line
    # Single echo in one line handler
    else:
        if re.search("\"",line):
            line = line.partition("\"")[2].partition("\"")[0]
        line = lineparser.parse(line)
        return line

def parse(infile):
    
    # The response returned to the attacker
    response = []
    # List of all lines of a function
    functionlines = []
    # All lines containing echos outside of functions
    echolines = []
    # Indicates if we are currently inside or outside a function
    infunction = False
    # A dictionary containing line numbers and lines of a file 
    filedict = {}
    # A dictionary containing all founded functions
    functdict = {}
    
    # Splitting up the whole file in his lines
    if re.search("\\r", infile):
        file = infile.split("\r")
    elif re.search("\\n", infile):
        file = infile.split("\n")
    else:
        file = []
        file.append(infile)
    # Create the file dictionary
    # TODO: Currently the dictionary is unused, but we will use it later for more effective file parsing
    # The line number counter
    linenumber = 1
    for line in file:
        filedictentry = {linenumber : line}
        filedict.update(filedictentry)
        linenumber += 1
    # Check the file size and skip files with more than n lines
    if len(filedict) > 100:
        # TODO: Handle large files
        pass
    # Look for function definitions and store the functions into a list
    functnumber = 1
    for line in file:
        # The function definition pattern
        pattern = re.compile("\A" + r"\bfunction\b" + "\s\w*")
        if re.search(pattern, line):
            infunction = True
        if infunction == True:
            functionlines.append(line)
        # Looking for function end
        if re.search("}", line):
            infunction = False
            if functionlines:
                functdictentry = {functnumber : functionlines}
                functdict.update(functdictentry)
                functnumber += 1
            functionlines = []
            continue
        # Add echos from outside of functions
        if infunction == False and re.search("echo", line):
            echolines.append(line)
    # Parse echos which are not related to functions
    if echolines:
        for part in echolines:
            response.append(pecho(part))
    # Look for echos in functions
    if functdict:
        # Looping through all functions
        for function in functdict.values():
            # Looping through all parts of the function
            for part in function:
                # Look for echos in function definition
                if re.search("echo", part):
                    functionname = function[0].partition(" ")[2].partition("(")[0]
                    for line in file:
                        # Look for function calls in file
                        searchfor = functionname + "\(\""
                        try:
                            if functionname != "" and re.search(searchfor, line):
                                response.append(pecho(line))
                        except:
                            continue
    return response