def splashscreen():
    """The splash message when starting the Glastopf"""
    __author__ = "lukas rist"
    __version__ = "Version: 0.2.1".split()[1]
    
    print """
            __             __                ___
     .-----|  .---.-.-----|  |_.-----.-----.'  _|
     |  _  |  |  _  |__ --|   _|  _  |  _  |   _|
     |___  |__|___._|_____|____|_____|   __|__|
     |_____|by: %s           |__|
     Version: %s
        """ % (__author__, __version__)