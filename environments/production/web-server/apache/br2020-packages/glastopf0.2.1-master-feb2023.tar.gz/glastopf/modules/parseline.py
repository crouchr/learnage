import re
import sys
import time

sys.path.append("modules/parser")

import fxparser
import echoparser

print "Injected file parser module loaded"
time.sleep(1)

def pecho(line):
    """Searches keywords in lines from included files. """
    if re.search("Safe Mode",line):
        line = "Safe Mode of this Server is : SafemodeOFF<br>"
        return line
    elif line.count("echo") > 1:
        list = re.split("echo", line)
        line = ""
        for i in range(len(list)):
            if re.search("\"",list[i]):
                list[i] = list[i].partition("\"")[2]
                list[i] = list[i].partition("\"")[0]
            line += echoparser.parse(list[i])
        return line
    else:
        if re.search("fx\(",line):
            return fxparser.parse(line)
        else:    
            if re.search("\"",line):
                line = line.partition("\"")[2]
                line = line.partition("\"")[0]
            return echoparser.parse(line)