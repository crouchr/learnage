import re
import cgi
import random

from time import gmtime, strftime, sleep

print "Echo parser loaded"
sleep(1)

def parse(line):
    """Replaces the variables with information."""
    # Looking for uname string and answering with predefined systems
    if re.search("uname|Uname|Kernel",line):
        uname = ["Linux debian 2.6.8 Tue Dec 12 12:58:25 UTC 2007 i686 " \
                "GNU/Linux","Linux my.leetserver.com 2.6.18-6-k7 #1 " \
                "SMP Fri Jun 6 22:56:53 UTC 2008 i686 GNU/Linux"]
        line = cgi.escape(line.partition("$")[0]) + random.choice(uname) + \
                "<br>"
        return line
    # Answering every operating system request with linux
    elif re.search("os\:|OSTYPE|SySOs",line):
        line = cgi.escape(line.partition(":")[0]) + ": Linux<br>"
        return line
    # Generating a totally random uptime and load response
    elif re.search("\$up|uptime",line):
        line = cgi.escape(line.partition(" ")[0]) + " " + \
        strftime("%H:%M:%S", gmtime()) + " up " + str(random.randint(10,200)) \
        + " days, " + str(random.randint(10,24)) + ":" \
        + str(random.randint(10,59)) + ", " \
        + str(random.randint(0,2)) + " user, load average: 0." \
        + str(random.randint(0,70)) + ", 0." \
        + str(random.randint(10,50)) + ", 0." \
        + str(random.randint(10,20)) + "<br>"
        return line
    # The webserver user with random uid and gid
    elif re.search("\$id.|id\:|eseguicmd",line):
        id = str(random.randint(30,70))
        uid = random.choice(["www-data","webserver","server","user",
                             "apache","www","data"])
        line = cgi.escape(line.partition(" ")[0]) + " uid=" + id + "(" \
                + uid + ") gid=" \
                + id + "(" + uid + ") groups=" \
                + id + "(" + uid + ")<br>"
        return line
    # The webroot
    elif re.search("\$pwd.|pwd",line):
        dir = ["/var/www/httpdocs","/var/www/server","/var/www/",
               "/var/www/http","/var/www/webserver"]
        line = cgi.escape(line.partition(" ")[0]) + " " \
                + random.choice(dir) + "<br>"
        return line
    # Answering NONE to user requests
    elif re.search("\$usr.|user",line):
        line = cgi.escape(line.partition(" ")[0]) + " <br>"
        return line
    # PHP Version reponse
    elif re.search("\$php.|php.",line):
        phpv =["5.2.6","5.0.1","4.2.3"]
        line = cgi.escape(line.partition(" ")[0]) + " " \
                + random.choice(phpv) + "<br>"
        return line
    # Webserver software response
    elif re.search("\$sof.|SoftWare|software|sof",line):
        webserver = ["Apache/2.0.53 (Unix)","Apache/2.2.6 (Unix)"]
        line = cgi.escape(line.partition(":")[0]) + ": " \
        + random.choice(webserver) + "<br>"
        return line
    # Server name is empty
    elif re.search("\$name.|ServerName|srvname|server-name|name",line):
        line = cgi.escape(line.partition(" ")[0]) + " <br>"
        return line
    # Server address is empty
    elif re.search("\$ip.|ServerAddr|srvip|server-ip",line):
        line = cgi.escape(line.partition(" ")[0]) + " <br>"
        return line
    # Free disk space, could be a bit more generic
    elif re.search("\$free|free|Free",line):
        line = cgi.escape(line.partition(":")[0]) + ": 15.80 Gb<br>"
        return line
    # Used disk space, could be a bit more generic
    elif re.search("\$used|used",line):
        line = cgi.escape(line.partition(" ")[0]) + " 56.20 Gb<br>"
        return line
    # Total disk space, the "sum" from free + used
    elif re.search("\$all|total",line):
        line = cgi.escape(line.partition(" ")[0]) + " 72 Gb<br>"
        return line
    # curl version response
    elif re.search("\$cUrl|curl",line):
        line = cgi.escape(line.partition(" ")[0]) + " curl 7.12.1 " \
                "(i686-redhat-linux-gnu) libcurl/7.12.1 OpenSSL/0.9.7a " \
                "zlib/1.2.1.2 libidn/0.5.6 Protocols: ftp gopher telnet " \
                "dict ldap http file https ftps Features: GSS-Negotiate " \
                "IDN IPv6 Largefile NTLM SSL libz<br>"
        return line
    # FeeLCoMz specific response
    elif re.search("FeeL|CoMz",line):
        line = cgi.escape(line.partition("\"")[2].replace("\",\"",": ").replace("\".\"","").partition("\"")[0])
        return line
    else:
        # Replacing HTML line brakes with new lines
        if re.search("<br>",line):
            line = cgi.escape(line.replace("<br>","\n")) + "<br>"
        # If nothing matches, return the escaped line
        return line