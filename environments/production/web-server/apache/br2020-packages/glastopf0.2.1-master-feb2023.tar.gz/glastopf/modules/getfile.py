import hashlib
import os
import re
import time

import opener
import logger

from settings import options

print "File retrieving and saving module loaded"#
time.sleep(1)

def getter(self,file,method):
    """File handler.
    
    Gets a file, calculates the hash and saves it, if its new, to disk.
    If there is a URL in the file, we store it to download it later.
    """
    
    urllist = []
    # Creating md5hash
    try:
        filename = hashlib.md5(file).hexdigest()
    except:
        if options.verbose == True: print "md5 error"
        pass
    # Check if file exists
    if os.path.exists("files/" + method.lower() + os.sep + filename):
        logger.writelog("File %s already exists" % (filename),"info")
        print 'File ' + filename + ' already exists.'
    else:
        try:
            bot = open("files/" + method.lower() + os.sep + filename, 'w+')
            lines = file.split("\n")
            for line in lines:
                # Write new file to disk
                bot.write(line)
                # Look for urls in file
                if re.search("exec|passthru|system|shell_exec",line):
                    urllist.append(line)
            bot.close()
            logger.writelog("File %s written to disk" % (filename),"info")
            print 'New file stored: ' + filename
        except:
            if options.verbose == True: print "writing file to disk error"
            pass
        if len(urllist):
            # Download the url's in urllist
            opener.geturl(self,urllist)
    return filename