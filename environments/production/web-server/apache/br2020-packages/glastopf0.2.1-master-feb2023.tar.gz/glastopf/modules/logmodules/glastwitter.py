import datetime
import urllib
import ConfigParser
import threading
import time
import MySQLdb

from settings import options

class Twitter():
    """The Twitter class"""
    def __init__(self):
        config = ConfigParser.ConfigParser()
        config.read("conf/glastopf.cfg")
        self.twitter_opts = {
            "username" : config.get("twitter","username"),
            "password" : config.get("twitter","password")
            }

        self.mysql_opts = {
            "host" : config.get("mysql", "host"),
            "port" : config.get("mysql", "port"),
            "user" : config.get("mysql", "user"),
            "pass" : config.get("mysql", "pass"),
            "db" : config.get("mysql", "db")
            }

        self.username = self.twitter_opts["username"]
        self.password = self.twitter_opts["password"]

    def tweet(self, message):
        data = urllib.urlencode({"status" : message})
        try:
            urllib.urlopen("http://%s:%s@twitter.com/statuses/update.xml"
                                 % (self.username,self.password), data)
            if options.verbose == True: print "Message submitted to Twitter!"
        except:
            print "Twitter connection error!"
            pass

    def dbconnect(self):
        try:
            mysql = MySQLdb.connect(
                self.mysql_opts["host"],
                self.mysql_opts["user"],
                self.mysql_opts["pass"],
                self.mysql_opts["db"],
                int(self.mysql_opts["port"])
                )
        except MySQLdb.Error, e:
            print "Twitter Error %d: %s" % (e.args[0], e.args[1])
            pass
        mysql.threadsafety = 2
        return mysql

    def squawk_ips(self):
        # Unique IPs in the database
        mysql = self.dbconnect()
        cursor = mysql.cursor()
        sql1 = """
                SELECT ip FROM log
                GROUP BY ip
                """
        cursor.execute(sql1)
        message = "There are %d non-recurring IPs in the database." % (cursor.rowcount,)
        self.tweet(message)
        mysql.close()

    def squawk_paths(self):
        # Unique google dorks in the database
        mysql = self.dbconnect()
        cursor = mysql.cursor()
        sql2 = """
                SELECT vicpath FROM path
                """
        cursor.execute(sql2)
        message = "There are %d non-recurring " \
                  "vulnerable paths (google dorks) in the database." \
                  % (cursor.rowcount,)
        self.tweet(message)
        mysql.close()

    def squawk_attacks(self):
        # Attacks in the last 30 minutes
        lasttime = (datetime.datetime.now() - datetime.timedelta(minutes=30)).strftime("%Y-%m-%d %X")
        mysql = self.dbconnect()
        cursor = mysql.cursor()
        sql3 = """
                SELECT id FROM log
                WHERE attime > %s
                """
        try:
            cursor.execute(sql3, (lasttime,))
        except MySQLdb.Error, e:
            print "Twitter Error %d: %s" % (e.args[0], e.args[1])
        message = "Got %d attacks in the last 30 minutes!" % (cursor.rowcount,)
        self.tweet(message)
        mysql.close()


class Timed():

    def __init__(self, twitter):
        self.twitter = twitter

    def action(self):
        if not self.canceled:
            self.twitter.squawk_attacks()
            time.sleep(1)
            self.twitter.squawk_paths()
            time.sleep(1)
            self.twitter.squawk_ips()
            self.start_timer()

    def start_timer(self):
        self.canceled = False
        self.t = threading.Timer(1800, self.action)
        self.t.start()

    def stop_timer(self):
        self.t.cancel()
        self.canceled = True


config = ConfigParser.ConfigParser()
config.read("conf/glastopf.cfg")

logtwitter = config.get("log","logtwitter")
if logtwitter == "True":
    print "Twitter logging module loaded"
    time.sleep(1)
    twitter = Twitter()
    timed = Timed(twitter)
    timed.start_timer()

    def cancelit():
        timed.stop_timer()
else:
    def cancelit():
		pass