import ConfigParser
import datetime
import MySQLdb
import socket
import threading
import time
import types

from settings import options

# Read the configuration file
config = ConfigParser.ConfigParser()
config.read("conf/glastopf.cfg")

# MySQl connection settings
mysql_opts = {
    "host" : config.get("mysql", "host"),
    "port" : config.get("mysql", "port"),
    "user" : config.get("mysql", "user"),
    "pass" : config.get("mysql", "pass"),
    "db" : config.get("mysql", "db")
    }

# IRC connection settings
irc_opts = {
    "ircserver" : config.get("irc","ircserver"),
    "ircport" : int(config.get("irc","ircport")),
    "nick" : config.get("irc","nick"),
    "ident" : config.get("irc","ident"),
    "realname" : config.get("irc","realname"),
    "channel" : config.get("irc","channel")
    }

class ircbot():
    """IRC client class"""
    def __init__(self):
        self.ircserver=irc_opts["ircserver"]
        self.ircport=irc_opts["ircport"]
        self.nick=irc_opts["nick"]
        self.ident=irc_opts["ident"]
        self.realname=irc_opts["realname"]
        self.channel=irc_opts["channel"]
        self.joined = False
        # Create socket
        self.s=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Connect socket
        try:
            self.s.connect((self.ircserver, self.ircport))
            if options.verbose == True: print "Successful connected to " \
                    "the IRC Server"
        except:
            print "Error while connecting to the IRC server!"
        # Set nick
        self.s.send("NICK %s\r\n" % self.nick)
        # Set user
        self.s.send("USER %s %s bla :%s\r\n" % (
                                                self.ident,
                                                self.ircserver,
                                                self.realname)
                                                )

    def getstats(self, request, timerange):
        """Gets the data from the database"""
        try:
            # Connect to MySQL database
            mysql = MySQLdb.connect(
                mysql_opts["host"],
                mysql_opts["user"],
                mysql_opts["pass"],
                mysql_opts["db"],
                int(mysql_opts["port"])
                )
            mysql.threadsafety = 2 
            cursor = mysql.cursor()
            # Query to get all attacks in a specific period
            sql1 = """
                    SELECT id FROM log 
                    WHERE attime > %s
                    """
            # Query to get all unique IPs from the database
            sql2 = """
                    SELECT ip FROM log 
                    GROUP BY ip
                    """
            # Query to get all unique paths from the vulnpath database
            sql3 = """
                    SELECT vicpath FROM path 
                    """
        except MySQLdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            pass
        # Create the string for the response
        try:
            if request == "attacks" and type(timerange) == types.IntType and \
                    timerange <= 1440:
                fromtime = (datetime.datetime.now() - 
                            datetime.timedelta(minutes=timerange)).strftime("%Y-%m-%d %X")
                cursor.execute(sql1, (fromtime))
                message = "Got " + str(cursor.rowcount) + " attacks in the last " \
                        + str(timerange) + " minutes!"
            elif request == "ips":
                cursor.execute(sql2)
                message = "There are " + str(cursor.rowcount) + \
                        " non-recurring IPs in the database."
            elif request == "paths":
                cursor.execute(sql3)
                message = "There are " + str(cursor.rowcount) + \
                        " non-recurring vulnerable paths (googledorks) in the database."
            else:
                message = "Try .help :)"
        except MySQLdb.Error, e:
                print "Error %d: %s" % (e.args[0], e.args[1])
                message = "Error %d: %s" % (e.args[0], e.args[1])
                pass
        return message
    
    gets = staticmethod(getstats)
    
    def sendmessage(self, line, message):
        """Sends a message to the requester"""
        # Get the requester
        requester = line[0].partition(":")[2].partition("!")[0]
        # Send the message
        self.s.send("PRIVMSG %s :%s\r\n" % (requester, message))
        if options.verbose == True: print "The IRC logging bot has " \
                "answered a request."
                
    sendm = staticmethod(sendmessage)
        
    def ircthread(self):
        """IRC client
        
        This function joins the irc channel and reads and processes incoming
        data on the socket. 
        
        """
        readbuffer = ""
        # The requested timerange
        timerange = ""
        # The user who has requested information
        while True:
            try:
                readbuffer=readbuffer+self.s.recv(1024)
                temp=readbuffer.split("\n")
                readbuffer=temp.pop()
                for line in temp:
                    line=line.rstrip()
                    line=line.split()
                    # The IRC table tennis 
                    if(line[0]=="PING"):
                        self.s.send("PONG %s\r\n" % line[1])
                    # If connected, join the channel
                    if line[1] == "001":
                        try:
                            self.s.send("JOIN %s\r\n" % self.channel)
                        except:
                            print "Error while trying to join a IRC Channel"
                    if line[1] == "366":
                        if options.verbose == True: print \
                                "IRC Channel successful joined."
                        self.joined = True
                    if len(line) > 3 and line[3] == ":.help":
                        message = "Help: \n" \
                                ".help: This message \n" \
                                ".info: Get info about the bot \n" \
                                ".attacks n: Get the number of unique attacks in the last n minutes \n" \
                                ".ips: non-recurring IPs in the database \n" \
                                ".paths: non-recurring vulnerable paths (googledorks) in the database"
                        message = message.split("\n")
                        print message
                        for msgpart in message:
                            ircbot.sendm(self, line, msgpart)
                    if len(line) > 3 and line[3] == ":.info":
                        message = "Glastopf IRC logging bot. " \
                                "Please don't touch me!"
                        ircbot.sendm(self, line, message)
                    if len(line) > 3 and line[3] == ":.attacks":
                        request = "attacks"
                        timerange = line[4]
                        if timerange != "":
                            try:
                                timerange = int(timerange)
                            except:
                                timerange = 30
                        else:
                            timerange = 30
                        message = ircbot.gets(self, request, timerange)
                        ircbot.sendm(self, line, message)
                    if len(line) > 3 and line[3] == ":.ips":
                        request = "ips"
                        message = ircbot.gets(self, request, timerange)
                        ircbot.sendm(self, line, message)
                    if len(line) > 3 and line[3] == ":.paths":
                        request = "paths"
                        message = ircbot.gets(self, request, timerange)
                        ircbot.sendm(self, line, message)
            except KeyboardInterrupt:
                break

bot = ircbot()
# Create and start IRC bot thread
ircthread = threading.Thread(target=bot.ircthread)
ircthread.start()
print "IRC logging module loaded"
time.sleep(1)