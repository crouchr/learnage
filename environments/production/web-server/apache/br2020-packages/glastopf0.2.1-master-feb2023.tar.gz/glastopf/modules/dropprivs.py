import ConfigParser


def drop_privs(new_uid='nobody', new_gid='nogroup'):
    
    config = ConfigParser.ConfigParser()
    config.read("conf/glastopf.cfg")
    log_opts = {
        "system" : config.get("log","system")
        }
    if log_opts["system"] == "unix":
        import os
        import pwd
        import grp
        starting_uid = os.getuid()
        starting_gid = os.getgid()
        
        if os.getuid() != 0:
            return
    
        # If we started as root, drop privs and become the specified user/group
        if starting_uid == 0:
    
            # Get the uid/gid from the name
            run_uid = pwd.getpwnam(new_uid)[2]
            run_gid = grp.getgrnam(new_gid)[2]
    
            # Try setting the new owner/uid/gid
            try:
                # Changing folder permissions
                for folder in os.listdir("files"):
                    os.chown("files" + os.sep + folder, run_uid, run_gid)
                    os.chown("log", run_uid, run_gid)
                    os.chown("res" + os.sep + "dyndorks", run_uid, run_gid)
                print "Changed files folder owner from: %s to %s" % (starting_uid, run_uid)
            except OSError, e:
                print "Could not set new group: %s" % (e)
            try:
                # Dropping gid permissions
                os.setgid(run_gid)
                print "Changed uid from: %s to %s" % (starting_gid, run_gid)
            except OSError, e:
                print "Could not set new group: %s" % (e)
    
            try:
                # Dropping uid permissions
                os.setuid(run_uid)
                print "Changed uid from: %s to %s" % (starting_uid, run_uid)
            except OSError, e:
                print "Could not set new user: %s" % (e)
    
            new_umask = 077
            # Changing umask
            umask = os.umask(new_umask)
            print "Changed umask from: %s to %s" % (oct(umask), oct(new_umask))
    else:
        print "Running with root privileges!"