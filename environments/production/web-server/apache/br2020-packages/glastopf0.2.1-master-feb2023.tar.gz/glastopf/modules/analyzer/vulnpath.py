import urlparse
import urllib
import cgi
import ConfigParser
import MySQLdb
import re
import time

from os import sep, pardir

from settings import options

config = ConfigParser.ConfigParser()
config.read("conf/glastopf.cfg")

mysql_opts = {
    "host" : config.get("mysql", "host"),
    "port" : config.get("mysql", "port"),
    "user" : config.get("mysql", "user"),
    "pass" : config.get("mysql", "pass"),
    "db" : config.get("mysql", "db")
    }

print "Vulnerability path handling module loaded"
time.sleep(1)


def clean_path(url):
    # Turns for example %22 into (
    url = urllib.unquote(url)
    protocol_pattern = re.compile("=https|=http|=ftp")
    if re.search(protocol_pattern, url) and url != "":
        # Match the pattern and extract the path
        matched_protocol = re.findall(protocol_pattern, url)
        vicurl = url.partition(str(matched_protocol[0]))[0]
    elif url != "":
        # Use this for other patterns
        vicurl = url
    else:
        # vicurl None if no path found
        vicurl = "None"
    # Replace // with /
    slash_pattern = re.compile(re.escape("//"))
    while True:
        if re.search(slash_pattern, vicurl):
            vicurl = vicurl.replace("//", "/")
        else:
            break
    return vicurl

def prozesspath(url):
    """This function analyzes and stores the vulnerability path."""
    vicurl = clean_path(url)
    attime = time.strftime("%Y-%m-%d %X")
    if vicurl != "None":
        try:
            # Connect to the MySQL Server
            mysql = MySQLdb.connect(
                                    mysql_opts["host"],
                                    mysql_opts["user"],
                                    mysql_opts["pass"],
                                    mysql_opts["db"],
                                    int(mysql_opts["port"])
                                    )
            mysql.threadsafety = 2
            cursor = mysql.cursor()
            # Query to check if the path isn't already in the database
            sql1 = """
                    SELECT vicpath FROM path
                    WHERE vicpath = %s
                    """
            # Execute queries
            if cursor.execute(sql1, (vicurl)) == False:
                # Query to write new paths into database
                sql2 = """
                    INSERT INTO path (vicpath, attime, lastseen) 
                    VALUES (%s, %s, %s)
                    """
                cursor.execute(sql2, (vicurl, attime, attime))
                if options.verbose == True: print "Path: %s written into " \
                        "database" % (vicurl)
            else:
                # Query if the path is already in the database
                sql3 = """
                        UPDATE path
                        SET count = count + 1, lastseen = %s
                        WHERE vicpath = %s
                        """
                cursor.execute(sql3, (attime, vicurl))
                if options.verbose == True: print "Path: %s already in " \
                        "database" % (vicurl)
        except MySQLdb.Error, e:
            print "Error %d: %s" % (e.args[0], e.args[1])
            pass