import time
import ConfigParser
import re
import sys

sys.path.append("plugins")

from settings import options

config = ConfigParser.ConfigParser()
config.read("conf/glastopf.cfg")

plugins_opts = {
    "dataplugins": config.get("plugins","dataplugins")
    }

datapluginlist = []

# Import the plugins
if plugins_opts["dataplugins"]:
    dataplugins = plugins_opts["dataplugins"].strip().split(",")
    for plugin in dataplugins:
        pluginname = plugin.strip().partition(".py")[0]
        importname = __import__(pluginname)
        datapluginlist.append(importname)
    print "Data handling plug-ins loaded"
    time.sleep(1)

def handle(self,id="",filename="",url="",method=""):
    """Writes data into the database."""
    # Gets the attacker domain
    domain = self.address_string()
    # Attacker ip
    sourceip = self.client_address[0] #attacker ip
    sourceport = str(self.client_address[1])
    destip = self.connection.getsockname()[0]
    destport = str(self.connection.getsockname()[1])
    # Time of attack
    attime = time.strftime("%Y-%m-%d %X")
    # Honeypot timezone
    tzo = time.timezone / 60 / 60
    tz = str(tzo)
    if tzo < 0:
        tz = tz.partition("-")[2]
        tzone = "-"
    elif re.search("\+", tz):
        tz = tz.partition("+")[2]
        tzone = "+"
    else:
        tzone = "+"
    if tzo < 0:
        tzo *= -1
    if tzo < 10:
        tzone = tzone + "0" + tz + "00"
    else:
        tzone = tzone + tz + "00"
    # Attacker request path
    req = self.path
    # Attacker referrer
    ref = self.headers.get('referer', '') #attacker referer
    ac = self.headers.get('accept', '') #accepts
    accha = self.headers.get('accept-charset', '') #accepts charset
    acla = self.headers.get('accept-language', '') #accepts language
    con = self.headers.get('connection', '') #attacker connection
    keep = self.headers.get('keep-alive', '') #keep alive
    agent = self.headers.get("user-agent", "") # Attacker user agent
    header = self.headers #full header information
    # Intermediate protocols and recipients between the
    # user agent and the server
    via = self.headers.get("via", "")
    forwardedfor = self.headers.get("Forwarded-For", "")
    xforwardedfor = self.headers.get("X-Forwarded-For", "")
    xvia = self.headers.get("x-via", "")
    onspdusr =  self.headers.get("X-SlipStream-Username", "")
    # Attacked host
    host = self.headers.get("host", "")
    # Host of the included file
    if (re.search("https://",req)):
        victim = req.partition("https://")[2].partition("/")[0]
    elif (re.search("http://", req)):
        victim = req.partition("http://")[2].partition("/")[0]
    else:
        victim = ""
    if (re.search("www\.",victim)): 
        victim = victim.partition("www.")[2]
    if (id == "error"):
        alive = "0"
    else: 
        alive = "1"
    if options.verbose == True:
        print "Full attacker header", header

    # Send all data to the plugins
    if datapluginlist:
        for plugin in datapluginlist:
            data = method, domain, sourceip, sourceport, destip, destport, attime, tzone, req, ref, agent, via, forwardedfor, xforwardedfor, xvia, onspdusr, host, alive, filename, victim, self
            plugin.dbwrite(data)
    # rch added
    #return header        