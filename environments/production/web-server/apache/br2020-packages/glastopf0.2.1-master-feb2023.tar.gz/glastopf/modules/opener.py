import urllib2
import socket
import re

from os import curdir, sep
from time import gmtime, strftime, sleep

import logger
import getfile
import datahandler

# Timeout in seconds
timeout = 10
socket.setdefaulttimeout(timeout)

print "URL handling module loaded"
sleep(1)

def openhandler(req):
    """Handler to open URLs."""
    handler = urllib2.build_opener()
    return handler.open(req)
    

def openurl(url,self):
    """Opens a URL with modified exception handler."""
    try:
        req = urllib2.Request(url)
        id = openhandler(req)
        logger.writelog("%s successfully opened" % (url),"info")
    except IOError, e:
        if hasattr(e, 'reason'):
            logger.writelog("Failed to reach the server: %s Reason: %s" % 
                            (url,e.reason),"info")
            f = open(curdir + sep + "res" + sep + "echo.txt")
            self.wfile.write(f.read())
            f.close()
            print 'We failed to reach a server.'
            print 'Reason: ', e.reason
            id = "error"
        elif hasattr(e, 'code'):
            logger.writelog("Couldn\'t fulfill the request: %s Reason: %s" % 
                            (url,e.code),"info")
            f = open(curdir + sep + "res" + sep + "echo.txt")
            self.wfile.write(f.read())
            f.close()
            print 'The server couldn\'t fulfill the request.'
            print 'Error code: ', e.code
            id = "error"
    return id

def geturl(self,urllist):
    """Downloads a URL from urllist."""
    url,id,filename,method = "", "", "", "GET"
    # Get only unique entries in urllist
    urls = []
    for url in urllist:
        if re.search("\;perl",url):
            url = "http://" + url.partition("http://")[2]
            url = url.rpartition(";perl")[0]
            urls.append(url)
        elif re.search("http://",url):
            url = "http://" + url.partition("http://")[2]
            url = url.rpartition("txt")[0] + "txt"
            urls.append(url)
        else:
            pass
    urls = list(set(urls))
    if len(urls):
        for url in urls:
            try:
                req = urllib2.Request(url)
                file = openhandler(req)
                file = file.read()
                filename = getfile.getter(self,file,method)
            except:
                pass
            if len(filename):
                datahandler.handle(self,id,filename,url,method)
                #print "rch - header = " + a.__str__()	# rch
    else:
        pass