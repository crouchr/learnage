import ConfigParser
import socket
import re
import time
import os

config = ConfigParser.ConfigParser()
config.read("conf/glastopf.cfg")
misc_opts = {
    'whoisserver':    config.get("misc","whoisserver")
    }

print "Whois module loaded"
time.sleep(1)

def mntwhois(domainname, whoisserver = 
             misc_opts['whoisserver'], whoisport = 43):
    """ A function to get the responsible ISP. """
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # Connect to the whois server
    try:
        s.connect((whoisserver, whoisport))
    except IOError, e:
        print e
        pass
    s.send("-r %s \n\n" % domainname)
    content = ""
    while 1:
        data = s.recv(2048)
        if not data: break
        content = content + data
    s.close()
    lines = content.split("\n")
    mntby = []
    for line in lines:
        # Look for the mnt-by entries
        if re.search("mnt-by",line):
            mntline = line.partition(" ")[2].lstrip()
            mntby.append(mntline)
    separator = " "
    mntby = list(set(mntby))
    mntby = separator.join(mntby)
    if mntby == "":
        mntby = "none"
    return mntby

def mailwhois(domainname):
    data = os.popen("whois %s" % domainname).read()
    lines = data.split("\n")
    mailadd = []
    for line in lines:
        if re.search("@",line):
            mailline = line.rpartition(" ")[2].lstrip()
            mailadd.append(mailline)
    separator = " "
    mailadd = list(set(mailadd))
    mailadd = separator.join(mailadd)
    if mailadd == "":
        mailadd = "none"
    return mailadd