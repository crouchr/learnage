import ConfigParser
import logging
import logging.handlers
import sys
import time

sys.path.append("modules/logmodules")

config = ConfigParser.ConfigParser()
config.read("conf/glastopf.cfg")

log_opts = {
    "logircbot": config.get("log","logircbot").capitalize(),
    "logtwitter": config.get("log","logtwitter").capitalize(),
    "level": config.get("log","level"),
    "system": config.get("log","system"),
    "size": config.get("log","size"),
    "count": config.get("log","count")
    }

if log_opts["logircbot"] == "True":
    import logircbot
if log_opts["logtwitter"] == "True":
    import glastwitter

logfile = 'log/glastopf.log'
LEVELS = {'debug': logging.DEBUG,
          'info': logging.INFO,
          'warning': logging.WARNING,
          'error': logging.ERROR,
          'critical': logging.CRITICAL}

level_name = log_opts['level']
level = LEVELS.get(level_name, logging.NOTSET)
FORMAT = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
mylogger = logging.getLogger('GlastopfLogger')
mylogger.setLevel(level)
# Add the log message handler to the logger
if log_opts['system'] == "unix":
    handler = logging.handlers.RotatingFileHandler(logfile, 
                                    maxBytes=int(log_opts['size']), 
                                    backupCount=int(log_opts['count']))
    handler.setFormatter(FORMAT)
    mylogger.addHandler(handler)
    print "Logging modules loaded"
    time.sleep(1)
elif log_opts['system'] == "win":
    handler = logging.FileHandler(logfile)
    handler.setFormatter(FORMAT)
    mylogger.addHandler(handler)
    print "Logging modules loaded"
    time.sleep(1)
else:
    print "wrong system set in glastopf.cfg"

def writelog(message,lvl):
    """Logs messages to a logfile."""
    getattr(mylogger,lvl)(message)