import base64
import re
import time

import getfile
import logger

from settings import options

print "Base64 decode module loaded"
time.sleep(1)

def debase64(self,line):
    """ Decodes base64 encoded strings in received files """
    method = "base64"
    if re.search("\"",line):
        line = line.partition("\"")[2]
        line = line.partition("\"")[0]
    # Decode the string
    line = base64.decodestring(line)
    if options.verbose == True: print "Base64 string in file from %s with " \
            "request: %s decoded" % (self.client_address[0],self.path)
    logger.writelog("Base64 string in file from %s with request: %s decoded" %
            (self.client_address[0],self.path),"info")
    # Save decoded string to disk
    getfile.getter(self,line,method)