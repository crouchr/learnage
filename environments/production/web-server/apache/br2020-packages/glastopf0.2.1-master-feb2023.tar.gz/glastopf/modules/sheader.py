from time import gmtime, strftime

def pheader(self):
    """Creates the response header."""
    try:
        header = "HTTP/1.1 200 OK\nDate: " + \
        strftime("%a, %d %b %Y %H:%M:%S GMT", gmtime())+ \
                "\nServer: Apache/2.2.6 (Unix)\nContent-Type: " \
                "text/html\nAccept-Ranges: bytes\nLast-Modified: " \
                "Tue, 15 Jul 2008 16:46:59 GMT\n"
        self.wfile.write(header)
        self.end_headers()
    except :
        pass