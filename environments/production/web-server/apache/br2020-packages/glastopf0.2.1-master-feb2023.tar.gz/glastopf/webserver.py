#Glastopf, a web honeypot
#
#Copyright (C) 2008-2009 Lukas Rist
#
#This program is free software; you can redistribute it and/or modify it under
#the terms of the GNU General Public License as published by the Free Software
#Foundation; either version 3 of the License, or (at your option) any later
#version.
#
#This program is distributed in the hope that it will be useful, but WITHOUT
#ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
#FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License along with
#this program; if not, see <http://www.gnu.org/licenses/>.

import sys
sys.path.append("modules")

import splash
splash.splashscreen()
from settings import options

import cgi
import re
import threading
import time
import ConfigParser

from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
from SocketServer import ThreadingMixIn
from os import curdir, sep, listdir

print "== Loading modules... =="
sys.path.append("modules/analyzer")
sys.path.append("modules/parser")
sys.path.append("modules/logmodules")

import logger
import datahandler
import dropprivs
import dyndork
import vulnpath
import base
import parseline
import phparser
import getfile
import opener
import sheader
from glastwitter import cancelit

class Handler(BaseHTTPRequestHandler):
    
    def do_HEAD(self):
        """Handles HEAD requests."""
        method = "HEAD"
        if options.verbose == True: print "Got HEAD request."
        sheader.pheader(self)
        
    def do_GET(self):
        """Serving a GET requests."""
        method = "GET"
        config = ConfigParser.ConfigParser()
        config.read("conf/glastopf.cfg")
        misc_opts = {
            "parser": config.get("misc","parser")
            }
        vulnpath_opts = {
            "enabled" : config.get("vulnpath", "enabled")
            }
        if options.verbose == True: print threading.activeCount(), "active threads."
        try:
            while 1:
                if options.verbose == True: print "Got GET request:", self.path 
                if re.search("%3A|%2F|%3f",self.path):
                    self.path = self.path.replace("%3A",":")
                    self.path = self.path.replace("%2F","/")
                    self.path = self.path.replace("%3f","?")
                # Search url for http or ftp patterns
                if re.search("=http|=ftp",self.path):
                    # Extract the url from request string
                    if re.search("=http",self.path):
                        url = "http" + self.path.rpartition("=http")[2]
                    elif re.search("=ftp",self.path):
                        url = "ftp" + self.path.rpartition("=ftp")[2]
                    logger.writelog("GET attack from %s with request: %s" % 
                                    (self.client_address[0],self.path),"info")
                    # Removing trailing question marks
                    url = url.rstrip("?")
                    if options.verbose == True: print "Included URL:", url
                    # Sending the header
                    sheader.pheader(self)
                    # Opens the URL
                    id = opener.openurl(url,self)
                    file = []
                    message = []
                    if (id == "error"):
                        break
                    else:
                        # Search for echos and url's
                        for line in id.readlines():
                            # Building the file
                            file.append(line)
                            if misc_opts["parser"] == "old":
                                if re.search("echo|fx\(\"",line) and not re.search("function",line):
                                    # Parsing the request and answer it
                                    line = parseline.pecho(line)
                                    # Creates the message
                                    message.append(line + "\n")
                                elif re.search("\$dc_source =",line):
                                    # TODO: extend
                                    base.debase64(self,line)
                        id.close()
                    separator = ""
                    if misc_opts["parser"] == "old":
                        message = separator.join(message)
                    file = separator.join(file)
                    if misc_opts["parser"] == "new":
                        message = separator.join(phparser.parse(file))
                    # Send the message
                    self.wfile.write(message)
                    self.wfile.write("\n")
                    # Write the file to disk
                    filename = getfile.getter(self,file,method)
                    # Write data into the database
                    datahandler.handle(self,id,filename,url,method)
                    if vulnpath_opts["enabled"] == "True":
                        vulnpath.prozesspath(self.path)
                    break
                # Looking for mail/webmail specific attacks
                if re.search("mail|webmail",self.path):
                    if options.verbose == True: print "mail or webmail request found."
                    logger.writelog("Mail attack found from %s with request: %s" %
                                    (self.client_address[0],self.path),"info")
                    # Respond with the the webmail index
                    sheader.pheader(self)
                    index = open(curdir + sep + "res" + sep + "webmail-index.html")
                    self.wfile.write(index.read())
                    index.close()
                    url, id, filename = "", "", ""
                    datahandler.handle(self,id,filename,url,method)
                    break
                # Looking for Local File Inclusion (LFI) attacks 
                if re.search("/etc/passwd|/etc/shadow|/etc/group", self.path):
                    if options.verbose == True: print "LFI attack string found in request."
                    logger.writelog("LFI attack found from %s with request: %s" %
                                    (self.client_address[0],self.path),"info")
                    sheader.pheader(self)
                    if re.search("/proc/self/environ", self.path):
                        index = open(curdir + sep + "res" + sep + "sys" + sep + "environ")
                    if re.search("/etc/passwd", self.path):
                        index = open(curdir + sep + "res" + sep + "sys" + sep + "passwd")
                    if re.search("/etc/shadow", self.path):
                        index = open(curdir + sep + "res" + sep + "sys" + sep + "shadow")
                    if re.search("/etc/group", self.path):
                        index = open(curdir + sep + "res" + sep + "sys" + sep + "group")
                    self.wfile.write(index.read())
                    index.close()
                    url, id, filename = "", "", ""
                    datahandler.handle(self,id,filename,url,method)
                    break
                else:
                    if options.verbose == True: print "No attack string found in request."
                    logger.writelog("No attack found from %s with request: %s" %
                                    (self.client_address[0],self.path),"info")
                    # Respond with the the dork list
                    sheader.pheader(self)
                    config = ConfigParser.ConfigParser()
                    config.read("conf/glastopf.cfg")
                    misc_opts = {
                        "custompage" : config.get("misc","custompage").capitalize()
                        }
                    dyndork_opts = {
                        "dyndork" : config.get("dyndork","dyndork").capitalize(),
                        "dorktime" : config.get("dyndork", "dorktime")
                        }
                    match = False
                    # If custom pages are activated, serve them if they match
                    if misc_opts["custompage"] == "True":
                        pageList = listdir("res/custompages")  
                        for p in pageList:
                            p = p.partition(".")[0]
                            if p == "": break
                            reqpath = self.path.partition("/")[2].partition("/")[0]
                            if reqpath == p:
                                if options.verbose == True: print "Custom page request found."
                                page = open(curdir + sep + "res" + sep + "custompages" + sep + p + ".html")
                                self.wfile.write(page.read())
                                page.close()
                                match = True
                                break
                    # Else respond with the gooledork page
                    if match == False:
                        index = open(curdir + sep + "res" + sep + "index.html")
                        self.wfile.write(index.read())
                        # If the dynamic dork list is activated, use it.
                        if dyndork_opts["dyndork"] == "True":
                            if dyndork_opts["dorktime"] == "live":
                                # Using a live version of the dork list
                                for row in dyndork.genlist():
                                    self.wfile.write(row[0] + "<br />")
                            else:
                                # Using the pregenerated dork list
                                dyndorks = open(curdir + sep + "res" + sep + "dyndorks")
                                self.wfile.write(dyndorks.read())
                                dyndorks.close()
                            if options.verbose == True: print "Dynamic Dork list served."
                        self.wfile.write("</font></body></html>")
                        index.close()
                    url, id, filename = "", "", ""
                    # Don't log favicon or robots.txt requests to database
                    if (self.path == "/" or self.path == "/favicon.ico" or self.path == "/robots.txt"):
                        if options.verbose == True: print "Request path cleanup matched."
                        logger.writelog("Request path cleanup matched","info")
                        break
                    datahandler.handle(self,id,filename,url,method)
                    break
        except IOError:
            self.send_error(404,"File Not Found: %s" % self.path)
            pass
        
    def do_POST(self):
        """ Serving a POST request. 
        
        The request data must be readable on a file-like object 
        called self.rfile"""
        method = "POST"
        if options.verbose == True: print "Got POST request."
        ctype, pdict = cgi.parse_header(self.headers.getheader("content-type"))
        length = int(self.headers.getheader("content-length"))
        # Handle multipart post content
        if ctype == "multipart/form-data":
            self.body = cgi.parse_multipart(self.rfile, pdict)
        # Handle URL-encoded query string
        elif ctype == "application/x-www-form-urlencoded":
            qs = self.rfile.read(length)
            self.body = cgi.parse_qs(qs, keep_blank_values=1)
        # Unknown content-type
        else:
            self.body = ""
        if self.body:
            logger.writelog("POST attack from %s" % (self.client_address[0]),"info")
            try:
                # Build the file from POSTed information
                postfile = self.body["_user"][0] + "\n\n" + self.body["_pass"][0]
                # Handle the generated file
                filename = getfile.getter(self,postfile,method)
                id, url = "", ""
                # If we have a new file, write data to database
                if len(filename):
                    datahandler.handle(self,id,filename,url,method)
            except:
                logger.writelog("Unknown POST attack from %s" %
                            (self.client_address[0]),"info")
        else: 
            logger.writelog("Unknown POST attack from %s" %
                            (self.client_address[0]),"info")

def glastopf():
    """Main program"""
    config = ConfigParser.ConfigParser()
    config.read("conf/glastopf.cfg")
    server_opts = {
                  "ip": config.get("server","ip"),
                  "port": config.get("server","port"),
                  "user": config.get("server","user"),
                  "group": config.get("server","group")
                  }
    try:
        server = ThreadedHTTPServer((server_opts["ip"],int(server_opts["port"])), Handler)
        print "== All modules loaded =="
        # Dropping privileges (unix only)
        print "Dropping rights (if possible)"
        time.sleep(1)
        dropprivs.drop_privs(server_opts["user"], server_opts["group"])
        time.sleep(1)
        print "Starting Glastopf server, use <Ctrl-c> to stop."
        logger.writelog("Glastopf Server started...","info")
        if options.verbose == True: print "Running in verbose mode"
        server.serve_forever()
    # Ctrl-c quits the server
    except KeyboardInterrupt:
        print "^C received, shutting down server"
        # Wait until all threads are finished
        cancelit()
        main_thread = threading.currentThread()
        for t in threading.enumerate():
            if t is main_thread:
                continue
            t.join
        server.socket.close()

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """Handle requests in a separate thread."""
    def process_request(self, request, client_address):
        """Start a new thread to process the request."""
        config = ConfigParser.ConfigParser()
        config.read("conf/glastopf.cfg")
        server_opts = {
                      "maxthreads": config.get("server","maxthreads"),
                      }
        t = threading.Thread(target = self.process_request_thread,
                             args = (request, client_address))
        if self.daemon_threads:
            t.setDaemon (1)
        # This would be the thread limitation
        max = server_opts["maxthreads"]
        if threading.enumerate() >= max:
            pass
        else:
            t.start()

if __name__ == "__main__":
    glastopf()