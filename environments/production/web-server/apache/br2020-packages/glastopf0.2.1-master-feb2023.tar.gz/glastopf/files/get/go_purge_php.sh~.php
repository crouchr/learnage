cd /usr/local/src/glastopf/files/get
rm -rf *.php.php
rm -rf *.php.php.php
rm -rf *.php.php.php.php
rm -rf *.php.php.php.php.php
rm -rf *.php.php.php.php.php.php
rm -rf *.php.php.php.php.php.php.php


