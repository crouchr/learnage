import psycopg2
import ConfigParser
import time

config = ConfigParser.ConfigParser()
config.read("conf/surfids.cfg")

pg_host = config.get("surfids","host")
pg_port = config.get("surfids","port")
pg_user = config.get("surfids","user")
pg_pass = config.get("surfids","pass")
pg_db = config.get("surfids","db")

print "SURFids plugin loaded"
time.sleep(1)

def dbwrite(data):
    # constants
    severity = 1
    atype = 3
    req_code = 60
    ref_code = 61
    agent_code = 62
    
    sourceip = data[2]
    sourceport = data[3]
    destip = data[4]
    destport = data[5]
    req = data[8]
    ref = data[9]
    agent = data[10]
    
    try:
        connection = psycopg2.connect("dbname=%s user=%s password=%s host=%s port=%s sslmode=prefer" % (pg_db, pg_user, pg_pass, pg_host, pg_port))
        pgsql = connection.cursor()
        sql0 = "SELECT surfnet_sensorid_get(%s)"
        pgsql.execute(sql0, (destip,))
        result = pgsql.fetchall()
        sensorid = result[0][0]
        if sensorid != "":
            sql1 = "SELECT surfnet_attack_add_by_id(%s, %s, %s, %s, %s, NULL, %s)"
            pgsql.execute(sql1, (severity, sourceip, sourceport, destip, destport, sensorid))
            result = pgsql.fetchall()
            attackid = result[0][0]
            if attackid != "":
                sql2 = "SELECT surfnet_attack_update_atype(%s, %s)"
                pgsql.execute(sql2, (attackid, atype))

                sql3 = "SELECT surfnet_detail_add_by_id(%s, %s, %s, %s)"
                pgsql.execute(sql3, (attackid, sensorid, req_code, req))

                if ref != "":
                    sql4 = "SELECT surfnet_detail_add_by_id(%s, %s, %s, %s)"
                    pgsql.execute(sql4, (attackid, sensorid, ref_code, ref))

                sql5 = "SELECT surfnet_detail_add_by_id(%s, %s, %s, %s)"
                pgsql.execute(sql5, (attackid, sensorid, agent_code, agent))
                connection.commit()
    
    except psycopg2.Error, error_message:
            print "PostgreSQL database error: " + str(error_message)