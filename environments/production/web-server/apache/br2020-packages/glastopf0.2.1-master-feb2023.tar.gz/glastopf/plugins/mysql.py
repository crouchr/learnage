import MySQLdb
import ConfigParser
import socket
import time
import sys
sys.path.append("modules")

import whois
import logger



config = ConfigParser.ConfigParser()
config.read("conf/glastopf.cfg")

mysql_opts = {
    "host" : config.get("mysql","host"),
    "port" : config.get("mysql","port"),
    "user" : config.get("mysql","user"),
    "pass" : config.get("mysql","pass"),
    "db" : config.get("mysql","db")
    }

misc_opts = {
    "domainwhois": config.get("misc","domainwhois").capitalize(),
    "ip_whois": config.get("misc","ip_whois").capitalize()
    }

server_opts = {
    "ip": config.get("server","ip")
    }

print "MySQL plugin loaded"
time.sleep(1)

def dbwrite(data):
    method, domain, sourceip, sourceport, destip, destport, attime, tzone, req, ref, agent, via, forwardedfor, xforwardedfor, xvia, onspdusr, host, alive, filename, victim = data[:-1]
    try:
        # Execute local database queries
        mysql = MySQLdb.connect(mysql_opts["host"],
                    mysql_opts["user"],
                    mysql_opts["pass"], mysql_opts["db"],
                    int(mysql_opts["port"]))
        mysql.threadsafety = 2 
        cursor = mysql.cursor()
        # If data exists already in db query
        if method == "GET":
            sql1 = """
                SELECT domain, req FROM log 
                WHERE domain = %s AND req = %s
                """
            check = req
        elif method == "POST":
            sql1 = """
                SELECT domain, filename FROM log 
                WHERE domain = %s AND filename = %s
                """
            check = filename
        else:
            pass # Raise error!
        if cursor.execute(sql1, (domain,check)):
            logger.writelog("Data for %s and %s already " \
                            "in local database" % (sourceip,req),"info")
            print "Already in local database"
            # Hit query
            if method == "GET":
                sql3 = """
                    UPDATE log
                    SET count = count + 1
                    WHERE domain = %s AND req = %s
                    """
                check = req
            elif method == "POST":
                sql3 = """
                    UPDATE log
                    SET count = count + 1
                    WHERE domain = %s AND filename = %s
                    """
                check = filename
            else:
                pass # Raise error
            cursor.execute(sql3, (domain, check))
        else:
            # Insert new data query
            # Get the attackers mnt-by information to identify 
            # the responsible ISP
            if misc_opts["ip_whois"] == "True":
                attmnt = whois.mntwhois(sourceip)
            else:
                attmnt = "none"
            if misc_opts["domainwhois"] == "True":
                attmail = whois.mailwhois(sourceip)
            else:
                attmail = "none"
            # Get the victims IP address
            vicip = socket.gethostbyname(victim)
            try: 
                vicadd = socket.gethostbyaddr(vicip)[0]
            except: 
                vicadd = "None"
            if victim != "" and victim != vicadd and vicip != server_opts["ip"]:
                # Get the victims mnt-by and email contact information
                # to identify the responsible ISP or owner
                if misc_opts["ip_whois"] == "True":
                    vicmnt = whois.mntwhois(vicip)
                else:
                    vicmnt = "none"
                if misc_opts["domainwhois"] == "True":
                    vicmail = whois.mailwhois(victim)
                else:
                    vicmail = "none"
            else:
                victim = "none"
                vicmnt = "undefined"
                vicmail = "none"
            
            if method == "GET" or "POST":
                sql2 = """
                    INSERT INTO log (domain, ip, attime, tzone, req, ref, 
                            via, xvia, forwardedfor, xforwardedfor, 
                            onspdusr, agent, host, attmnt, attmail, vicmnt, vicmail,
                             alive, filename, victim)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 
                            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """
                cursor.execute(sql2, (domain, sourceip, attime, tzone, req, 
                                      ref, via, xvia, forwardedfor, 
                                      xforwardedfor, onspdusr, agent, 
                                      host, attmnt, attmail, vicmnt, vicmail,
                                      alive, filename, victim))
                logger.writelog("Data for %s and %s written " \
                                "into local database" % (sourceip,req),"info")
                print "Data written into local database"
            else:
                pass # Raise error
    except MySQLdb.Error, e:
        logger.writelog("MySQL error %s for %s: %s " % (e.args[0], filename, 
                                                        e.args[1]),"info")
        print "Error %d: %s" % (e.args[0], e.args[1])
        pass