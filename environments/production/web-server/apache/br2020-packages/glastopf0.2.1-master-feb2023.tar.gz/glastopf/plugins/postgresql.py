import psycopg2
import ConfigParser
import time
import sys
import socket

import whois
import  logger

config = ConfigParser.ConfigParser()
config.read("conf/postgresql.cfg")

pg_host = config.get("postgresql","host")
pg_port = config.get("postgresql","port")
pg_user = config.get("postgresql","user")
pg_pass = config.get("postgresql","pass")
pg_db = config.get("postgresql","db")

config.read("conf/glastopf.cfg")
misc_opts = {
    "domainwhois": config.get("misc","domainwhois").capitalize()
    }
server_opts = {
    "ip": config.get("server","ip")
    }

print "postgresql plugin loaded"
time.sleep(1)

def dbwrite(data):
    """Write into the PostgreSQL database"""
    method, domain, sourceip, sourceport, destip, destport, attime, tzone, req, ref, agent, via, forwardedfor, xforwardedfor, xvia, onspdusr, host, alive, filename, victim = data[:-1]
    try:
        connection = psycopg2.connect("dbname=%s user=%s password=%s host=%s port=%s sslmode=prefer" % (pg_db, pg_user, pg_pass, pg_host, pg_port))
        cursor = connection.cursor()
        # If data exists already in db query
        if method == "GET":
            sql1 = """
                SELECT domain, req FROM log 
                WHERE domain = %s AND req = %s
                """
            check = req
        elif method == "POST":
            sql1 = """
                SELECT domain, filename FROM log 
                WHERE domain = %s AND filename = %s
                """
            check = filename
        else:
            pass # Raise error!
        if cursor.execute(sql1, (domain,check)):
            logger.writelog("Data for %s and %s already " \
                            "in local database" % (sourceip,req),"info")
            print "Already in local database"
            # Hit query
            if method == "GET":
                sql3 = """
                    UPDATE log
                    SET count = count + 1
                    WHERE domain = %s AND req = %s
                    """
                check = req
            elif method == "POST":
                sql3 = """
                    UPDATE log
                    SET count = count + 1
                    WHERE domain = %s AND filename = %s
                    """
                check = filename
            else:
                pass # Raise error
            cursor.execute(sql3, (domain, check))
        else:
            # Insert new data query
            # Get the attackers mnt-by information to identify 
            # the responsible ISP
            attmnt = whois.mntwhois(sourceip)
            if misc_opts["domainwhois"] == "True":
                attmail = whois.mailwhois(sourceip)
            else:
                attmail = "none"
            # Get the victims IP address
            vicip = socket.gethostbyname(victim)
            try: 
                vicadd = socket.gethostbyaddr(vicip)[0]
            except: 
                vicadd = "None"

            if victim != "" and victim != vicadd and vicip != server_opts["ip"]:
                # Get the victims mnt-by and email contact information
                # to identify the responsible ISP or owner
                vicmnt = whois.mntwhois(vicip)
                if misc_opts["domainwhois"] == "True":
                    vicmail = whois.mailwhois(victim)
                else:
                    vicmail = "none"
            else:
                victim = "none"
                vicmnt = "undefined"
                vicmail = "none"
                
            if method == "GET" or "POST":
                sql2 = """
                    INSERT INTO log (domain, ip, attime, tzone, req, ref, 
                            via, xvia, forwardedfor, xforwardedfor, 
                            onspdusr, agent, host, attmnt, attmail, vicmnt, vicmail,
                             alive, filename, victim)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 
                            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """
                cursor.execute(sql2, (domain, sourceip, attime, tzone, req, 
                                      ref, via, xvia, forwardedfor, 
                                      xforwardedfor, onspdusr, agent, 
                                      host, attmnt, attmail, vicmnt, vicmail,
                                      alive, filename, victim))
                logger.writelog("Data for %s and %s written " \
                                "into local PostgreSQL database" % (sourceip,req),"info")
                connection.commit()
                print "Data written into local PostgreSQL database"
            else:
                pass # Raise error
            
    except psycopg2.Error, error_message:
        logger.writelog("PostgreSQL error %s for %s: %s " % (e.args[0], filename, 
                                                        e.args[1]),"info")
        print "PostgreSQL database error: " + str(error_message)