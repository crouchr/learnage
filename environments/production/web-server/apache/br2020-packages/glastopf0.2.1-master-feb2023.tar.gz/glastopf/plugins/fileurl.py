import re
import time
import ConfigParser
import MySQLdb
import sys
sys.path.append("modules")

import logger

config = ConfigParser.ConfigParser()
config.read("conf/glastopf.cfg")

mysql_opts = {
    "host" : config.get("mysql","host"),
    "port" : config.get("mysql","port"),
    "user" : config.get("mysql","user"),
    "pass" : config.get("mysql","pass"),
    "db" : config.get("mysql","db")
    }

print "File URL plugin loaded"
time.sleep(1)

def dbwrite(data):
    req = data[8]
    if (re.search("=https://", req)):
        fileurl = "https://" + req.partition("=https://")[2]
    elif (re.search("=http://", req)):
        fileurl = "http://" + req.partition("=http://")[2]
    else:
        fileurl = ""
    if (re.search("www\.", fileurl)): 
        fileurl = fileurl.replace("www.", "")
    try:
        # Execute local database queries
        mysql = MySQLdb.connect(mysql_opts["host"],
                    mysql_opts["user"],
                    mysql_opts["pass"], mysql_opts["db"],
                    int(mysql_opts["port"]))
        mysql.threadsafety = 2 
        cursor = mysql.cursor()
        # If data exists already in db query
        sql1 = """
                SELECT fileurl FROM files 
                WHERE fileurl = %s
            """
        if cursor.execute(sql1, (fileurl,)):
            logger.writelog("%s already " \
                            "in files database" % (fileurl,),"info")
            print "Already in files database"
        else:
            sql2 = """
                    INSERT INTO files (fileurl)
                    VALUES (%s)
                    """
            cursor.execute(sql2, (fileurl,))
            logger.writelog("%s written " \
                            "into fileurl database" % (fileurl,),"info")
            print "Data written into fileurl database"
    except MySQLdb.Error, e:
        logger.writelog("MySQL error %s for %s: %s " % (e.args[0], fileurl, 
                                                        e.args[1]),"info")
        print "Error %d: %s" % (e.args[0], e.args[1])
        pass