# Thanks to Konrad Rieck

import time
import ConfigParser
import sys
import datetime

sys.path.append("modules")

import logger

config = ConfigParser.ConfigParser()
config.read("conf/glastopf.cfg")
raw_dir = "files/raw"

print "Raw output plug-in loaded"
time.sleep(1)

def dbwrite(data):
    # parser object
    pr = data[20]
    # filename: sourceip:port-destip:port
    file_name = str(datetime.date.today())

    f = open(raw_dir + "/" + file_name, "a+")
    f.write(pr.command + " " + pr.path + " " + pr.request_version + " ")
    for var, val in pr.headers.items():
        f.write(var + ": " + val + " ")
    f.write("\n\n")       
    f.close()