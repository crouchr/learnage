import socket
import time
import ConfigParser
import hashlib
import hmac
try:
    import cPickle as pickle
except:
    import pickle

config = ConfigParser.ConfigParser()
config.read("conf/dbclient.cfg")

central_opts = {
    "topf_id" : config.get("centralserver","topf_id"),
    "secret_key" : config.get("centralserver","secret_key"),
    "centralhost" : config.get("centralserver","centralhost"),
    "centralport" : config.get("centralserver","centralport")
    }

print "Central database client plugin loaded"
time.sleep(1)

def make_digest(message):
    """Return a digest for the message."""
    return hmac.new(central_opts["secret_key"], message, hashlib.sha1).hexdigest()


class dbsender():
    """Connects to the central server end sends the data string"""
    def __init__(self):
        ip = central_opts["centralhost"]
        port = int(central_opts["centralport"])
        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
        self.s.connect((ip, port))
        
    def send(self,msg):
        self.s.send(msg)
    
    def close(self):
        self.s.close()
        
def dbwrite(data):
    """Prepares the data string, sends the header and data to the central database server. """
    # Execute central database queries
    dbsend = dbsender()
    seperator = "|"
    datastring =  seperator.join(data[:-1])
    pickled_data = pickle.dumps(datastring)
    digest = make_digest(pickled_data)
    header = "%s %s %s" % (digest, len(pickled_data), central_opts["topf_id"])
    print "Writing into central database. Header:", header
    dbsend.send(header)
    dbsend.send(pickled_data)
    dbsend.close()