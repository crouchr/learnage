#!/bin/sh

echo -n "Starting kippo in background..."
cd /usr/local/src/kippo-0.5
twistd -y /usr/local/src/kippo-0.5/kippo.tac -l /home/var/log/kippo.log --pidfile /var/run/rchpids/kippo.pid


