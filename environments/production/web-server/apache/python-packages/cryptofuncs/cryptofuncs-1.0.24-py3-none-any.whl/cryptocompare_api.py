# https://www.cryptocompare.com
# free - 250, 000
# lifetime
# API
# calls

import requests
import json


def get_current_price(symbol, api_key):

    endpoint = 'https://min-api.cryptocompare.com/data/price?fsym=' + symbol + '&tsyms=USD,GBP,EUR&api_key=' + api_key
    response = requests.get(endpoint, )

    if response.status_code != 200:
        return False, None

    response_dict = json.loads(response.content.decode('utf-8'))

    return True, response_dict


if __name__ == '__main__':
    api_key = 'afd8aecbb2492033e21742b51400537317eef92343977ed19df7002857d642a0'
    # symbol = 'ETH'
    symbol = 'XLM'
    symbol = 'XRP'

    flag, price = get_current_price(symbol, api_key)

    print(price)
