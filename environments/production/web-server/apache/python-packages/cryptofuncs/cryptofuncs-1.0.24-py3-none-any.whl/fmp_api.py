# https://financialmodelingprep.com/developer/docs#Cryptocurrencies
# Free if less than 250 requests per day
# https://www.marketwatch.com/investing/index/djia

import requests
import json
import time


def get_symbol_info(symbol):
    API_KEY = 'dd7f15de28ae017ddacbdda412d3853a'

    try:
        endpoint = 'https://financialmodelingprep.com/api/v3/quote/' + symbol + '?apikey=' + API_KEY

        response = requests.get(endpoint)

        if response.status_code != 200:
            return False, 'HTTP error=' + response.status_code

        response_dict = json.loads(response.content.decode('utf-8'))
        if len(response_dict) == 0:
            return False, 'Empty response from server, bad symbol ?'

        time.sleep(0.3)
        return True, response_dict[0]

    except Exception as e:
        return False, e.__str__()


def display_poll_period():
    """
    Utility function to determine POLL_SECS value
    API (free tier) permits 250 requests per day
    :return:
    """
    secs_in_day = 24 * 60 * 60
    for num_endpoints in range(1, 6):
        poll_period_secs = (num_endpoints * secs_in_day) / 250
        poll_period_mins = poll_period_secs / 60
        print(num_endpoints.__str__() + ' ' + poll_period_secs.__str__() + 's ' + poll_period_mins.__str__() + 'm')


# Test code
def main():
    import sys
    display_poll_period()
    # sys.exit()
    # flag, results = get_symbol_info('BTCUSD')
    # flag, results = get_symbol_info('XLMUSD')
    # flag, results = get_symbol_info('XRPUSD')
    # flag, results = get_symbol_info('ETHUSD')
    # flag, results = get_symbol_info('BCHUSD')

    # flag, results = get_symbol_info('^DJI')    # Dow Jones
    # if flag:
    #     print(results['name'] + " " + results['price'].__str__())
    flag, results = get_symbol_info('^FTSE')
    flag, results = get_symbol_info('^IXIC')   # NASDAQ

    flag, results = get_symbol_info('ZGUSD')   # Gold 100 oz
    flag, results = get_symbol_info('CLUSD')   # Crude oil

    print('done')


if __name__ == '__main__':
    main()
