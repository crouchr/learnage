import requests
import json


def get_bcn_price():
    """
    Call REST API endpoint to get current BTC price

    :param endpoint:e.g. 'http://127.0.0.1:9500/wind_deg_to_wind_rose'
    :param query: e.g. query = {'wind_deg': wind_deg}
    :return:
    """
    try:
        bcn_info = {}
        endpoint = 'https://api.coindesk.com/v1/bpi/currentprice.json'

        response = requests.get(endpoint,)

        if response.status_code != 200:
            return 500, None

        response_dict = json.loads(response.content.decode('utf-8'))

        bcn_info['updateduk'] = response_dict['time']['updateduk']
        bcn_info['GBP'] = response_dict['bpi']['GBP']['rate_float']
        bcn_info['USD'] = response_dict['bpi']['USD']['rate_float']
        bcn_info['EUR'] = response_dict['bpi']['EUR']['rate_float']

        return response.status_code, bcn_info

    except Exception as e:
        print('get_bcn_price() : Error=' + e.__str__())
        return 500, None


if __name__ == '__main__':
    btc_price_usd = get_bcn_price()[1]['USD']
    btc_price_gbp = get_bcn_price()[1]['GBP']
    print()
