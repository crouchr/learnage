# https://alternative.me/crypto/fear-and-greed-index/
import requests
import json


def get_fng_index():
    """
    API call to Fear and Greed Index

    :return:
    """
    try:
        fng_info = {}
        endpoint = 'https://api.alternative.me/fng/'

        response = requests.get(endpoint,)

        if response.status_code != 200:
            return False, None

        response_dict = json.loads(response.content.decode('utf-8'))
        fng_info['value'] = int(response_dict['data'][0]['value'])
        fng_info['classification'] = response_dict['data'][0]['value_classification']
        fng_info['timestamp'] = int(response_dict['data'][0]['timestamp'])
        fng_info['time_until_update'] = int(response_dict['data'][0]['time_until_update'])

        return True, fng_info

    except Exception as e:
        print('get_fng_index() : Error=' + e.__str__())
        return False, None


# basic test harness
if __name__ == '__main__':
    status, results = get_fng_index()
