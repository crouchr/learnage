# -*- coding: utf-8 -*-
# Make calls to a reachable Bitcoin full node via RPC
import json
import logging
import requests
from base64 import b64encode

log = logging.getLogger(__name__)


# return status, data
class Bitcoin():
    __id_count = 0

    def __init__(self,
                 rpcuser,
                 rpcpasswd,
                 rpchost,
                 rpcport,
                 rpc_call=None
                 ):
        self.__rpcuser = rpcuser
        self.__rpcpasswd = rpcpasswd
        self.__rpchost = rpchost
        self.__rpcport = rpcport
        self.__auth_header = ' '.join(
            ['Basic', b64encode(':'.join([rpcuser, rpcpasswd]).encode()).decode()]
        )
        self.__headers = {'Host': self.__rpchost,
                          'User-Agent': 'Bitcoin python binding',
                          'Authorization': self.__auth_header,
                          'Content-type': 'application/json'
                          }
        self.__rpc_call = rpc_call

    def __getattr__(self, name):
        if name.startswith('__') and name.endswith('__'):
            # Python internal stuff
            raise AttributeError
        if self.__rpc_call is not None:
            name = "%s.%s" % (self.__rpc_call, name)
        return Bitcoin(self.__rpcuser,
                          self.__rpcpasswd,
                          self.__rpchost,
                          self.__rpcport,
                          name)

    def __call__(self, *args):
        Bitcoin.__id_count += 1
        postdata = {'params': args,
                    'method': self.__rpc_call,
                    'id': Bitcoin.__id_count}
        protocol = 'https' if int(self.__rpcport) == 443 else 'http'
        url = '{0}://{1}:{2}'.format(protocol, self.__rpchost, self.__rpcport)
        encoded = json.dumps(postdata)
        log.info("Request: %s" % encoded)

        try:
            r = requests.post(url, data=encoded, headers=self.__headers)
            if r.status_code == 200:
                log.info("Response: %s" % r.json())
                return True, r.json()['result']
            else:
                log.error("Error! Status code: %s" % r.status_code)
                log.error("Text: %s" % r.text)
                log.error("Json: %s" % r.json())
                return False, r.json()
        except Exception as e:
           return False, None


# test harness
if __name__ == '__main__':

    # Embassy parameters
    # bitcoind_host = 'embassy'
    # bitcoind_username = 'bitcoin'
    # bitcoind_password = 'fil in'
    # bitcoind_rpcport = 8332

    # mainnet parameters
    # bitcoind_host = 'j1900'
    # bitcoind_username = 'bitcoinrpc'
    # bitcoind_password = 'protectrpcserver1928'
    # bitcoind_rpcport = 8332

    # testnet parameters
    bitcoind_host = 'kube'
    bitcoind_username = 'bitcoinrpc-testnet'
    bitcoind_password = 'protectrpcserver1928-testnet'
    bitcoind_rpcport = 18332

    bitcoin = Bitcoin(bitcoind_username, bitcoind_password, bitcoind_host, bitcoind_rpcport)
    status, blockchain_info = bitcoin.getblockchaininfo()

    print('finished')