import fear_and_greed_index_api


def test_get_fng_index():

    flag, results = fear_and_greed_index_api.get_fng_index()

    assert flag is True
    assert results['value'] > 0
    assert results['timestamp'] > 0
    assert results['time_until_update'] > 0
