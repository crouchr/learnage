# Glassnode OnChain metrics
# Free if less than 250 requests per day


import requests
import json
import time


# BITCOIN tailored
def get_glassnode_info(endpoint, api_key):
    from pprint import pprint
    try:
        endpoint = 'https://api.glassnode.com/v1/metrics/' + endpoint
        # make API request
        response = requests.get(endpoint,
                           params={'a': 'BTC', 'api_key': api_key})

        if response.status_code != 200:
            return False, 'HTTP error=' + response.status_code

        response_dict = json.loads(response.content.decode('utf-8'))
        if len(response_dict) == 0:
            return False, 'Empty response from server for ' + endpoint

        items_returned = len(response_dict)
        endpoint_point = endpoint.split('/')[-1]
        if endpoint_point == 'stock_to_flow_ratio':
            value = response_dict[items_returned - 1]['o']['ratio']
        else:
            value = response_dict[items_returned - 1]['v']

        time.sleep(0.3)
        return True, value

    except Exception as e:
        return False, e.__str__()


# Lightning Network
def get_glassnode_lightning_info(endpoint, api_key):

    try:
        endpoint = 'https://api.glassnode.com/v1/metrics/lightning/' + endpoint
        # make API request
        response = requests.get(endpoint,
                           params={'a': 'BTC', 'api_key': api_key})

        if response.status_code != 200:
            return False, 'HTTP error=' + response.status_code

        response_dict = json.loads(response.content.decode('utf-8'))
        if len(response_dict) == 0:
            return False, 'Empty response from server for ' + endpoint

        items_returned = len(response_dict)

        value = response_dict[items_returned - 1]['v']

        time.sleep(0.3)
        return True, value

    except Exception as e:
        return False, e.__str__()

# ETH, ADA, SOL
def get_glassnode_alt_info(endpoint, symbol, api_key):

    try:
        endpoint = 'https://api.glassnode.com/v1/metrics/' + endpoint
        # make API request
        response = requests.get(endpoint,
                           params={'a': symbol, 'api_key': api_key})

        if response.status_code != 200:
            return False, 'HTTP error=' + response.status_code

        response_dict = json.loads(response.content.decode('utf-8'))
        if len(response_dict) == 0:
            return False, 'Empty response from server for ' + endpoint

        items_returned = len(response_dict)
        endpoint_point = endpoint.split('/')[-1]

        value = response_dict[items_returned - 1]['v']

        time.sleep(0.3)
        return True, value

    except Exception as e:
        return False, e.__str__()


# Test Code
def main():
    API_KEY = '1sqerc4GlhuixQSjauaOaW7r6ZS'

    # Lightning Network
    # flag, total_lightning_addresses = get_glassnode_lightning_info('channel_size_mean', API_KEY)
    flag, lightning_nodes = get_glassnode_lightning_info('nodes_count', API_KEY)
    if flag:
        print('Lightning nodes : ' + lightning_nodes.__str__())

    # Alts - ETH only from API ?
    flag, total_eth_addresses = get_glassnode_alt_info('addresses/non_zero_count', 'ETH', API_KEY)

    if flag:
        print('ETH addresses : ' + total_eth_addresses.__str__())

    # Bitcoin
    flag, block_rewards = get_glassnode_info('mining/volume_mined_sum', API_KEY)
    if flag:
        print(block_rewards.__str__())

    flag, miner_fees = get_glassnode_info('mining/revenue_from_fees', API_KEY)
    if flag:
        print(miner_fees.__str__())

    # The number of bitcoin flowing from / to the Purpose Bitcoin ETF. Source: Purpose Investments
    flag, purpose_etf_flows_btc = get_glassnode_info('institutions/purpose_etf_flows_sum', API_KEY)
    if flag:
        print(purpose_etf_flows_btc.__str__())

    # The number of bitcoin in the Purpose Bitcoin ETF. Source: Purpose Investments
    flag, purpose_etf_holdings_btc = get_glassnode_info('institutions/purpose_etf_holdings_sum', API_KEY)
    if flag:
        print(purpose_etf_holdings_btc.__str__())

    # The total amount of all coins ever created / issued
    flag, circulation_btc = get_glassnode_info('supply/current', API_KEY)
    if flag:
        print(circulation_btc.__str__())

    flag, inflation_btc = get_glassnode_info('supply/inflation_rate', API_KEY)
    if flag:
        print(inflation_btc.__str__())

    # flag, transactions_btc = get_glassnode_info('transactions/count', API_KEY)
    # if flag:
    #     print(transactions_btc.__str__())

    # successful transactions per second
    flag, transactions_rate = get_glassnode_info('transactions/rate', API_KEY)
    if flag:
        print(transactions_rate.__str__())

    # - - - -

    flag, total_addresses = get_glassnode_info('addresses/count', API_KEY)
    if flag:
        print('BTC addresses : ' + total_addresses.__str__())

    flag, new_addresses = get_glassnode_info('addresses/new_non_zero_count', API_KEY)
    if flag:
        print(new_addresses.__str__())

    flag, non_zero_balance_addresses = get_glassnode_info('addresses/non_zero_count', API_KEY)
    if flag:
        print(non_zero_balance_addresses.__str__())

    flag, min_point_zero_1_count = get_glassnode_info('addresses/min_point_zero_1_count', API_KEY)
    if flag:
        print(min_point_zero_1_count.__str__())

    flag, min_point_1_count = get_glassnode_info('addresses/min_point_1_count', API_KEY)
    if flag:
        print(min_point_1_count.__str__())

    flag, min_1_count = get_glassnode_info('addresses/min_1_count', API_KEY)
    if flag:
        print(min_1_count.__str__())

    flag, min_10_count = get_glassnode_info('addresses/min_10_count', API_KEY)
    if flag:
        print(min_10_count.__str__())

    flag, min_100_count = get_glassnode_info('addresses/min_100_count', API_KEY)
    if flag:
        print(min_100_count.__str__())

    flag, min_1k_count = get_glassnode_info('addresses/min_1k_count', API_KEY)
    if flag:
        print(min_1k_count.__str__())

    flag, min_10k_count = get_glassnode_info('addresses/min_10k_count', API_KEY)
    if flag:
        print(min_10k_count.__str__())

    flag, profit_relative = get_glassnode_info('addresses/profit_relative', API_KEY)
    if flag:
        print(profit_relative.__str__())

    flag, block_interval_mean = get_glassnode_info('blockchain/block_interval_mean', API_KEY)
    if flag:
        print(block_interval_mean.__str__())

    flag, sopr = get_glassnode_info('indicators/sopr', API_KEY)
    if flag:
        print(sopr.__str__())

    flag, liveliness = get_glassnode_info('indicators/liveliness', API_KEY)
    if flag:
        print(liveliness.__str__())

    flag, stock_to_flow_ratio = get_glassnode_info('indicators/stock_to_flow_ratio', API_KEY)
    if flag:
        print(stock_to_flow_ratio.__str__())

    flag, stock_to_flow_deflection = get_glassnode_info('indicators/stock_to_flow_deflection', API_KEY)
    if flag:
        print(stock_to_flow_deflection.__str__())

    flag, puell_multiple = get_glassnode_info('indicators/puell_multiple', API_KEY)
    if flag:
        print(puell_multiple.__str__())

    flag, reserve_risk = get_glassnode_info('indicators/reserve_risk', API_KEY)
    if flag:
        print(reserve_risk.__str__())

    flag, net_unrealized_profit_loss = get_glassnode_info('indicators/net_unrealized_profit_loss', API_KEY)
    if flag:
        print(net_unrealized_profit_loss.__str__())

    print('done')


if __name__ == '__main__':
    main()
