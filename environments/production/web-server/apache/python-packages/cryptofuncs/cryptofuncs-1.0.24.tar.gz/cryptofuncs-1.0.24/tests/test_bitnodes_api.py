import bitnodes_api


def test_get_number_bitcoin_nodes():
    nodes = bitnodes_api.get_number_bitcoin_nodes()
    assert nodes is not None
