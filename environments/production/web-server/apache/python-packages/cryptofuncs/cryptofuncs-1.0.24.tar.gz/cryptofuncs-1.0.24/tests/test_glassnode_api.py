import glassnode_api
# Lightning metrics - see : https://docs.glassnode.com/api/lightning

API_KEY = '1sqerc4GlhuixQSjauaOaW7r6ZS'


def test_get_glassnode_lightning_info_node():
    flag, result = glassnode_api.get_glassnode_lightning_info('nodes_count', API_KEY)

    assert flag is True
    assert result > 0


def test_get_glassnode_lightning_info_chans():
    flag, result = glassnode_api.get_glassnode_lightning_info('channels_count', API_KEY)

    assert flag is True
    assert result > 0


def test_get_glassnode_lightning_info_capacity():
    flag, result = glassnode_api.get_glassnode_lightning_info('network_capacity_sum', API_KEY)

    assert flag is True
    assert result > 0


def test_get_glassnode_lightning_info_chmean():
    flag, result = glassnode_api.get_glassnode_lightning_info('channel_size_mean', API_KEY)

    assert flag is True
    assert result > 0


def test_get_glassnode_lightning_info_chmed():
    flag, result = glassnode_api.get_glassnode_lightning_info('channel_size_median', API_KEY)

    assert flag is True
    assert result > 0


def test_get_glassnode_info():
    flag, result = glassnode_api.get_glassnode_info('addresses/non_zero_count', API_KEY)

    assert flag is True
    assert result > 0


def test_stock_to_flow():
    flag, result = glassnode_api.get_glassnode_info('indicators/stock_to_flow_ratio', API_KEY)

    assert flag is True
    assert result > 0


def test_stock_to_flow_deflection():
    flag, result = glassnode_api.get_glassnode_info('indicators/stock_to_flow_deflection', API_KEY)

    assert flag is True
    assert result > 0


def test_get_glassnode_alt_info():
    flag, result = glassnode_api.get_glassnode_alt_info('addresses/non_zero_count', 'ETH', API_KEY)

    assert flag is True
    assert result > 0
