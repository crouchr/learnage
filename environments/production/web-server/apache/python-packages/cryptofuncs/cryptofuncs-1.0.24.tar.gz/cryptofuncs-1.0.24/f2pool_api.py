
import requests
import json
import time
import traceback

def get_f2pool_info(symbol, username):
    """
    Retrieve critical metrics from f2pool API - the API is unauthenticated
    :param symbol: bitcoin or bitcoin-cash
    :param username: e.g. crouchr
    :return:
    """
    api_data = {}

    try:
        endpoint = 'https://api.f2pool.com/' + symbol + '/' + username
        attempts = 0
        api_call_success = False
        while attempts < 3:
            response = requests.get(endpoint,)

            if response.status_code == 200:
                api_call_success = True
                break
            attempts += 1
            holdoff_secs = 20 * attempts
            print(f'API call failed after attempt {attempts}, waiting {holdoff_secs} seconds...')
            time.sleep(holdoff_secs)

        if api_call_success is False:
            api_data['error'] = 'HTTP status=' + response.status_code.__str__()
            return False, api_data

        response_dict = json.loads(response.content.decode('utf-8'))

        api_data['crypto'] = symbol
        api_data['username'] = username
        api_data['worker_online'] = response_dict['worker_length_online']
        api_data['hashrate_ghps'] = response_dict['hashrate']

        # units are Satoshis as BTC values are so small
        api_data['yesterday_revenue'] = int(100000000 * response_dict['today_paid'])
        api_data['todays_estimated_revenue'] = int(100000000 * response_dict['value_today'])
        api_data['balance'] = int(100000000 * response_dict['fixed_balance'])
        api_data['paid'] = int(100000000 * response_dict['paid'])

        # Derived metrics
        api_data['per_annum_estimate'] = int(365 * api_data['yesterday_revenue'])

        return True, api_data

    except Exception as e:
        print('get_f2pool_info : Error=' + e.__str__())
        traceback.print_exc()
        return False, None


# Test harness
if __name__ == '__main__':
    while True:
        # status, api_data = get_f2pool_info('bitcoin-cash', 'crouchr')
        status, api_data = get_f2pool_info('bitcoin', 'crouchr')
        if not status:
            print('API call failed with error=' + api_data['error'])
            time.sleep(60)
            continue

        print(time.ctime())
        print(api_data['crypto'])
        print(api_data['username'])
        print('worker_online: ' + api_data['worker_online'].__str__())
        print('hashrate: ' + api_data['hashrate_ghps'].__str__())

        print('balance (Sats): ' + api_data['balance'].__str__())
        print('yesterday_revenue (Sats): ' + api_data['yesterday_revenue'].__str__())
        print('todays_estimated_revenue (Sats): ' + api_data['todays_estimated_revenue'].__str__())
        print('per_annum_estimate (Sats): ' + api_data['per_annum_estimate'].__str__())

        print('\nsleeping...')
        time.sleep(120)
