import pytest

from xgminer_api import *


@pytest.mark.parametrize(
    "hostname, api_port, expected_status, expected_code",
    [
        ('j1900', 4028, True, 11),
        ('192.168.1.6', 4028, True, 11),
        ('j1900xx', 4028, False, 11),
        ('j1900', 4029, True, 11),
        ('192.168.1.6', 4029, True, 11),
        ('j1900xx', 4029, False, 11),
    ]
)
def test_xgminer_miner(hostname, api_port, expected_status, expected_code):

    miner_results = get_miner_summary(hostname, api_port)

    assert miner_results['status'] == expected_status
    if miner_results['status'] == True:
        assert miner_results['tstamp'] > 0
        assert miner_results['giga_hps'] > 10.0
        assert miner_results['miner_hashing_online'] == 1
        assert miner_results['found_blocks'] >= 0
