import pytest

import blockchaininfo_api


# Test address is my main wallet
@pytest.mark.parametrize(
    "btc_address",
    [
        ('19HvidH9wno6HtZg5JTNEqH6QuiFYjU2zp'),
    ]
)
def test_check_balance(btc_address):
    btc = blockchaininfo_api.check_balance(btc_address)

    assert btc > 0
