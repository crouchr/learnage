import coinbase_api


def test_get_bcn_price():

    http_code, results = coinbase_api.get_bcn_price()

    assert http_code == 200
    assert results['GBP'] > 0
    assert results['USD'] > 0
    assert results['EUR'] > 0
