import cryptocompare_api

api_key = 'afd8aecbb2492033e21742b51400537317eef92343977ed19df7002857d642a0'


def test_get_current_price_eth():
    symbol = 'ETH'

    flag, results = cryptocompare_api.get_current_price(symbol, api_key)

    assert flag is True
    assert results['GBP'] > 0
    assert results['USD'] > 0
    assert results['EUR'] > 0


def test_get_current_price_cardano():
    symbol = 'ADA'

    flag, results = cryptocompare_api.get_current_price(symbol, api_key)

    assert flag is True
    assert results['GBP'] > 0
    assert results['USD'] > 0
    assert results['EUR'] > 0


def test_get_current_price_solana():
    symbol = 'SOL'

    flag, results = cryptocompare_api.get_current_price(symbol, api_key)

    assert flag is True
    assert results['GBP'] > 0
    assert results['USD'] > 0
    assert results['EUR'] > 0