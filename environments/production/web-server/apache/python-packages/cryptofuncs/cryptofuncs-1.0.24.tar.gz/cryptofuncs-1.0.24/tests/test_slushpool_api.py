import slushpool_api


def test_get_get_slushpool_info():
    api_key = "wtgokWtCGdj4nnh2"
    flag, results = slushpool_api.get_slushpool_info(api_key)

    assert flag == True
    assert results['username'] == 'crouchr'


