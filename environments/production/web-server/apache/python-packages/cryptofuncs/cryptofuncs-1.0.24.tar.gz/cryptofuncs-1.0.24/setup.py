# see - https://packaging.python.org/guides/hosting-your-own-index/
# run '$ pipenv run python setup.py bdist_wheel' to create a Wheel file

from setuptools import setup

setup(version='1.0.24',
      description='Functions for handling cryptocurrency',
      author='Richard Crouch',
      author_email='richard.crouch100@gmail.com',
      license='MIT',
      include_package_data=True,
      zip_safe=False,
      py_modules=[
            'xgminer_api',
            'bitcoin_rpc_client',
            'bitnodes_api',
            'coinbase_api',
            'blockchaininfo_api',
            'fmp_api',
            'glassnode_api',
            'cryptocompare_api',
            'fear_and_greed_index_api',
            'f2pool_api',
            'slushpool_api'
            ],
)
