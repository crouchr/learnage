import fmp_api


# Bitcoin Core
def test_get_symbol_info_btc():

    flag, results = fmp_api.get_symbol_info('BTCUSD')

    assert flag == True
    assert results['name'] == 'Bitcoin USD'
    assert results['price'] >= 0.0
    assert results['marketCap'] >= 0.0
    assert results['volume'] >= 0.0
    assert results['avgVolume'] >= 0.0
    assert results['priceAvg50'] >= 0.0
    assert results['priceAvg200'] >= 0.0


# Bitcoin Cash
def test_get_symbol_info_bch():

    flag, results = fmp_api.get_symbol_info('BCHUSD')

    assert flag == True
    assert results['name'] == 'Bitcoin Cash USD'
    assert results['price'] >= 0.0
    assert results['marketCap'] >= 0.0
    assert results['volume'] >= 0.0
    assert results['avgVolume'] >= 0.0
    assert results['priceAvg50'] >= 0.0
    assert results['priceAvg200'] >= 0.0
