# https://help.slushpool.com/en/support/solutions/articles/77000433512-api-configuration-guide
# curl https://slushpool.com/stats/json/btc/ -H "SlushPool-Auth-Token: <your access token>"
# curl https://slushpool.com/stats/json/btc/ -H "X-SlushPool-Auth-Token: wtgokWtCGdj4nnh2"
# r=requests.get("http://www.example.com/", headers={"content-type":"text"})

import requests
import json
import time
from pprint import pprint


def get_slushpool_info(api_key):

    api_data = {}

    try:
        # pool_endpoint = 'https://slushpool.com/stats/json/btc/'
        account_endpoint = 'https://slushpool.com/accounts/profile/json/btc/'

        headers = {'X-SlushPool-Auth-Token': api_key}
        response = requests.get(account_endpoint, headers=headers)

        if response.status_code != 200:
            return None

        response_dict = json.loads(response.content.decode('utf-8'))
        # pprint(response_dict)

        api_data['crypto'] = 'btc'
        api_data['username'] = response_dict['username']
        api_data['hashrate'] = response_dict['btc']['hash_rate_scoring']
        api_data['hashrate_5m'] = response_dict['btc']['hash_rate_5m']
        api_data['hashrate_60m'] = response_dict['btc']['hash_rate_60m']
        if api_data['hashrate_5m'] == 0:
            api_data['worker_online'] = 0
        else:
            api_data['worker_online'] = 1

        # # units are Satoshis as values are so small
        api_data['todays_estimated_revenue'] = int(100000000 * float(response_dict['btc']['estimated_reward']))
        api_data['balance'] = int(100000000 * float(response_dict['btc']['confirmed_reward']))

        return True, api_data

    except Exception as e:
        print('get_slushpool_info : Error=' + e.__str__())
        return False, None


# Test harness
if __name__ == '__main__':
    api_key = "wtgokWtCGdj4nnh2"

    while True:
        status, api_data = get_slushpool_info(api_key)

        print(time.ctime())
        pprint(api_data)

        print('\nsleeping...')
        time.sleep(60)
