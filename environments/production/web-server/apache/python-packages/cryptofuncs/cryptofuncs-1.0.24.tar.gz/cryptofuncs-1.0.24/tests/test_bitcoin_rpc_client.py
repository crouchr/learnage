import pytest

from bitcoin_rpc_client import Bitcoin


@pytest.mark.parametrize(
    "btcd_hostname, btcd_port, btcd_username, btcd_password, expected_status",
    [
        ('j1900', 8332, 'bitcoinrpc', 'protectrpcserver1928', True),
        ('j1900xxx', 8332, 'bitcoinrpc', 'protectrpcserver1928', False),
        ('j1900', 1000, 'bitcoinrpc', 'protectrpcserver1928', False),
        ('j1900', 8332, 'bitcoinrpcXXX', 'protectrpcserver1928', False),
        ('j1900', 8332, 'bitcoinrpc', 'protectrpcserver1928XXX', False),
    ]
)
def test_bitcoin_rpc_client(btcd_hostname, btcd_port, btcd_username, btcd_password, expected_status):

    bitcoin = Bitcoin(btcd_username, btcd_password, btcd_hostname, btcd_port)
    status, mining_info = bitcoin.getmininginfo()

    assert status == expected_status
