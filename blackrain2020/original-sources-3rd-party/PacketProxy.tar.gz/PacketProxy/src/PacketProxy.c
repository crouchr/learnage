/*	PacketProxy.c
	A simple TCP proxy implementation, supporting ip-based authentication.
	
	PacketProxy is licensed under the BSD-license:
	
	Copyright (c) 2003-2008, Daniel Stoedle <daniels@cs.uit.no>,
	Yellow Lemon Software. All rights reserved.
	
	Redistribution and use in source and binary forms, with or without
	modification, are permitted provided that the following conditions are met:

	- Redistributions of source code must retain the above copyright notice,
	  this list of conditions and the following disclaimer.

	- Redistributions in binary form must reproduce the above copyright notice,
	  this list of conditions and the following disclaimer in the documentation
	  and/or other materials provided with the distribution.

	- Neither the name of Yellow Lemon Software nor the names of its
	  contributors may be used to endorse or promote products derived from this
	  software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
	IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
	ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
	LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
	CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
	SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
	INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
	CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
	ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
	POSSIBILITY OF SUCH DAMAGE.
*/

#include	<pthread.h>
#include	"PacketProxy.h"
#include	"netutils.h"
#include	"ds_utils.h"
#include	<stdarg.h>
#include	"config_pp.h"

volatile unsigned long		total_in				= 0,
							total_out				= 0,
							num_threads				= 0,
							bw_in					= 0,
							bw_out					= 0;
		 unsigned long		max_threads				= kMaxThreads,
							max_bandwidth			= 0,
							bw_cap_global			= 0,
							dump_raw				= 0;
							
pthread_mutex_t		xfr_lock,
					bw_lock,
					num_threads_lock;

bool				authentication_enabled	= false,
					quit					= false;
AuthElem			*authorized_clients		= 0;
RouteElem			*routes					= 0;
int					log_level				= kLogInfo;
FILE				*log_file;

int		main(int argc, char *argv[]) {
	char	*dest_addr, *conf_file = 0;
	int		dest_port, listen_port, i, opt;
	srandom(time(0));
	log_file		= stdout;
	if (argc <= 1) {
		PrintUsage(argv[0]);
		return 0;
	}
	init_thread_safe_netutils();
	
	dest_port		= 0;
	listen_port		= kListenPort;
	dest_addr		= 0;
	opt				= kOptUndefined;
	max_bandwidth	= 0;
	for (i=1;i<argc;i++) {
		if (strcmp(argv[i], "-d") == 0)
			opt	= kOptSetDestAddr;
		else if (strcmp(argv[i], "-p") == 0)
			opt	= kOptSetDestPort;
		else if (strcmp(argv[i], "-l") == 0)
			opt	= kOptSetListenPort;
		else if (strcmp(argv[i], "-m") == 0)
			opt	= kOptSetMaxThreads;
		else if (strcmp(argv[i], "-b") == 0)
			opt = kOptSetMaxBandwidth;
		else if (strcmp(argv[i], "-g") == 0)
			bw_cap_global	= 1;
		else if (strcmp(argv[i], "-a") == 0)
			opt	= kOptSetConfFile;
		else if (strcmp(argv[i], "-v") == 0)
			opt	= kOptSetVerbosity;
		else if (strcmp(argv[i], "-f") == 0)
			opt	= kOptSetLogFile;
		else if (strcmp(argv[i], "-D") == 0)
			dump_raw	= !dump_raw;
		else {
			switch (opt) {
				case kOptSetDestAddr:
					dest_addr	= argv[i];
					break;
				case kOptSetDestPort:
					dest_port	= atoi(argv[i]);
					break;
				case kOptSetListenPort:
					listen_port	= atoi(argv[i]);
					break;
				case kOptSetMaxThreads:
					max_threads	= atoi(argv[i]);
					if (max_threads < 0)
						max_threads	= kMaxThreads;
					break;
				case kOptSetMaxBandwidth:
					max_bandwidth	= atoi(argv[i]);
					if (max_bandwidth < 0)
						max_bandwidth	= 0;	//	infinite
					break;
				case kOptSetConfFile:
					conf_file		= argv[i];
					break;
				case kOptSetLogFile:
					log_file		= fopen(argv[i], "w+");
					break;
				case kOptSetVerbosity:
					log_level		= atoi(argv[i]);
					break;
				case kOptUndefined:
					PrintUsage(argv[0]);
					return 1;
			}
			opt	= kOptUndefined;
		}
	}
	
	log(kLogInfo, "Starting PacketProxy v %d.%.2d.\n", kMajorVersion, kMinorVersion);
	log(kLogInfo, "(c) 2003-2008 Daniel Stoedle, daniels@cs.uit.no\n");
	log(kLogInfo, "The most recent version of PacketProxy can always be\n");
	log(kLogInfo, "found here: http://www.cs.uit.no/~daniels/PacketProxy\n");
	
	if (listen_port <= 0) {
		log(kLogError, "Invalid listening port specified -- reverting to default port (%d).\n", kListenPort);
		listen_port	= kListenPort;
	}
	
	if (max_bandwidth)
		log(kLogDebug, "Bandwidth capped at %d bytes/s\n", max_bandwidth);
	
	if (dest_addr && dest_port > 0) {
		routes	= (RouteElem*)malloc(sizeof(RouteElem));
		routes->dest_addr	= malloc(strlen(dest_addr)+1);
		strcpy(routes->dest_addr, dest_addr);
		routes->dest_port	= dest_port;
		routes->listen_port	= listen_port++;
		routes->sock		= 0;
		routes->route_no	= 0;
		routes->chain		= routes;
		routes->chain_mark	= 1;
		routes->next		= 0;
	}
	else if (dest_addr && dest_port <= 0)
		log(kLogError, "Invalid destination port -- ignoring route to %s.\n", dest_addr);
	
	if (conf_file)
		LoadConfig(conf_file, listen_port);
	
	if (routes == 0) {
		log(kLogError, "You must specify atleast one destination address and port.\n");
		return 1;
	}
	signal(SIGPIPE, SIG_IGN);
	//	signal(SIGINT, do_quit);
	pthread_mutex_init(&xfr_lock, 0);
	pthread_mutex_init(&bw_lock, 0);
	pthread_mutex_init(&num_threads_lock, 0);
	StartProxy();
	
	//	Clean up
	if (log_file != stdout)
		fclose(log_file);
	log(kLogInfo, "PacketProxy is exiting.\n");
	return 0;
}


void		do_quit(int signal) {
	time_t	t;
	
	quit	= true;
	log(kLogInfo, "Received interrupt -- waiting for threads to exit..\n");
	t		= time(0);
	//	Wait for other threads. In case something hangs, don't wait for more than 1 second
	while (num_threads > 0 && (t+1) > time(0))
		sleep(1);
}


void		PrintUsage(char *exec_name) {
	printf("PacketProxy v %d.%.2d.\n", kMajorVersion, kMinorVersion);
	printf("Usage: %s -d <destination host name> -p <destination port> [-l <listening port>] [-m <max threads>] [-a <config file>] [-f <logfile>] [-v <level>]\n", exec_name);
	printf("   -d: Destination address, a hostname or an IP address.\n");
	printf("   -p: The destination port number, to which packets will be redirected.\n");
	printf("   -l: The port on which PacketProxy will listen for incoming connections (the default is %d).\n", kListenPort);
	printf("   -m: The maximum number of threads PacketProxy will ever spawn simultaneously (default is %d).\n", kMaxThreads);
	printf("   -b: The maximum amount of bandwidth used, in b/s, allowed per thread.\n");
//	printf("   -g: Makes the bandwidth cap supplied with -b global (ie, not per thread).\n");
	printf("   -a: Load configuration from <config file>\n");
	printf("   -f: Log file\n");
	printf("   -v: Verbosity level (-1 to 4, where -1 is no output, and 4 is all output)\n");
	printf("   -D: Dump forwarded streams\n");
}


/*	StartServer: This function opens a listening socket on port <port>, forking a
	new pthread for every connection accepted.
*/
void		StartProxy() {
	int					new_sock, addrLen, max_sock;
	struct sockaddr_in	addr;
	ProxyThreadInfo		*info;
	pthread_t			pid;
	char				*ip_str;
	fd_set				set;
	struct timeval		time;
	RouteElem			*r, *p_r, *chain;
	
	max_sock			= 0;
	p_r					= 0;
	r					= routes;
	while (r!=0) {
		log(kLogDebug, "Attempting to open socket on port %d.\n", r->listen_port);
		r->sock			= CreateServerSocket(r->listen_port);
		if (r->sock > max_sock)
			max_sock	= r->sock;
		if (!r->sock) {
			log(kLogError, "Route %d: Failed to open server socket.\n", r->route_no);
			if (p_r)
				p_r->next	= r->next;
			else {
				routes		= r->next;
				p_r			= 0;
			}
			
			free(r->dest_addr);
			free(r);
			r	= ((p_r == 0) ? routes : p_r);
			continue;
		}
		else
			listen(r->sock, 10);
		
		p_r	= r;
		r	= r->next;
	}
	if (max_sock == 0) {
		log(kLogError, "No sockets could be opened -- no point in continuing.\n");
		return;
	}
	max_sock++;
	
	//	Print forward list
	log(kLogInfo, "Verbosity level is set to %d.\n", log_level);
	for (r=routes;r!=0;r=r->next) {
		log(kLogInfo, "Forwarding localhost:%d to %s:%d\n", r->listen_port, r->dest_addr, r->dest_port);
		chain	= r->chain;
		while (chain && chain != r) {
			log(kLogInfo, "  Chaining localhost:%d to %s:%d\n", r->listen_port, chain->dest_addr, chain->dest_port);
			chain	= chain->chain;
		}
	}
	//	Listen for connections on all sockets
	while (!quit && routes != 0) {
		FD_ZERO(&set);
		for (r=routes;r!=0;r=r->next)
			FD_SET(r->sock, &set);
		
		time.tv_sec		= 1;
		time.tv_usec	= 0;
		if (select(max_sock, &set, 0, 0, &time) > 0) {
			for (r=routes;r!=0;r=r->next) {
				if (!FD_ISSET(r->sock, &set))
					continue;
				
				chain	= r->chain;
				if (!r->chain_mark) {
					while (chain && !chain->chain_mark)
						chain	= chain->chain;
				}
				else
					chain	= r;
				
				//	Accept connections
				addrLen			= sizeof(struct sockaddr);
				new_sock		= accept(r->sock, (struct sockaddr*)&addr, &addrLen);
				ip_str			= f_inet_ntoa((long)addr.sin_addr.s_addr);
				log(kLogInfo, "  Incoming: %s   Routing to %s:%d\n", ip_str, chain->dest_addr, chain->dest_port);
				free(ip_str);
				if (authentication_enabled) {
					if (!Authenticate((long)addr.sin_addr.s_addr)) {
						close(new_sock);
						new_sock	= 0;
						continue;
					}
				}
				chain->chain->chain_mark	= 1;
				if (chain->chain != chain)
				  chain->chain_mark			= 0;
				info			= (ProxyThreadInfo*)malloc(sizeof(ProxyThreadInfo));
				info->sock		= new_sock;
				info->client_ip	= (long)addr.sin_addr.s_addr;
				info->dest_port	= chain->dest_port;
				info->dest_addr	= chain->dest_addr;
				pthread_mutex_lock(&num_threads_lock);
				if (num_threads >= max_threads) {
					log(kLogEvent, "Maximum thread count (%ld) exceeded, dropping incoming connection.\n", max_threads);
					close(new_sock);
					free(info);
					pthread_mutex_unlock(&num_threads_lock);
					continue;
				}
				else {
					num_threads++;
					pthread_mutex_unlock(&num_threads_lock);
				}
				if (pthread_create(&pid, 0, ProxyThread, info) != 0) {
					log(kLogError, "Couldn't create thread! Dropping incoming connection.\n");
					close(new_sock);
					free(info);
				}
				else
					pthread_detach(pid);
			}
		}
	}
}


/*	ProxyThread: This serves as the entry point for all proxy-threads.
	
*/
void*		ProxyThread(void *args) {
	ProxyThreadInfo		*info;
	int					fwd_sock, client_sock, sock_max;
	fd_set				set;
	struct timeval		sel_time;
	char				*buf, *ip_str, name[32];
	unsigned long		xfrd_in, xfrd_out, xfrd_in_tmp, xfrd_out_tmp;
	long				quota[2];
	FILE				*raw[2];
	time_t				last;
	
	/*
	unsigned long		th_bw_in, th_bw_out;
	time_t				last_measure;
	*/
	
	info		= (ProxyThreadInfo*)args;
	//	Connect to the destination
	client_sock	= info->sock;
	fwd_sock	= CreateClientSocketFromName(info->dest_addr, info->dest_port, 0);
	if (!fwd_sock) {
		log(kLogError, "Connect to destination host [%s] failed.\n", info->dest_addr);
		close(client_sock);
		free(info);
		pthread_mutex_lock(&num_threads_lock);
		num_threads--;
		pthread_mutex_unlock(&num_threads_lock);
		return 0;
	}
	sock_max	= (fwd_sock < client_sock ? client_sock : fwd_sock);
	buf			= malloc(kBufSize);
	xfrd_in		= 0;
	xfrd_out	= 0;
	if (dump_raw) {
		sprintf(name, "raw_%ld", random());
		raw[0]  = fopen(name, "w");
		log(kLogInfo, "Stream 1 logging to file %s\n", name);
		sprintf(name, "raw_%ld", random());
		raw[1]  = fopen(name, "w");
		log(kLogInfo, "Stream 2 logging to file %s\n", name);
	}
	else {
		raw[0]  = 0;
		raw[1]  = 0;
	}
	//	Run a loop, exchangig traffic between the two peers
	last	= time(0);
	while (client_sock && fwd_sock && !quit) {
		FD_ZERO(&set);
		FD_SET(client_sock, &set);
		FD_SET(fwd_sock, &set);
		
		sel_time.tv_sec		= 1;
		sel_time.tv_usec	= 0;
		xfrd_in_tmp		= 0;
		xfrd_out_tmp	= 0;
		if (select(sock_max + 1, &set, 0, 0, &sel_time) > 0) {
			if (last+1 < time(0)) {
				last		= time(0);
				quota[0]	= max_bandwidth;
				quota[1]	= max_bandwidth;
			}
			if (FD_ISSET(client_sock, &set))
				xfrd_out_tmp	+= ForwardData(&client_sock, &fwd_sock, buf, raw[0], &quota[0]);
			if (FD_ISSET(fwd_sock, &set))
				xfrd_in_tmp		+= ForwardData(&fwd_sock, &client_sock, buf, raw[1], &quota[1]);
			
			if (max_bandwidth && (quota[0] <= 0 || quota[1] <= 0)) {
				sleep(1);
			}
		}
		if (xfrd_in_tmp > 0 || xfrd_out_tmp > 0) {
			pthread_mutex_lock(&xfr_lock);
			total_out		+= xfrd_out_tmp;
			total_in		+= xfrd_in_tmp;
			pthread_mutex_unlock(&xfr_lock);
			xfrd_out		+= xfrd_out_tmp;
			xfrd_in			+= xfrd_in_tmp;
		}
		//	Update bandwidth usage
		/*
		th_bw_in		+= xfrd_in_tmp;
		th_bw_out		+= xfrd_out_tmp;
		th_bw_in		>>= 1;
		th_bw_out		>>= 1;
		*/
	}
	//	Close sockets
	if (client_sock)
		close(client_sock);
	if (fwd_sock)
		close(fwd_sock);
	
	if (dump_raw) {
		fflush(raw[0]);
		fflush(raw[1]);
		fclose(raw[0]);
		fclose(raw[1]);
		raw[0]  = raw[1]	= 0;
		log(kLogInfo, "Log was successful.\n");
	}
				
	//	Print stats
	pthread_mutex_lock(&xfr_lock);
	ip_str	= f_inet_ntoa(info->client_ip);
	log(kLogEvent, "   Closing: %s\n", ip_str);
	free(ip_str);
	log(kLogInfo, "     Total in: %8ld kb    Session: %8ld b\n", total_in / 1024, xfrd_in);
	log(kLogInfo, "    Total out: %8ld kb    Session: %8ld b\n", total_out / 1024, xfrd_out);
	pthread_mutex_unlock(&xfr_lock);
	pthread_mutex_lock(&num_threads_lock);
	num_threads--;
	pthread_mutex_unlock(&num_threads_lock);
	
	//	Clean up
	free(info);
	free(buf);
	return 0;
}


long		ForwardData(int *sock_from, int *sock_to, char *buf, FILE *raw_file, long *quota) {
	int		rcvd, sent, buf_size;
	
	if (*sock_from == 0 || *sock_to == 0)
		return 0;
	
	buf_size		= kBufSize;
	if (max_bandwidth > 0) {
		if (*quota <= 0)
			return 0;
		else if (*quota < kBufSize)
			buf_size	= *quota;
	}
		
	rcvd		= recv(*sock_from, buf, buf_size, 0);
	if (rcvd <= 0) {
		close(*sock_from);
		*sock_from	= 0;
		return 0;
	}
	*quota			-= rcvd;
	if (raw_file) {
		fwrite(buf, 1, rcvd, raw_file);
		fflush(raw_file);
	}
	sent		= send(*sock_to, buf, rcvd, 0);
	if (sent <= 0) {
		close(*sock_to);
		*sock_to	= 0;
		return 0;
	}
	return rcvd;
}


bool	Authenticate(long ip) {
	AuthElem			*auth	= authorized_clients;
	long				comp_ip;
	int					i;
	struct hostent     	*hInfo;
	char				*ip_str, *filter, *filter_mask;
	
	ip_str		= f_inet_ntoa(ip);
	while (auth != 0) {
		if (auth->is_dns) {
			hInfo	= ts_gethostbyname(auth->u.dns.name);
			i		= 0;
			for (i=0;hInfo->h_addr_list[i] != 0;i++) {
				comp_ip	= *(long*)hInfo->h_addr_list[i];
				if (ip == comp_ip) {
					log(kLogEvent, "Authorized: %s [Rule: %3d]\n", ip_str, auth->rule_no);
					free(ip_str);
					ts_ghbn_done();
					return true;
				}
			}
			ts_ghbn_done();
		}
		else {
			if ((auth->u.ip.addr & auth->u.ip.mask) == (ip & auth->u.ip.mask)) {
				filter		= f_inet_ntoa(auth->u.ip.addr);
				filter_mask	= f_inet_ntoa(auth->u.ip.mask);
				log(kLogEvent, "Authorized: %s [Rule: %3d]\n", ip_str, auth->rule_no);
				free(ip_str), free(filter), free(filter_mask);
				return true;
			}
		}
		auth	= auth->next;
	}
	log(kLogInfo, "  Rejected: %s\n", ip_str);
	free(ip_str);
	return false;
}


char*	f_inet_ntoa(long ip) {
	char	*str = malloc(16);
	
	snprintf(str, 16, "%3ld.%3ld.%3ld.%3ld", ip & 0xff, (ip >> 8) & 0xff, (ip >> 16) & 0xff, (ip >> 24) & 0xff);
	return str;
}


void	log(int level, char *fmt, ...) {
	va_list	args;
	const char *header[]	= { "ERROR: ",
								" INFO: ",
								"EVENT: ",
								"EXTRA: ",
								"DEBUG: " };
	
	if (level <= log_level) {
		va_start(args, fmt);
		TimeStamp(0), fprintf(log_file, "%s", header[level]), vfprintf(log_file, fmt, args);
		va_end(args);
		if (log_file != stdout)
			fflush(log_file);
	}
}
