/*	netutils.c
	PacketProxy is licensed under the BSD-license:
	
	Copyright (c) 2002-2008, Daniel Stoedle <daniels@cs.uit.no>,
	Yellow Lemon Software. All rights reserved.
	
	Redistribution and use in source and binary forms, with or without
	modification, are permitted provided that the following conditions are met:

	- Redistributions of source code must retain the above copyright notice,
	  this list of conditions and the following disclaimer.

	- Redistributions in binary form must reproduce the above copyright notice,
	  this list of conditions and the following disclaimer in the documentation
	  and/or other materials provided with the distribution.

	- Neither the name of Yellow Lemon Software nor the names of its
	  contributors may be used to endorse or promote products derived from this
	  software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
	IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
	ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
	LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
	CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
	SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
	INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
	CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
	ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
	POSSIBILITY OF SUCH DAMAGE.
*/

#include	"netutils.h"

int			CreateMCSocket(char *mcAddr, int port, int connectIt) {
	struct sockaddr_in	destAddr,
						addr; 
	struct hostent     	*hInfo;
	struct ip_mreq		mreq;
	int					sock, yes = 1;
	char				loop = 1;
	
	sock = socket(AF_INET, SOCK_DGRAM, 0); 
	if (sock < 0) {
		//perror("CreateMCSocket: Unable to create socket");
		return 0; 
	}
	memset(&addr, 0, sizeof(addr));
	addr.sin_family			= AF_INET;
	addr.sin_addr.s_addr	= htonl(INADDR_ANY);
	addr.sin_port			= htons(port);
	
	if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) < 0) {
		//perror("CreateMCSocket: Got an error setting socket option SO_REUSEADDR");
		close(sock);
		return 0;
	}
	
	if (bind(sock, (struct sockaddr*) &addr, sizeof(addr)) < 0) {
		//perror("CreateMCSocket: Bind failed");
		close(sock);
		return 0;
	}
	
	hInfo = ts_gethostbyname(mcAddr);
	if (hInfo == NULL) {
		ts_ghbn_done();
		//perror("CreateMCSocket: gethostbyname failed");
		close(sock);
		return 0;
	}
	destAddr.sin_addr.s_addr	= *(in_addr_t*)hInfo->h_addr_list[0];
	destAddr.sin_port			= htons(port);
	destAddr.sin_family			= AF_INET;
	
	mreq.imr_multiaddr.s_addr	= destAddr.sin_addr.s_addr;
	mreq.imr_interface.s_addr	= htonl(INADDR_ANY);
	
	if (setsockopt(sock, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char*) &mreq, sizeof(mreq)) < 0) {
		ts_ghbn_done();
		//perror("CreateMCSocket: Got an error setting socket option IP_ADD_MEMBERSHIP");
		close(sock);
		return 0;
	}
	setsockopt(sock, IPPROTO_IP, IP_MULTICAST_LOOP, &loop, sizeof(char));
	if (connectIt)
		connect(sock, (struct sockaddr*)&destAddr, sizeof(struct sockaddr));
	
	ts_ghbn_done();
	return sock;
}


int			CreateUDPSocket(in_addr_t ip, int port, int connectIt) {
	struct sockaddr_in	destAddr,
						addr; 
	int					sock, yes = 1;
	
	sock = socket(AF_INET, SOCK_DGRAM, 0); 
	if (sock < 0) {
		//perror("CreateUDPSocket: Unable to create socket");
		return 0; 
	}
	memset(&addr, 0, sizeof(addr));
	addr.sin_family			= AF_INET;
	addr.sin_addr.s_addr	= htonl(INADDR_ANY);
	if (!connectIt)
		addr.sin_port		= htons(port);
	else
		addr.sin_port		= 0;
	
	if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) < 0) {
		//perror("CreateUDPSocket: Got an error setting socket option SO_REUSEADDR");
		close(sock);
		return 0;
	}
	
	if (bind(sock, (struct sockaddr*) &addr, sizeof(addr)) < 0) {
		//perror("CreateUDPSocket: Bind failed");
		close(sock);
		return 0;
	}
	
	if (connectIt) {
		destAddr.sin_addr.s_addr	= ip;
		destAddr.sin_port			= htons(port);
		destAddr.sin_family			= AF_INET;
		connect(sock, (struct sockaddr*)&destAddr, sizeof(struct sockaddr));
	}
	return sock;
}


int		CreateServerSocket(int port) {
	int						sock, yes = 1;
	struct sockaddr_in		addr;
	
	sock					= socket(AF_INET, SOCK_STREAM, 0);
	//	To avoid errors when attempting to bind the socket to the given port, specify
	//	that we want to reuse the port number, if the port number has been recently used.
	if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) {
		//perror("CreateServerSocket: Got an error setting socket option SO_REUSEADDR");
		close(sock);
		return 0;
	}
	
	//	Bind the socket to port <port>
	addr.sin_family			= AF_INET;
	addr.sin_port			= htons(port);
	addr.sin_addr.s_addr	= INADDR_ANY;
	memset(&(addr.sin_zero), '\0', 8);
	if (bind(sock, (struct sockaddr*)&addr, sizeof(struct sockaddr)) == -1) {
		//perror("CreateServerSocket: Got an error binding the socket");
		close(sock);
		return 0;
	}
	return sock;
}


int			CreateClientSocketFromName(char *host, int port, struct sockaddr_in *hostAddr) {
	struct hostent			*hInfo;
	in_addr_t				server;
	
	hInfo					= ts_gethostbyname(host);
	if (!hInfo) {
		ts_ghbn_done();
		//printf("CreateClientSocketFromName: gethostbyname failed.\n");
		return 0;
	}
	server					= *(in_addr_t*)hInfo->h_addr_list[0];
	ts_ghbn_done();
	
	return CreateClientSocket(server, port, hostAddr);
}


int			CreateClientSocket(in_addr_t ip, int port, struct sockaddr_in *hostAddr) {
	int						sock, yes = 1;
	struct sockaddr_in		addr;
	
	sock					= socket(AF_INET, SOCK_STREAM, 0);
	if (!sock) {
		//perror("CreateClientSocketFromName: Got an error creating a TCP socket");
		return 0;
	}
	if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) {
		//perror("CreateClientSocketFromName: Got an error setting a socket option");
		return 0;
	}
	
	addr.sin_family			= AF_INET;
	addr.sin_port			= htons(port);
	addr.sin_addr.s_addr	= ip;
	memset(&(addr.sin_zero), '\0', 8);
	if (hostAddr)
		*hostAddr			= addr;
	
	if (connect(sock, (struct sockaddr*)&addr, sizeof(struct sockaddr)) == -1) {
		//printf("CreateClientSocket: Connect failed.\n");
		return 0;
	}
	return sock;	
}


void	TimeStamp(FILE *out) {
    time_t		t;
	struct tm	*result;
	
	if (out == 0)
		out	= stdout;
	
	t			= time(0);
	result		= localtime(&t);
	if (result->tm_mday < 10)
		fprintf(out, "[0%d/", result->tm_mday);
	else
		fprintf(out, "[%d/", result->tm_mday);
	
	if (result->tm_mon < 9)
		fprintf(out, "0%d-", result->tm_mon+1);
	else
		fprintf(out, "%d-", result->tm_mon+1);
	
	if (result->tm_year > 100) {
		result->tm_year -= 100;
		if (result->tm_year > 10)
			fprintf(out, "20%d | ", result->tm_year);
		else
			fprintf(out, "200%d | ", result->tm_year);
	}
	else
		fprintf(out, "19%d | ", result->tm_year);
	
	if (result->tm_hour < 10)
		fprintf(out, "0%d:", result->tm_hour);
	else
		fprintf(out, "%d:", result->tm_hour);
	
	if (result->tm_min < 10)
		fprintf(out, "0%d:", result->tm_min);
	else
		fprintf(out, "%d:", result->tm_min);
	
	if (result->tm_sec < 10)
		fprintf(out, "0%d]\t", result->tm_sec);
	else
		fprintf(out, "%d]\t", result->tm_sec);
}


/*	Thread safe functions for calling gethostbyname, and accessing the returned
	hostent structure. Proper usage requires that all calls to gethostbyname first
	call ThreadSafe_gethostbyname(..), and then call ThreadSafe_ghbn_done() to indicate
	that others may call TS_ghbn.
*/
static pthread_mutex_t	ghbn_lock;

void	init_thread_safe_netutils(void) {
	pthread_mutex_init(&ghbn_lock, 0);
}


struct hostent*	ts_gethostbyname(char *name) {
	pthread_mutex_lock(&ghbn_lock);
	return gethostbyname(name);
}


void	ts_ghbn_done(void) { pthread_mutex_unlock(&ghbn_lock); }
