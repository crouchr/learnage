/*	ds_utils.c
	PacketProxy is licensed under the BSD-license:
	
	Copyright (c) 2004-2008, Daniel Stoedle <daniels@cs.uit.no>,
	Yellow Lemon Software. All rights reserved.
	
	Redistribution and use in source and binary forms, with or without
	modification, are permitted provided that the following conditions are met:

	- Redistributions of source code must retain the above copyright notice,
	  this list of conditions and the following disclaimer.

	- Redistributions in binary form must reproduce the above copyright notice,
	  this list of conditions and the following disclaimer in the documentation
	  and/or other materials provided with the distribution.

	- Neither the name of Yellow Lemon Software nor the names of its
	  contributors may be used to endorse or promote products derived from this
	  software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
	IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
	ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
	LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
	CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
	SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
	INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
	CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
	ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
	POSSIBILITY OF SUCH DAMAGE.
*/

#include	"ds_utils.h"
#include	<stdarg.h>
#include	<stdio.h>
#include	<ctype.h>
#include	<string.h>

/*	ds_strtok: Takes as input a constant string, and a set of tokens.
	The return value is the length of the substring, starting at strStart,
	that ends with one of the tokens in <tokens>. Note that the token is
	*not* included in the length of the substring.
*/
int32_t	ds_strtok(const char *strStart, const char *tokens) {
	int32_t	i, x, done;
	
	done	= 0;
	i		= 0;
	while (strStart[i] != 0 && !done) {
		x	= 0;
		while (tokens[x] != 0) {
			if (tokens[x] == strStart[i]) {
				done	= 1;
				break;
			}
			x++;
		}
		i++;
	}
	return (i-1);
}


/*	ds_strsrch: Searches strStart for the first occurence of word. If ignore_case
	is set, the characters of strStart are converted to lowercase before comparison
	with word. It is assumed that the characters of word are allready all lowercase.
	Returns the offset of the first character following the string searched for.
*/
int32_t	ds_strsrch(const char *strStart, const char *word, bool ignore_case) {
	int32_t		i, x, found;
	char		a;
	
	i		= 0;
	x		= 0;
	found	= 0;
	while (strStart[i] != 0 && !found) {
		if (ignore_case)
			a	= tolower(strStart[i]);
		else
			a	= strStart[i];
		
		if (a == word[x]) {
			x++;
			if (word[x] == 0) {
				found	= 1;
			}
		}
		else
			x = 0;
		
		i++;
	}
	if (found)
		return i;
	else
		return -1;
}

/*	ds_parse_elem: Will parse out Test from the following string, given these arguments:
	ds_parse_elem("<FORM NAME="test"", "NAME="", dst, 1);
	-> dst = test

*/
int32_t	ds_parse_elem(const char *strStart, const char *key, char *dst, bool ignore_case) {
	int32_t		offset, tmp;
	
	//	TODO: Add bounds checking
	dst[0]		= 0;
	offset		= ds_strsrch(strStart, key, ignore_case);
	if (offset != -1) {
		//	Copy contents of string
		tmp		= ds_strsrch(strStart+offset, "\"", 0);
		if (tmp != -1) {
			memcpy(dst, strStart+offset, tmp-1);
			dst[tmp-1]	= 0;
			return tmp+offset;
		}
	}
	return -1;
}


int		skip_whitespace(char *buf, int idx) {
	while (buf[idx] != 0) {
		if (buf[idx] == ' ' || buf[idx] == '\t')
			idx++;
		else
			break;
	}
	return idx;
}

#ifndef NDEBUG
void		dprintf(const char *fmt, ...) {
	va_list	args;
	
	va_start(args, fmt);
	vprintf(fmt, args);
	va_end(args);
}
#endif
