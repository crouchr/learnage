/*	config_pp.c
	PacketProxy is licensed under the BSD-license:
	
	Copyright (c) 2004-2008, Daniel Stoedle <daniels@cs.uit.no>,
	Yellow Lemon Software. All rights reserved.
	
	Redistribution and use in source and binary forms, with or without
	modification, are permitted provided that the following conditions are met:

	- Redistributions of source code must retain the above copyright notice,
	  this list of conditions and the following disclaimer.

	- Redistributions in binary form must reproduce the above copyright notice,
	  this list of conditions and the following disclaimer in the documentation
	  and/or other materials provided with the distribution.

	- Neither the name of Yellow Lemon Software nor the names of its
	  contributors may be used to endorse or promote products derived from this
	  software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
	IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
	ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
	LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
	CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
	SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
	INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
	CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
	ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
	POSSIBILITY OF SUCH DAMAGE.
*/

#include	"config_pp.h"
#include	"ds_utils.h"
#include	"PacketProxy.h"

extern bool	authentication_enabled;

/*	InitAuthentication:
	Handles setting up the authentication structure, and parsing the authentication
	file.
*/
void		LoadConfig(char *conf_file_name, int start_listen_port) {
	FILE	*cf;
	char	*buf;
	long	len, res;
	
	authentication_enabled	= false;
	if (conf_file_name == 0) {
		log(kLogError, "No config file provided!\n");
		return;
	}
	cf						= fopen(conf_file_name, "r");
	if (!cf) {
		log(kLogError, "Couldn't find config file: %s\n", conf_file_name);
		return;
	}
	
	fseek(cf, 0, SEEK_END);
	len	= ftell(cf);
	fseek(cf, 0, SEEK_SET);
	if (len <= 0) {
		log(kLogError, "Config file is empty.\n");
		return;
	}
	buf	= malloc(len+1);
	if (!buf)
		return;
	
	log(kLogDebug, "Using config file %s.\n", conf_file_name);	
	res	= fread(buf, len, 1, cf);
	if (res <= 0) {
		log(kLogError, "Error (%d) reading config file!\n", res);
		free(buf);
		fclose(cf);
		return;
	}
	fclose(cf);
	buf[len]	= 0;
	ParseConfig(buf, len+1, start_listen_port);
	if (authorized_clients)
		authentication_enabled	= true;
	
	free(buf);
}


/*	ParseConfig:
	Parses the authentication configuration read from a file. The format is as follows:
	- Anything following a # (a hash) is ignored, until a newline is encountered.
	- Any other line is treated either as a hostname/ip address, or an ip-address with mask,
	  depending on the qualifier used (H for a dns name, I for an ip-address with optional mask)
	# These are the hosts allowed to connect for forwarding
	H www.abc.com
	I 143.117.22.22
	I 143.117.22.22 255.255.255.0	
	
	ie, <host> or <ip> [mask]
	# Requested proxies (T for forward, C for chain to previous forward)
	# Format: {T, C} <destination> <port> [listen-port]
	# listen-port defaults to 1999. Successive rules
	# will default to ports 1999+1, 1999+2, etc.
	T localhost 65534 1
	T localhost 65535 1999

	
*/
void	ParseConfig(char *buf, long len, int start_listen_port) {
	const char	*tokens	= " #\t\n";
	
	int			idx	= 0, sub_len, a, b, c, d;
	char		*host_or_ip, *mask;
	AuthElem	*auth, *auth_tail;
	RouteElem	*route, *route_tail, *tmp;
	int			state = 0, line = 1, chain = 0;
	
	auth		= 0;
	auth_tail	= 0;
	route		= 0;
	route_tail	= routes;	//	In case we have a route already, passed in via the command line
	while (idx < len && buf[idx] != 0) {
		if (buf[idx] == '\n') {
			idx++;
			line++;
		}
		if (buf[idx] == '#') {
			//	scan to next newline
			sub_len	= ds_strtok(buf+idx, "\n");
			if (sub_len <= 0)
				break;
			
			idx	+= sub_len;
		}
		else if (buf[idx] == 'H') {
			state	= kParseHostName;
			idx++;
		}
		else if (buf[idx] == 'I') {
			state	= kParseIP;
			idx++;
		}
		else if (buf[idx] == 'T' || buf[idx] == 'C') {
			chain	= 0;
			if (buf[idx] == 'C') {
				if (!route_tail)
					log(kLogError, "Trying to chain a route (line %d) without specifying 'root' route first.\n", line);
				else
					chain	= 1;
			}
			state	= kParseRoute;
			idx++;
		}
		else if (buf[idx] == ' ' || buf[idx] == '\t')
			idx++;
		else {
			if (state == kParseHostName) {
				//	rest of line is a hostname
				sub_len	= ds_strtok(buf+idx, tokens);
				if (sub_len <= 0)
					break;
				host_or_ip	= malloc(sub_len+1);
				memcpy(host_or_ip, buf+idx, sub_len);
				host_or_ip[sub_len]	= 0;
				
				idx	+= sub_len;
				auth				= (AuthElem*)malloc(sizeof(AuthElem));
				auth->is_dns		= true;
				auth->u.dns.name	= host_or_ip;
				state				= kNoState;
				auth->rule_no		= line;
			}
			else if (state == kParseIP || state == kParseMask) {
				if (state == kParseIP) {
					auth			= (AuthElem*)malloc(sizeof(AuthElem));
					auth->is_dns	= false;
				}
				sub_len	= sscanf(buf+idx, "%d.%d.%d.%d", &a, &b, &c, &d);
				if (sub_len < 4 && state == kParseIP) {
					free(auth);
					state			= kNoState;
					log(kLogError, "Malformed input line (%d) in authentication config.\n", line);
					sub_len			= ds_strtok(buf+idx, "\n");
					idx				+= sub_len+1;
					line++;
					
					auth			= 0;
					continue;
				}
				else if (sub_len < 4 && state == kParseMask) {
					state	= kNoState;
					continue;
				}
				if (state == kParseIP) {
					auth->rule_no	= line;
					auth->u.ip.addr	= d<<24|c<<16|b<<8|a;
					auth->u.ip.mask	= 0xFFFFFFFF;
					state			= kParseMask;
				}
				else {
					auth->u.ip.mask	= d<<24|c<<16|b<<8|a;
					state			= kNoState;
				}
				sub_len				= ds_strtok(buf+idx, tokens);
				idx					+= sub_len;
			}
			else if (state == kParseRoute) {
				if (route != 0) {
					log(kLogDebug, "Leaking memory due to recursive route definition (%d). Should not happen!\n", route->route_no);
				}
				//	Parse a line of the form <host/ip> <port number> [listen port]
				route				= (RouteElem*)malloc(sizeof(RouteElem));
				route->dest_addr	= 0;
				route->dest_port	= -1;
				route->listen_port	= -1;
				route->route_no		= line;
				route->sock			= 0;
				if (chain) {
					route->chain	= route_tail;
					tmp				= route_tail;
					while (tmp->chain != route_tail)
						tmp	= tmp->chain;
					
					tmp->chain		= route;
				}
				else
					route->chain	= route;
				
				route->chain_mark	= !chain;
				//	Get destination host
				sub_len	= ds_strtok(buf+idx, tokens);
				if (sub_len <= 0)
					break;
				host_or_ip			= malloc(sub_len+1);
				memcpy(host_or_ip, buf+idx, sub_len);
				host_or_ip[sub_len]	= 0;
				idx	+= sub_len;
				
				route->dest_addr	= host_or_ip;
				state				= kParsePorts;
			}
			else if (state == kParsePorts) {
				//	Parse dest port and listen-port
				sub_len		= sscanf(buf+idx, "%d", &a);
				if (sub_len <= 0 || (a <= 0 || a > 65535)) {
					//	Route will be freed by check further down
					if (sub_len <= 0 && route->dest_port == -1)
						log(kLogError, "Route %d lacks mandatory specification of destination port.\n", route->route_no);
					else if (sub_len > 0)
						log(kLogError, "Route %d has invalid ports specified (%d). Ports must be in range 1-65535.\n", route->route_no, a);
				}
				else {
					if (route->dest_port == -1) {
						log(kLogDebug, "Setting dest port of route %d to %d.\n", route->route_no, a);
						route->dest_port	= a;
						sub_len	= ds_strtok(buf+idx, tokens);
						if (sub_len <= 0)
							route->listen_port	= start_listen_port++;
						else {
							idx		+= sub_len;
							continue;
						}
					}
					else
						route->listen_port	= a;
				}
				state	= kNoState;
			}
			else
				idx++;
		}
		if (auth) {
			auth->next			= 0;
			if (auth_tail == 0) {
				authorized_clients	= auth;
				auth_tail				= auth;
			}
			else if (auth_tail != auth) {
				auth_tail->next	= auth;
				auth_tail		= auth;
			}
		}
		if (route) {
			if ((route->dest_port == -1 || route->listen_port == -1) && state == kParsePorts)
				continue;
			else if (state != kParsePorts) {
				if (route->dest_port != -1 && route->listen_port == -1 && route->chain_mark) {
					if (start_listen_port > 65535)
						log(kLogError, "Route %d would be listening to a port out of range [1-65535]. Ignoring this route.\n", route->route_no);
					else
						route->listen_port	= start_listen_port++;
				}
				if (route->dest_port == -1 || (route->listen_port == -1 && route->chain_mark) || route->listen_port > 65535) {
					log(kLogError, "Dropping route %d to %s.\n", route->route_no, route->dest_addr);
					tmp = route->chain;
					while (tmp->chain != route && tmp->chain) {
						tmp  = tmp->chain;
					}
					if (tmp->chain)
						tmp->chain  = route->chain;
					
					if (tmp->chain)
						log(kLogDebug, "Patching chain: %s now chained to %s\n", tmp->dest_addr, tmp->chain->dest_addr);
					
					free(route->dest_addr);
					free(route);
					route	= 0;
				}
			}
			if (route) {
				if (route->chain_mark) {
					log(kLogDebug, "Adding route %d - %s:%d on port %d.\n", route->route_no, route->dest_addr, route->dest_port, route->listen_port);
					route->next				= 0;
					if (route_tail == 0) {
						routes				= route;
						route_tail			= route;
					}
					else if (route_tail != route) {
						route_tail->next	= route;
						route_tail			= route;
					}
				}
				else {
					log(kLogDebug, "Chaining route %d - %s:%d.\n", route->route_no, route->dest_addr, route->dest_port, route->listen_port);
					
				}
				route	= 0;
			}
		}
	}
	
	//	Print auth list
	auth		= authorized_clients;
	while (auth != 0) {
		if (auth->is_dns)
			log(kLogVerbose, "       Allowing host: %s\n", auth->u.dns.name);
		else {
			host_or_ip	= f_inet_ntoa(auth->u.ip.addr);
			mask		= f_inet_ntoa(auth->u.ip.mask);
			log(kLogVerbose, "  Allowing IP [mask]: %s [%s]\n", host_or_ip, mask);
			free(host_or_ip);
			free(mask);
		}
		auth	= auth->next;
	}
}
