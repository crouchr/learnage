/*	PacketProxy.h
	PacketProxy is licensed under the BSD-license:
	
	Copyright (c) 2003-2008, Daniel Stoedle <daniels@cs.uit.no>,
	Yellow Lemon Software. All rights reserved.
	
	Redistribution and use in source and binary forms, with or without
	modification, are permitted provided that the following conditions are met:

	- Redistributions of source code must retain the above copyright notice,
	  this list of conditions and the following disclaimer.

	- Redistributions in binary form must reproduce the above copyright notice,
	  this list of conditions and the following disclaimer in the documentation
	  and/or other materials provided with the distribution.

	- Neither the name of Yellow Lemon Software nor the names of its
	  contributors may be used to endorse or promote products derived from this
	  software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
	IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
	ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
	LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
	CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
	SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
	INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
	CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
	ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
	POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef PACKETPROXY_H
	#define PACKETPROXY_H

//	Includes
	#include	<sys/unistd.h>
	#include	<sys/types.h>
	#include	<sys/socket.h>
	#include	<netinet/in.h>
	#include	<arpa/inet.h>
	#include	<netdb.h>
	#include	<stdio.h>
	#include	<stdlib.h>
	#include	<string.h>
	#include	<time.h>
	#include	<signal.h>
	#include	"ds_utils.h"
	#include	"config_pp.h"
	
//	Constants
#define	false		0
#define	true		1

enum {
	kBufSize		= 65535,	//	Default buffer size to allocate for each thread
	kListenPort		= 1999,		//	Default port to listen for incoming connections
	
	kOptUndefined	= 0,		//	Constants for parsing options
	kOptSetDestAddr,
	kOptSetDestPort,
	kOptSetListenPort,
	kOptSetMaxThreads,
	kOptSetMaxBandwidth,
	kOptSetConfFile,
	kOptSetLogFile,
	kOptSetVerbosity,
	
	kMaxThreads		= 10,		/*	Set this constant to the number of concurrent
									connections you wish to handle by default. */
	kMajorVersion	= 0,
	kMinorVersion	= 71,
	
	kNoLog			= -1,
	kLogError		= 0,
	kLogInfo,
	kLogEvent,
	kLogVerbose,
	kLogDebug,
};

/*	ProxyThreadInfo: This struct is passed to newly created ProxyThreads, to
	inform them of the socket they are to communicate on, as well as the port
	and address of the host to which packets should be routed.
*/
typedef struct {
	int			sock;
	int			dest_port;
	long		client_ip;
	char		*dest_addr;
} ProxyThreadInfo;

//	Externs
extern	AuthElem			*authorized_clients;
extern	RouteElem			*routes;
//	Prototypes
	void		do_quit(int signal);
	
	void		StartProxy();
	void		PrintUsage(char *exec_name);
	void*		ProxyThread(void *args);
	long		ForwardData(int *sock_from, int *sock_to, char *buf, FILE *raw_file, long *quota);
	bool		Authenticate(long ip);
	
	char*	f_inet_ntoa(long ip);
	void	log(int level, char *fmt, ...);
#endif
