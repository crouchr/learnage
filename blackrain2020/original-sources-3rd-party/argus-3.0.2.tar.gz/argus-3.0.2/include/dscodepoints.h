/*
 * Argus Software
 * Copyright (c) 2000-2009 QoSient, LLC
 * All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

/* 
 * $Id: //depot/argus/argus-3.0/clients/include/dscodepoints.h#8 $
 * $DateTime: 2006/03/31 13:25:33 $
 * $Change: 793 $
 */


/* prepared from IANA DS codepoint definitions Wed Aug 16 11:45:21 EDT 2000 */


#ifndef  DSCodePoints_h
#define DSCodePoints_h

struct ArgusDSCodePointStruct {
   char code, *label, *desc;
};

struct ArgusDSCodePointStruct argus_dscodepoints [] = {
   { 0x00,   "cs0", "Pool 1 Recommended"},
   { 0x08,   "cs1", "Pool 1 Recommended"},
   { 0x10,   "cs2", "Pool 1 Recommended"},
   { 0x18,   "cs3", "Pool 1 Recommended"},
   { 0x20,   "cs4", "Pool 1 Recommended"},
   { 0x28,   "cs5", "Pool 1 Recommended"},
   { 0x30,   "cs6", "Pool 1 Recommended"},
   { 0x38,   "cs7", "Pool 1 Recommended"},
   { 0x0A,  "af11", ""},
   { 0x0C,  "af12", ""},
   { 0x0E,  "af13", ""},
   { 0x12,  "af21", ""},
   { 0x14,  "af22", ""},
   { 0x16,  "af23", ""},
   { 0x1A,  "af31", ""},
   { 0x1C,  "af32", ""},
   { 0x1E,  "af33", ""},
   { 0x22,  "af41", ""},
   { 0x24,  "af42", ""},
   { 0x26,  "af43", ""},
   { 0x2E,  "ef",   ""},
   { 0x00, (char *) 0, (char *) 0 }, 
};

#endif
