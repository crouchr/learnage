
/* 
 * $Id: $
 * $DateTime: $
 * $Change: $
 */
/* linux does not give us the link level header */
#define SLIP_HDRLEN 16

#define SLX_DIR 0
#define SLX_CHDR 1
#define CHDR_LEN 15

#define SLIPDIR_IN 0
#define SLIPDIR_OUT 1

