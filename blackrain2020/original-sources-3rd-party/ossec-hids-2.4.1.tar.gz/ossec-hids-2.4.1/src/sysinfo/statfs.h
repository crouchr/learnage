
#ifndef __OS__statfs_H

#define __OS__statfs_H
int  getstatfs(char *path);
int getstatfspath();
#endif

