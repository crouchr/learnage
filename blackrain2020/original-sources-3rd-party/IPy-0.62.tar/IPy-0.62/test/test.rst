>>> from IPy import IP
>>> IP('::ffff:1.2.3.4').strCompressed()
'::ffff:1.2.3.4'

