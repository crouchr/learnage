/*
 * $smu-mark$
 * $name: memunlock.c$
 * $other_author: Mika <mika@qualys.com>
 * $other_copyright: Copyright (C) 1999 Mika <mika@qualys.com>
 * $license: This software is under GPL version 2 of license$
 * $date: Fri Nov  5 11:55:48 MET 1999$
 * $rev: 2$
 */

#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
                     
#include "hping2.h"
#include "globals.h"

char ip_opt_build(char* ip_opt)
{
	char optlen;
	unsigned long ip;

	if (opt_rroute)
	{
		memset(ip_opt,0,sizeof(ip_opt));
		ip_opt[0]=IPOPT_RR;
		ip_opt[1]=39;
		ip_opt[2]=8;
		ip=inet_addr("1.2.3.4");
		memcpy(ip_opt+3,&ip,4);
		optlen=40;
	}
	else
	{
		optlen=0;
	}

  return optlen;		                            
}

