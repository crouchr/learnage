/* 
 * $smu-mark$ 
 * $name: release.h$
 * $author: Salvatore Sanfilippo <antirez@invece.org>$
 * $copyright: Copyright (C) 1999 by Salvatore Sanfilippo$
 * $license: This software is under GPL version 2 of license$
 * $date: Fri Nov  16 11:55:49 MET 1999$
 * $rev: 17$
 */ 

#ifndef _RELEASE_H
#define _RELEASE_H

#define RELEASE_VERSION "2.0.0 beta 54"
#define RELEASE_DATE "$date: Sat May 27 00:54:19 MET DST 2000"
#define CONTACTS "<antirez@linuxcare.com> <antirez@invece.org>"

#endif /* _RELEASE_H */
