/* 
 * $smu-mark$ 
 * $name: hgetopt.h$
 * $author: Salvatore Sanfilippo <antirez@invece.org>$
 * $copyright: Copyright (C) 1999 by Salvatore Sanfilippo$
 * $license: This software is under GPL version 2 of license$
 * $date: Fri Nov  5 11:55:48 MET 1999$
 * $rev: 9$
 */ 

#ifndef _HGETOPT_H
#define _HGETOPT_H

extern char *hoptarg;
extern int targethost;
char *hgetopt(char **argv, char **optype);

#endif /* _HGETOPT_H */
