/* 
 * $smu-mark$ 
 * $name: sendtcp.c$ 
 * $author: Salvatore Sanfilippo <antirez@invece.org>$ 
 * $copyright: Copyright (C) 1999 by Salvatore Sanfilippo$ 
 * $license: This software is under GPL version 2 of license$ 
 * $date: Fri Nov  5 11:55:49 MET 1999$ 
 * $rev: 8$ 
 */ 

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>

#include "hping2.h"
#include "globals.h"

void send_tcphdr (int signal_id)
{
	int			packet_size;
	int			errno_save = errno;
	char			*packet, *data;
	struct mytcphdr		*tcp;
	struct pseudohdr	*pseudoheader;

	packet_size = TCPHDR_SIZE + data_size;
	packet = malloc(PSEUDOHDR_SIZE + packet_size);
	if (packet == NULL) {
		perror("[send_tcphdr] malloc()");
		errno = errno_save;
		return;
	}
	pseudoheader = (struct pseudohdr*) packet;
	tcp =  (struct mytcphdr*) (packet+PSEUDOHDR_SIZE);
	data = (char*) (packet+PSEUDOHDR_SIZE+TCPHDR_SIZE);
	
	bzero(packet, PSEUDOHDR_SIZE+packet_size);

	/* tcp pseudo header */
	memcpy(&pseudoheader->saddr, &local.sin_addr.s_addr, 4);
	memcpy(&pseudoheader->daddr, &remote.sin_addr.s_addr, 4);
	pseudoheader->protocol		= 6; /* tcp */
	pseudoheader->lenght		= htons(TCPHDR_SIZE+data_size);

	/* tcp header */
	tcp->th_dport	= htons(dst_port);
	tcp->th_sport	= htons(src_port);

	/* sequence number and ack are random if not set */
	if (!set_seqnum)
		tcp->th_seq	= htonl(rand());
	else
		tcp->th_seq	= htonl(tcp_seqnum);

	if (!set_ack)
		tcp->th_ack	= htonl(rand());
	else
		tcp->th_ack	= htonl(tcp_ack);

	tcp->th_off	= src_thoff;
	tcp->th_win	= htons(src_winsize);
	tcp->th_flags	= tcp_th_flags;

	/* data */
	data_handler(data, data_size);

	/* compute checksum */
	tcp->th_sum = cksum((u_short*) packet, PSEUDOHDR_SIZE +
		      packet_size);

	/* adds this pkt in delaytable */
	delaytable[delaytable_index % TABLESIZE].seq = src_port - initsport;
	delaytable[delaytable_index % TABLESIZE].sec = time(NULL);
	delaytable[delaytable_index % TABLESIZE].usec = get_usec();
	delaytable[delaytable_index % TABLESIZE].status = S_SENT;

	/* send packet */
	send_ip_handler(packet+PSEUDOHDR_SIZE, packet_size);
	free(packet);

	delaytable_index++;
	sent_pkt++;
	signal(SIGALRM, send_tcphdr);
	
	if (count != -1 && count == sent_pkt)	/* count reached */
	{
		signal(SIGALRM, print_statistics);
		alarm(COUNTREACHED_TIMEOUT);
	}
	else if (!opt_listenmode)
	{
		if (opt_waitinusec == FALSE)
			alarm(sending_wait);
		else
			setitimer(ITIMER_REAL, &usec_delay, NULL);
	}

	if (!opt_keepstill)
		src_port++;		/* next src port */

	if (opt_force_incdport)
		dst_port++;

	errno = errno_save;
}
