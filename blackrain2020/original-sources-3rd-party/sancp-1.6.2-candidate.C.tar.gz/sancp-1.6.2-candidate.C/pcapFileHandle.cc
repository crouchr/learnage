
#include "pcapFileHandle.h"

/**************************************************************************
 **SA Network Connection Profiler [sancp] - A TCP/IP statistical/collection tool
 * ************************************************************************
 * * Copyright (C) 2003 John Curry <john.curry@metre.net>
 * *
 * * This program is distributed under the terms of version 1.0 of the
 * * Q Public License.  See LICENSE.QPL for further details.
 * *
 * * This program is distributed in the hope that it will be useful,
 * * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * *
 * ***********************************************************************/


pcapFileHandle::pcapFileHandle(){
	setPcapHandle(0);
	setPcapDumperHandle(0);
}

//pcapFileHandle::pcapFileHandle():ipcapt(0), opcapdt(0) { }
 
//pcapFileHandle::pcapFileHandle(const char *newfilename, pcap_t * ipcapt) : ipcapt(ipcapt), opcapdt(0)

pcapFileHandle::pcapFileHandle(const char *newfilename, pcap_t * ipcapt)
{
	setFileName(newfilename);
	setMode(APPEND_MODE);
	setPcapHandle(ipcapt);
	setPcapDumperHandle(0);
}

int pcapFileHandle::isOpen()
{
        if(opcapdt){ return 1; }
        return 0;
}


int pcapFileHandle::stat()
{
	struct stat buffer;
	if(::stat(getFileName(),&buffer)||(buffer.st_size < (long) sizeof(pcap_file_header)))
	{
		return 0;
	}
	return 1;
}


void pcapFileHandle::close(struct timeval *time)
{
        struct utimbuf times;
        times.actime=time->tv_sec;
        times.modtime=time->tv_sec;
        if(getFileName())
        {
                ::utime(getFileName(), &times);
                close();
        }
	handle=0;
}

void pcapFileHandle::close()
{
        if(opcapdt)
        {
		pcap_dump_close(opcapdt);
        	opcapdt=0;
		handle=0;
        }
}

void pcapFileHandle::setPcapDumperHandle(pcap_dumper_t *pcapdt)
{
	opcapdt=pcapdt;
}

void pcapFileHandle::setPcapHandle(pcap_t *pcapt)
{
	ipcapt=pcapt;
}

pcap_t *pcapFileHandle::getPcapHandle()
{
	return ipcapt;
}

pcap_dumper_t *pcapFileHandle::getPcapDumperHandle()
{
	return opcapdt;
}

void pcapFileHandle::destroy()
{
        detach();
#ifdef DEBUGFH
	printf ("Detaching from 0x%X (%llu)\n",(u_int32_t)this,in_use);
#endif
        if(!in_use){ delete this; }
}


int pcapFileHandle::open()
{ 
	if(opcapdt){ return 1; }
	if(getFileName()==0){ 
		//No filename set!
		return -2; 
	}
	startpos=0;
	// Check if file is present and that it has a minimum header size
	if(stat()){
		opcapdt=(pcap_dumper_t *)fopen(getFileName(),"a");
		handle=(FILE *)opcapdt;
		stoppos=(long long)tell();
	}else{
		opcapdt = pcap_dump_open(ipcapt, getFileName());
		handle=(FILE *)opcapdt;
		stoppos=sizeof(pcap_file_header);
	}	
	if(opcapdt){ return 1; }

	return -1;
}


ssize_t pcapFileHandle::write(const struct pcap_pkthdr * pkthdr, const u_char * pkt)
{
	ssize_t bytes=0;

 	if(open()==1)
	{
		size+=pkthdr->len;
                startpos=stoppos;
		pcap_dump((u_char *) opcapdt, pkthdr, pkt);
		stoppos=(startpos+pkthdr->caplen+sizeof(pcap_pkthdr));
	}else{
		//Unable to print to file
		return -1;
	}
	return bytes;
}

pcapFileHandle * pcapFileHandle::attach() 
{
	fileHandle::attach();
#ifdef DEBUGFH
	printf ("Attaching to 0x%X (%llu)\n",(u_int32_t)this,in_use);
#endif
	return this;
}

pcapFileHandle::~pcapFileHandle() {  
	close(); 

#ifdef DEBUGFH
	printf ("Deleting this 0x%X\n",(u_int32_t)this); 
#endif

}
