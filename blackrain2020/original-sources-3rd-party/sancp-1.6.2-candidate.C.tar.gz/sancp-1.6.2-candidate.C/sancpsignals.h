
#ifndef GVARS_H
#include "gvars.h"
#endif

#ifndef SANCPSIGNALS_H
#define SANCPSIGNALS_H 1
void set_exit_all (int a);
void set_record_all (int a);
void set_print_acl (int a);
void set_erase_idle (int a);
void set_reload_config (int a);
void set_signals();
void handle_signals();
#endif
