#include "sancpsignals.h"
 
void set_signals()
{
        signal(SIGHUP, set_reload_config);
        signal(SIGALRM, set_erase_idle);
        signal(SIGUSR1, set_print_acl);
        signal(SIGUSR2, set_record_all);
        signal(SIGTERM, set_exit_all);
        signal(SIGINT, set_exit_all);
        signal(SIGKILL, set_exit_all);
        signal(SIGQUIT, set_exit_all);
	return;
}

void handle_signals()
{

	//
	// Address signals received by sancp here
	//

	extern struct gvars gVars;

        if(gVars.sancpsignals.reload_config){ reload_config(gVars.sancpsignals.reload_config); gVars.sancpsignals.reload_config=0; };
        if(gVars.sancpsignals.erase_idle){ erase_idle(gVars.sancpsignals.erase_idle); gVars.sancpsignals.erase_idle=0; };
        if(gVars.sancpsignals.print_acl){ print_acl(gVars.sancpsignals.print_acl) ; gVars.sancpsignals.print_acl=0; };
        if(gVars.sancpsignals.record_all){ record_all(gVars.sancpsignals.record_all); gVars.sancpsignals.record_all=0; };
        if(gVars.sancpsignals.exit_all){ exit_all(gVars.sancpsignals.exit_all); gVars.sancpsignals.exit_all=0; };

	return;
}


void set_exit_all (int a) { extern struct gvars gVars; gVars.sancpsignals.exit_all=a; if(!gVars.incriticalsection){ handle_signals(); } return; }
void set_record_all (int a) { signal(SIGUSR2, set_record_all); extern struct gvars gVars; gVars.sancpsignals.record_all=a; if(!gVars.incriticalsection){ handle_signals(); } return; }
void set_print_acl (int a) {  extern struct gvars gVars; gVars.sancpsignals.print_acl=a; if(!gVars.incriticalsection){ handle_signals(); } return; }
void set_erase_idle (int a) { extern struct gvars gVars; gVars.sancpsignals.erase_idle=a; if(!gVars.incriticalsection){ handle_signals(); } return; }
void set_reload_config (int a) { extern struct gvars gVars; gVars.sancpsignals.reload_config=a; if(!gVars.incriticalsection){ handle_signals(); } return; }

