#ifndef NCP_H

# include "strings.h"
#include "sancp.h"

#endif

#ifndef SANCPSIGNALS_H
#include "sancpsignals.h"
#endif

/**************************************************************************
 **SA Network Connection Profiler [sancp] - A TCP/IP statistical/collection tool
 * ************************************************************************
 * * Copyright (C) 2003 John Curry <john.curry@metre.net>
 * *
 * * This program is distributed under the terms of version 1.0 of the
 * * Q Public License.  See LICENSE.QPL for further details.
 * *
 * * This program is distributed in the hope that it will be useful,
 * * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * *
 * ***********************************************************************/

/************* 
 *Global Vars* 
 *************/

u_int64_t cnx_id=0;
u_int16_t bytes_in=0;
u_int16_t bytes_out=0;
u_int16_t pkts_in=0;
u_int16_t pkts_out=0;
u_int16_t l_bytes_in=0;
u_int16_t l_bytes_out=0;
u_int16_t l_pkts_in=0;
u_int16_t l_pkts_out=0;
static u_int8_t getHdrLen(u_int32_t type);


struct gvars gVars;


	/* Here are all the possible output fields */
	/* MAXFLDS & MAXFLDSIZE are defined in sancp.h */

/* Modifications to this statement can cause alignment problems with 'enum id' in gvars.h */
/* Make certain all strings are represented in the same order (as barewords) in 'enum id' in gvars.h */
#ifdef ENABLE_PRELUDE_SUPPORT
char fmtnames[MAXFLDS][MAXFLDSIZE] = { {"null"},{"sancp_id"},{"start_time_gmt"},{"start_time_local"},{"start_time_local_unixtime"},{"stop_time_gmt"},{"stop_time_local"},{"stop_time_local_unixtime"},{"erased_time_gmt"},{"erased_time_local"},{"erased_time_local_unixtime"},{"eth_proto_hex"},{"eth_proto"},{"ip_proto"},{"src_ip_decimal"},{"src_ip_dotted"},{"src_port"},{"dst_ip_decimal"},{"dst_ip_dotted"},{"dst_port"},{"duration"},{"timeout"},{"src_pkts"},{"dst_pkts"},{"src_bytes"},{"dst_bytes"},{"sflags_hex"},{"sflags"},{"sflags_1"},{"sflags_2"},{"sflags_U"},{"sflags_A"},{"sflags_P"},{"sflags_R"},{"sflags_S"},{"sflags_F"},{"dflags_hex"},{"dflags"},{"dflags_1"},{"dflags_2"},{"dflags_U"},{"dflags_A"},{"dflags_P"},{"dflags_R"},{"dflags_S"},{"dflags_F"},{"cflags_hex"},{"cflags"},{"cflags_DA"},{"cflags_SA"},{"cflags_DR"},{"cflags_SR"},{"cflags_DF"},{"cflags_SF"},{"ip_len_s"},{"ip_ttl_s"},{"ip_df_s"},{"tcp_wss_s"},{"tcp_mss_s"},{"tcp_wscale_s"},{"tcp_sack_ok_s"},{"tcp_nop_s"},{"ip_len_d"},{"ip_ttl_d"},{"ip_df_d"},{"tcp_wss_d"},{"tcp_mss_d"},{"tcp_wscale_d"},{"tcp_sack_ok_d"},{"tcp_nop_d"},{"total_bytes"},{"collect"},{"collected"},{"climit"},{"tcplag"},{"pcap"},{"realtime"},{"stats"},{"index"},{"reversed"},{"hash"},{"rid"},{"rgid"},{"node"},{"zone"},{"status"},{"retro"},{"src_mac"},{"dst_mac"},{"prelude_impact_sevirty"},{"prelude_impact_completion"},{"prelude_impact_type"},{"prelude_confidence_rating"},{"prelude_profile"},{"sample_src_len"},{"sample_src_hex"},{"sample_src_asc"},{"sample_dst_len"},{"sample_dst_hex"},{"sample_dst_asc"},{"output_session_id"},{"output_filename"},{"start_pos"},{"stop_pos"},{"first_start_pos"},{"last_stop_pos"} };
#else
char fmtnames[MAXFLDS][MAXFLDSIZE] = { {"null"},{"sancp_id"},{"start_time_gmt"},{"start_time_local"},{"start_time_local_unixtime"},{"stop_time_gmt"},{"stop_time_local"},{"stop_time_local_unixtime"},{"erased_time_gmt"},{"erased_time_local"},{"erased_time_local_unixtime"},{"eth_proto_hex"},{"eth_proto"},{"ip_proto"},{"src_ip_decimal"},{"src_ip_dotted"},{"src_port"},{"dst_ip_decimal"},{"dst_ip_dotted"},{"dst_port"},{"duration"},{"timeout"},{"src_pkts"},{"dst_pkts"},{"src_bytes"},{"dst_bytes"},{"sflags_hex"},{"sflags"},{"sflags_1"},{"sflags_2"},{"sflags_U"},{"sflags_A"},{"sflags_P"},{"sflags_R"},{"sflags_S"},{"sflags_F"},{"dflags_hex"},{"dflags"},{"dflags_1"},{"dflags_2"},{"dflags_U"},{"dflags_A"},{"dflags_P"},{"dflags_R"},{"dflags_S"},{"dflags_F"},{"cflags_hex"},{"cflags"},{"cflags_DA"},{"cflags_SA"},{"cflags_DR"},{"cflags_SR"},{"cflags_DF"},{"cflags_SF"},{"ip_len_s"},{"ip_ttl_s"},{"ip_df_s"},{"tcp_wss_s"},{"tcp_mss_s"},{"tcp_wscale_s"},{"tcp_sack_ok_s"},{"tcp_nop_s"},{"ip_len_d"},{"ip_ttl_d"},{"ip_df_d"},{"tcp_wss_d"},{"tcp_mss_d"},{"tcp_wscale_d"},{"tcp_sack_ok_d"},{"tcp_nop_d"},{"total_bytes"},{"collect"},{"collected"},{"climit"},{"tcplag"},{"pcap"},{"realtime"},{"stats"},{"index"},{"reversed"},{"hash"},{"rid"},{"rgid"},{"node"},{"zone"},{"status"},{"retro"},{"src_mac"},{"dst_mac"},{"sample_src_len"},{"sample_src_hex"},{"sample_src_asc"},{"sample_dst_len"},{"sample_dst_hex"},{"sample_dst_asc"},{"output_session_id"},{"output_filename"},{"start_pos"},{"stop_pos"},{"first_start_pos"},{"last_stop_pos"} };
#endif

        /* This will be our default realtime layout */

        char dfltrealtimefmt[]= { sancp_id,start_time_gmt,duration,src_ip_dotted,dst_ip_dotted,ip_proto,src_port,dst_port,src_pkts,dst_pkts,src_bytes,dst_bytes,sflags,dflags,total_bytes,collect,climit,collected,pcap,realtime,stats,reversed,hash,rid,rgid,node,zone,status,retro,src_mac,dst_mac,sample_src_len,sample_src_asc };


	/* This will be our default stats layout */

        char dfltstatsfmt[]= { sancp_id,start_time_gmt,stop_time_gmt,erased_time_gmt,eth_proto,ip_proto,src_ip_decimal,src_port,dst_ip_decimal,dst_port,duration,timeout,src_pkts,dst_pkts,src_bytes,dst_bytes,sflags,dflags,cflags,total_bytes,collect,collected,climit,tcplag,pcap,realtime,stats,reversed,hash,rid,rgid,node,zone,status,retro,src_mac,dst_mac,sample_src_len,sample_dst_len,sample_src_hex,sample_dst_hex };


	/* This will be our default console layout */

	char dfltconsolefmt[]= { sancp_id,start_time_local,src_mac,dst_mac,src_ip_dotted,dst_ip_dotted,eth_proto,ip_proto,src_port,dst_port,src_pkts,dst_pkts,src_bytes,dst_bytes,timeout,total_bytes,output_session_id,sflags_hex,dflags_hex,cflags_hex,duration,sample_src_asc };


	/* This will be our default index layout */

	char dfltindexfmt[]= { sancp_id,output_filename,start_pos,stop_pos };


        /* This will be our default stats human-readable layout */

        char dfltfmt_human_readable[]= { sancp_id,start_time_gmt,stop_time_gmt,erased_time_gmt,eth_proto,ip_proto,src_ip_dotted,src_port,dst_ip_dotted,dst_port,duration,timeout,src_pkts,dst_pkts,src_bytes,dst_bytes,sflags,dflags,cflags,total_bytes,collect,collected,climit,tcplag,pcap,realtime,stats,reversed,hash,rid,rgid,node,zone,status,retro,src_mac,dst_mac };


#ifdef ENABLE_PRELUDE_SUPPORT

prelude_client_t *client;
static idmef_analyzer_t *idmef_analyzer;

int sancp_alert_init(prelude_client_t *client) 
{

        int ret;
        prelude_string_t *string;
        
        idmef_analyzer = prelude_client_get_analyzer(client);
        if ( ! idmef_analyzer )
                return -1;
        
        ret = idmef_analyzer_new_model(idmef_analyzer, &string);
        if ( ret < 0 )
                return -1;
        prelude_string_set_constant(string, PRELUDE_ANALYZER_MODEL);

        ret = idmef_analyzer_new_class(idmef_analyzer, &string);
        if ( ret < 0 )
                return -1;
        prelude_string_set_constant(string, PRELUDE_ANALYZER_CLASS);

        ret = idmef_analyzer_new_manufacturer(idmef_analyzer, &string);
        if ( ret < 0 )
                return -1;
        prelude_string_set_constant(string, PRELUDE_ANALYZER_MANUFACTURER);

        ret = idmef_analyzer_new_version(idmef_analyzer, &string);
        if ( ret < 0 )
                return -1;
        prelude_string_set_constant(string, VERSION);

        return 0;
}

#endif

/************* 
 *  Main     * 
 *************/

int main(int argc, char *argv[]) {
	extern struct gvars gVars;
	int cKey;
#ifdef ENABLE_PRELUDE_SUPPORT
	int ret;
#endif
	pid_t pid=0;

	/*
	 * Setup our defaults for the enviroment
	 */

	bzero(&gVars,sizeof(struct gvars));
	gVars.default_timeout=DEFAULT_TIMEOUT;
	gVars.default_limit=DEFAULT_LIMIT;
	gVars.default_tcplag=DEFAULT_LAG;
	gVars.shift=0;  //DEFAULT_DEVICE is 'any' so we need this set from the start
        gVars.cmdl_pcap_action=ACTION_LOG;
        gVars.cmdl_stats_action=ACTION_LOG;
        gVars.cmdl_realtimes_action=ACTION_LOG;
        gVars.cmdl_index_action=ACTION_PASS;
	gVars.default_flush_interval=DEFAULT_FLUSH_INTERVAL;
	gVars.default_expire_interval=DEFAULT_EXPIRE_INTERVAL;
	gVars.default_sample_length[FROM_INITIATOR]=DEFAULT_SAMPLE_LENGTH;
	gVars.default_sample_length[FROM_TARGET]=DEFAULT_SAMPLE_LENGTH;
	gVars.print_schemas=0;

	//
	// Default to enable use_pcap_time to reduces interruptions generated by SIGALRM
	//  Need to evaluate signal handling, more interruptions increase likely-hood of FUTEX_WAIT conditions (jlc/2006-09-25)
	//  (i.e. -SIGUSR2 signals are used to  console output logging)
	//

       	gVars.use_pcap_time=ENABLED;

	//gVars.log_facility=LOG_DAEMON;

	gVars.log_facility=LOG_LOCAL1;
	gVars.pmode=OMODE_TSFILENAME;
	gVars.smode=OMODE_TSFILENAME;
	gVars.rmode=OMODE_TSFILENAME;
	gVars.imode=OMODE_PASS;
	gVars.burst_mode=ENABLED;
	gVars.strip_8021Q=DISABLED;
        gVars.cnx_pool = new CMemoryPool(true,sizeof(struct cnx),1024);//
        gVars.acl_pool = new CMemoryPool(true,sizeof(struct acl),24);//
	gVars.timeptr.tv_sec=gVars.lastexpire=gVars.lasterase=gVars.restart_time=gVars.start_time=time(0);

        gVars.realtime_fmt_len=sizeof(dfltrealtimefmt);
        gVars.realtime_fmt=(char *) calloc(gVars.realtime_fmt_len,1);
        memcpy(gVars.realtime_fmt,dfltrealtimefmt,gVars.realtime_fmt_len);
	gVars.realtime_delimiter=DEFAULT_DELIMITER;
	gVars.realtime_eor=DEFAULT_EOR;

        gVars.stats_fmt_len=sizeof(dfltstatsfmt);
        gVars.stats_fmt=(char *) calloc(gVars.stats_fmt_len,1);
        memcpy(gVars.stats_fmt,dfltstatsfmt,gVars.stats_fmt_len);
	gVars.stats_delimiter=DEFAULT_DELIMITER;
	gVars.stats_eor=DEFAULT_EOR;

        gVars.index_fmt_len=sizeof(dfltindexfmt);
        gVars.index_fmt=(char *) calloc(gVars.index_fmt_len,1);
        memcpy(gVars.index_fmt,dfltindexfmt,gVars.index_fmt_len);
	gVars.index_delimiter=DEFAULT_DELIMITER;
	gVars.index_eor=DEFAULT_EOR;

        gVars.console_fmt_len=sizeof(dfltconsolefmt);
        gVars.console_fmt=(char *) calloc(gVars.console_fmt_len,1);
        memcpy(gVars.console_fmt,dfltconsolefmt,gVars.console_fmt_len);
	gVars.console_delimiter=DEFAULT_DELIMITER;
	gVars.console_eor=DEFAULT_EOR;

	gVars.prelude_impact_severity=PRELUDE_IMPACT_SEVERITY;
	gVars.prelude_impact_completion=PRELUDE_IMPACT_COMPLETION;
	gVars.prelude_impact_type=PRELUDE_IMPACT_TYPE;
	gVars.prelude_confidence_rating=PRELUDE_CONFIDENCE_RATING;
	gVars.prelude_profile=PRELUDE_PROFILE;

	

	for(cKey=0; cKey<HASH_KEYS; cKey++)
	{
		gVars.cnx_head[cKey]=NULL;
		gVars.cnx_tail[cKey]=NULL;
	}

	/* Intialize the default syslog mode (Log to system console, stderr and to syslog) */

	openlog(NAME,LOG_CONS+LOG_PERROR,gVars.log_facility);

	/* These would be nice to have right now */

	parse_args(argc, argv);

	/* We should have a pidfilename by now */



	if(!gVars.pidfilename) 
	{
		if( (gVars.pidfilename = (char *)calloc(strlen(PIDFILENAME)+1,1) ) ==NULL){
			syslog(LOG_ERR,"Unable to allocate memory for pidfilename \n");
			exit(0);
		}
		bcopy(PIDFILENAME,gVars.pidfilename,strlen(PIDFILENAME));
	}



	
        if(gVars.daemon_mode==1){
    	  if(getppid() != 1)
	  {
            pid = fork();

            if(pid > 0){
	       manage_pid(pid);
	       printf("(%d) sancp daemonized successfully!\n",(int)pid); 
               exit(0);                /* parent */
	    }

            setsid();
          }

	if(gVars.human_readable){
		//
		// TODO: Evaluate human_readable format detection - non critical 
		// Below may not be an accurate way to detect a difference in format, if both formats are literally the same length.
		//
             if(gVars.realtime_fmt_len!=sizeof(dfltfmt_human_readable)){
        	free(gVars.realtime_fmt);
        	gVars.realtime_fmt_len=sizeof(dfltfmt_human_readable);
        	gVars.realtime_fmt=(char *) calloc(gVars.realtime_fmt_len,1);
	     } 
             memcpy(gVars.realtime_fmt,dfltfmt_human_readable,gVars.realtime_fmt_len);
             if(gVars.stats_fmt_len!=sizeof(dfltfmt_human_readable)){
        	free(gVars.stats_fmt);
        	gVars.stats_fmt_len=sizeof(dfltfmt_human_readable);
	        gVars.stats_fmt=(char *) calloc(gVars.stats_fmt_len,1);
	     }
      	     memcpy(gVars.stats_fmt,dfltfmt_human_readable,gVars.stats_fmt_len);
	}

#ifdef ENABLE_PRELUDE_SUPPORT
       	  prelude_log_set_flags((prelude_log_flags_t)PRELUDE_LOG_FLAGS_SYSLOG);
#endif
        }

#ifdef ENABLE_PRELUDE_SUPPORT

       /* Initialize prelude */
       ret = prelude_init(&argc, argv);
       if (ret < 0) {
               prelude_perror(ret, "unable to initialize the prelude library");
               exit_all(0);
       }
#endif

	/* Retrieve the last cnxid from cache file if we haven't already in parse_args() */

	if(!gVars.cnx_id)
		manage_cid(0);

	/* Do we have a default device set yet? If not, we will read from all network devices. */

	if(!gVars.default_device) 
	{
		if((gVars.default_device = (char *)calloc(strlen("any")+1,1))==NULL){
			syslog(LOG_ERR,"Unable to allocate memory for -u option\n");
			exit(0);
		}
		bcopy("any",gVars.default_device,strlen("any"));
	}


	/* We should decide on a log directory now */

	if(!gVars.log_directory)
	{
		if( (gVars.log_directory = (char *)calloc(strlen(LOG_DIR)+1,1) ) ==NULL){
			syslog(LOG_ERR,"Unable to allocate memory for -u option\n");
			exit(0);
		}
		bcopy(LOG_DIR,gVars.log_directory,strlen(LOG_DIR));
	}


	/* Set an initial default pcap output filename */

	gVars.pcap_fname=(char *) calloc(1,strlen(PCAP_FNAME)+1);
	strncpy(gVars.pcap_fname,PCAP_FNAME,strlen(PCAP_FNAME));

	/* Set an initial default stats output filename */

	gVars.stats_fname=(char *) calloc(1,strlen(STATS_FNAME)+1);
	strncpy(gVars.stats_fname,STATS_FNAME,strlen(STATS_FNAME));

	/* Set an initial default realtime output filename */

	gVars.realtime_fname=(char *) calloc(1,strlen(REALTIME_FNAME)+1);
	strncpy(gVars.realtime_fname,REALTIME_FNAME,strlen(REALTIME_FNAME));

	/* Set an initial default console output filename */

	gVars.console_fname=(char *) calloc(1,strlen(CONSOLE_FNAME)+1);
	strncpy(gVars.console_fname,CONSOLE_FNAME,strlen(CONSOLE_FNAME));

	gVars.index_fname=(char *) calloc(1,strlen(INDEX_FNAME)+1);
	strncpy(gVars.index_fname,INDEX_FNAME,strlen(INDEX_FNAME));


	if(gVars.input_filename){

		/* Read from a pcap file */

		gVars.ph=open_pcap_file(gVars.bpf_filter,gVars.input_filename);


		if(gVars.ph==0){
			perror("open_pcap_file");
			exit(0);
		}

	}else{

		/* Read from an interface */

		if(gVars.bpf_filter!=0)
			syslog(LOG_INFO,"Opening with filter: '%s'\n",gVars.bpf_filter);
		else
			syslog(LOG_INFO,"Opening without filter\n");

		gVars.ph=open_pcap_live(gVars.bpf_filter,gVars.default_device);
		if(gVars.ph==0){
			perror("open_pcap_live");
			exit(0);
		}
	}

       	gVars.hdrlen=getHdrLen(pcap_datalink(gVars.ph));



	/* Create the default output files for stats, pcap, and realtime (and debug_pcap_raw) */

	open_files();

	/* Read default collection mode settings and the rules */

	build_config(1);

#ifdef ENABLE_PRELUDE_SUPPORT

	/* Create prelude sensor */
        
	ret = prelude_client_new(&client, gVars.prelude_profile);
	if ( ! client ) {
		prelude_perror(ret, "Unable to create a prelude client object");
		exit_all(0);
	}

	/* Start prelude sensor */
	sancp_alert_init(client);
	ret = prelude_client_start(client);
	if ( ret < 0 ) {
		prelude_perror(ret, "Unable to start prelude client");
		exit_all(0);
	}

	ret = prelude_client_set_flags(client, (prelude_client_flags_t)
		(PRELUDE_CLIENT_FLAGS_ASYNC_SEND|PRELUDE_CLIENT_FLAGS_ASYNC_TIMER));
	if ( ret < 0 ) {
		fprintf(stderr, "Unable to set asynchronous send and timer.\n");
		exit_all(0);
	}
#endif

	reopen_files(1);

	if(gVars.sampling_enabled){
	    printf("Creating sample_pool for sampling %d payload bytes from the initiator packets\n",gVars.default_sample_length[FROM_INITIATOR]);

	    gVars.sample_pool[FROM_INITIATOR] = new CMemoryPool(true,gVars.default_sample_length[FROM_INITIATOR],24);

	    printf("Creating sample_pool for sampling %d payload bytes from the target packets\n",gVars.default_sample_length[FROM_TARGET]);

	    gVars.sample_pool[FROM_TARGET] = new CMemoryPool(true,gVars.default_sample_length[FROM_TARGET],24);

	}


	if(gVars.print_schemas){
		SChangeUserGroup();
		print_schemas();
		exit_all(0);
	}
	
	if(gVars.print_config){
		SChangeUserGroup();
		print_acl(1);
		exit_all(0);
	}
	
#ifdef DEBUG
	fprintf(stdout,"built the acls\n");
#endif
	if(gVars.input_filename)
	{
		/* Read from a pcap file */

		gVars.ph=open_pcap_file(gVars.bpf_filter,gVars.input_filename);

		if(gVars.ph==0){
			perror("open_pcap_file");
			exit_all(0);
		}

	}else{
		/* Read from an interface */
		if(gVars.bpf_filter!=0)
			syslog(LOG_INFO,"Opening with filter: '%s'\n",gVars.bpf_filter);

		gVars.ph=open_pcap_live(gVars.bpf_filter,gVars.default_device);
		if(gVars.ph==0){
			perror("open_pcap_live");
			exit_all(0);
		}
	}
	SChangeUserGroup();

	/* If we read from a file or 'any' then we expect two extra bytes prefixing each packet */

	if(gVars.shift) {
		    gVars.pcap_shift=2;
	}

	/* Setup the signal handling routines */
	set_signals();

#ifdef PLATFORM_SOLARIS
	// Force default to use pcap timestamp on Solaris until SIGARLM issue is addressed
       	gVars.use_pcap_time=ENABLED;
#else
	if(!gVars.use_pcap_time){
        	alarm(gVars.default_flush_interval);
	}
#endif

	syslog(LOG_INFO,"started normally");
	/* Call our C function to call pcap_loop() */
	start_pcap_loop(gVars.ph);
	/* We should exit if we make it this far */
	exit_all(0);
	    
 return 1;

}

/************** 
 * End of Main* 
 **************/


/* moved into here from p0f code */
static u_int8_t getHdrLen(u_int32_t type) {

  switch(type) {
    case DLT_NULL:
    case DLT_RAW:
    case DLT_SLIP:  
		return 0;
    case DLT_EN10MB: 
		return 14; 
#ifdef DLT_LOOP
    case DLT_LOOP:
#endif
#ifdef DLT_PPP_SERIAL
    case DLT_PPP_SERIAL: /* NetBSD oddity */
#endif
#ifdef DLT_PPP_ETHER
    case DLT_PPP_ETHER:  /* PPPoE on NetBSD */
     	return 8;
#endif
    case DLT_PPP:    
	return 4;

    case DLT_IEEE802:
      	return 22;
#ifdef DLT_PFLOG
    case DLT_PFLOG:
      	return 28;
#endif
#ifdef DLT_LINUX_SLL
    case DLT_LINUX_SLL:
      	return 16;
#endif
    default:
      syslog(LOG_INFO,"[!] WARNING: Unknown datalink type %d, assuming no header.\n",type);
      return 0;

  }

}


#ifdef DEBUG

/* Dummy function
 * Used for debugging
 */
void notify(){
	return;
}

#endif

/******************************************************************* 
 * Function for C code to call C++ code (used by pcap_functions.c) * 
 *******************************************************************/

extern "C" void ProcessMyPacket(char *user, struct pcap_pkthdr * pkthdr, u_char * pkt)
{
	extern struct gvars gVars;
	int err=0;
	struct cnx *new_cnx=0;
	gVars.incriticalsection=1;
        gVars.timeptr.tv_sec=pkthdr->ts.tv_sec;
        gVars.timeptr.tv_usec=pkthdr->ts.tv_usec;

       /* Record ALL data from packet before handling */

         if(gVars.pcap_raw){
               if(gVars.rpfH){
                        // FIX: added new code to write to raw pcap filehandle
                                if((err=((pcapFileHandle *)gVars.rpfH)->write(pkthdr,pkt))<0)
                            syslog(LOG_INFO,"Unable to print to raw pcap file (err: %d)\n",err);
               }
         }


         /* Strip the 8021Q header off */

         if( gVars.strip_8021Q && (*(u_int16_t*)(pkt + gVars.hdrlen + gVars.pcap_shift)==ETHPROTO_8021Q)){

#ifdef DEBUG
                printf("Have 8021Q, %.4x\n",*(u_int32_t*)(pkt + 12 + gVars.pcap_shift));
#endif
                /* shift packet data over 4 bytes to access encapsulated packet */
		/* this works even regardless of pcap_shift !!! NEED TO FIX THIS !!!*/
                memmove(pkt+4,pkt,4);
                pkthdr->caplen-=4;
                pkt+=4;
        }

/*	Copy the complete packet into an ethernet header structure for easy access */

	CBuffer *buffer=0;

	if((buffer=gVars.cnx_pool->Alloc())==NULL){ syslog(LOG_CRIT,"Out of Memory?\n"); return; }

	new_cnx = (struct cnx *) buffer->GetBuffer();

        bzero((char *) new_cnx,sizeof(struct cnx));

	new_cnx->CBufferPtr = buffer;

#ifdef DEBUG
	if(gVars.cnx_pool->GetFreeBuffers() + gVars.cnx_pool->GetUsedBuffers() != gVars.cnx_pool->GetTotalBuffers())
	{
		/* We should notify someone that we have an inconsistency in our memory pool */
		notify(); // dummy function
	}
#endif


/*
 *	Decode Packet
 */
	decode(new_cnx,pkthdr->caplen,pkt+gVars.pcap_shift);

#ifdef DEBUG
	notify(); // dummy function
        //pktcnt++;
#endif

/*
 * 	Now we have something to work with...
 */
	process(new_cnx,pkthdr,pkt+gVars.pcap_shift);

	

        if((gVars.timeptr.tv_sec - gVars.lastexpire)>gVars.default_expire_interval){
		/*
		 *  If we are configured to use the timestamp in the packets
		 *  to determine when to flush a file, then we should handle that here
		 */ 
		if(gVars.use_pcap_time && ((gVars.timeptr.tv_sec - gVars.lasterase)>gVars.default_flush_interval)){
			erase_idle(2); // This function will call expire_conections() for us
                	gVars.lasterase=gVars.timeptr.tv_sec;
		}
		else{
			expire_connections();
		}

                gVars.lastexpire=gVars.timeptr.tv_sec;
        }

	//
	//	 Execute signal actions safely here
	//

	handle_signals();

	gVars.incriticalsection=0;
}
