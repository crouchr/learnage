#ifndef SANCP_H
#include "sancp.h"
#endif
/**************************************************************************
 * *SA Network Connection Profiler [sancp] - A TCP/IP statistical/collection tool
 * ************************************************************************
 * * Copyright (C) 2003 John Curry <john.curry@metre.net>
 * *
 * * This program is distributed under the terms of version 1.0 of the
 * * Q Public License.  See LICENSE.QPL for further details.
 * *
 * * This program is distributed in the hope that it will be useful,
 * * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * *
 * ***********************************************************************/


/******************/
/*    retroactive */
//  
//  traverses all active connections modifying 
//  acl settings as applicable
//
/****************/

void retroactive( struct acl *myacl) {
        extern struct gvars gVars;
 	struct cnx *tc;	
	int t;
	char *ftmp=0;
	for( t = 0; t < HASH_KEYS; t++) {
		tc = gVars.cnx_head[t];
		while(tc) {
			if ( ( tc->h_proto<=myacl->h_proto_h) && ( tc->h_proto>=myacl->h_proto_l )
			&& ( ( tc->proto<=myacl->proto_h) && ( tc->proto>=myacl->proto_l ) 
			&& ( ( ( ntohs(tc->s_port)<=myacl->s_port_h ) && ( ntohs(tc->s_port)>=myacl->s_port_l )  
			&& ( ( tc->s_ip & (myacl->s_ip&myacl->s_mask) ) ^ (myacl->s_ip&myacl->s_mask) )==0 ) )
		    	&& ( ( ntohs(tc->d_port)<=myacl->d_port_h ) && ( ntohs(tc->d_port)>=myacl->d_port_l )
		 	&& ( ( ( tc->d_ip & (myacl->d_ip&myacl->d_mask) ) ^ (myacl->d_ip&myacl->d_mask) )==0 )) ) ){ 
				tc->cmode=myacl->cmode;	
				tc->imode=myacl->imode;	
				tc->pcap=myacl->pcap;	
				tc->realtime=myacl->realtime;	
				tc->stats=myacl->stats;	
				tc->index=myacl->index;	
				tc->limit=myacl->limit;	
				tc->timeout=myacl->timeout;	
				tc->tcplag=myacl->tcplag;	
				tc->status=myacl->status;	
				tc->rid=myacl->rid;	
				tc->rgid=myacl->rgid;	
				tc->zone=myacl->zone;	
				tc->node=myacl->node;	

#ifdef ENABLE_PRELUDE_SUPPORT
                                tc->prelude_impact_severity=myacl->prelude_impact_severity;
                                tc->prelude_impact_completion=myacl->prelude_impact_completion;
                                tc->prelude_impact_type=myacl->prelude_impact_type;
                                tc->prelude_confidence_rating=myacl->prelude_confidence_rating;
#endif


				if(myacl->pmode==OMODE_UNIQ)
				{
					// FIX: Added code to create uniq pcap filehandle here
					if(tc->fH){ tc->fH->destroy(); tc->fH=0; }
					
					ftmp=createPcapFileName(tc);
					tc->fH= new pcapFileHandle(ftmp,gVars.ph);
					free(ftmp);
				}else{
					if(myacl->fH){
						if(tc->fH){ tc->fH->destroy(); tc->fH=0; }
						tc->fH=myacl->fH->attach();	
					}
				}
#ifdef DEBUG				
				if(tc->fH){ fprintf(stderr,"retro cnx logging to %s\n",tc->fH->getFileName()); }
#endif

				// Reset output session id
				if(tc->fH) tc->output_session_id=tc->fH->getSessionid();

				tc->retro=true;
				myacl->ctr++;	
				if(tc->realtime) {
                                	record(tc,gVars.rfH);
	                        }
			}
tc=tc->next;	
		}
	}
}

/****************/
/*  apply_rule  */
/****************/
void apply_rule(struct cnx *nc) {
	extern struct gvars gVars;
	struct acl* myacl;
	myacl=gVars.acl_head;
	char *ftmp=0;
	while(myacl!=NULL){
		if( ( nc->h_proto<=myacl->h_proto_h) && ( nc->h_proto>=myacl->h_proto_l) &&
		( (nc->proto<=myacl->proto_h) && ( nc->proto>=myacl->proto_l ) 
		&& ( ( ( nc->s_ip & (myacl->s_ip&myacl->s_mask) ) ^ (myacl->s_ip&myacl->s_mask) )==0 ) 
	    	&& ( ( ntohs(nc->s_port)<=myacl->s_port_h ) && ( ntohs(nc->s_port)>=myacl->s_port_l ) ) 
	 	&& ( ( ( nc->d_ip & (myacl->d_ip&myacl->d_mask) ) ^ (myacl->d_ip&myacl->d_mask) )==0 ) 
	    	&& ( ( ntohs(nc->d_port)<=myacl->d_port_h ) && ( ntohs(nc->d_port)>=myacl->d_port_l )))){ 
			if(myacl->pmode==OMODE_UNIQ)
			{
				// FIX: added code to create unique pcap filehandle here
				if(nc->fH){ nc->fH->destroy(); nc->fH=0; }
				ftmp=createPcapFileName(nc);
#ifdef DEBUG
				printf("Connection (uniq) 0x%X ->\n",(u_int32_t)nc);
#endif
				nc->fH = new pcapFileHandle(ftmp,gVars.ph);
				free(ftmp);
			}else{
				if(myacl->fH)
				{
					if(nc->fH){ nc->fH->destroy(); nc->fH=0; }
#ifdef DEBUG
					printf("Connection (acl) 0x%X ->\n",(u_int32_t)nc);
#endif
					nc->fH = myacl->fH->attach();
				}
			}
			nc->cmode=myacl->cmode;	
			nc->imode=myacl->imode;	
			nc->index=myacl->index;	
			nc->pcap=myacl->pcap;	
			nc->realtime=myacl->realtime;	
			nc->stats=myacl->stats;	
			nc->limit=myacl->limit;	
			nc->timeout=myacl->timeout;	
			nc->tcplag=myacl->tcplag;	
			nc->status=myacl->status;	
			nc->rid=myacl->rid;	
			nc->rgid=myacl->rgid;	
			nc->zone=myacl->zone;	
			nc->node=myacl->node;	

#ifdef ENABLE_PRELUDE_SUPPORT
                        nc->prelude_impact_severity=myacl->prelude_impact_severity;
                        nc->prelude_impact_completion=myacl->prelude_impact_completion;
                        nc->prelude_impact_type=myacl->prelude_impact_type;
                        nc->prelude_confidence_rating=myacl->prelude_confidence_rating;
#endif
			// Set output session id
			if(nc->fH) nc->output_session_id=nc->fH->getSessionid();
			myacl->ctr++;	
			return;
		}
		myacl=myacl->next;	
	}
	// Perform default collect any non-matches
	if(gVars.pfH && gVars.pmode){	
		if(nc->fH){ nc->fH->destroy(); nc->fH=0; }
		nc->fH=gVars.pfH->attach();	
		if(nc->fH) nc->output_session_id=nc->fH->getSessionid();
#ifdef DEBUG

		printf("Connection (default) 0x%X ->\n",(u_int32_t)nc);
#endif
	}
	nc->stats=gVars.smode?1:0;
	nc->pcap=gVars.pmode?1:0;
	nc->index=gVars.imode?1:0;
	nc->realtime=gVars.rmode?1:0;
	nc->limit=gVars.default_limit;	
	nc->status=gVars.default_status;	
	nc->timeout=gVars.default_timeout;	
	nc->tcplag=gVars.default_tcplag;	
	nc->node=gVars.default_node;	
#ifdef ENABLE_PRELUDE_SUPPORT
	nc->prelude_impact_severity=gVars.prelude_impact_severity;
	nc->prelude_impact_completion=gVars.prelude_impact_completion;
	nc->prelude_impact_type=gVars.prelude_impact_type;
	nc->prelude_confidence_rating=gVars.prelude_confidence_rating;
#endif
	gVars.default_ctr++;
#ifdef DEBUG
	printf("Setting stats: %d  pcap: %d realtime: %d limit: %llu timeout: %d tcplag: %d\n", nc->stats, nc->pcap, nc->realtime, nc->limit, nc->timeout, nc->tcplag);
#endif
	return;
}
