`echo '101      production' >> /etc/iproute2/rt_tables`
`echo '102      honeypot' >> /etc/iproute2/rt_tables`
`echo '103      my_out' >> /etc/iproute2/rt_tables`

