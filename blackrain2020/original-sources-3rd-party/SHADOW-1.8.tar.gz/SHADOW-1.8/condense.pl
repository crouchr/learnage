#! /usr/bin/perl -Tw
#
# condense.pl          - SHADOW Version 1.8
#                        Last changed 09 Apr 2003
#
# Written by Bill Ralph <RalphWD@nswc.navy.mil>.
#
#  This script analyzes a text file containg output lines from tcpdump.
#  It sorts the file first by IP source address, then by time.
#  It uses some logic to eliminate duplicate lines. After the file is 
#  sorted by source IP, as it reads each line, it compares it to the previous
#  one. If the source and destination IPs are the same in the first two digits,
#  the program keeps track of the number of "matching" lines and the range
#  of digits in the third and fourth IP address quads and ports to list
#  those ranges in a second line of repeats. Because the numbers of repeated
#  attempted contacts can take up so much of the SHADOW web page, this
#  script shortens it considerably. It replaces the sort_and_resolve.pl
#  script of previous versions.
#
#  This program requires two command line arguments. The first is the 
#  name of the file containing tcpdump output, (input to this script), 
#  and the second is the name of the file to which the output of this 
#  script is to be written. If the first argument is the character "-",
#  then STDIN is read for input. If the second argument is the character "-",
#  then the output is written to STDOUT.
#
use strict;
use Socket;
use DB_File;
use IO::File;
use POSIX qw(tmpnam);
use File::Basename;
#
# Global declarations.
#
our %ip_name = ();
our ($db_file, %h);
#
#
# Fetch a non-existant temporary file name, and make sure it disappears
# when we exit.
#
do { $db_file = tmpnam() } until (! -e $db_file);
#
END { unlink($db_file) or die ("Couldn't unlink $db_file : $!") }
#
# Tie the hash %h to the btree format of the Berkeley DB module. 
# The hash %h is the tcpdump output line indexed by the source IP 
# address concatenated with the time.
#
tie %h, "DB_File", $db_file, O_RDWR|O_CREAT, 0644, $DB_BTREE;
#
#########################################################################
#
sub resolve
{
#
# Given an IP address: xxx.xxx.xxx.xxx, return a machine name if it exists.
# Keep found names in a hash table to prevent repetitive name lookups.
#
   my $name;
   our %ip_name;

   my $ip_addr = shift;
   my ($a, $b, $c, $d) = split(/\./, $ip_addr);
   
    
   if ($ip_name{$ip_addr}) {
     $name = $ip_name{$ip_addr};
   } elsif (($d == 0) or ($a == 255) or ($b == 255) or 
            ($c == 255) or ($d == 255)) {
         $name = $ip_addr;
         $ip_name{$ip_addr} = $ip_addr;
   } else {
#
# call system to fetch hostname
#   
     my $binip = inet_aton($ip_addr);
     my @info = gethostbyaddr($binip, AF_INET);
     $name = $info[0] ? $info[0] : "";
    
     $ip_name{$ip_addr} = $name;
   }
   return $name;

}
#
########################################################################
#
sub print_line
{
#
# Print a tcpdump output line, resolving the IP addresses within it.
#
   my @ip_matches = ();

   my $line = shift;
   if (@ip_matches = ($line =~ m/((?:\d+\.){3}\d+)/g)) {
      foreach my $match (@ip_matches) {
         my $name = resolve($match);
         $line =~ s/$match/$name/ if ($name);
       }
   }
   print OUT $line;
}

########################################################################
#
sub to_secs
#
# Convert a tcpdump timestamp: HH:MM:SS.SSSSSS to actual seconds.
#
{
   my ($hr, $min, $sec) = split(/:/, $_[0]);
   return (3600*$hr + 60*$min + $sec);
}
#
########################################################################
#
sub to_timestamp
#
# Convert a decimal number of seconds to a tcpdump timestamp: HH:MM:SS.SSSSSS
#
{
   my $secs = shift;
   my $hr = int($secs / 3600);
   $secs -= 3600*$hr;
   my $min = int($secs / 60);
   $secs -= 60*$min;
   return sprintf("%02d:%02d:%09.6f", $hr, $min, $secs);
}
#
########################################################################
#
sub sort_file
{
   my $filein = shift;
   my @addr = () x 4;
   our %h;

   open(IN,"< $filein") or die("unable to open: $filein.");
#
# Read through the entire text file. Constract a key for each record 
# consisting of the source IP address of the record followed by the 
# time tcpdump recorded the record. This will automatically sort the 
# records by IP and time.
#
   while (<IN>) {
      my ($ts, $src_ip, $crap ) = split(/\s+/ , $_, 3);
      my @addr = split(/\./ , $src_ip);
      my $string_ip = sprintf("%03d%03d%03d%03d", @addr);
      my $key = "$string_ip $ts";
   #  print "$key\n";
      $h{$key} = $_;
   }
   close(IN);
}
#
########################################################################
#
sub same_ip
#
# Compare two IP addresses, return 0 if they don't match the first $count
# quads. Otherwise return the byte number that first differs and reset
# the minimum and maximum values for that quad to reflect the new value.
# The addresses and min and max arrays are passed as references.
#
{
   my ($aref, $bref, $min, $max, $count) = @_;
   my ($b_int, $min_int, $max_int) = (0, 0, 0);

   my $byte_no = $count;
   return 0 if (! scalar(@{ $aref} ));
   for (my $byte=0; $byte <= $#$aref; $byte++) {
      if ($$aref[$byte] != $$bref[$byte]) {
         $byte_no = $byte;
         last;
      }
   }
   return 0 if ($byte_no < $count);
   for (my $byte=$byte_no; $byte <= $#$aref; $byte++) {
      $b_int = $$bref[$byte];
      $min_int = $$min[$byte];
      $max_int = $$max[$byte];
      $$min[$byte] = $b_int if ($b_int < $min_int);
      $$max[$byte] = $b_int if ($b_int > $max_int);
   }
   return $byte_no;
}
#
########################################################################
#

sub range_ip
#
# Given two references to minimum and maximum arrays, return a string,
# (a dotted quad), that gives the range between the min and max.
#
{

   my ($min, $max)  = @_;

   my @out = ();

   for (my $byte=0; $byte < 5; $byte++) {
      if ($$min[$byte] == $$max[$byte]) {
         $out[$byte] = sprintf("%d", $$min[$byte]);
      } else {
         $out[$byte] = sprintf("[%d...%d]", $$min[$byte], $$max[$byte]);
      }
   }
   return(join(".", @out));
}
#
########################################################################
#
my $input_filename = $ARGV[0];
my $output_filename = $ARGV[1];
#
if ((! $input_filename) || ($input_filename eq "-")) {
   die("No input filename specified.")
} else {
   my ($input_dir, $input_file) = ("", "");
   my ($tmp) = $input_filename =~ m!([-\w./]+)!s;
   $input_dir = dirname($tmp);
   $input_file = basename($tmp);
   $input_filename = "$input_dir/$input_file";
}
#
if ((! $output_filename) || ($output_filename eq "-")) {
   *OUT = *STDOUT;
} else {
   my ($output_dir, $output_file) = ("", "");
   my ($tmp) = $output_filename =~ m!([-\w./]+)!s;
   $output_dir = dirname($tmp);
   $output_file = basename($tmp);
   $output_filename = "$output_dir/$output_file";
   open(OUT,">$output_filename") || die("Unable to open $output_filename: $!");
}
#
&sort_file($input_filename);
#
my $line_number = 0;
my $min_ts = to_secs("23:59:59.999999");
my $max_ts = to_secs("00:00:00.000000");
my $line_count = 0;
my @prev_src = (0) x 5;
my @min_src = (255) x 5;
my @max_src = (0) x 5;
my @prev_dst = (0) x 5;
my @min_dst = (255) x 5;
my @max_dst = (0) x 5;
my @src = (0) x 5;
my @dst = (0) x 5;
my ($source, $dest, $ts1, $ts2, $out_line);
#
#
# Cycle through our DB file in sorted order and print each line.
#
my $old_source = "0.0.0.0";
my $prev_line = "";
#
while (my ($key, $cur_line) = each %h)
{
   $line_number++;
   my ($ts, $src_ip, $dir, $dst_ip, $flags, $crap2) = 
           split(/\s+/, $cur_line, 6);
   $ts = to_secs($ts);
   
   @src = split(/\./, $src_ip);
   push @src, "0" if (scalar(@src) == 4);

   my $source_ip = join('.', $src[0], $src[1], $src[2], $src[3]);
   
   $dst_ip =~ tr/://d;
   @dst = split(/\./, $dst_ip);
   push @dst, "0" if (scalar(@dst) == 4);

   my $dest_ip = join('.', $dst[0], $dst[1], $dst[2], $dst[3]);
#
# Compare the current line to the previous one to see if the source and
# destination IPs are "nearly" the same.
#
   if (same_ip(\@prev_src, \@src, \@min_src, \@max_src, 3) &&
       same_ip(\@prev_dst, \@dst, \@min_dst, \@max_dst, 2)) {
      $min_ts = $ts if ($ts < $min_ts);
      $max_ts = $ts if ($ts > $max_ts);
      $line_count++;
   } else {
#
# We've found a new line, substantially different than the previous bunch.
# Print out some information about the extent of the previous run.
#
   my $str1 = qq(<A HREF="/cgi-bin/whois.cgi?query=$source_ip&targetnic=auto" ONCLICK="whoisWin()" TARGET="whois">$source_ip </A>);
#
   my $str2 = qq(<A HREF="/cgi-bin/whois.cgi?query=$dest_ip&targetnic=auto" ONCLICK="whoisWin()" TARGET="whois">$dest_ip </A>);
#
      print OUT "\n<B>${str1} > ${str2}</B>\n" if ($line_number == 1);
      if ($prev_line) {
         print_line($prev_line);
         if ($line_count) {
            $source = &range_ip(\@min_src, \@max_src);
            $dest = &range_ip(\@min_dst, \@max_dst);
            $ts1 = to_timestamp($min_ts);
            $ts2 = to_timestamp($max_ts);
            $out_line = "$ts1 --> <B>$line_count</B> repeats from: $source > $dest until $ts2\n";
            print OUT "<FONT COLOR=#FF0033>$out_line</FONT>";
         }
         print OUT "\n<B>${str1} > ${str2}</B>\n";
         $old_source = $source_ip;
      }
      $line_count = 0;
      $prev_line = $cur_line;
      @prev_src = @src;
      @min_src = @src;
      @max_src = @src;
      @prev_dst = @dst;
      @min_dst = @dst;
      @max_dst = @dst;
      $min_ts = $ts;
      $max_ts = $ts;
   }
#
}
#
if ($prev_line) {
   print_line($prev_line);
   if ($line_count) {
      $source = &range_ip(\@min_src, \@max_src);
      $dest = &range_ip(\@min_dst, \@max_dst);
      $ts1 = to_timestamp($min_ts);
      $ts2 = to_timestamp($max_ts);
      $out_line = "$ts1 --> <B>$line_count</B> repeats from: $source > $dest until $ts2\n";
      print OUT "<FONT COLOR=#FF0033>$out_line</FONT>";
    }
}
close(OUT);
