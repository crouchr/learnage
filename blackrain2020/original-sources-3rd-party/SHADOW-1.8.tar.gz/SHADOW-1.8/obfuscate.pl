#!/usr/bin/perl -Tw
#
# obfuscate.pl           - SHADOW Release 1.8
#                          Last modified: 12 Dec 2002
#
# Read a text file, change all IP addresses known to be "ours" into different
# addresses to protect our data. Do the same for machines with their domain
# names, and email addresses.
#
# Written by Bill Ralph <RalphWD@nswc.navy.mil>
#
#
# Read the SHADOW configuration file, if it exists. If not, define arrays
# for "local" IP addresses, and local domains.
#
if (-e "/etc/shadow.conf") {
   do "/etc/shadow.conf" ||
      die("Unable to open SHADOW configuration file /etc/shadow.conf.");
} else {
#
###############################################################################
#                 
# For the obfuscate.pl script and the statistics scripts, define an array of
# local addresses with the CIDR notation the netmask, e.g.
#
# 172.16.0.0/16 where 16 is the number of network mask bits.
#
# For the obfuscate.pl script define an array of addresses into which to
# obfuscate the local addreses into. There must be one obfuscation address
# for each local address.
#
   our @LOCAL_IP = (
                    "172.16.0.0/16", "172.31.66.0/24"
                   );
   our @OBF_IP = (
                  "192.168.0.0", "192.168.245.0"
                 );
#
# Part of the obfuscation process is to take real domain addresses and
# email addresses that may be part of the data and obfuscate them as
# well as the IP addresses. Define those domain names that you want 
# obfuscated here:
#
   our @LOCAL_DOMAIN = (   
                       "righteousdudes.com", 
                       "goodfellows.com"
                       );
#
}
#
#
$ENV{PATH} = "/bin:/usr/bin:/usr/local/bin";
delete @ENV{qw(IFS CDPATH ENV BASH_ENV)};
#
use strict;
use File::Basename;
#
# Declare some global variables.
#
srand();
our $host_num = int(rand 255) + 1;
our $SUBNET = int(rand 255) + 1;
my $dummy_host_name = "host0000";
my $dummy_mail_name = "bubba0000";
my $dummy_dom_name = "obfuscated.org";
#
our $mask = from_dotted("255.255.255.255");
our (%name_alias, %mail_alias) = ();
our (@LOCAL_DOMAIN, @LOCAL_IP, @OBF_IP, %local_ip);
#
#########################################################################
#
# Build regular expressions to convert our legal domain names
# and mail addresses to obfuscated ones.
#
my ($regex1, $regex2) = "";
foreach my $name (@LOCAL_DOMAIN) {
   my $tmp = '.' . $name;
   $tmp =~ s/\./\\\./g;
   $regex1 .= '|' if ($regex1);
   $regex1 .= qq/(?:[-\\w]+${tmp})/;
   my $tmp2 = '\@' . $name;
   $tmp2 =~ s/\./\\\./g;
   $regex2 .= '|' if ($regex2);
   $regex2 .= qq/(?:[-\\w]+${tmp2})/;
}
$regex1 = '(' . $regex1 . ')';
$regex2 = '(' . $regex2 . ')';
$regex1 = qr/$regex1/i;
$regex2 = qr/$regex2/i;
#
#########################################################################
#
# Convert 32-bit IP address to dotted notation
#
sub to_dotted
#
# Given a decimal number, convert it to a string with dots.
#
{
   my $d = $_[0] & 255;
   my $c = $_[0] >> 8 & 255;
   my $b = $_[0] >> 16 & 255;
   my $a = $_[0] >> 24 & 255;

   if ($a) {
      return("$a.$b.$c.$d");
   } elsif ($b) {
      return("$b.$c.$d");
   } elsif ($c) {
      return("$c.$d");
   } else {
      return("$d");
   }
}
#
#########################################################################
#
sub from_dotted {
#
# Given a dotted string, convert it to a decimal number suitable for
# masking and shifting.
#
   my $dum = 0;
   my @octets = split(/\./, $_[0]);
   foreach (@octets) {
      $dum = (($dum << 8) | $_) if (defined $_);
   }
   return($dum);
}
#
#########################################################################
#
sub netmatch
{
#
# Given a regular expression match of a portion of an IP address, 
# calculate whether that fragment exists in our hash of "local" IP addresses.
# If it does, return the key to the matching entry.
#
   use integer;
   my $addr_int = from_dotted($_[0]);
   #
   return $_[0] if (exists $local_ip{$_[0]});
   foreach (keys %local_ip) {
      if (($addr_int & $local_ip{$_}{mask}) == $local_ip{$_}{int}) {
         return $_;
      }
   }
   return 0;
}
#########################################################################
#
sub get_alias
#
# Generate an alias for a local address.
#
{
   use integer;

   my $loc_match = shift;
   my $addr = shift;

   my $value = from_dotted($local_ip{$loc_match}{alias});
   our $host_num = ++$host_num % 255;
   if ($local_ip{$loc_match}{msk_len} eq "16") {
      my $subnet =  ($SUBNET + ((from_dotted($addr) >> 8) & 255)) % 256;
      $subnet = 0 if ($subnet == 255);
      $value += ($subnet << 8) + $host_num;
   } else {
      $value += $host_num;
   }
   $local_ip{$addr}{int} = from_dotted($addr);
   $local_ip{$addr}{msk_len} = 24;
   $local_ip{$addr}{mask} = $mask << 8;
   $local_ip{$addr}{alias} = to_dotted($value);
   return ($local_ip{$addr}{alias});
}
#
#########################################################################
#
#
for (my $index=0; $index<=$#LOCAL_IP; $index++) {
   my $entry = $LOCAL_IP[$index];
   my ($ip, $msk_len) = split(/\//, $entry);
   $local_ip{$ip}{msk_len} =  $msk_len;
#
   my $alias_net = $OBF_IP[$index];
   my $ip_int = from_dotted($ip);
   my $alias_int = from_dotted($alias_net);
   if ($local_ip{$ip}{msk_len} == 16) {
      delete $local_ip{$ip};
      my $new_int = $ip_int >> 16;
      my $new_ip = to_dotted($new_int);
      $local_ip{$new_ip}{alias} = to_dotted($alias_int >> 16);
      $local_ip{$new_ip}{int} = $new_int;
      $local_ip{$new_ip}{msk_len} = 16;
      $local_ip{$new_ip}{mask} = $mask >> 16;
      for (my $subnet=0; $subnet < 256; $subnet++) {
         my $alias_subnet = ($SUBNET + $subnet) % 256;
         $new_int = $ip_int | ($subnet << 8);
         $new_ip = to_dotted($new_int);
         $local_ip{$new_ip}{int} = $new_int;
         $local_ip{$new_ip}{msk_len} = 24;
         $local_ip{$new_ip}{mask} = $mask << 8;
         my $new_alias_int = from_dotted($alias_net) | ($alias_subnet << 8);
         $local_ip{$new_ip}{alias} = to_dotted($new_alias_int);
#
         $new_int = $new_int >> 8;
         $new_ip = to_dotted($new_int);
         $local_ip{$new_ip}{int} = $new_int;
         $local_ip{$new_ip}{msk_len} = 32;
         $local_ip{$new_ip}{mask} = $mask >> 8;
         $new_alias_int = $new_alias_int >> 8;
         $local_ip{$new_ip}{alias} = to_dotted($new_alias_int);
      }
   } else {
      $local_ip{$ip}{int} = from_dotted($ip);
      $local_ip{$ip}{mask} = $mask << (32 - $local_ip{$ip}{msk_len});
      my $new_int = $ip_int >> 8;
      my $new_ip = to_dotted($new_int);
      $local_ip{$new_ip}{alias} = to_dotted($alias_int >> 8);
      $local_ip{$new_ip}{int} = $new_int;
      $local_ip{$new_ip}{msk_len} = 32;
      $local_ip{$new_ip}{mask} = $mask >> 8;
   }

}
#
#
# Look at the calling parameter, insure that it is a legal file name
# and that it exists. Read that file searching for IP addresses, 
# IP fragments, domain names, and email addresses.
#
my $input_filename = $ARGV[0];
#
die("No input filename specified.") unless ($input_filename);
my ($input_dir, $input_file) = ("", "");
my ($tmp) = $input_filename =~ m!([-\w./]+)!s;
$input_dir = dirname($tmp);
$input_file = basename($tmp);
$input_filename = "$input_dir/$input_file";
die("No such file: $input_filename : $!") unless (-e $input_filename);
#
open(FILE, "< $input_filename");
while (<FILE>) {
   my $line = $_;
   my $new_name; 
#
# Look for domain name matches.
#
   if (my @name_matches = ($line =~ m/$regex1/g)) {
      foreach my $match (@name_matches) {
         if (! defined $name_alias{$match}) {
            $new_name = ++$dummy_host_name . ".$dummy_dom_name";
            $name_alias{$match} = $new_name;
         } else {
            $new_name = $name_alias{$match};
         }
         $line =~ s/$match/$new_name/g;
      }
   }
#
# Look for email addresses.
#
   if (my @mail_matches = ($line =~ m/$regex2/g)) {
      foreach my $match (@mail_matches) {
         if (! exists $mail_alias{$match}) {
            $new_name = ++$dummy_mail_name . "\@$dummy_dom_name";
            $mail_alias{$match} = $new_name;
         } else {
            $new_name = $mail_alias{$match};
         }
         $line =~ s/$match/$new_name/g;
      }
   }
#
# Look for IP addresses and fragments of IP addresses.
#
#  if (my @ip_matches = ($line =~ m/((?:\d+\.){1,3}\d+)/g)) {
   if (my @ip_matches = ($line =~ m/(?:\D|^)((?:\d{1,3}\.){1,3}\d{1,3})/g)) {
      foreach my $match (@ip_matches) {
         next unless (defined $match);
         my $alias = "";
         if (exists $local_ip{$match}) {
            $alias = $local_ip{$match}{alias};
         } else {
            if (my $loc_match = netmatch($match)) {
               unless ($alias = $local_ip{$match}{alias}) {
                  $alias = get_alias($loc_match, $match);
               }
            }
         }
         $line =~ s/$match/$alias/ if ($alias);
      }
   }
   print STDOUT $line;
}
close(FILE);
#open(KEY, ">key.out") || die ("Unable to open key.out.");
#foreach my $key (sort keys %name_alias) {
#   printf KEY "Name = %s, ALIAS = %s\n", $key, $name_alias{$key};
#}
#foreach my $key (sort keys %mail_alias) {
#   printf KEY "Mail = %s, ALIAS = %s\n", $key, $mail_alias{$key};
#}
#foreach my $key (sort keys %local_ip) {
#   printf KEY "IP = %s, ALIAS = %s\n", $key, $local_ip{$key}{alias};
#}
#close(KEY);
#
