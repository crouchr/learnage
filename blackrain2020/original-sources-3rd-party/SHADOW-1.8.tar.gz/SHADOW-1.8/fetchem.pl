#!/usr/bin/perl -Tw
#
# fetchem.pl         - SHADOW Version 1.8
#                      Last changed 10 Apr 2003
#
#
#  Script to fetch tcpdump gzipped hourly logfiles from a sensor,
#  move them to an dated subdirectory on the analyzer, run through
#  a tcpdump filter looking for suspicious events, and copy the output of
#  those suspicious events to a web page.
#
#  Written by Bill Ralph  <RalphWD@nswc.navy.mil>
#
# Set up some variables.
#
use strict;
use File::Path;
use Getopt::Long;
use IO::File;
use POSIX qw(strftime);
use Time::Local;
use Socket;
use Sys::Hostname;
use Sys::Syslog qw(:DEFAULT setlogsock);
#
my @args = @ARGV;
#
#
#########################################################################
#
sub load_config {
#
# This subroutine loads a configuration file, and will abort if the file
# is missing, non-parsible, or non-compilable.
#
   my $config_file = shift;
   unless (my $do_return = do "$config_file") {
      die ("Couldn't find $config_file") if (! -e $config_file);
      die ("Couldn't parse $config_file: $@") if $@;
      die ("Couldn't compile $config_file: $!")
         unless (defined $do_return);
      die ("Couldn't run $config_file") unless ($do_return);
   }
}
#
#########################################################################
#
# Read the SHADOW configuration file.
#
load_config("/etc/shadow.conf");
#
our (
     $SHADOW_PATH, $SHADOW_SITE_PATH, $OUTPUT_WEB_DIR, $ANALYZER_DIR, 
     $SENSOR, $SENSOR_DIR, $TCPDUMP_CMD, $SSH_CMD, $SCP_CMD,
     $SHADOW_FILE_SERVER, $FILTER_DIR, $GUNZIP_CMD
    );
#
$ENV{PATH} = "/bin:/usr/bin:/usr/local/bin:$SHADOW_PATH";
delete @ENV{qw(IFS CDPATH ENV BASH_ENV)};
#
my $tz = "LOC";
#
############################################################################
#
sub mark_it {
#
# This subroutine writes a time and command marker to the output file and
# the system log.
#
   my ($suffix, @args) = @_;
   my $marker = strftime("%Y-%b-%d %T:", localtime(time));
   my $params = join(" ", @args);
   my $log_line = "$0($params) => $suffix";
   my $out_line = $marker . $log_line;
   print STDOUT "$out_line\n";
   setlogsock('unix');
   openlog("SHADOW", 'nowait', 'user');
   syslog('info', '%s', $log_line);
   closelog();
}
#
############################################################################
#
sub usage {
        print "Usage: fetchem --loc Site {--debug} {--date YYYYMMDDHH}.\n";
	exit 2;
}
#
############################################################################
#
#	Parse the parameters.
#
#
my ($debug, $fetch_date, $site) = (0, '', '');

GetOptions("debug+" => \$debug, "date:s" => \$fetch_date, 
           "location=s" => \$site);
#
###############################################################################
#
#  Check parameter validity.
#
my $fdlen = $fetch_date ? length($fetch_date) : 0;
if (("$site" eq "") or (($fdlen > 0) and ($fdlen != 10) ))
{
	usage();
}
#
# Untaint the $site.
#
my ($Site) = $site =~ m!([-\w]+)!s;
#
##############################################################################
#
#  If -debug was set on the command line, make STDOUT and STDERR write to
#  a file /tmp/fetchem.log. Otherwise, close STDOUT and STDERR.
#
my @lvls = split(/\//,$0);				# Split path
my ($call, $suf) = $lvls[$#lvls] =~ m!([-\w]+).([-\w]+)!s;
my $tmp = $debug ? "/tmp/$call.log" : "/dev/null";
my ($LOG_FILE) = ($tmp =~ m!([-\w/\.]+)!s);
open(STDOUT, ">>$LOG_FILE");
select STDOUT; $| = 1;
open(STDERR, ">&STDOUT");
select STDERR; $| = 1;              # make unbuffered
#
#############################################################################
#
# Writer a marker to the log file.
#
mark_it("begun.", @args);
#
#
############################################################################
#
# Once the Site is identified from the command line,
# load the needed site specific parameters.
#
my $site_file = "$SHADOW_SITE_PATH/${Site}.ph";
load_config($site_file);
#
our ($SITE_LABEL, $SCAN_THRESHHOLD);
#
# If we have been called with a SNIFDATE parameter, set up the $subdir variable,
# else assume last hour.
#
our @cur_time = ();
our $snifdate;

if ($fetch_date eq "") {
#
# Fetch current time.
#
   @cur_time = localtime(time - 3599);
   $snifdate = strftime("%Y%m%d%H", @cur_time);
} else {
#
# Untaint the calling paramater $fetch_date
#
   ($snifdate) = $fetch_date =~ m!(\d{10})!s;
}
#
#  Unpack the "snifdate" into its useful components.
#
my ($year, $mon, $mday, $hour_only) = unpack("a4a2a2a2", $snifdate);
#
# Compensate for the way Perl stores months and years.
#
$mon -= 1; 
$year -= 1900;
#
# Convert our snif date back to time format.
#
our $snif_time = 0;
if ($tz eq "GMT") {
   $snif_time = timegm(0, 0, $hour_only, $mday, $mon, $year);
} else {
   $snif_time = timelocal(0, 0, $hour_only, $mday, $mon, $year);
}
#
# Let's try to keep track of some times. I'm easily confused, so if our
# sensor is in a different time zone, we need to relate it to GMT cause
# that seems like the thing to do.
#
my @gmt_snif_date = gmtime($snif_time);
#
# But at the same time, the person at the analyzer needs to relate to
# the time zone in which he is working. Mentally translating back and
# forth to GMT is a real pain in the posterior.
#
my @loc_snif_date = localtime($snif_time);
#
# Lets put the web page information in the timezone of the analyzer. 
# What timezone are we in?
#
POSIX::tzset();
my ($tz_name, $tz_dst) = POSIX::tzname();
#
my $TZ = ($tz_name, $tz_dst)[$loc_snif_date[8]];
my $tz_diff = ( 24 + $gmt_snif_date[2] - $loc_snif_date[2]) % 24;
#
# I still haven't decided what to do with all this time zone stuff. If
# all your sensors are in your time zone, no problem. If your sensors are
# in different time zones, then we need to use GMT time... Or do we?
#
our @snif_date = ();
if ($tz_diff == 0 ) {
   @snif_date = @gmt_snif_date;
} else {
   @snif_date = @loc_snif_date;
}
#
$snifdate = strftime("%Y%m%d%H", @snif_date);
$hour_only = strftime("%H", @snif_date);
my $hour = $hour_only . ":00";
our $subdir = strftime("%b%d", @snif_date);
our $output_dir = "${OUTPUT_WEB_DIR}/$subdir";
#
print STDOUT "snifdate = $snifdate, dir = $output_dir, hour = $hour\n";

#
# Predict the previous hour and next hour for html links.
#
my $last_hour = strftime("%Y%m%d%H", localtime($snif_time - 3600));
my $last_hour_dir = "../".strftime("%b%d", localtime($snif_time - 3600));
#
my $next_hour = strftime("%Y%m%d%H", localtime($snif_time + 3600));
my $next_hour_dir = "../".strftime("%b%d", localtime($snif_time + 3600));

print STDOUT "Last HR. = $last_hour, Next HR. = $next_hour\n";
print STDOUT "Last HR/dir = $last_hour_dir, Next HR/dir = $next_hour_dir\n";


#
#  Make sure subdirectory "MONXX" exists under $ANALYZER_DIR and
#  on web page
#
unless ( -d "$ANALYZER_DIR/$subdir") {
   eval { mkpath("$ANALYZER_DIR/$subdir", 0, 0755)  };
   if ($@) {
    die "Unable to mkdir $ANALYZER_DIR/$subdir: $?";
   }
}
unless ( -d "$output_dir") {
   eval { mkpath("$output_dir", 0, 0755)  };
   if ($@) {
    die "Unable to mkdir $output_dir: $?";
   }
}
#
# Prepare to copy down the raw gzipped tcpdump data file.
#
my $src_prefix = "${SENSOR}:";
my $src_dir = "$SENSOR_DIR";
my $src_file = "${src_dir}/tcp.${snifdate}.gz";
my $dst_dir = "$ANALYZER_DIR/$subdir";
my $zipped_file = "${dst_dir}/tcp.${snifdate}.gz";
my @ssh_cmd = "";
my @scp_cmd = "";
#
# If our raw file is already on the analyzer, don't re-fetch it.
#
unless ( (-f $zipped_file)) {
#
# Let's see if the file exists on our sensor?
#
   my @rmt_cmd = ("$SSH_CMD", "$SENSOR", "ls $src_file 2>&1");
   open(REMOTE, "-|")
      or exec(@rmt_cmd)
      or die("Can't execute ", join(' ', @rmt_cmd), ": $!");
   my $result = <REMOTE>;
   close(REMOTE);
   if ($result =~ /No such file/) {
      die("Unable to locate RAW data file on sensor.");
   }
#
   @scp_cmd = ("$SCP_CMD", "-q", "${src_prefix}${src_file}", "$zipped_file");
   print STDOUT (join(' ', @scp_cmd), "\n");
#
# If this script is running on the $SHADOW_FILE_SERVER, don't remotely 
# execute the scp command on the $SHADOW_FILE_SERVER, we can do it directly.
#
   my $my_hostname = hostname();
   my $my_address = gethostbyname($my_hostname);
   $my_address = sprintf("%vd", $my_address);
   my $server_address = gethostbyname($SHADOW_FILE_SERVER);
   $server_address = sprintf("%vd", $server_address);
   if ($my_address eq $server_address) {
      @ssh_cmd = @scp_cmd;
   } else {
      @ssh_cmd = ("$SSH_CMD", "-n", "$SHADOW_FILE_SERVER", join(' ', @scp_cmd));
   }
   print STDOUT (join(' ', @ssh_cmd), "\n");
#
# It's not on the analyzer, so fetch it from the sensor.
#
   system(@ssh_cmd) == 0 or
      die("Unable to copy zipped Data file from $SENSOR.");
#
# Wait a few seconds for the file to appear, give it 10 tries. We may
# be doing the fetch asynchronously.
#
   until (-e $zipped_file) {
      my $count++;
      print STDOUT "In wait loop, $zipped_file missing.\n";
      die("Unable to see: $zipped_file.") if ($count > 10);
      sleep 30;
   }
}
#
#  Call tcpdump to read the newly fetched file, scan it with our bad guys
#  filters, and write the results to the web page.
#
chdir($FILTER_DIR);
our @filters = glob("*.filter");
#

print STDOUT "Filter names: @filters\n";

our $output_txt_file = "$output_dir/$snifdate.txt";
our $scan_in_file = "$output_dir/$snifdate.scan_in";
our $scan_out_file = "$output_dir/$snifdate.scan_out";
our $output_html_file = "$output_dir/$snifdate.html";
my $prev_out_file = "$last_hour_dir/$last_hour.html";
my $next_out_file = "$next_hour_dir/$next_hour.html";

print STDOUT "zip file = $zipped_file\n";
print STDOUT "output(txt) = $output_txt_file\nprev = $prev_out_file\n";
print STDOUT "output(html) = $output_html_file\nnext = $next_out_file\n";

open(OUTPUT, ">$output_html_file");
#
# Write out the HTML header information to the html file.
#
print OUTPUT <<"EOF";
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Final//EN">
<HTML>
<HEAD>
<TITLE>Hourly tcpdump for $SITE_LABEL on $subdir at $hour $TZ.</TITLE>
<STYLE>
<!--
A:link          { color: blue; text-decoration: none}
A:visited       { color: purple; text-decoration: none}
-->
</STYLE>
<SCRIPT LANGUAGE="JavaScript" SRC="/js/openwin.js">
</SCRIPT>
</HEAD>
<BODY BGCOLOR='FFFFE1''> 
<H3>Site: $SITE_LABEL - Date: $subdir - $TZ: $hour.</H3>
<PRE>
EOF
close(OUTPUT);
#
# Create the text output file so each tcpdump iteration appends to it.
#
our (@out_handle, @out_file, @out_cmd, $scan_index);
#
if (not -e $output_txt_file) {
   open(OUT_TEXT, ">$output_txt_file");
   close(OUT_TEXT);
#
# Open our zipped data file, start the unzipper, and then start up 
# individual processes to tcpdump it through the filters.
#
   my @unzip_cmd = ($GUNZIP_CMD, "-c",  $zipped_file);      
   open(ZIP_CMD, "-|")
      or exec(@unzip_cmd)
      or die("Can't open unzip process: $!");
#
#  Loop through site filters, call tcpdump and save the output text file.
#
   my $no_filters = scalar(@filters);
   for (my $count =0; $count < $no_filters; $count++) {
      my ($fil) = $filters[$count] =~ m!([\w\.]+)!s;
      my ($file_suffix, undef) = split(/\./, $fil);
      $out_handle[$count] = IO::File->new();
      $out_file[$count] = $output_txt_file . "_$file_suffix";
      $out_cmd[$count] = ["$TCPDUMP_CMD", "-Sn", "-r", "-", "-F", "$fil"];
   }
   my $num_children = $no_filters + 1;
#
#  Add special file name and command for find_scan.pl script
#
   $scan_index = $num_children - 1;
   my $fil = "filter.getall";
   $out_handle[$scan_index] = IO::File->new();
   $out_file[$scan_index] = $scan_in_file;
   $out_cmd[$scan_index] = ["$TCPDUMP_CMD", "-tnq", "-r", "-", "-F", "$fil"];
#
# Open all the output commands...
#
   for (my $count =0; $count < $num_children; $count++) {
      printf STDOUT ("%s\n", join(' ', @{ $out_cmd[$count] }));
      unless (open ($out_handle[$count], "|-")) {
      
#
# This is the child process running tcpdump, reading gunzipped data from
# it parent on STDIN. Let's disconnect STDOUT and make it the output file
# named in $out_file[$count].
#
         open (STDOUT, "> $out_file[$count]");
         exec ( @{ $out_cmd[$count] } )
            or die ("Unable to start cmd: $out_cmd[$count] : $!");
         exit;
       }
   }
#
# Our output commands are open, read a buffer load from the unzipper, 
# and feed it to each of the output tcpdump commands.
#
   my $blksize = 32768;
   my $buf = "";
   while (my $read_len = read(ZIP_CMD, $buf, $blksize)) {
      if (!defined $read_len) {
         next if $! =~ /^Interrupted/;
         die "System read error: $!\n";
      }
      for (my $count =0; $count < $num_children; $count++) {
         my $write_len = $read_len;
         my $offset = 0;
         while ($write_len ) {          # Handle partial writes.
            my $written = syswrite($out_handle[$count], $buf, $write_len, $offset);
            die("System write error: $!\n")
               unless defined $written;
            $write_len -= $written;
            $offset += $written;
         }
      }
   }
   close(ZIP_CMD);
#
# Close all the pipes to our children.
#
   for (my $count = 0; $count < $num_children; $count++) {
      close($out_handle[$count]);
   }

#
# Concatenate all the output from the "normal" filters onto the 
# $output_txt_file. 
#
# The last file is the one created for find_scan.pl. It will be read by
# that script a bit later.
#
   open (TXT_OUT, ">>$output_txt_file") or
        die("Unable to open $output_txt_file: $!");
   for (my $count =0; $count < $no_filters; $count++) {
      if ($out_file[$count]) {
         open (TXT_IN, "<$out_file[$count]") or
              die("Unable to open $out_file[$count]: $!");
         while (<TXT_IN>) {
            print TXT_OUT $_;
         }
         close(TXT_IN);
         unlink($out_file[$count]) unless ($debug == 2);
      }
   }
   close(TXT_OUT);
}

#
# Call the condense.pl script to tidy up the output text file, remove
# piles of duplicated lines, sort and space the results by source IP and 
# time, and resolve the IP to names for the web page.
#
print STDOUT "Condensing ${output_txt_file}.\n";

my $sorted_txt_file = "${output_txt_file}.sorted";
my @condense_cmd = ("$SHADOW_PATH/condense.pl");
push @condense_cmd, "$output_txt_file", "$sorted_txt_file";
system("@condense_cmd") == 0 or
      die("Unable to condense $output_txt_file.");
#
# Add the output from the condensing to the HTML file.
#
print STDOUT "Copying ${output_txt_file}.sorted to $output_html_file.\n";

open(OUTPUT, ">>$output_html_file") or 
     die "Can't open $output_html_file";
   open(TEXTFILE, "<${output_txt_file}.sorted") or 
     die "Can't open ${output_txt_file}.sorted";
   while (<TEXTFILE>) {
      print OUTPUT $_;
   }
   close(TEXTFILE);
#
# Add a divider line to the HTML page.
#
   print OUTPUT "<HR SIZE=3>\n";
#
#
# The final tcpdump command created a file in the output directory for 
# use in detecting scans. Run that file through the find_scan.pl script,
# to create a scan_out file.
#
   open(RESULTS, "<$scan_in_file") 
      or die "Can't open $scan_in_file";
   my @find_scan_cmd = ();
   push @find_scan_cmd, "$SHADOW_PATH/find_scan.pl", "$scan_out_file";
   push @find_scan_cmd,  "$SCAN_THRESHHOLD";
   my $scan_pid = open(FIND_SCAN, "|-")
       or exec(@find_scan_cmd)
       or die ("Unable to start ", join(' ', @find_scan_cmd), ": $!"); 
   while (<RESULTS>) {
      print FIND_SCAN $_;
   }
   close(RESULTS);
   close(FIND_SCAN);
#
# Open the file containing the results of find_scan.pl, and append them
# to the web page.
#
   open(SCAN_RESULTS, "< $scan_out_file") or 
        die("Unable to open $scan_out_file : $!");
   while (<SCAN_RESULTS>) {
      print OUTPUT $_;
   }
   close(SCAN_RESULTS);
#
# Add a divider line to the HTML page.
#
   print OUTPUT "<HR SIZE=3>\n";
#
#
# Append the date information and navigation bar to the end of the HTML page.
#
   print OUTPUT <<"EOF";
</PRE>
<H3>Site: $SITE_LABEL - Date: $subdir - $TZ: $hour.</H3>
<HR>
<TABLE CELLSPACING="0" CELLPADDING="0">
<TR>
<TD ALIGN=CENTER VALIGN=MIDDLE><A HREF="$prev_out_file"><IMG SRC="/images/navbars/2/1.jpg" WIDTH="90" HEIGHT="20" BORDER="0" HSPACE="0" VSPACE="0"></A><IMG SRC="/images/navbars/2/2.jpg" WIDTH="110" HEIGHT="20" HSPACE="0" VSPACE="0"><A HREF="/tcpdump_results/index.html" TARGET="_top"><IMG SRC="/images/navbars/2/3.jpg" WIDTH="50" HEIGHT="20" BORDER="0" HSPACE="0" VSPACE="0"></A><IMG SRC="/images/navbars/2/2.jpg" WIDTH="110" HEIGHT="20" HSPACE="0" VSPACE="0"><A HREF="$next_out_file"><IMG SRC="/images/navbars/2/5.jpg" WIDTH="90" HEIGHT="20" BORDER="0" HSPACE="0" VSPACE="0"></A></TD></TR>
</TABLE>

</BODY>
</HTML>
EOF
   close(OUTPUT);
#
# Clean up temporary files.
#
unless ($debug == 2) {
   unlink($output_txt_file) if ( -e $output_txt_file);
   unlink($sorted_txt_file) if ( -e $sorted_txt_file);
   unlink($scan_in_file) if ( -e $scan_in_file);
   unlink($scan_out_file) if ( -e $scan_out_file);
}
#
mark_it("completed.", @args);
#
