#! /usr/bin/perl -Tw
#
# find_scan.pl         - SHADOW Version 1.8
#                        Last changed 24 Dec 2002
#
# Written by Bill Ralph <RalphWD@nswc.navy.mil>.
#
#  This script expects the output of a gunzip command containing a libpcap
#  tcpdump file. The script parses the output lines and collect statistics 
#  about multiple external sources contacting multiple internal destinations.
#  This information can assist in indication "potential" external scanners.
#  
#  It requires two command line arguments. The first is the name of the 
#  file into which the output will be written. The second is the count of
#  number of different destination IP addresses that a single source IP
#  addresses contacts over which a "scan" is a likely possibility. When
#  started by fetchem.pl, the second paramter is furnished by a parameter
#  in the SHADOW configuration file: $SYS_THRESHHOLD.
#
use strict;
use File::Basename;
#
#  Declare our globals:
#
my (
    %src_dsthash, $src_ip, $num_ports, %tgt_sys, %tgt_port, %tgt_hits
   );
#
############################################################################
#
sub read_data() 
{
#
   my $pkt_number = 0;

   while(<STDIN>) 
   {
      $pkt_number++;
#     next if /gre-proto/;
      next if /trunc/;
#     next if /ESP/;
      my ($src_ip, undef, $dst_ip, $ip_proto, undef) = split(/\s+/, $_, 5);

      my $src_port = "";
      my @ip = split(/\./, $src_ip);
      if (scalar(@ip) == 5) {
         $src_port = pop(@ip);
         $src_ip = join('.', @ip);
      }

      $dst_ip =~ tr/://d;
      my $dst_port = "";
      $dst_port = "ICMP" if ($ip_proto eq "icmp:");
      @ip = split(/\./, $dst_ip);
      if (scalar(@ip) == 5) {
         $dst_port = pop(@ip);
         $dst_ip = join('.', @ip);
      }
 
      $src_dsthash{$src_ip}{$dst_ip}{$dst_port}++;
      if ($pkt_number%10000 == 0) {
         printf STDERR "Packet number %-10i processed....\r", $pkt_number;
      }
   }
   print STDERR "\n";
}
#
#########################################################################
#
sub by_ip
{
   my @avec = split(/\./ , $a);
   my @bvec = split(/\./ , $b);

   $avec[0] <=> $bvec[0]
       or
   $avec[1] <=> $bvec[1]
       or
   $avec[2] <=> $bvec[2]
       or
   $avec[3] <=> $bvec[3]
}
############################################################################
#
my $output_filename = $ARGV[0];
die("No output file name specified.") if (! $output_filename);
my ($output_dir, $output_file) = ("", "");
my ($tmp) = $output_filename =~ m!([-\w./]+)!s;
$output_dir = dirname($tmp);
$output_file = basename($tmp);
$output_filename = "$output_dir/$output_file";
#
open(OUT,">$output_filename") || die("Unable to open $output_filename: $!");
#
my $sys_threshhold = $ARGV[1] ? $ARGV[1] : 100;
my $port_threshhold = 3*$sys_threshhold;
#
print STDERR "Begin find_scan.pl \n";

&read_data();


#print STDERR "Analyzing output....\n";

foreach $src_ip (keys(%src_dsthash))
{
   my $num_hits = 0;
   my $total_ports = 0;
   my $num_sys = scalar(keys(%{ $src_dsthash{$src_ip} }));
   my %union = ();
   foreach my $dst_ip (keys(%{ $src_dsthash{$src_ip} })) {
      $num_ports = scalar(keys(%{ $src_dsthash{$src_ip}{$dst_ip} } ));
      $total_ports += $num_ports;
      foreach my $dst_port (keys(%{ $src_dsthash{$src_ip}{$dst_ip} } )) {
         $num_hits += $src_dsthash{$src_ip}{$dst_ip}{$dst_port};
         $union{$dst_port} = 1;
      }
   }
   my $distinct_ports = scalar(keys(%union));
   if ($distinct_ports) {
      if (
          ($num_sys > $sys_threshhold) ||
          (($num_sys < $sys_threshhold/10) && 
           ($distinct_ports > $port_threshhold))
         ) {
         $tgt_sys{$src_ip} = $num_sys;
         $tgt_port{$src_ip} = $distinct_ports;
         $tgt_hits{$src_ip} = $num_hits;
      }
   }
}

#print STDERR "Writing output file .....\n";


printf(OUT "%-7s %-7s %-7s %-17s %-50s \n\n",
        "#IPs", "ports", "pkts", "src", "name");

foreach $src_ip (sort by_ip keys(%tgt_sys))
{
   my ($a, $b, $c, $d) = split(/\./, $src_ip);
   my $binip = pack "c4", ($a, $b, $c, $d);
   my @info = gethostbyaddr($binip,2);
   my $srcname = $info[0];

   $srcname = " " unless ($srcname);
   printf(OUT "%-7d %-7s %-7d %-17s %-40s \n",
     $tgt_sys{$src_ip}, $tgt_port{$src_ip}, $tgt_hits{$src_ip},
     $src_ip, $srcname);
}
#
close(OUT);

print STDERR "End find_scan.pl.\n";
