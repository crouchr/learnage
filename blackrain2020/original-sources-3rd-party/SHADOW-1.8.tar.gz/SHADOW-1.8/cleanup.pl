#!/usr/bin/perl -Tw
#
# cleanup.pl         - SHADOW Version 1.8
#                      Last changed 09 Oct 2002
#
#  Script to clean up the directory on the SENSOR to prevent loss of data 
#  due to a disk partition filling up. 
#  This script will be run by cron nightly.
#  
#  Written by Bill Ralph <RalphWD@nswc.navy.mil>
#
# Set up some variables.
#
use strict;
use Getopt::Long;
use POSIX qw(strftime);
use Sys::Syslog qw(:DEFAULT setlogsock);
#
$ENV{PATH} = "/bin:/usr/bin:/usr/local/bin";
delete @ENV{qw(IFS CDPATH ENV BASH_ENV)};
#
#########################################################################
#
sub load_config {
#
# This subroutine loads a configuration file, and will abort if the file
# is missing, non-parsible, or non-compilable.
#
   my $config_file = shift;
   unless (my $do_return = do "$config_file") {
      die ("Couldn't find $config_file") if (! -e $config_file);
      die ("Couldn't parse $config_file: $@") if $@;
      die ("Couldn't compile $config_file: $!")
         unless (defined $do_return);
      die ("Couldn't run $config_file") unless ($do_return);
   }
}
#
##########################################################################
#
sub usage {
        print "Usage: cleanup.pl [-debug] -d YYYYMMDD -l Site.\n";
        exit 2;
}
#
##########################################################################
#
#	Load the SHADOW configuration file and declare our globals.
#
load_config("/etc/shadow.conf");
#
our (
     $SHADOW_PATH, $SSH_CMD, $DF_CMD, $SENSOR, $SENSOR_DIR, $CLEAN_TIME
    );
our ($debug, $clean_date, $Site, $site);
#
##
#
#  Rid ourselves of standard output and error to prevent tons of mail messages
#  from cron.
#
my @lvls = split(/\//,$0);				# Split path
my ($call, $suf) = $lvls[$#lvls] =~ m!([-\w]+).([-\w]+)!s;
if ($debug) {
   my $LOG_FILE = "/tmp/$call.log";
   open(STDOUT, ">>$LOG_FILE");
   open(STDERR, ">&STDOUT");
}
select STDOUT; $| = 1;
select STDERR; $| = 1;              # make unbuffered
#
############################################################################
#
sub mark_it {
#
# This subroutine writes a time and command marker to the output file and
# the system log.
#
   my ($suffix, @args) = @_;
   my $marker = strftime("%Y-%b-%d %T:", localtime(time));
   my $params = join(" ", @args);
   my $log_line = "$0($params) => $suffix";
   my $out_line = $marker . $log_line;
   print STDOUT "$out_line\n";
   setlogsock('unix');
   openlog("SHADOW", 'nowait', 'user');
   syslog('info', '%s', $log_line);
   closelog();
}
#
############################################################################
#
# Write a marker to the log file.
#
mark_it("begun.", @ARGV);
#
##########################################################################
#
#	Parse the parameters.
#
&GetOptions("debug", \$debug, "d:s", \$clean_date, "l=s", \$site);
my $date_len = $clean_date ? length($clean_date) : 0;
#
# Untaint the $site.
#
($Site) = $site =~ m!([-\w]+)!s;
#
# Parse the $clean_date  into its subcomponents.
#
if ($clean_date) {
#
# Untaint the $clean_date and unpack it.
#
   my ($date) = $clean_date =~ m!(\d{8})!s;
   die("Unknown date format: $clean_date") unless ($date);
}
############################################################################
#
print STDOUT "Command line: d = $clean_date \n" if ($clean_date);
print STDOUT "Command line: l = $Site \n";
#  
#
# Once the Site is identified from the command line,
# load the needed external Parameters.
#
load_config("$SHADOW_PATH/sites/$Site.ph");

#
# If the $clean_date is specified in the call, use it, otherwise
# use the default specified in the site-specific .ph file.
#
unless ($clean_date) {
   my @def_clean_time = localtime(time - $CLEAN_TIME*24*60*60-15*60);
   my $def_clean_date = strftime("%Y%m%d", @def_clean_time);
   $clean_date = $def_clean_date;
}
print STDOUT "clean_date = $clean_date\n";

#
#
# Remove the files matching our clean_date
#
my $file_pat = "$SENSOR_DIR/tcp.$clean_date??.gz";
my @rmt_cmd = ();
push @rmt_cmd, "$DF_CMD $SENSOR_DIR";
if ($debug) {
   push @rmt_cmd, "echo \'rm $file_pat\'";
} else {
   push @rmt_cmd, "rm $file_pat";
}
push @rmt_cmd, "$DF_CMD $SENSOR_DIR";
my $rmt_cmd = join(';', @rmt_cmd);

my @ssh_cmd = ("$SSH_CMD", "$SENSOR", "$rmt_cmd");
print STDOUT "Removing $file_pat from $SENSOR.\n";
#print STDOUT ("$SSH_CMD $SENSOR $rmt_cmd\n");

system(@ssh_cmd) == 0  or 
     die("Can't run $SSH_CMD $SENSOR $rmt_cmd");
#
############################################################################
#
# Write a marker to the log file.
#
mark_it("ended.");
#
