#! /usr/bin/perl -Tw
#
# do_daily_stats.pl             - SHADOW Version 1.8
#                                 Last changed 26 Nov 2002
#
# This script takes location (site) and date (YYYYMMDD) as parameters and
# loops through the hourly tcpdump SHADOW files (tcp.YYYYMMDDHH.gz) to 
# construct a daily statistical summary of the packets documented in those 
# files. This one script replaces run_daily_byhr_stats.pl, 
# combine_hourly_stats.pl, and run_daily_stats.pl by performing the
# complete daily job in one script, at the cost of producing no hourly
# statistics. Built hopefully speed up an annoyingly long (> 8 hours)
# sequence of obtaining the statistics.
#
#  Written by Bill Ralph	<RalphWD@nswc.navy.mil>
#
use strict;
use Getopt::Long;
use POSIX qw(strftime);
use Sys::Syslog qw(:DEFAULT setlogsock);
use Time::Local;
use File::Basename;
#
my @args = @ARGV;
#
#########################################################################
#
sub load_config {
#
# This subroutine loads a configuration file, and will abort if the file
# is missing, non-parsible, or non-compilable.
#
   my $config_file = shift;
   unless (my $do_return = do "$config_file") {
      die ("Couldn't find $config_file") if (! -e $config_file);
      die ("Couldn't parse $config_file: $@") if $@;
      die ("Couldn't compile $config_file: $!")
         unless (defined $do_return);
      die ("Couldn't run $config_file") unless ($do_return);
   }
}
#
############################################################################
#
load_config("/etc/shadow.conf");
#
our ($SHADOW_PATH, $SHADOW_SITE_PATH, $OUTPUT_WEB_DIR, $ANALYZER_DIR);
#
$ENV{PATH} = "/bin:/usr/bin:/usr/local/bin:$SHADOW_PATH";
delete @ENV{qw(IFS CDPATH ENV BASH_ENV)};
#
my ($fetch_date, $debug, $site, $snifdate);
#
############################################################################
#
sub mark_it {
#
# This subroutine writes a time and command marker to the output file and
# the system log.
#
   my ($suffix, @args) = @_;
   my $marker = strftime("%Y-%b-%d %T:", localtime(time));
   my $params = join(" ", @args);
   my $log_line = "$0($params) => $suffix";
   my $out_line = $marker . $log_line;
   print STDOUT "$out_line\n";
   setlogsock('unix');
   openlog("SHADOW", 'nowait', 'user');
   syslog('info', '%s', $log_line);
   closelog();
}
#
############################################################################
#
sub usage {
        print "Usage: do_daily_stats.pl -location Site {-debug} {-date YYYYMMDD}.\n"
;
        exit 2;
}
#
############################################################################
#
#       Parse the parameters.
#
#
&GetOptions("debug", \$debug, "date:s", \$fetch_date, "location=s", \$site);
#
############################################################################
#
#  Rid ourselves of standard output and error to prevent tons of mail messages
#  from cron.
#
my @lvls = split(/\//,$0);                              # Split path
my ($call, $suf) = split(/\./, $lvls[$#lvls]);  # Split call.suffix
my $tmp = $debug ? "/tmp/$call.log" : "/dev/null";
my ($LOG_FILE) = ($tmp =~ m!([-\w/\.]+)!s);
open(STDOUT, ">>$LOG_FILE");
select STDOUT; $| = 1;
open(STDERR, ">&STDOUT");
select STDERR; $| = 1;              # make unbuffered
#
#############################################################################
#
# Writer a marker to the log file.
#
mark_it("begun.", @args);
#
###############################################################################
#
#  Check parameter validity.
#
my $fdlen = $fetch_date ? length($fetch_date) : 0;
if (("$site" eq "") or (($fdlen > 0) and ($fdlen != 8) ))
{
        usage();
}
#
# Untaint the $site.
#
(my $Site) = $site =~ m!([-\w]+)!s;
#
############################################################################
#
# 
# Once the Site is identified from the command line, 
# load the needed external Parameters.  
#
load_config("$SHADOW_SITE_PATH/${Site}.ph");
#
our ($SITE_LABEL);
#
load_config("$SHADOW_PATH/stats/statistics.ph");
#
#
# If we have been called with a date parameter, set up the $subdir variable,
# else assume the midnight of yesterday.
#
if (! defined $fetch_date) {
#
# Fetch time of 24 hours ago..
#
   my @cur_time = localtime(time - 86400);
   $snifdate = strftime("%Y%m%d", @cur_time);
} else {
   ($snifdate) = $fetch_date =~ m!(\d{8})!s;
   die("Unknown date format: $fetch_date") unless ($snifdate);
}
#
#  Unpack the "snifdate" into its useful components.
#
my ($year, $mon, $mday) = unpack("a4a2a2", $snifdate);
#
# Compensate for the way Perl stores months and years.
#
$mon -= 1; 
$year -= 1900;
#
# Convert our snif date back to time format.
#
my $snif_time = timelocal(0, 0, 0, $mday, $mon, $year);
my @snif_date = localtime($snif_time);
#
my $subdir = strftime("%b%d", @snif_date);
my $output_dir = "${OUTPUT_WEB_DIR}/$subdir";
my $dst_dir = "$ANALYZER_DIR/$subdir";
#
# Predict the previous day and next day for html links.
#
my $last_day = strftime("%Y%m%d", localtime($snif_time - 86400));
my $last_day_dir = strftime("%b%d", localtime($snif_time - 86400));
$last_day_dir = "../$last_day_dir";
#
my $next_day = strftime("%Y%m%d", localtime($snif_time + 86400));
my $next_day_dir = strftime("%b%d", localtime($snif_time + 86400));
$next_day_dir = "../$next_day_dir";

print STDOUT "Last Day = $last_day, Next Day = $next_day\n";
print STDOUT "Last Day/dir = $last_day_dir, Next Day/dir = $next_day_dir\n";
#
my $stats_output_text = "${output_dir}/stats.${snifdate}.txt";
my $stats_output_html = "${output_dir}/stats.${snifdate}.html";
my $prev_day_file = "${last_day_dir}/stats.${last_day}.html";
my $next_day_file = "${next_day_dir}/stats.${next_day}.html";
#
my $stats_file = "${dst_dir}/daily_stats.dat";
#
#  Initialize the statistics pool.
#
   &init_state();
#
# Loop through the hours of the day.
#
for (my $hr=0; $hr<24; $hr++) {
#
# Convert our snifdate back to time format.
#
   my $snif_time = timelocal(0, 0, $hr, $mday, $mon, $year);
   my @snif_date = localtime($snif_time);
   my $snifdate = strftime("%Y%m%d%H", @snif_date);
#
   my $subdir = strftime("%b%d", @snif_date);
   my $dst_dir = "$ANALYZER_DIR/$subdir";
   print STDOUT "\$dst_dir = $dst_dir\n";
#
# Run script to read the tcpdump binary files and accumulate statistics
# for this hour.
#
   my $rawfile = "${dst_dir}/tcp.${snifdate}.gz";
   next if (! -e $rawfile);
   print STDOUT "Analyzing: $rawfile, data to: $stats_file\n";
#
# Read the Raw file and collect the statistics.
#
   &read_rawfile($rawfile);
}
#
# Save the statistics data.
#
   &save_state($stats_file) if ($stats_file);
#
printem($stats_output_text, $stats_file);
#
open(HTMLFILE, ">$stats_output_html");
#
# Write out the HTML header information to the html file.
#
print HTMLFILE <<"EOF";
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Final//EN">
<HTML>
<HEAD>
<STYLE>
<!--
A:link          { color: blue; text-decoration: none}
A:visited       { color: purple; text-decoration: none}
-->
</STYLE>
<TITLE>$subdir Traffic Statistics for $SITE_LABEL.</TITLE>
</HEAD>
<BODY BGCOLOR='FFFFE1''>
<H3>Site: $SITE_LABEL - Date: $subdir.</H3>
<PRE>
EOF
#
# Append the text generated by the printem subroutine onto the HTML file.
#
open(TXTFILE, "<$stats_output_text");
while (<TXTFILE>) {
   print HTMLFILE $_;
}
close(TXTFILE);
#
# Append the date information and navigation bar to the end of the HTML page.
#
print HTMLFILE <<"EOF";
</PRE>
<H3>Site: $SITE_LABEL - Date: $subdir.</H3>
<HR>
<TABLE CELLSPACING="0" CELLPADDING="0">
<TR>
<TD ALIGN=CENTER VALIGN=MIDDLE><A HREF="$prev_day_file"><IMG SRC="/images/navbars/2/1.jpg" WIDTH="90" HEIGHT="20" BORDER="0" HSPACE="0" VSPACE="0"></A><IMG SRC="/images/navbars/2/2.jpg" WIDTH="110" HEIGHT="20" HSPACE="0" VSPACE="0"><A HREF="/tcpdump_results/index.html" TARGET="_top"><IMG SRC="/images/navbars/2/3.jpg" WIDTH="50" HEIGHT="20" BORDER="0" HSPACE="0" VSPACE="0"></A><IMG SRC="/images/navbars/2/2.jpg" WIDTH="110" HEIGHT="20" HSPACE="0" VSPACE="0"><A HREF="$next_day_file"><IMG SRC="/images/navbars/2/5.jpg" WIDTH="90" HEIGHT="20" BORDER="0" HSPACE="0" VSPACE="0"></A></TD></TR>
</TABLE>

</BODY>
</HTML>
EOF
close(HTMLFILE);
unlink($stats_output_text) if ($stats_output_text);
#
mark_it("completed.");
close(STDOUT);
#
# End of do_daily_stats.pl
