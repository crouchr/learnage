#! /usr/bin/perl -Tw
#
# print_stats.pl         - SHADOW Version 1.8
#                          Last changed 03 Jan 2003
#
#
#  Script to read a file dumped by statistics.pl containging a number of
#  arrays and hashes with statistics from one or more tcpdump files, and
#  print out those statistics.
#
#  Written by Bill Ralph <RalphWD@nswc.navy.mil>
#
#
use strict;
use File::Basename;
use Cwd;
use Sys::Syslog;
#
#########################################################################
#
sub load_config {
#
# This subroutine loads a configuration file, and will abort if the file
# is missing, non-parsible, or non-compilable.
#
   my $config_file = shift;
   unless (my $do_return = do "$config_file") {
      die ("Couldn't find $config_file") if (! -e $config_file);
      die ("Couldn't parse $config_file: $@") if $@;
      die ("Couldn't compile $config_file: $!")
         unless (defined $do_return);
      die ("Couldn't run $config_file") unless ($do_return);
   }
}
#########################################################################
#
load_config("/etc/shadow.conf");
#
our ($SHADOW_PATH);
#
load_config("$SHADOW_PATH/stats/statistics.ph");
#
$ENV{PATH} = "/bin:/usr/bin:/usr/local/bin:$SHADOW_PATH";
delete @ENV{qw(IFS CDPATH ENV BASH_ENV)};
#
############################################################################
#
# First calling parameter is raw Storable file to read. Second parameter is 
# statistics output file.
#
########################################################################
#
my $input_filename = $ARGV[0];
my $output_filename = $ARGV[1];
#
if (! $input_filename) {
   die("No input filename specified.")
} else {
   my ($input_dir, $input_file) = ("", "");
   my ($tmp) = $input_filename =~ m!([-\w./]+)!s;
   $input_dir = dirname($tmp);
   $input_file = basename($tmp);
   $input_filename = "$input_dir/$input_file";
   die("No such file: $input_filename : $?") unless (-e $input_filename);
}
#
if ((! $output_filename) || ($output_filename eq "-")) {
   $output_filename = "-";
} else {
   my ($output_dir, $output_file) = ("", "");
   my ($tmp) = $output_filename =~ m!([-\w./]+)!s;
   $output_dir = dirname($tmp);
   $output_file = basename($tmp);
   $output_filename = "$output_dir/$output_file";
}
#
# Fetch previous stored data if it exists
#
&fetch_state($input_filename);
#
# Print out the results.
#
&printem($output_filename, $input_filename);
#
# End of print_stats.pl
#
