// Javascript code used by the SHADOW system.
//
// openwin.js		- SHADOW version 1.8
//                        Last modified 21 Feb 2002
//
// writen by:		  Bill Ralph <RalphWD@nswc.navy.mil>
//
// -----------------------------------------------------------------------
// Open a window
function OpenWindow(page, win_name, horiz, vert) 
{
    var newwin = window.open(page, win_name,
     "width="+horiz+",height="+vert+",scrollbars=yes,resizable=yes,status=yes");
    newwin.focus();
    if (newwin != null && newwin.opener == null) newwin.opener = self;
} 
// -----------------------------------------------------------------------
//
function whoisWin()
{
   OpenWindow('', 'whois', '614', '450');
}
// -----------------------------------------------------------------------
//
function SearchWin()
{
   var newwin = window.open('', 'search',
     "width=670,height=700,scrollbars,resizable,status,menubar");
   newwin.focus();
   if (newwin != null && newwin.opener == null) newwin.opener = self;
}
// -----------------------------------------------------------------------
//
function ReportWin()
{
   var newwin = window.open('', 'compose',
     "width=620,height=675,scrollbars,resizable,status,menubar");
   newwin.focus();
   if (newwin != null && newwin.opener == null) newwin.opener = self;
}
// -----------------------------------------------------------------------
//
function ToolWin()
{
   window.name = "shadow";
   var newwin = window.open('/cgi-bin/tools.cgi', 'tools',
     "width=155,height=610");
   newwin.focus();
   if (newwin != null && newwin.opener == null) newwin.opener = self;
}
// -----------------------------------------------------------------------
//
function KillWin()
{
   window.name = "search";
   var newwin = window.open('/cgi-bin/kill_group.cgi', 'killer',
     "width=200,height=50");
   newwin.focus();
   if (newwin != null && newwin.opener == null) newwin.opener = self;
}

