/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TDEFINE = 258,
     TUNDEF = 259,
     TIFDEF = 260,
     TIFNDEF = 261,
     TIFNHOST = 262,
     TIFHOST = 263,
     TELSE = 264,
     TENDIF = 265,
     TINCLUDE = 266,
     TBEGIN_CONFIG = 267,
     TEND_CONFIG = 268,
     TBEGIN_DB = 269,
     TEND_DB = 270,
     TEND_DBNOMD = 271,
     TID = 272,
     TSTRING = 273,
     TACLNOSYMLINKFOLLOW = 274,
     TWARNDEADSYMLINKS = 275,
     TGROUPED = 276,
     TSUMMARIZECHANGES = 277,
     TNEWLINE = 278,
     TVERBOSE = 279,
     TCONFIG_FILE = 280,
     TDATABASE = 281,
     TDATABASE_OUT = 282,
     TDATABASE_NEW = 283,
     TREPORT_URL = 284,
     TGZIPDBOUT = 285,
     TUMASK = 286,
     TTRUE = 287,
     TFALSE = 288,
     TRECSTOP = 289,
     TCONFIG_VERSION = 290,
     TSELRXRULE = 291,
     TEQURXRULE = 292,
     TNEGRXRULE = 293,
     TRIGHTS = 294,
     TUSER = 295,
     TGROUP = 296,
     TINODE = 297,
     TLINKCOUNT = 298,
     TFTYPE = 299,
     TSIZE = 300,
     TGROWINGSIZE = 301,
     TATIME = 302,
     TCTIME = 303,
     TMTIME = 304,
     TACL = 305,
     TXATTRS = 306,
     TSELINUX = 307,
     TE2FSATTRS = 308,
     TTIGER = 309,
     TSHA1 = 310,
     TRMD160 = 311,
     TMD2 = 312,
     TMD4 = 313,
     TMD5 = 314,
     TSHA256 = 315,
     TSHA512 = 316,
     TWHIRLPOOL = 317,
     TL = 318,
     TR = 319,
     TGZIPHEADER = 320,
     TDBSPEC = 321,
     TUNKNOWN = 322,
     TNAME = 323,
     TERROR = 324,
     TEOF = 325
   };
#endif
/* Tokens.  */
#define TDEFINE 258
#define TUNDEF 259
#define TIFDEF 260
#define TIFNDEF 261
#define TIFNHOST 262
#define TIFHOST 263
#define TELSE 264
#define TENDIF 265
#define TINCLUDE 266
#define TBEGIN_CONFIG 267
#define TEND_CONFIG 268
#define TBEGIN_DB 269
#define TEND_DB 270
#define TEND_DBNOMD 271
#define TID 272
#define TSTRING 273
#define TACLNOSYMLINKFOLLOW 274
#define TWARNDEADSYMLINKS 275
#define TGROUPED 276
#define TSUMMARIZECHANGES 277
#define TNEWLINE 278
#define TVERBOSE 279
#define TCONFIG_FILE 280
#define TDATABASE 281
#define TDATABASE_OUT 282
#define TDATABASE_NEW 283
#define TREPORT_URL 284
#define TGZIPDBOUT 285
#define TUMASK 286
#define TTRUE 287
#define TFALSE 288
#define TRECSTOP 289
#define TCONFIG_VERSION 290
#define TSELRXRULE 291
#define TEQURXRULE 292
#define TNEGRXRULE 293
#define TRIGHTS 294
#define TUSER 295
#define TGROUP 296
#define TINODE 297
#define TLINKCOUNT 298
#define TFTYPE 299
#define TSIZE 300
#define TGROWINGSIZE 301
#define TATIME 302
#define TCTIME 303
#define TMTIME 304
#define TACL 305
#define TXATTRS 306
#define TSELINUX 307
#define TE2FSATTRS 308
#define TTIGER 309
#define TSHA1 310
#define TRMD160 311
#define TMD2 312
#define TMD4 313
#define TMD5 314
#define TSHA256 315
#define TSHA512 316
#define TWHIRLPOOL 317
#define TL 318
#define TR 319
#define TGZIPHEADER 320
#define TDBSPEC 321
#define TUNKNOWN 322
#define TNAME 323
#define TERROR 324
#define TEOF 325




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 45 "conf_yacc.y"
{
  char* s;
  DB_ATTR_TYPE i;
}
/* Line 1489 of yacc.c.  */
#line 194 "conf_yacc.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE conflval;

