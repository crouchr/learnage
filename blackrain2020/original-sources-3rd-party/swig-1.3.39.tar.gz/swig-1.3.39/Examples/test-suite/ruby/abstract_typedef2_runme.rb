#!/usr/bin/env ruby
#
# Put description here
#
# 
# 
# 
#

require 'swig_assert'
require 'abstract_typedef2'

include Abstract_typedef2

swig_assert( 'a = A_UF.new' )


