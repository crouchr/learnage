from java.sql import SQLException
from java.sql import DriverManager
from java.lang import Class


class classPathHacker():
	"""
    Author: SG Langer Jan 2007 
    Loads the MySQL/J jar at runtime
    """
	import java.lang.reflect.Method
	import java.io.File
	import java.net.URL
	import java.net.URLClassLoader
	import jarray

	def addFile(self, s):
		f = self.java.io.File(s)
		u = f.toURL()
		a = self.addURL(u)
		return a

	def addURL(self, u):
		sysloader =  self.java.lang.ClassLoader.getSystemClassLoader()
		sysclass = self.java.net.URLClassLoader
		method = sysclass.getDeclaredMethod("addURL", [self.java.net.URL])
		a = method.setAccessible(1)
		jar_a = self.jarray.array([u], self.java.lang.Object)
		b = method.invoke(sysloader, [u])
		return u

class SQLiteDB():
	"""
    Class to interact with a SQLite database
    """
	def __init__(self):
		jarLoad = classPathHacker()
		a = jarLoad.addFile("GlastopfNG_lib/sqlitejdbc-v057-pure.jar")
		Class.forName("org.sqlite.JDBC")
		self.url = "jdbc:sqlite:" + dorkListPresenter_dorkdb

	def sqlite_get_dorks(self):
		# Shows the database content
		db = DriverManager.getConnection(self.url)
		statement = db.prepareStatement("SELECT dork FROM log")
		try:
			result = statement.executeQuery()
		except SQLException, e:
			print "SQLite error reading dork db:", e.message
			dorks = False
		else:
			if not result.next():
				dorks = False
			else:
				dorks = []
				while result.next():
					dorks.append(result.getString(1))
		result.close()
		statement.close()
		db.close()
		return dorks
	
	
def dorkListPresenter():
	pre_data = ""
	post_data = ""

	try: dorkListPresenter_prefile
	except NameError:
		pass
	else:
		pre_file = open(dorkListPresenter_prefile, 'r')
		pre_data = pre_file.read()
		pre_file.close()

	try: dorkListPresenter_postfile
	except NameError:
		pass
	else:
		post_file = open(dorkListPresenter_postfile, 'r')
		post_data = post_file.read()
		post_file.close()

	sqlite = SQLiteDB()
	dorks = sqlite.sqlite_get_dorks()
	if dorks:
		uniquelines = dorks
	else:
		f = open(dorkListPresenter_dorkfile, 'r')
		uniquelines = set(f.read().split("\n"))
		f.close()
	dorks = "".join(["<a href='"+line+"'>"+ line + "</a><br/>" for line in uniquelines])

	return pre_data+dorks+post_data