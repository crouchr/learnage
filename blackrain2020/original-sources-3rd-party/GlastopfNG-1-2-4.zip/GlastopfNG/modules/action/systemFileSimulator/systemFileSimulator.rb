require 'net/http'

# TODO: Add the posibility to add something before and something after the "system" output

def systemFileSimulator()
  module_path = "./modules/action/systemFileSimulator/files/"
  $decodedRawRequest = URI.decode($rawRequest)
  
  if (/.*\/etc\/passwd.*/.match($decodedRawRequest))
    return get_file_as_string(module_path+"etc_passwd.txt")
  elseif(/.*=id( -[a-z]{1,3})$/.match($decodedRawRequest))
    return get_file_as_string(module_path+"id.txt")
  else
    return "file not found"
  end
end

def get_file_as_string(filename)
  data = ''
  f = File.open(filename, "r") 
  f.each_line do |line|
    data += line
  f.close
  end
  return data
end
