import re
import urllib2
import urllib
import cgi
import random

from time import gmtime, strftime
"""
available parameters:
uri, method, headers, params, rawRequest, clientIpAddr, totalImpact, timestamp
"""

def log(msg):
    print "[php_emulator] %s" % msg

def lineparse(line):
    """Replaces the variables with information."""
    # Looking for uname string and answering with predefined systems
    if re.search("uname|Uname|Kernel|UNAME", line):
        uname = ["Linux debian 2.6.8 Tue Dec 12 12:58:25 UTC 2007 i686 " \
                "GNU/Linux","Linux my.leetserver.com 2.6.18-6-k7 #1 " \
                "SMP Fri Jun 6 22:56:53 UTC 2008 i686 GNU/Linux"]
        if re.search("\$", line):
            line = cgi.escape(line.partition("$")[0]) + random.choice(uname) + "<br>"
        else:
            line = cgi.escape(line.partition(":")[0]) + ": " + random.choice(uname) + "<br>"
        return line
    # Answering every operating system request with linux
    elif re.search("os\:|OSTYPE|SySOs", line):
        line = cgi.escape(line.partition(" ")[0]) + " Linux<br>"
        return line
    # Generating a totally random uptime and load response
    elif re.search("\$up|uptime", line):
        line = cgi.escape(line.partition(" ")[0]) + " " + \
        strftime("%H:%M:%S", gmtime()) + " up " + str(random.randint(10,200)) \
        + " days, " + str(random.randint(10,24)) + ":" \
        + str(random.randint(10,59)) + ", " \
        + str(random.randint(0,2)) + " user, load average: 0." \
        + str(random.randint(0,70)) + ", 0." \
        + str(random.randint(10,50)) + ", 0." \
        + str(random.randint(10,20)) + "<br>"
        return line
    # The webserver user with random uid and gid
    elif re.search("\$id.|id\:|eseguicmd|UID", line) and line != "ID":
        id = str(random.randint(30,70))
        uid = random.choice(["www-data","webserver","server","user",
                             "apache","www","data"])
        line = cgi.escape(line.partition(":")[0]) + ": uid=" + id + "(" \
                + uid + ") gid=" \
                + id + "(" + uid + ") groups=" \
                + id + "(" + uid + ")<br>"
        return line
    # The webroot
    elif re.search("\$pwd.|pwd|DIR", line):
        dir = ["/var/www/httpdocs","/var/www/server","/var/www/",
               "/var/www/http","/var/www/webserver"]
        line = cgi.escape(line.partition(":")[0]) + ": " \
                + random.choice(dir) + "<br>"
        return line
    # Answering NONE to user requests
    elif re.search("\$usr.|user|User|USER", line):
        line = cgi.escape(line.partition(":")[0]) + ": <br>"
        return line
    # PHP Version reponse
    elif re.search("\$php.|php.", line):
        phpv =["5.2.6","5.0.1","4.2.3"]
        line = cgi.escape(line.partition(" ")[0]) + " " \
                + random.choice(phpv) + "<br>"
        return line
    # Webserver software response
    elif re.search("\$sof.|SoftWare|software|sof|Software", line):
        webserver = ["Apache/2.0.53 (Unix)","Apache/2.2.6 (Unix)"]
        if re.search(":", line):
            line = cgi.escape(line.partition(":")[0]) + ": " \
                + random.choice(webserver) + "<br>"
        else:
            line = line + " " + random.choice(webserver) + "<br>"
        return line
    # Server name is empty
    elif re.search("\$name.|ServerName|srvname|server-name|name|SERVER", line):
        line = cgi.escape(line.partition(":")[0]) + ": <br>"
        return line
    # Server address is empty
    elif re.search("\$ip.|ServerAddr|srvip|server-ip", line):
        line = cgi.escape(line.partition(" ")[0]) + ": <br>"
        return line
    # Free disk space, could be a bit more generic
    elif re.search("\$free|free|Free", line):
        line = cgi.escape(line.partition(":")[0]) + ": 15.80 Gb<br>"
        return line
    # Used disk space, could be a bit more generic
    elif re.search("\$used|used", line):
        line = cgi.escape(line.partition(" ")[0]) + " 56.20 Gb<br>"
        return line
    # Total disk space, the "sum" from free + used
    elif re.search("\$all|total", line):
        line = cgi.escape(line.partition(" ")[0]) + " 72 Gb<br>"
        return line
    # curl version response
    elif re.search("\$cUrl|curl", line):
        line = cgi.escape(line.partition(" ")[0]) + " curl 7.12.1 " \
                "(i686-redhat-linux-gnu) libcurl/7.12.1 OpenSSL/0.9.7a " \
                "zlib/1.2.1.2 libidn/0.5.6 Protocols: ftp gopher telnet " \
                "dict ldap http file https ftps Features: GSS-Negotiate " \
                "IDN IPv6 Largefile NTLM SSL libz<br>"
        return line
    # Answering every operating system request with linux
    elif re.search("OS", line):
        line = "OS: Linux<br>"
        return line
    # Total random disk stats
    elif re.search("HDD", line):
        used = random.randint(30,120)
        free = random.randint(30,70)
        total = used + free
        line = "HDD: Used: " + str(used) + " GB Free: " + str(free) + \
                " GB Total: " + str(total) + " GB<br>"
        return line
    # Empty disfunc response
    elif re.search("DISFUNC", line):
        line = "DISFUNC: <br>"
        return line
    # Permission set to read and write
    elif re.search("PERM", line):
        line = "PERM: [RW]<br>"
        return line
    # SaveMode response
    elif re.search("SAFE",line):
        line = "SAFE: OFF<br>"
        return line
    # Extracting the ID
    elif re.search("ID", line) and not re.search("UID",line):
        line = cgi.escape("ID: " + line.partition("ID")[2]) + "<br>"
        return line
    else:
        # Replacing HTML line brakes with new lines
        if re.search("<br>", line):
            line = cgi.escape(line.replace("<br>","")) + "<br>"
        else:
            line = cgi.escape(line) + "<br>"
        # If nothing matches, return the escaped line
        return line

def pecho(line):
    """Prepares the lines for the vulnerability emulator. """
    # Turns for example %22 into (
    line = urllib.unquote(line)
    # This was seen in FeeLCoMz files
    line = line.replace("\",\"","").replace("\".\"","")
    # Look for Safe Mode strings
    if re.search("Safe Mode",line):
        line = "Safe Mode of this Server is : SafemodeOFF<br>"
        return line
    # Handle multiple echos in one line
    elif line.count("echo") > 1:
        echolist = re.split("echo", line)
        line = ""
        for echopiece in echolist:
            if re.search("\"", echopiece):
                echopiece = echopiece.partition("\"")[2].partition("\"")[0]
                line += lineparse(echopiece)
        return line
    # Single echo in one line handler
    else:
        if re.search("\"",line):
            line = line.partition("\"")[2].partition("\"")[0]
        line = lineparse(line)
        return line

def parse(injected_file):
    # The response returned to the attacker
    response = []
    # List of all lines of a function
    functionlines = []
    # All lines containing echos outside of functions
    echolines = []
    # Indicates if we are currently inside or outside a function
    infunction = False
    # A dictionary containing line numbers and lines of a file 
    filedict = {}
    # A dictionary containing all founded functions
    functdict = {}
    
    # Splitting up the whole file in his lines
    if re.search("\\r", injected_file):
        file = injected_file.split("\r")
    elif re.search("\\n", injected_file):
        file = injected_file.split("\n")
    else:
        file = []
        file.append(injected_file)
    # Create the file dictionary
    # TODO: Currently the dictionary is unused, but we will use it later for more effective file parsing
    # The line number counter
    linenumber = 1
    for line in file:
        filedictentry = {linenumber : line}
        filedict.update(filedictentry)
        linenumber += 1
    # Check the file size and skip files with more than n lines
    if len(filedict) > 100:
        # TODO: Handle large files
        pass
    # Look for function definitions and store the functions into a list
    functnumber = 1
    for line in file:
        # The function definition pattern
        pattern = re.compile("\A" + r"\bfunction\b" + "\s\w*")
        if re.search(pattern, line):
            infunction = True
        if infunction == True:
            functionlines.append(line)
        # Looking for function end
        if re.search("}", line):
            infunction = False
            if functionlines:
                functdictentry = {functnumber : functionlines}
                functdict.update(functdictentry)
                functnumber += 1
            functionlines = []
            continue
        # Add echos from outside of functions
        if infunction == False and re.search("echo", line):
            echolines.append(line)
    # Parse echos which are not related to functions
    if echolines:
        for part in echolines:
            response.append(pecho(part))
    # Look for echos in functions
    if functdict:
        # Looping through all functions
        for function in functdict.values():
            # Looping through all parts of the function
            for part in function:
                # Look for echos in function definition
                if re.search("echo", part):
                    functionname = function[0].partition(" ")[2].partition("(")[0]
                    for line in file:
                        # Look for function calls in file
                        searchfor = functionname + "\(\""
                        try:
                            if functionname != "" and re.search(searchfor, line):
                                response.append(pecho(line))
                        except:
                            continue
    return response

def get_file(injected_url):
    try:
        req = urllib2.Request(injected_url)
        data = urllib2.urlopen(req)
    except:
        log("Unable to get injected file!")
    else:
        injected_file = data.read()
    return injected_file

def vulnPHPEmulator():
    response = ""
    injected_url = uri.partition("=")[2]
    injected_file = get_file(injected_url)
    try:
        response = parse(injected_file)
    except:
        log("Unable to parse injected file")
    else:
        separator = ""
        response = separator.join(response)
        log("Injected PHP file successful parsed")
    return response