from java.sql import SQLException

class classPathHacker():
    """
    Author: SG Langer Jan 2007 
    Loads the MySQL/J jar at runtime
    """
    import java.lang.reflect.Method
    import java.io.File
    import java.net.URL
    import java.net.URLClassLoader
    import jarray

    def addFile(self, s):
        f = self.java.io.File(s)
        u = f.toURL()
        a = self.addURL(u)
        return a

    def addURL(self, u):
        sysloader =  self.java.lang.ClassLoader.getSystemClassLoader()
        sysclass = self.java.net.URLClassLoader
        method = sysclass.getDeclaredMethod("addURL", [self.java.net.URL])
        a = method.setAccessible(1)
        jar_a = self.jarray.array([u], self.java.lang.Object)
        b = method.invoke(sysloader, [u])
        return u


class SQLiteDB():
    """
    Class to log events into a SQLite database
    """
    def __init__(self):
        from java.lang import Class
        jarLoad = classPathHacker()
        a = jarLoad.addFile("GlastopfNG_lib/sqlitejdbc-v057-pure.jar")
        Class.forName("org.sqlite.JDBC")
        self.sqlite_create()

    def sqlite_connect(self):
        from java.sql import DriverManager
        url = "jdbc:sqlite:" + sqLite_sqlitePath
        try:
            db = DriverManager.getConnection(url)
        except SQLException, e:
            print "SQLite exception: %s" % e.message
        else:
            return db

    def sqlite_create(self):
        # Creates the database if it doesn't exist already.
        db = self.sqlite_connect()
        query = "CREATE TABLE IF NOT EXISTS log(id INTEGER PRIMARY KEY, timestamp TEXT, attacker TEXT, request TEXT, impact INTEGER)"
        statement = db.prepareStatement(query)
        try:
            count = statement.executeUpdate()
        except SQLException, e:
            print "SQLite error: %s" % e.message
        else:
            if count > 0:
                print "SQLite structure created"
        statement.close()
        db.close()

    def sqlite_insert(self, attacker, request, impact):
        # Writes an event into the database
        db = self.sqlite_connect()
        statement = db.prepareStatement("INSERT INTO log VALUES(NULL, date('now'), ?, ?, ?)")
        statement.setString(1, attacker)
        statement.setString(2, request)
        statement.setString(3, impact)
        try:
            count = statement.executeUpdate()
        except SQLException, e:
            print "SQLite error: %s" % e.message
        else:
            print "Logged to SQLite:", attacker, request, impact
        statement.close()
        db.close()


def sqLite():
    sqlite = SQLiteDB()
    sqlite.sqlite_insert(clientIpAddr, uri, totalImpact)