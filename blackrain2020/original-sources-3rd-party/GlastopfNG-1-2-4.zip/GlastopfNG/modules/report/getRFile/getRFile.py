import urllib2
import hashlib
import os
import datetime
import re
import socket

socket.setdefaulttimeout(5)

def log(msg):
    print "[getRFile] %s" % msg

def get_filename(data):
    file_name = None
    try:
        file_name = hashlib.md5(data).hexdigest()
    except:
        pass
    finally:
        return file_name

def get_file(injected_url):
    data = ""
    download_timeout = 120
    try:
        starttime = datetime.datetime.now()
        handler = urllib2.urlopen(injected_url)
        for item in handler:
            data += item
            if (datetime.datetime.now() - starttime).seconds > download_timeout:
                data = None
                break
    except Exception, e:
        log(e.message)
        data = None
    finally:
        handler.close()
        return data
        
def save_file(data, file_name):
    status = "unknown"
    if not file_name in os.listdir(getRFile_downloadDir):
        try:
            local_file = open(getRFile_downloadDir + file_name, "wb")
            local_file.write(data)
        except:
            status = "error"
        else:
            status = "saved"
	finally:
            local_file.close()
    else:
        status = "known"
    return status

def getRFile():
    if re.search("=https?|=ftps?", uri):
        injected_url = uri.partition("=")[2]
        injected_file = get_file(injected_url)
        if injected_file:
            file_name = get_filename(injected_file)
            if file_name:
                status = save_file(injected_file, file_name)
            else:
                log("Unable to save injected file from %s" % injected_url)
            log("Injected file %s from %s: %s" % (file_name, injected_url, status))
            injected_file.close()
        else:
            log("Unable to get injected file from %s" % injected_url)
