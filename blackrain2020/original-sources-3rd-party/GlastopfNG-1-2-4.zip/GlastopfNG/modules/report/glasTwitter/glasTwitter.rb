require 'net/http'

def glasTwitter()
  #puts $impact+" / TOTAL: "+$totalImpact
  if($totalImpact.to_i>=$glasTwitter_impact.to_i)
  puts "I'm using twitter"
  url = URI.parse('http://api.twitter.com/1/statuses/update.xml')
  req = Net::HTTP::Post.new(url.path)
  req.basic_auth $glasTwitter_username, $glasTwitter_password
  #req.set_form_data({'status'=>'test', 'to'=>'2005-03-31'}, ';')
  req.set_form_data({'status'=>$clientIpAddr+' - '+$method+': '+ $uri + " - Impact: " +$totalImpact}, ';')
  res = Net::HTTP.new(url.host, url.port).start {|http| http.request(req) }
  responseToGlastopNG = "Everything's ok @ glasTwitter:)"
  #puts res.body
  end
end