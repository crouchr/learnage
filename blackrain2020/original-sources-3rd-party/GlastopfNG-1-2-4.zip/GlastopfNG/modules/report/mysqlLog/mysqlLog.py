class classPathHacker():
    """
    Author: SG Langer Jan 2007 
    Loads the mysql jar in runtime
    """
    import java.lang.reflect.Method
    import java.io.File
    import java.net.URL
    import java.net.URLClassLoader
    import jarray

    def addFile(self, s):
        f = self.java.io.File(s)
        u = f.toURL()
        a = self.addURL(u)
        return a

    def addURL(self, u):
        sysloader =  self.java.lang.ClassLoader.getSystemClassLoader()
        sysclass = self.java.net.URLClassLoader
        method = sysclass.getDeclaredMethod("addURL", [self.java.net.URL])
        a = method.setAccessible(1)
        jar_a = self.jarray.array([u], self.java.lang.Object)
        b = method.invoke(sysloader, [u])
        return u
    
class MySQLReporter():
    """
    Connects to the MySQL database and provides the sql methods.
    """
    def __init__(self):
        from java.lang import Class
        jarLoad = classPathHacker()
        #a = jarLoad.addFile("mysql-connector-java-5.1.14-bin.jar")
        a = jarLoad.addFile("GlastopfNG_lib/mysql-connector-java-5.1.14-bin.jar")
        Class.forName("com.mysql.jdbc.Driver")
        conn = self.mysql_connect()
        self.mysql_create(conn)
    
    def mysql_connect(self):
        from java.sql import DriverManager
        url = "jdbc:mysql://" \
               + mysqlLog_server + "/" \
               + mysqlLog_database + "?user=" \
               + mysqlLog_username + "&password=" \
               + mysqlLog_password
        conn = DriverManager.getConnection(url)
        return conn
    
    def mysql_create(self, conn):
        stmt = conn.createStatement()
        stmt.executeUpdate("""
        CREATE TABLE IF NOT EXISTS `log` (
          `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
          `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
          `attacker` varchar(20) NOT NULL,
          `request` varchar(250) NOT NULL,
          `impact` int(11) NOT NULL,
          PRIMARY KEY (`id`),
          UNIQUE KEY `id` (`id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
        """)
    
    def mysql_select(self, conn):
        stmt = conn.createStatement()
        rs = stmt.executeQuery("SELECT * FROM log")
        while rs.next():
            attacker = rs.getString(2)
            request = rs.getString(3)
            impact = rs.getString(4)
            print "event:", attacker, request, impact
            
    def mysql_insert(self, conn, clientIpAddr, uri, totalImpact):
        s = conn.prepareStatement("INSERT INTO log (attacker, request, impact) VALUES(?,?,?)")
        s.setString(1, clientIpAddr)
        s.setString(2, uri)
        s.setString(3, totalImpact)
        count = s.executeUpdate()
        s.close()
        print "Data written to MySQL database: %s %s" % (clientIpAddr, uri)
        
def mysqlLog():
    """
    Logs events to a MySQL database.
    """
    reporter = MySQLReporter()
    mysql_connection = reporter.mysql_connect()
    reporter.mysql_insert(mysql_connection, clientIpAddr, uri, totalImpact)