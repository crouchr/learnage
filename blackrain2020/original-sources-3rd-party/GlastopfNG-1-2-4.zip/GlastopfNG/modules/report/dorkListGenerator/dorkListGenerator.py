from java.sql import SQLException
from java.sql import DriverManager
from java.lang import Class


class classPathHacker():
    """
    Author: SG Langer Jan 2007 
    Loads the MySQL/J jar at runtime
    """
    import java.lang.reflect.Method
    import java.io.File
    import java.net.URL
    import java.net.URLClassLoader
    import jarray

    def addFile(self, s):
        f = self.java.io.File(s)
        u = f.toURL()
        a = self.addURL(u)
        return a

    def addURL(self, u):
        sysloader =  self.java.lang.ClassLoader.getSystemClassLoader()
        sysclass = self.java.net.URLClassLoader
        method = sysclass.getDeclaredMethod("addURL", [self.java.net.URL])
        a = method.setAccessible(1)
        jar_a = self.jarray.array([u], self.java.lang.Object)
        b = method.invoke(sysloader, [u])
        return u

class SQLiteDB():
    """
    Class to interact with a SQLite database
    """
    def __init__(self):
        
        jarLoad = classPathHacker()
        a = jarLoad.addFile("GlastopfNG_lib/sqlitejdbc-v057-pure.jar")
        Class.forName("org.sqlite.JDBC")
        self.url = "jdbc:sqlite:" + dorkListGenerator_dorkdb
        self.sqlite_create()

    def sqlite_create(self):
        # Creates the database if it doesn't exist already.
        db = DriverManager.getConnection(self.url)
        query = "CREATE TABLE IF NOT EXISTS log (id INTEGER PRIMARY KEY, timestamp TEXT, dork TEXT)"
        statement = db.prepareStatement(query)
        try:
            count = statement.executeUpdate()
        except SQLException, e:
            print e.message
        statement.close()
        db.close()

    def sqlite_insert(self, dork):
        # Writes an event into the database
        db = DriverManager.getConnection(self.url)
        statement = db.prepareStatement("INSERT INTO log VALUES(NULL, strftime('%Y-%m-%d %H:%M:%S','now'), ?)")
        statement.setString(1, dork)
        try:
            count = statement.executeUpdate()
        except SQLException, e:
            print e.message
        else:
            if count > 0:
                print "New dork stored:", dork
        statement.close()
        db.close()

    def sqlite_check(self, new_dork):
        # Shows the database content
        db = DriverManager.getConnection(self.url)
        statement = db.prepareStatement("SELECT dork FROM log WHERE dork == ?")
        statement.setString(1, new_dork)
        try:
            result = statement.executeQuery()
        except SQLException, e:
            print e.message
        else:
            if not result.next():
                self.sqlite_insert(new_dork)
        result.close()
        statement.close()
        db.close()
        
def dork_file(uri):
    old_list = open(dorkListGenerator_dorkfile)
    uniquelines = list(old_list.read().split("\n"))
    old_list.close()
    dork = dork_cut(uri)
    uniquelines.append(dork)
    uniquelines = list(set(uniquelines))
    new_list = open(dorkListGenerator_dorkfile, "w")
    new_list.write("".join([line + "\n" for line in uniquelines]))
    new_list.close()
    
def dork_cut(uri):
    if "?" in uri:
        uri = uri.partition("?")[0]
    return uri

def dorkListGenerator():
    try:
        sqlite = SQLiteDB()
        dork = dork_cut(uri)
        sqlite.sqlite_check(dork)
    except:
        "SQLite error, falling back to file logging"
        dork_file(uri)