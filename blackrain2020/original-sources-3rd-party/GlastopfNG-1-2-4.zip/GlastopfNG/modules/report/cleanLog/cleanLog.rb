def cleanLog()
  
  # TODO: Add more information about the request like the attackers IP addr
  # TODO: Add the response that was sent if this is configured in config.xml
  
  
  open($cleanLog_logPath, 'a') { |f|
    f.puts "-------------- / " + $clientIpAddr + " / " + $timestamp
    f.puts $rawRequest
    f.puts "--------------"
  }  
end
