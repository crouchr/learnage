INFO:
GlastopfNG was written by Sven Vetsch <sven.vetsch _at_ disenchant.ch>

INSTALL:
No installation is needed.

RUN:
You can simply run the following command from your command line:
   java -jar GlastopfNG.jar

FAQ:

I configured my modules in the config.xml but GlastopfNG won't load it.
 - Check if the attribute "active" is true.

I defined a value for my module in the config.xml but it's not visible in the module's code.
 - Be aware of the fact, that these values have to be called with the name [module name]_[name defined in config.xml]. This is not the case for variables which should be usable by all modules!