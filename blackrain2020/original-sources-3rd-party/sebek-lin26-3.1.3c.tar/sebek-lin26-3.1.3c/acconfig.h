#undef PACKAGE
#undef VERSION
#undef BSDI
#undef FREEBSD
#undef LINUX
#undef OPENBSD
#undef MACOS
#undef SOLARIS

#undef RAW_SOCK
#undef SBK_TASK_P_PPTR
#undef INET_OPT
#undef HAVE_LINUX_SYSCALLS_H
#undef PACK_SEQ_FOPS
#undef KBUILD_BASENAME
