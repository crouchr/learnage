# $Id: __init__.py 470 2010-02-22 17:28:19Z arthur $
import main
