# for backwards compatibility

from Cython import __version__ as version
