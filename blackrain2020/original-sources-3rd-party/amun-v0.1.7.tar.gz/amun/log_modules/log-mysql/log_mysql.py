"""
[Amun - low interaction honeypot]
Copyright (C) [2008]  [Jan Goebel]

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, see <http://www.gnu.org/licenses/>
"""

import psyco ; psyco.full()
from psyco.classes import *

import time
import amun_logging
import MySQLdb

class log:
	def __init__(self):
		try:
			self.log_name = "Log MySQL"
			self.myHost = "127.0.0.1"
			self.myUser = ""
			self.myPass = ""
			self.myTable = ""
		except KeyboardInterrupt:
			raise

	def connectDB(self, logger):
		try:
			self.db = MySQLdb.connect(self.myHost, self.myUser, self.myPass, self.myTable)
			self.cursor = self.db.cursor()
			return True
		except MySQLdb.Error, e:
			logger.log("log-mysql failed: %s" % (e), 12, "crit", Log=True, display=True)
			raise
		except KeyboardInterrupt:
			raise

	def closeDB(self, logger):
		try:
			self.db.close()
			self.cursor.close()
			return True
		except MySQLdb.Error, e:
			logger.log("log-mysql failed: %s" % (e), 12, "crit", Log=True, display=True)
			raise
		except KeyboardInterrupt:
			raise

	def query(self, query):
		try:
			self.cursor.execute(query)
			return self.cursor.fetchall()
		except MySQLdb.Error, e:
			self.log_obj.log("log-mysql failed: %s" % (e), 12, "crit", Log=True, display=True)
		except KeyboardInterrupt:
			raise
		return False

	def incoming(self, attackerIP, attackerPort, victimIP, victimPort, vulnName, timestamp, downloadMethod, loLogger, attackerID, shellcodeName):
		try:
			self.log_obj = amun_logging.amun_logging("log_mysql", loLogger)
			### current table
			tableName = time.strftime('%Y%m%d')
			if self.connectDB(self.log_obj):
				### insert new connection
				self.insertConnection(tableName, attackerIP, attackerPort, victimIP, victimPort, vulnName)
				self.closeDB(self.log_obj)
			else:
				self.log_obj.log("log-mysql failed connection", 12, "crit", Log=True, display=True)

		except KeyboardInterrupt:
			raise

	def insertConnection(self, tableName, attackerIP, attackerPort, victimIP, victimPort, vulnName):
		try:
			### create new table for connections if not exists (daily-basis)
			query = "CREATE TABLE IF NOT EXISTS amun_connections_%s ( id INT(11) NOT NULL AUTO_INCREMENT, timestamp INT(11) NOT NULL, hostileip VARCHAR(255) NOT NULL, hostileport VARCHAR(255) NOT NULL, targetip VARCHAR(255) NOT NULL, targetport VARCHAR(255) NOT NULL, DialogueName VARCHAR(255) NOT NULL, count int(11) NOT NULL DEFAULT '1', warned INT(11) NOT NULL DEFAULT '0', PRIMARY KEY (id), KEY hostileip (hostileip), KEY targetip (targetip), KEY DialogueName (DialogueName) ) ENGINE = MYISAM" % (tableName)
			self.query(query)
			### check for already existing entry
			query = "SELECT id FROM amun_connections_%s WHERE hostileip='%s' AND targetip='%s' AND targetport='%s'" % (tableName, attackerIP, victimIP, victimPort)
			result = self.query(query)
			if len(result)>0:
				### existing connection
				updateID = str(result[0][0])
				query = "UPDATE amun_connections_%s SET count=count+1 WHERE id='%s'" % (tableName, updateID)
				self.query(query)
			else:
				### new connection
				curTimestamp = int(time.time())
				query = "INSERT INTO amun_connections_%s (timestamp,hostileip,hostileport,targetip,targetport,DialogueName) VALUES ('%s','%s','%s','%s','%s','%s')" % (tableName, curTimestamp, attackerIP, attackerPort, victimIP, victimPort, vulnName)
				self.query(query)
			### return from insert connection
			return True
		except KeyboardInterrupt:
			raise

	def successfullSubmission(self, attackerIP, attackerPort, victimIP, downloadURL, md5hash, data, filelength, downMethod, loLogger, vulnName, fexists):
		pass

	def initialConnection(self, attackerIP, attackerPort, victimIP, victimPort, identifier, initialConnectionsDict, loLogger):
		pass
