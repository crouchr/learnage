
defaultReply = '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>It works!</title></head><html><body><h1>It works!</h1><br>tim.bohn@gmx.net<br>johan83@freenet.de</body></html>\n\n'

badRequest = '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">\r\n<html><head>\r\n<title>400 Bad Request</title>\r\n</head><body>\r\n<h1>Bad Request</h1>\r\n<p>Your browser sent a request that this server could not understand.<br />\r\n</p>\r\n<hr>\r\n<address>Apache/1.3.29 Server at Port 80</address>\r\n</body></html>\r\n'
