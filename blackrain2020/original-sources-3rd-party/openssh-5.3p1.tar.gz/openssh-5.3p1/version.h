/* $OpenBSD: version.h,v 1.56 2009/06/30 14:54:40 markus Exp $ */

#define SSH_VERSION	"OpenSSH_5.3"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
