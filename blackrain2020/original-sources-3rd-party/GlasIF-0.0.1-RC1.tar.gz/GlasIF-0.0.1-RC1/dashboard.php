<?php        
/* This file is part of Glasif 0.0.1
   =================================
   Copyright (c) 2008 - 2009 Glastopf Project                   

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/

require_once("inc/main.php");
require_once("inc/session.php");

$tpl->assign("num_hits", firstRow("SELECT COUNT(id) FROM log"));
$tpl->assign("time_ago", time_ago(firstRow("select attime from log order by attime Limit 1"), 3));

$query="SELECT DISTINCT(log.ip), MAX(attime) AS attime, iso, printable_name FROM log LEFT JOIN country ON log.ip = country.ip LEFT JOIN country_def ON country.country = country_def.iso GROUP BY log.ip ORDER BY attime DESC LIMIT 5";
$res = mysql_query($query);
if (!$res) {
	die('bad request: ' . mysql_error());
}
while ($arr = mysql_fetch_array($res)) {
	if ($arr[printable_name] == NULL) {
		$country_data=get_set_geoip($arr[ip]);
		$arr['printable_name']=$country_data['printable_name'];
		$arr['iso']=$country_data['iso'];
	}
	$arr[iso] = strtolower($arr[iso]);
	$arr[attime]=time_ago($arr[attime],$granularity=2);
	$data[]=$arr;
}
$tpl->assign("last_attacks", $data);
unset($data);



$query="SELECT log.ip, COUNT(log.ip) as acount, SUM(count) as scount, iso, printable_name FROM log LEFT JOIN country ON log.ip = country.ip LEFT JOIN country_def ON country.country = country_def.iso GROUP BY ip ORDER BY scount DESC LIMIT 5";
$res = mysql_query($query);
if (!$res) {
	die('bad request: ' . mysql_error());
}
while ($arr = mysql_fetch_array($res)) {
	if ($arr[printable_name] == NULL) {
		$country_data=get_set_geoip($arr[ip]);
		$arr['printable_name']=$country_data['printable_name'];
		$arr['iso']=$country_data['iso'];
	}
	$arr[iso] = strtolower($arr[iso]);
	$arr[attime]=time_ago($arr[attime],$granularity=2);
	$arr[round]=round(($arr[scount]/$arr[acount]),2);
	$data[]=$arr;
}
$tpl->assign("top_ip", $data);
unset($data);

$query="SELECT fileurl FROM files WHERE fileurl != '' ORDER BY id DESC LIMIT 5";
$res = mysql_query($query);
if (!$res) {
	die('bad request: ' . mysql_error());
}
while ($arr = mysql_fetch_array($res)) {
	$result = http_test_existance($arr[fileurl]);
	if($result['status'] == '200') {
		$arr[status]="<a href=javascript:newwindow('./showrfi.php?url=" . htmlentities($arr[fileurl]) . "');><img src=media/sourcecode.png border=0 /></a>";
	} else {
		$arr[status]="<img src=media/sourcecode_unav.png border=0 />";
	}
	$data[]=$arr;
}
$tpl->assign("last_file", $data);
unset($data);


$tpl->assign("menunum", "0");
$tpl->display('dashboard.tpl');

?>
