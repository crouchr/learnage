CREATE TABLE `country` (
  `ip` varchar(15) NOT NULL,
  `country` varchar(2) NOT NULL,
  PRIMARY KEY  (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1
