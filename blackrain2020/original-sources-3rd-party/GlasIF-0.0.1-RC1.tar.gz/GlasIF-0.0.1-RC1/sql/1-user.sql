CREATE TABLE `user` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(20) NOT NULL default '',
  `pass` varchar(32) NOT NULL default '',
  `level` tinyint(1) NOT NULL default '0',
  `full_name` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `last_login` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1
