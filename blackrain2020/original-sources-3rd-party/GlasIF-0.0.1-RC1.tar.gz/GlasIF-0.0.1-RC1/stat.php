<?php        
/* This file is part of Glastopf Log v0.2
   ================================
   Copyright (c) 2008 Glastopf Project                   

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/

include ("inc/header.php");
include ("inc/connect.php");
?>
    <script type="text/javascript">tabdropdown.init("menu", 2)</script>

    <h2>Top 20 Attacker</h2>
    <p>
    <?php
		$query = "SELECT DISTINCT ip, req, count FROM log GROUP BY victim ORDER BY count DESC LIMIT 20";
		$res = mysql_query($query);
		if (!$res) {
			die('Ungültige Abfrage: ' . mysql_error());
		}
		echo "<table border=\"1\" cellpadding=\"2\">
			<tr><td align=center>IP</td>
				<td align=center>Req</td>
				<td align=center>Count</td>
			 </tr>";
			 while ($arr = mysql_fetch_assoc($res)) {
			 	$ip = explode(":",$arr['ip']);
				echo "<tr><td><a href=whois.php?ip=$ip[0]>$ip[0]</a></td>
						 <td>".substr($arr['req'], 0, 144)."</td>
						 <td>$arr[count]</td>
					  </tr>";
			 }
			 echo "</table>";
	?>
    </p>
<?php
include ("inc/footer.php");
?>
