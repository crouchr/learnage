<?php        
/* This file is part of Glasif 0.0.1
   =================================
   Copyright (c) 2008 - 2010 Glastopf Project                   

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/

require_once("inc/main.php");
require_once("inc/session.php");

if(isset($_REQUEST['mode']) && $_REQUEST['mode'] == "change") {
	$query = "SELECT pass FROM user WHERE name = '" . $_SESSION['username'] . "'";
	$res =  mysql_query($query);
	$arr = mysql_fetch_assoc($res);

	if($arr["pass"] != md5($_REQUEST['oldpass'])) {
		$tmpl_msg="Your current password doesn't match the password from database! Password not changed!";
		$tmpl_msg_color="red";
		$tpl->assign("PASSWORD_NOT_CHANGED", "true");
	} else {
		if(!isset($_REQUEST['newpass']) || $_REQUEST['newpass'] == "") {
			$tmpl_msg="The new password mustn't be empty! Password not changed!";
			$tmpl_msg_color="red";
			$tpl->assign("PASSWORD_NOT_CHANGED", "true");
		} else {
			if($_REQUEST['newpass'] != $_REQUEST['newpassrepeated']) {
				$tmpl_msg="The new passwords doesn't match! Password not changed!";
				$tmpl_msg_color="red";
				$tpl->assign("PASSWORD_NOT_CHANGED", "true");
			} else {
				$tmpl_msg="Your password has been changed!";
				$tmpl_msg_color="green";	
				$query = "UPDATE user SET pass = '" . md5($_REQUEST['newpass']) . "'WHERE name = '" . $_SESSION['username'] . "'";
				$res =  mysql_query($query);
			}
		}
		
	}

} else {
	$tmpl_msg="Enter your current password. Enter the new one twice.";
	$tmpl_msg_color="black";
	$tpl->assign("PASSWORD_NOT_CHANGED", "true");
}

$tpl->assign("tmpl_msg", $tmpl_msg);
$tpl->assign("tmpl_msg_color", $tmpl_msg_color);
$tpl->assign("menunum", "4");

$tpl->display('password.tpl');

?>
