<?php        
/* This file is part of GlafIF 0.0.1
   =================================
   Copyright (c) 2008 - 2009 Glastopf Project                   

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU general Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/
require_once ("inc/main.php");
require_once ("inc/header.php");
?>
    <script type="text/javascript">tabdropdown.init("menu", 2)</script>
    <h2>Search for SourceIP</h2>
        <p>
	<form action="search.php?ipquery="$ipquery"" method="post">
	SourceIP: <br />
        <input type="text" name="ipquery" size="15" maxlength="15"><br>
        <input type="submit" name="Search" value="Search">
        </form> 
        </p>
    <p>
	<?php 	
			$ipquery = $_GET['ipquery'];
#			echo "GET: $ipquery\n";
			if ("$ipquery" == "") {
			$ipquery = $_POST['ipquery'];
#			echo "POST $ipquery\n";
			}
			if (!isset($ipquery)) {
			echo "Please enter (partial) IP. You may use '*' as placeholder.<br>Examples: *.124.*.* | 218.* | *24* |  127.0.0.1";
			}
			else {

			$start = intval("$_GET[start]");
			if (!isset($start)) {
  				$start = 0;
				}		
			//Querry um die Daten ab zu rufen
			$ppage = 40;
			$search = ereg_replace("\*","%", $ipquery);
#			echo "\nipquery :" ,$ipquery;
#			echo "\nsearch :" ,$search;		
			$end=$start+40;
			$query = "SELECT id, host, ip, attime, req FROM log WHERE `ip` LIKE '".$search."' ORDER BY ip, id DESC, req LIMIT $start,$end";
			echo "<b>Database query:</b> <br>";
			echo "$query <br>";
			$res = mysql_query($query);
			if (!$res) {
				die('bad request: ' . mysql_error());
			}
			$query2 = "SELECT id FROM log WHERE `ip` LIKE '".$search."'";
			$res2 = mysql_query($query2);
			if (!$res2) {
				die('bad request: ' . mysql_error());
			}
			$num_search_hits = mysql_num_rows($res2);
			echo "Search hits: <b>$num_search_hits</b><br />";
			if($start > 0) {
  			 	echo "<a href=\"search.php?ipquery=$ipquery&start=0\">[First Page]</a>&nbsp;";
  				$back=$start-$ppage;
  				if($back < 0) {
    				$back = 0;
  					}
  				echo "<a href=\"search.php?ipquery=$ipquery&start=$back\">[One Page back]</a>&nbsp;";
 			}
			if($num_search_hits>$ppage) {
  			 	$pages=intval($num_search_hits/$ppage);
  				if($num_search_hits%$ppage) {
    				$pages++;
					}
  				}
				$i=$start/$ppage+1;
			if ($i<=5) {
				$d=$i-1;
				}
			else {$d=5;
				}
			if ($i>=$pages-5) {
				$dd=1+$pages-$i;
				}
			else {$dd=6;
				}
			for ($i=$i-$d;$i<=$start/$ppage+$dd;$i++) {
  				$fwd=($i-1)*$ppage;
				if ($i==$start/$ppage+1) echo "<a href=\"search.php?ipquery=$ipquery&start=$fwd\"><b>$i</b></a>&nbsp;";
  				else echo "<a href=\"search.php?ipquery=$ipquery&start=$fwd\">$i</a>&nbsp;";
				}
			if($start < $num_search_hits-$ppage) {
  				$fwd=$start+$ppage;
#				$ppage=$fwd+40
				echo "<a href=\"search.php?ipquery=$ipquery&start=$fwd\">[One Page forward]</a>&nbsp;";
  				$fwd=($pages-1)*40;
#				$ppage=$fwd+40;
  				echo "<a href=\"search.php?ipquery=$ipquery&start=$fwd\">[Last Page]</a>";
				}
			echo "<table border=\"1\" cellpadding=\"2\">
			<tr><td align=center>Detail</td>
			<td align=center>IP</td>
			<td align=center>AttackedHost</td>
			<td align=center>Time</td>
			<td align=center>Request</td>
			</tr>";
			while ($arr = mysql_fetch_array($res)) {
                            echo "<tr><td><a href=display.php?show=$arr[id]><center>$arr[id]</center></a></td>
                                 <td><a href=whois.php?ip=$arr[ip]>$arr[ip]</a></td>
                                  <td>".substr($arr['host'], 0, 32)."</td>
                                   <td>$arr[attime]</td>
                                    <td>".substr($arr['req'], 0, -1)."</td>
                                  </tr>";
			}
			echo "</table>";
			}
	?>
<?php
include ("inc/footer.php");
?>
