<?php
/* This file is part of GlasIF 0.0.1
   ================================
   Copyright (c) 2008 - 2009 Glastopf Project                   

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/
require_once ("inc/main.php");
require_once ("inc/header.php");
?>
    <script type="text/javascript">tabdropdown.init("menu", 2)</script>																				
    <h2>CustomSearch</h2>
        <p>
	<form action="custom.php?cqueryWhere="$cqueryWhere"&cqueryLike="$cqueryLike"" method="post">
	CustomSearch: <br />
        SELECT id, ip, attime, cqueryWhere, req FROM 'log'
	WHERE <input type="text" name="cqueryWhere" size="16" maxlength="255">
	LIKE <input type="text" name="cqueryLike" size="64" maxlength="255"><br>
        <input type="submit" name="CustomSearch" value="CustomSearch">
        </form> 
        </p>
    <p>
	<?php 	
			$cqueryWhere = $_GET['cqueryWhere'];
			$cqueryLike = $_GET['cqueryLike'];
			if (("$cqueryWhere" == "")||("$cqueryLike" == "")) {
			$cqueryWhere = $_POST['cqueryWhere'];
			$cqueryLike = $_POST['cqueryLike'];
			}
			if ((!isset($cqueryWhere)) || (!isset($cqueryLike))) {
			echo "yea. give it to me!";
			}
			else {

			$start = intval("$_GET[start]");
			if (!isset($start)) {
  				$start = 0;
				}		
			//Querry um die Daten ab zu rufen
			$ppage = 40;
			$cquery = "WHERE `".$cqueryWhere."` LIKE '".$cqueryLike."'";
			$search = ereg_replace("\*","%", $cquery);
			$end=$start+40;
			$query = "SELECT id, ip, attime, ".$cqueryWhere.", req FROM log ".$search." ORDER BY attime DESC, req, ip, id DESC LIMIT $start,$end";
			echo "<b>Database query:</b> <br>";
			echo "$query <br>";
			$res = mysql_query($query);
			if (!$res) {
				die('bad request: ' . mysql_error());
			}
			$query2 = "SELECT id FROM log ".$search."";
			$res2 = mysql_query($query2);
			if (!$res2) {
				die('bad request: ' . mysql_error());
			}
			$num_search_hits = mysql_num_rows($res2);
			echo "Search hits: <b>$num_search_hits</b><br />";
			if($start > 0) {
  			 	echo "<a href=\"custom.php?cqueryWhere=$cqueryWhere&cqueryLike=$cqueryLike&start=0\">[First Page]</a>&nbsp;";
  				$back=$start-$ppage;
  				if($back < 0) {
    				$back = 0;
  					}
  				echo "<a href=\"custom.php?cqueryWhere=$cqueryWhere&cqueryLike=$cqueryLike&start=$back\">[One Page back]</a>&nbsp;";
 			}
			if($num_search_hits>$ppage) {
  			 	$pages=intval($num_search_hits/$ppage);
  				if($num_search_hits%$ppage) {
    				$pages++;
					}
  				}
				$i=$start/$ppage+1;
			if ($i<=5) {
				$d=$i-1;
				}
			else {$d=5;
				}
			if ($i>=$pages-5) {
				$dd=1+$pages-$i;
				}
			else {$dd=6;
				}
			for ($i=$i-$d;$i<=$start/$ppage+$dd;$i++) {
  				$fwd=($i-1)*$ppage;
				if ($i==$start/$ppage+1) echo "<a href=\"custom.php?cqueryWhere=$cqueryWhere&cqueryLike=$cqueryLike&start=$fwd\"><b>$i</b></a>&nbsp;";
  				else echo "<a href=\"custom.php?cqueryWhere=$cqueryWhere&cqueryLike=$cqueryLike&start=$fwd\">$i</a>&nbsp;";
				}
			if($start < $num_search_hits-$ppage) {
  				$fwd=$start+$ppage;
#				$ppage=$fwd+40
				echo "<a href=\"custom.php?cqueryWhere=$cqueryWhere&cqueryLike=$cqueryLike&start=$fwd\">[One Page forward]</a>&nbsp;";
  				$fwd=($pages-1)*40;
#				$ppage=$fwd+40;
  				echo "<a href=\"custom.php?cqueryWhere=$cqueryWhere&cqueryLike=$cqueryLike&start=$fwd\">[Last Page]</a>";
				}
			echo "<table border=\"1\" cellpadding=\"2\">
			<tr><td align=center>Detail</td>
			<td align=center>SourceIP</td>
			<td align=center>Time</td>";
			if (($cqueryWhere != "req") && ($cqueryWhere != "ip") && ($cqueryWhere != "id") && ($cqueryWhere != "attime")) {
			echo "<td align=center>$cqueryWhere</td>";
			}
			echo "<td align=center>Request</td>
			</tr>";
			while ($arr = mysql_fetch_array($res)) {
                            echo "<tr><td><a href=display.php?show=$arr[id]><center>$arr[id]</center></a></td>
                                 <td><a href=whois.php?ip=$arr[ip]>$arr[ip]</a></td>
                                   <td>$arr[attime]</td>";
				   if (($cqueryWhere != "req") && ($cqueryWhere != "ip") && ($cqueryWhere != "id") && ($cqueryWhere != "attime")) {
				   echo "<td>$arr[$cqueryWhere]</td>";
				   }
                                    echo "<td>".substr($arr['req'], 0, -1)."</td>
                                  </tr>";
			}
			echo "</table>";
			}
	?>
<?php
include ("inc/footer.php");
?>
