<?php

require_once ("inc/main.php");
require_once ("inc/classes/phplot/phplot.php");

if(!isset($_REQUEST['dimx']) || $_REQUEST['dimx'] == '') {
	$_REQUEST['dimx'] = '320';
}

if(!isset($_REQUEST['dimy']) || $_REQUEST['dimy'] == '') {
        $_REQUEST['dimy'] = '240';
}


$p = new PHPlot($_REQUEST['dimx'], $_REQUEST['dimy']);

# Colors for charts
$p->SetDataColors(array('red', 'orange'));


switch($_REQUEST['chart']) {
    case req_by_hour:
	$query = "SELECT CONCAT(RIGHT(LEFT(`attime`, 13) , 2)) AS atdate, sum(count) AS sum_attacks FROM log GROUP BY RIGHT(LEFT(`attime`, 13) , 2)";
	$p->SetPlotAreaWorld(NULL, 0, 24, NULL);
	$p->SetTitle('overall malicious requests by hour');
	$p->SetDataType('text-data');
	$p->SetPlotType('bars');
	$p->SetShading(0);
	$p->SetPrecisionY(0);
    break;
    case att_by_hour:
        $query = "SELECT CONCAT(RIGHT(LEFT(`attime`, 13) , 2)) AS atdate, count(distinct(ip)) AS uniqe_attackers FROM log GROUP BY RIGHT(LEFT(`attime`, 13) , 2)";
        $p->SetPlotAreaWorld(NULL, 0, 24, NULL);
        $p->SetTitle('overall unique attackers by hour');
        $p->SetDataType('text-data');
        $p->SetPlotType('bars');
        $p->SetShading(0);
	$p->SetDataColors(array('orange'));
	$p->SetPrecisionY(0);
    break;
    case att_last_month:
        $query = "SELECT DISTINCT(RIGHT(LEFT(`attime`, 10), 2)) AS atdate, COUNT(DISTINCT(ip)) AS uniqe_attackers FROM log WHERE DATE_SUB(NOW(), INTERVAL 30 DAY) < attime GROUP BY LEFT(`attime`, 10)";
        $p->SetPlotAreaWorld(NULL, 0, 30, NULL);
        $p->SetTitle('lastmonth attackers per day');
        $p->SetDataType('text-data');
        $p->SetPlotType('bars');
        $p->SetShading(0);
        $p->SetDataColors(array('orange'));
	$p->SetYLabelType('data');
	$p->SetPrecisionY(0);
    break;
    case req_last_month:
        $query = "SELECT DISTINCT(RIGHT(LEFT(`attime`, 10), 2)) AS atdate, SUM(count) AS sum_attacks FROM log WHERE DATE_SUB(NOW(), INTERVAL 30 DAY) < attime GROUP BY LEFT(`attime`, 10)";
        $p->SetPlotAreaWorld(NULL, 0, 30, NULL);
        $p->SetTitle('lastmonth malicious requests per day');
        $p->SetDataType('text-data');
        $p->SetPlotType('bars');
        $p->SetShading(0);
	$p->SetYLabelType('data');
	$p->SetPrecisionY(0);
    break;
    default:
    	echo "no chartdefinition";
    break;
}

# Use TrueType fonts:
$p->SetDefaultTTFont('inc/fonts/FreeMonoBold.ttf');
$p->SetFont(title, 'inc/fonts/FreeMonoBold.ttf', 8, 1);


$res = mysql_query($query);
if (!$res) {
	die('Ungültige Abfrage: ' . mysql_error());
}

for($i = 0; $data[$i] = mysql_fetch_assoc($res); $i++) ;
   
# Delete last empty one
array_pop($data);

# Select the data array representation and store the data:
$p->SetDataValues($data);

# Select an overall image background color and another color under the plot:
$p->SetBackgroundColor('#F0F0F0');
$p->SetDrawPlotAreaBackground(True);
$p->SetPlotBgColor('#ffffff');

# Draw lines on all 4 sides of the plot:
$p->SetPlotBorderType('none');

$p->SetXDataLabelPos('plotdown');
$p->SetXTickPos('none');
$p->SetXTickLabelPos('none');

# Generate and output the graph now:
$p->DrawGraph();

?>
