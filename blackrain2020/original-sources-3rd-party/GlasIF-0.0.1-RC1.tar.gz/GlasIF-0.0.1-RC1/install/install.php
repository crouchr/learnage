<?php

/* This file is part of GlasIF 0.0.1
   =================================
   Copyright (c) 2008 - 2009 Glastopf Project                   

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 
*/


$config_header="; This file is part of GlasIF 0.0.1
; =================================
; Copyright (c) 2008 - 2009 Glastopf Project                   
;
; This program is free software; you can redistribute it and/or
; modify it under the terms of the GNU General Public License
; as published by the Free Software Foundation; either version 2
; of the License, or (at your option) any later version.
;
; This program is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with this program; if not, write to the Free Software
; Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

[MYSQL]
";

if(is_dir("conf")) {
	if(is_writable("conf")) {
		$tpl->assign("confdir_msg", "config file is writable");
		$tpl->assign("confdir_status", "save");
	} else {
		$tpl->assign("confdir_msg", "config file is not writable");
		$tpl->assign("confdir_status", "fail");
	}
} else {
	$tpl->assign("confdir_msg", "conf does not exist");
	$tpl->assign("confdir_status", "fail");
}

if(is_dir("templates_c")) {
	if(is_writable("templates_c")) {
		$tpl->assign("tpldir_msg", "template directory is writable");
		$tpl->assign("tpldir_status", "save");
	} else {
		$tpl->assign("tpldir_msg", "template directory is not writable");
		$tpl->assign("tpldir_status", "fail");
	}
} else {
	$tpl->assign("tpldir_msg", "template directory doesn't exist");
	$tpl->assign("tpldir_status", "fail");
}

if(isset($_REQUEST['MYSQL_HOST'])) {
	$tpl->assign("MYSQL_HOST", $_REQUEST['MYSQL_HOST']);
}

if(isset($_REQUEST['MYSQL_PASS'])) {
	$tpl->assign("MYSQL_PASS", $_REQUEST['MYSQL_PASS']);
}

if(isset($_REQUEST['MYSQL_DATABASE'])) {
	$tpl->assign("MYSQL_DATABASE", $_REQUEST['MYSQL_DATABASE']);
}

if(isset($_REQUEST['MYSQL_USER'])) {
	$tpl->assign("MYSQL_USER", $_REQUEST['MYSQL_USER']);
}

if(isset($_REQUEST['GLASIF_USER'])) {
	$tpl->assign("GLASIF_USER", $_REQUEST['GLASIF_USER']);
}

if(isset($_REQUEST['GLASIF_PASS'])) {
	$tpl->assign("GLASIF_PASS", $_REQUEST['GLASIF_PASS']);
}

if(isset($_REQUEST['MYSQL_PORT'])) {
	$tpl->assign("MYSQL_PORT", $_REQUEST['MYSQL_PORT']);
} else {
	$tpl->assign("MYSQL_PORT", "3306");
}

if(isset($_REQUEST['MYSQL_HOST'])) {
	if(!@mysql_connect($_REQUEST['MYSQL_HOST'].":".$_REQUEST['MYSQL_PORT'], $_REQUEST['MYSQL_USER'], $_REQUEST['MYSQL_PASS'])) {
		$tpl->assign("mysql_msg", mysql_error());
		$tpl->assign("mysql_status", "fail");
		$tpl->assign("MYSQL_STATUS_INCOMPLETE", TRUE);
	} else {
		if(!mysql_select_db($_REQUEST['MYSQL_DATABASE'])) {
			$tpl->assign("mysql_msg", mysql_error());
			$tpl->assign("mysql_status", "fail");
			$tpl->assign("MYSQL_STATUS_INCOMPLETE", TRUE);
		} else {
			$tpl->assign("mysql_msg", "MySQL connect successful");
			$tpl->assign("mysql_status", "save");
			$tpl->assign("MYSQL_STATUS_COMPLETE", TRUE);
			if(mysql_query("SELECT * FROM log LIMIT 1")) {
				$tpl->assign("glaslog_msg", "found glastopf log table");
				$tpl->assign("glaslog_status", "save");
				$tpl->assign("GLAS_STATUS_COMPLETE", TRUE);
				if(!@mysql_query("SELECT * FROM user LIMIT 1")) {
					$SQL_INSERTER=TRUE;
					if (is_dir("sql")) {
						$sqlfiles=scandir("sql");
						foreach($sqlfiles as $sqlfile) { 
							if ($sqlfile != "." && $sqlfile != ".." && $sqlfile != ".svn") {
								if(!mysql_query(file_get_contents("sql/". $sqlfile))) {
									$SQL_INSERTER = FALSE;
									echo mysql_error();
								}
							}
						}

						if($SQL_INSERTER) {
							$tpl->assign("TABLE_STATUS_COMPLETE", TRUE);
							$tpl->assign("USER_STATUS", TRUE);
							$tpl->assign("glastable_msg", "created GlasIF database");
							$tpl->assign("glastable_status", "save");
							$result = @mysql_query("SELECT * FROM user LIMIT 1");
							if(mysql_num_rows($result) >= 1) {
							} else {
								$tpl->assign("USER_STATUS_INCOMPLETE", TRUE);
							}
						} else {
							$tpl->assign("TABLE_STATUS_COMPLETE", TRUE);
							$tpl->assign("glastable_msg", "failed to create GlasIF database: " . mysql_error());
							$tpl->assign("glastable_status","fail");
						}
					}
				} else {
					if($_REQUEST['create_user'] == 'true') {
						$tpl->assign("TABLE_STATUS_COMPLETE", TRUE);
						$tpl->assign("USER_STATUS", TRUE);
						$tpl->assign("glastable_msg", "GlasIF database created");
						$tpl->assign("glastable_status", "save");
						$tpl->assign("user_msg", "admin user created");
						$tpl->assign("user_status", "save");
						@mysql_query("INSERT INTO user VALUES ('', '" . $_REQUEST['GLASIF_USER'] . "', '" . md5($_REQUEST['GLASIF_PASS']) . "', '0', '', '', '')");
						$configfile=$config_header;
						$configfile.='MYSQL_HOST = "' . $_REQUEST['MYSQL_HOST'] . '"     ; host with sql-database' . "\r\n";
						$configfile.='MYSQL_USER = "' . $_REQUEST['MYSQL_USER'] . '"     ; username for sql-database' . "\r\n";
						$configfile.='MYSQL_PASS = "' . $_REQUEST['MYSQL_PASS'] . '"     ; password for sql-database' . "\r\n";
						$configfile.='MYSQL_DATABASE = "' . $_REQUEST['MYSQL_DATABASE'] . '"      ; name of database with logentries' . "\r\n";
						$configfile.='MYSQL_PORT = "' . $_REQUEST['MYSQL_PORT'] . '"     ; default 3306' . "\r\n";
						$confhandle = fopen("conf/glasif.cfg", "w+");
						fwrite($confhandle, $configfile);
						fclose($confhandle);
					} else {
						$tpl->assign("DUMP_STATUS_COMPLETE", TRUE);
						$tpl->assign("glasdump_msg", "found old GlasIF tables. Aborting!");
						$tpl->assign("glasdump_status", "fail");						
					}
				}
			} else {
				$tpl->assign("glaslog_msg", "Couldn't read glastopf log table:" . mysql_error());
				$tpl->assign("glaslog_status", "fail");
				$tpl->assign("MYSQL_STATUS_INCOMPLETE", TRUE);
			}
		}
	}
} else {
	$tpl->assign("MYSQL_STATUS_INCOMPLETE", TRUE);
}

$tpl->display('install.tpl');
die();
?>
