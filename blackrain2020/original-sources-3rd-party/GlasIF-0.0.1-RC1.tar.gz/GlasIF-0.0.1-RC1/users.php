<?php        
/* This file is part of Glasif 0.0.1
   =================================
   Copyright (c) 2008 - 2010 Glastopf Project                   

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/

require_once("inc/main.php");
require_once("inc/session.php");

if(isset($_REQUEST['func']) && $_REQUEST['func'] == 'users') {

	if(isset($_REQUEST['edit'])) {

		$query = "SELECT * FROM user WHERE id = '" . $_REQUEST['edit'] . "';";

		$res = mysql_query($query);
		if (!$res) {
			die('bad request: ' . mysql_error());
		}
		$arr = mysql_fetch_array($res);
		if(!isset($_REQUEST['new_name'])) {
			$_REQUEST['new_name'] = $arr['full_name'];
		}
		if(!isset($_REQUEST['new_email'])) {
			$_REQUEST['new_email'] = $arr['email'];
		}

		$tpl->assign("EDIT_USER", "true");
		$tpl->assign("name", $arr['name']);
		$tpl->assign("new_name", $_REQUEST['new_name']);
		$tpl->assign("new_email", $_REQUEST['new_email']);
		$tpl->assign("edit", $_REQUEST['edit']);

	} elseif(isset($_REQUEST['save'])) {

		if(isset($_REQUEST['new_name']) && isset($_REQUEST['new_email'])) {

			if(isset($_REQUEST['new_pass'])) {
				$query = "INSERT INTO user VALUES ('', '" . $_REQUEST['new_username'] . "', '" . md5($_REQUEST['new_pass']) . "', '0', '" . $_REQUEST['new_name'] . "', '" . $_REQUEST['new_email'] . "', '')";
			} else {
				$query = "UPDATE user SET full_name = '" . $_REQUEST['new_name'] . "', email = '" . $_REQUEST['new_email'] . "' WHERE id = '" . $_REQUEST['save'] . "'";
			}

			$res = mysql_query($query);
			if (!$res) {
				die('bad request: ' . mysql_error());
			}			
		}

		header('Location: users.php');

	} elseif(isset($_REQUEST['add'])) {

		$tpl->assign("ADD_USER", "true");

	} elseif(isset($_REQUEST['del'])) {

		$query="DELETE FROM user WHERE id = '" . $_REQUEST['del'] . "'";

		$res = mysql_query($query);
		if (!$res) {
			die('bad request: ' . mysql_error());
		}		
		
		header('Location: users.php');
	}


} else {

	$query="SELECT * FROM user";
	$res = mysql_query($query);
	if (!$res) {
		die('bad request: ' . mysql_error());
	}
	while ($arr = mysql_fetch_array($res)) {
		if($arr[name] == $_SESSION['username']) {
			$arr['delete']="<img src=media/delete_unav.png border=0 />";
		} else {
			$arr['delete']="<a href=users.php?func=users&del=" . $arr[id] . "><img src=media/delete.png border=0 /></a>";
		}
		$data[]=$arr;
	}
	$tpl->assign("users", $data);
	$tpl->assign("SHOW_USERS", "true");
	unset($data);

}

$tpl->assign("menunum", "4");

$tpl->display('users.tpl');

?>
