<?

require_once('classes/smarty/Smarty.class.php');

class Lib_Site extends Smarty {
    function Lib_Site() {
        $this->template_dir = 'templates';
        $this->compile_dir = 'templates_c/';
        $this->config_dir = 'configs';
        $this->cache_dir = 'cache';
    }
}

$tpl = & new Lib_Site;

?>
