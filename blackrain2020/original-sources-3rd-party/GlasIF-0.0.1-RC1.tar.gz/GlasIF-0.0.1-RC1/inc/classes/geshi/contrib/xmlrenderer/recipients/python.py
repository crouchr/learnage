"""Python recepient for GeSHi XML output."""
class GeSHiRecipient:
    """GeSHi recepient class."""
    
    def _init_ (self):
        """Constructor."""
        
        
    