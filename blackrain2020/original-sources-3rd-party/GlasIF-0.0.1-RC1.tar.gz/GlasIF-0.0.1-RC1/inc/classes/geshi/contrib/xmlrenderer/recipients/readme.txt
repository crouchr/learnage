This directory contains recepient files in different languages.

Most of the files are empty, but they exist to be filled ;)