<?php
/**
 * Smarty plugin
 * @package Smarty
 * @subpackage plugins
 */

 
function smarty_modifier_lcint($string)
{
    $result = "";
    if ($string < 10) $result = "0";
    $result .= $string;
    return $result;
}


?>
