<?php
/**
 * Smarty plugin
 * @package Smarty
 * @subpackage plugins
 */

 
function smarty_modifier_kwtops($string)
{
    return round($string * 1.36);
}


?>
