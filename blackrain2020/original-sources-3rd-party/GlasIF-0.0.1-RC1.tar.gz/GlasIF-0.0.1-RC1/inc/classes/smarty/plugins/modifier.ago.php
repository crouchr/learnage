<?php
/**
 * Smarty plugin
 * @package Smarty
 * @subpackage plugins
 */


 function t($string, $args = array(), $langcode = NULL) {

   if (empty($args)) {
     return $string;
   }
   else {
     // Transform arguments before inserting them.
     foreach ($args as $key => $value) {
       switch ($key[0]) {
         case '@':
           // Escaped only.
           $args[$key] = $value;
           break;

         case '%':
         default:
           // Escaped and placeholder.
           $args[$key] = theme('placeholder', $value);
           break;

         case '!':
           // Pass-through.
       }
     }
     return strtr($string, $args);
   }
 }


 function format_plural($count, $singular, $plural, $args = array(), $langcode = NULL) {
   $args['@count'] = $count;
   if ($count == 1) {
     return t($singular, $args, $langcode);
   }

   // Get the plural index through the gettext formula.
   $index = (function_exists('locale_get_plural')) ? locale_get_plural($count, $langcode) : -1;
   // Backwards compatibility.
   if ($index < 0) {
     return t($plural, $args, $langcode);
   }
   else {
     switch ($index) {
       case "0":
         return t($singular, $args, $langcode);
       case "1":
         return t($plural, $args, $langcode);
       default:
         unset($args['@count']);
         $args['@count['. $index .']'] = $count;
         return t(strtr($plural, array('@count' => '@count['. $index .']')), $args, $langcode);
     }
   }
 }


 function hace($timestamp, $granularity = 2, $langcode = NULL) {
   $units = array('1 year|@count years' => 31536000, '1 week|@count weeks' => 604800, '1 day|@count days' => 86400, '1 hour|@count hours' => 3600, '1 min|@count min' => 60, '1 sec|@count sec' => 1);
   $output = '';
   foreach ($units as $key => $value) {
     $key = explode('|', $key);
     if ($timestamp >= $value) {
       $output .= ($output ? ' ' : '') . format_plural(floor($timestamp / $value), $key[0], $key[1], array(), $langcode);
       $timestamp %= $value;
       $granularity--;
     }

     if ($granularity == 0) {
       break;
     }
   }
   return $output ? $output : t('0 sec', array(), $langcode);
}


/**
 * Smarty indent modifier plugin
 *
 * Type:     modifier<br>
 * Name:     indent<br>
 * Purpose:  indent lines of text
 * @link http://smarty.php.net/manual/en/language.modifier.indent.php
 *          indent (Smarty online manual)
 * @author   Monte Ohrt <monte at ohrt dot com>
 * @param string
 * @param integer
 * @param string
 * @return string
 */
function smarty_modifier_ago($string)
{


$tt = mktime( substr($string, 11, 2),  substr($string, 14, 2), substr($string, 17, 2), substr($string, 5, 2), substr($string, 8, 2), substr($string, 0, 4));
    return hace(time() - $tt, 1);
}

?>
