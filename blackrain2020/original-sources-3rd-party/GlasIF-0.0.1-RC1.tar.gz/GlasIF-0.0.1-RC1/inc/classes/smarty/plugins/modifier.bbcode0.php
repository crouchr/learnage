<?php

function smarty_modifier_bbcode0($message) {
  $preg = array(
          '/(?<!\\\\)\[br(?::\w+)?\]/si'             => "<br>", 
          // [img]
          '/(?<!\\\\)\[img(?::\w+)?\](.*?)\[\/img(?::\w+)?\]/si'             => "<img src=\"\\1\" alt=\"\\1\" class=\"bb-image\" />",
          '/(?<!\\\\)\[img(?::\w+)?=(.*?)x(.*?)\](.*?)\[\/img(?::\w+)?\]/si' => "<img width=\"\\1\" height=\"\\2\" src=\"\\3\" alt=\"\\3\" class=\"bb-image\" />",
          '/\\\\(\[\/?\w+(?::\w+)*\])/'                                      => "\\1"

  );
  $message = preg_replace(array_keys($preg), array_values($preg), $message);
  return $message;
}

?>