<?php        
/* This file is part of GlasIF 0.0.1
   =================================
   Copyright (c) 2008-2010 Glastopf Project                   

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 
*/


function get_set_geoip($ipaddr) {
	$data['iso']=get_geo_ip_code($ipaddr);
	$add_country_query="INSERT INTO country VALUES ('" . $ipaddr . "', '" . $data['iso'] . "')";
	$add_country_res = mysql_query($add_country_query);
	if (!$add_country_res) {
		die('bad request: ' . mysql_error());
	}
	$get_country_query="SELECT printable_name FROM country_def WHERE iso = '" . $data['iso'] . "'";
	$get_country_res = mysql_query($get_country_query);
	if (!$get_country_res) {
		die('bad request: ' . mysql_error());
	}
	$get_country_arr = mysql_fetch_array($get_country_res);
	$data['printable_name']=$get_country_arr['printable_name'];
	return $data;
}

function get_geo_ip_code($ipaddr) {
	return file_get_contents("http://geoip.wtanaka.com/cc/$ipaddr");
}

function time_ago($date, $granularity=2) {
  $date = strtotime($date);
  $difference = time() - $date;
  $periods = array(
    'decade' => 315360000,
    'year' => 31536000,
    'month' => 2628000,
    'week' => 604800, 
    'day' => 86400,
    'hour' => 3600,
    'minute' => 60,
    'second' => 1
  );
                                 
  foreach ($periods as $key => $value) {
    if ($difference >= $value) {
      $time = round($difference/$value);
      $difference %= $value;
      $retval .= ($retval ? ' ' : '').$time.' ';
      $retval .= (($time > 1) ? $key.'s' : $key);
      $granularity--;
    }
    if ($granularity == '0') {
      break;
    }
  }
  return $retval;      
}

function http_test_existance($url, $timeout = 1) {
  $timeout = (int)round($timeout/2+0.00000000001);
  $return = array();

  $inf = parse_url($url);

  if (!isset($inf['scheme']) or $inf['scheme'] !== 'http') {
    return array('status' => -1);
  }
  
  if (!isset($inf['host'])) {
    return array('status' => -2);
  }

  $host = $inf['host'];

  if (!isset($inf['path'])) {
    return array('status' => -3);
  }

  $path = $inf['path'];

  if (isset($inf['query'])) {
    $path .= '?'.$inf['query'];
  }

  if (isset($inf['port'])) {
    $port = $inf['port'];
  } else {
    $port = 80;
  }

  $pointer = @fsockopen($host, $port, $errno, $errstr, $timeout);
  if (!$pointer) {
    return array('status' => -4, 'errstr' => $errstr, 'errno' => $errno);
  }

  socket_set_timeout($pointer, $timeout);

  $head =
    'HEAD '.$path.' HTTP/1.1'."\r\n".
    'Host: '.$host."\r\n";

  if (isset($inf['user'])) {
    $head .= 'Authorization: Basic '. base64_encode($inf['user'].':'.(isset($inf['pass']) ? $inf['pass'] : ''))."\r\n";
  }
  if (func_num_args() > 2) {
    for ($i = 2; $i < func_num_args(); $i++) {
      $arg = func_get_arg($i);
      if (
        strpos($arg, ':') !== false and
        strpos($arg, "\r") === false and
        strpos($arg, "\n") === false
      ) {
        $head .= $arg."\r\n";
      }
    }
  } else {
    $head .= 
      'User-Agent: Glastopf WI 0.0.1 (http://dev.glastopf.org/projects/show/glasif/)'."\r\n";
    $head .=
      'Connection: close'."\r\n"."\r\n";
     fputs($pointer, $head);
    $response = '';
    $status = socket_get_status($pointer);
    while (!$status['timed_out'] && !$status['eof']) {
      $response .= fgets($pointer);
      $status = socket_get_status($pointer);
    }

    fclose($pointer);

    if ($status['timed_out']) {
      return array('status' => -5, '_request' => $head);
    }

    $res = str_replace("\r\n", "\n", $response);
    $res = str_replace("\r", "\n", $res);
    $res = str_replace("\t", ' ', $res);

    $ares = explode("\n", $res);
    $first_line = explode(' ', array_shift($ares), 3);

    $return['status'] = trim($first_line[1]);
    $return['reason'] = trim($first_line[2]);

    foreach ($ares as $line) {
      $temp = explode(':', $line, 2);
      if (isset($temp[0]) and isset($temp[1])) {
        $return[strtolower(trim($temp[0]))] = trim($temp[1]);
      }
    }

    $return['_response'] = $response;
    $return['_request'] = $head;

    return $return;
  }
}


function fetchRow($query) {
    $res = mysql_query($query);
    if (!$res) 
        die('bad request: ' . mysql_error());
    return mysql_fetch_array($res);
}

function firstRow($query) {
    $res = fetchRow($query);
    return $res[0];
}

function fetchAll($query) {
    $db = array();
    $res = mysql_query($query);
    if (!$res) 
        die('bad request: ' . mysql_error());
    while ($arr = mysql_fetch_array($res)) {
        $db[] = $arr;
    }
    return $db;
}

function getHost($Address) {
   $parseUrl = parse_url(trim($Address));
   return trim($parseUrl[host] ? $parseUrl[host] : array_shift(explode('/', $parseUrl[path], 2)));
} 

?>
