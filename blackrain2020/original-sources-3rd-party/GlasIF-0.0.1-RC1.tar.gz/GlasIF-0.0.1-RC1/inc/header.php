<?php        
/* This file is part of GlasIF 0.0.1
   =================================
   Copyright (c) 2008 - 2009 Glastopf Project                   

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/

session_start();
if (! session_is_registered('username')) {
	header("Location: index.php?unauth=true");
	exit;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Glastopf Log</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body class="style">

<div id="container">
  <div id="header">
  <img src="media/glastopf.png" alt="" width="204" height="83" />
    <!-- end #header -->
    </div>
  <div id="mainContent">
    <br />
    <!-- Einbinden des Java Menu Scripts -->
    <script type="text/javascript" src="drop/drop.js"></script>

    <!-- Menu -->
        <div id="menu" class="menu">
        <ul>
	<li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="dropmenu1" rel="dropmenu1">Raw Data</a></li>
        <li><a rel="dropmenu2">Search</a></li>
	<li><a rel="dropmenu3">Admin</a></li>
        <li><a href="logout.php">Logout</a></li>
        </ul>
        </div>
        <br style="clear: left;" />
	<!--1st drop down menu -->
	<div id="dropmenu1" class="drop">
	<a href="log.php">Logfile</a>
	<a href="victims.php?num=40">Victims</a>
	<a href="files.php?num=40">Files</a>
        </div>
	
	<div id="dropmenu2" class="drop">
	<a href="search_log.php">Logfile</a>
	<a href="search.php?ipquery=">search IP</a>
	<a href="searchreq.php">search request</a>
	<a href="custom.php">CustomSearch</a>
	</div>
		
	<div id="dropmenu3" class="drop">
	<a href="users.php">Usermanagement</a>
	</div>
