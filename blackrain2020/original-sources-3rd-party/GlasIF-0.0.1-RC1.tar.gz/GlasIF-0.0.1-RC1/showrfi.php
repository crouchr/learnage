<?php        
/* This file is part of GlafIF 0.0.1
   =================================
   Copyright (c) 2008 - 2010 Glastopf Project                   

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU general Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/

require_once("inc/main.php");
require_once("inc/session.php");

$fp = @fsockopen(getHost($_REQUEST['url']), 80, $errno, $errstr, 5);
if (!$fp) {
	echo "I tried hard to connect to http://" . getHost($_REQUEST['url']) . ", but I got an error message: " . $errstr . "(" . $errno .")" . "<br />";
} else {
	fwrite($fp, "GET / HTTP/1.0\r\n\r\n");
	stream_set_timeout($fp, 10);
	$res = @fread($fp, 4096);

	$info = stream_get_meta_data($fp);
	fclose($fp);

	if ($info['timed_out']) {
		echo 'Connection timed out!';
	}

	include_once 'inc/classes/geshi/class.geshi.php';
	$geshi = new GeSHi($source, 'html');

	$content = @file_get_contents($_REQUEST['url']);
	if ($content !== false) {
		$geshi = &new GeSHi($content, 'php');
		echo $geshi->parseCode();
	} else {
	   	echo "File seems to be offline now";

	}

}

?>
