<?php        
/* This file is part of GlasIF 0.0.1
   =================================
   Copyright (c) 2008 - 2010 Glastopf Project                   

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/

require_once("inc/main.php");
require_once("inc/session.php");
require_once("inc/classes/paginateit/PaginateIt.php");

if (!isset($_REQUEST['start'])) {
	$_REQUEST['start']=1;
}

$search = ereg_replace("\*","%", $_REQUEST['query']);

$PaginateIt = new PaginateIt();
$PaginateIt->SetCurrentPage($_REQUEST['start']);
$PaginateIt->SetItemsPerPage(20);
$PaginateIt->SetQueryStringVar('start'); 
$PaginateIt->SetLinksHref('log.php');

$PaginateIt->SetLinksToDisplay(10);
$PaginateIt->SetLinksFormat('&laquo; Back',' | ','Next &raquo;');

$query = "SELECT SQL_CALC_FOUND_ROWS id, host, ip, attime, req FROM log ORDER BY id DESC " . $PaginateIt->GetSqlLimit();

$res = mysql_query($query);

while ($arr = mysql_fetch_array($res)) {
	$data[]=$arr;
}

$query = "SELECT FOUND_ROWS() as total";
$res = mysql_query($query);
$row = mysql_fetch_array($res, MYSQL_ASSOC);

$PaginateIt->SetItemCount($row['total']);

$tpl->assign("pagination", $PaginateIt->GetPageLinks());
$tpl->assign("results", $data);
$tpl->assign("menunum", "1");

$tpl->display('log.tpl');

?>
