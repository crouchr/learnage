<?php        
/* This file is part of GlafIF 0.0.1
   =================================
   Copyright (c) 2008 - 2010 Glastopf Project                   

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU general Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/

require_once("inc/main.php");
require_once("inc/session.php");
require_once("inc/classes/paginateit/PaginateIt.php");

if (!isset($_REQUEST['start'])) {
	$_REQUEST['start']=1;
}

$search = ereg_replace("\*","", $_REQUEST['query']);

$PaginateIt = new PaginateIt();
$PaginateIt->SetCurrentPage($_REQUEST['start']);
$PaginateIt->SetItemsPerPage(20);
$PaginateIt->SetQueryStringVar('start'); 
$PaginateIt->SetLinksHref('search_log.php');

$PaginateIt->SetLinksToDisplay(10);
$PaginateIt->SetLinksFormat('&laquo; Back',' | ','Next &raquo;');

$column_query = 'SELECT * FROM log';
$column_res = mysql_query($column_query);
for ($x = 0; $x < mysql_num_fields($column_res); $x++ ) {
	$columns[]=mysql_field_name($column_res, $x);
}

$tpl->assign("columns", $columns);

switch($_REQUEST['mode']) {
	case 'ip':
		$query = "SELECT SQL_CALC_FOUND_ROWS id, host, ip, attime, req FROM log WHERE ip LIKE '%" . $search . "%' ORDER BY ip, id DESC, req " . $PaginateIt->GetSqlLimit();
		$PaginateIt->SetQueryString('mode=ip&query=' . $_REQUEST['query']);
		$tpl->assign("ipquery", $_REQUEST['query']);
		break;
	case 'req':
		$query = "SELECT SQL_CALC_FOUND_ROWS id, host, ip, attime, req FROM log WHERE req LIKE '%".$search."%' ORDER BY attime DESC, req, ip, id " . $PaginateIt->GetSqlLimit();
		$PaginateIt->SetQueryString('mode=req&query=' . $_REQUEST['query']);
		$tpl->assign("reqquery", $_REQUEST['query']);
		break;
	case 'custom':
		$query = "SELECT SQL_CALC_FOUND_ROWS id, host, ip, attime, req FROM log WHERE " . $_REQUEST['column'] . " LIKE '%".$search."%' ORDER BY attime DESC, req, ip, id " . $PaginateIt->GetSqlLimit();
		$PaginateIt->SetQueryString('mode=custom&query=' . $_REQUEST['query'] . '&field=' . $_REQUEST['field']);
		$tpl->assign("customquery", $_REQUEST['query']);
		$tpl->assign("customcolumn", $_REQUEST['column']);
		break;
	default:
		$query = "SELECT SQL_CALC_FOUND_ROWS id, host, ip, attime, req FROM log WHERE ip LIKE '" . $search . "' ORDER BY ip, id DESC, req " . $PaginateIt->GetSqlLimit();
		$PaginateIt->SetQueryString('mode=ip&query=' . $_REQUEST['query']);
		$tpl->assign("ipquery", $_REQUEST['query']);
}

$res = mysql_query($query);

while ($arr = mysql_fetch_array($res)) {
	$data[]=$arr;
}

$query = "SELECT FOUND_ROWS() as total";
$res = mysql_query($query);
$row = mysql_fetch_array($res, MYSQL_ASSOC);

$PaginateIt->SetItemCount($row['total']);

if($row['total'] > 0) {
	$tpl->assign("RESULTSET", "TRUE");
	$tpl->assign("pagination", $PaginateIt->GetPageLinks());
	$tpl->assign("results", $data);
}
$tpl->assign("menunum", "3");

$tpl->display('search_log.tpl');

?>

