#!/bin/bash

VERSION="0.9.2"
