# syslog event ids

# Amun
WIN32_EXPLOIT = 1000
MALWARE_PROPAGATION_SELF = 1001
MALWARE_PROPAGATION_OTHER = 1001

# TSOM
NEW_ATTACKER = 2000
NEW_ATTACK = 2001
DELETE_ATTACKER = 2002

# TESTING - test scripts etc
TEST_ID = 9999

# Other
NULL_ID = 0  # for cases where calling code has not been modified yet
