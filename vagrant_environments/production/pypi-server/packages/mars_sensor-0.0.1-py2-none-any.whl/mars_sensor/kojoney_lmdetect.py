#!/usr/bin/python

import time, os , syslog , re , sys , time
#import kojoney_funcs
#import ipintellib
#import twitter_funcs
#import traceroute_matrix
#import kojoney_nmap
#import kojoney_cymru_hash
#import kojoney_hiddenip
#import analyse_php_scripts
#import kojoney_anubis_idmef
#import virustotal
#import kojoney_alert_client	# my wrapper for sending email via Googlemail

# need this so program can be monitored by monit
# make this a library function
def makePidFile(name):
    pid = os.getpid()
    
    pidFilename = "/var/run/rchpids/" + name + ".pid"
    fp=open(pidFilename,'w')
    print >> fp,pid
    fp.close()            
    #print "pid is " + `pid`
    return pid	# returns None if failed
    
            
#    except Exception,e:
#        msg = "isSafeToScan() : exception : " + e.__str__()
#        print msg
#        syslog.syslog(msg)
#        return False

    


# ----------------------------------------------
# why not make this code also analyse URL jobs ?
# ----------------------------------------------

def main():

    
    ############
    #test = True
    test = False
    ############
    
    # Start of code        
    syslog.openlog("kojoney_anubis", syslog.LOG_PID, syslog.LOG_LOCAL2)         # Set syslog program name         
    syslog_msg = "started, test_mode=" + test.__str__()
    syslog.syslog(syslog_msg)
       
    # Make pidfile so we can be monitored by monit        
    pid =  makePidFile("kojoney_anubis")
    if pid == None:
        syslog.syslog("Failed to create pidfile for pid " + `pid`)
        sys.exit(0)
    else:
        syslog_msg = "Started with pid=%s" % (pid)
        syslog.syslog(syslog_msg)
                
    # kojoney_guru populates the kojoney_analyst.txt file with jobs to analyse
    if test == True :
        filename = '/home/var/log/kojoney_analyst_test.txt' 			
    else :
        filename = '/home/var/log/kojoney_analyst.txt' 			
    
    syslog_msg = "kojoney_analyst file to read analysis jobs from is %s" % (filename)
    syslog.syslog(syslog_msg)
    
    fp = open(filename,'r')
            
    # ------------
    # tail -f mode
    # ------------

    # Find the size of the Job file and move to the end
    st_results = os.stat(filename)
    
    if test == False :	# test mode starts at start of file
        st_size    = st_results[6]
        fp.seek(st_size)
        print "kojoney_anubis.py : Seek to END of Analyst Job file " + filename
    else:
        print "kojoney_anubis.py : Seek to START of Analyst Job file " + filename

    ######
    #sys.exit()
    ######
    
    while True:
        tweet = None               
        RECON_DELAY = 300 	# leave enough for Blackhole to have been removed
                    
        where = fp.tell()
        line  = fp.readline().rstrip()
        
        if not line:		# no data to process
            #print "kojoney_anubis.py : nothing in Analyst Job file to process"
            fp.seek(where)
        else :			
            print " "
            print "***********************************************************"
            print "kojoney_anubis.py : NEW EVENT in Analyst jobfile to analyse"
            print "***********************************************************"
            print line
            syslog_msg = "---@@--- Analysis job retrieved from intray is %s" % (line)
            syslog.syslog(syslog_msg)
            
            if line[0] == "#":
                syslog_msg = "Job is commented out so ignore"
                syslog.syslog(syslog_msg)
                continue
            
            fields    = line.split(",")
            print "JOB : " + fields.__str__()
            jobType = fields[1]	
            #print "kojoney_anubis.py : jobType = " + jobType
            
            #if jobType   == "URL":
            #    tweet = analyseURL(fields[2],test) 
            
            if jobType == "PHPFILE" and DO_PHP_JOB == True :
                print "\n----------------------------------------------------------------------"
                print "                         PHP Malware Analysis" 
                print "----------------------------------------------------------------------\n"
                syslog_msg = "Detected a file downloaded by Glastopf via RFI attack"
                syslog.syslog(syslog_msg)
                
                print "JOB = " + line
                phpfilename = "/usr/local/src/glastopf/files/get/" + fields[2]	# fields[2] = MD5 name
                syslog_msg = "PHP file to be analysed is %s" % (phpfilename) 
                syslog.syslog(syslog_msg)
                
                tweet, syslog_msg = analyse_php_scripts.makeTweet(phpfilename)
                syslog.syslog(syslog_msg)
                
                if tweet == None :
                    tweet = "ANALYST,BOTJUICER=" + fields[2] + " => Indeterminate analysis"
                else:
                    kojoney_alert_client.sendAlert("Botjuicer Analysis",tweet,True,False)
                    tweet = "ANALYST,BOTJUICER=" + tweet
                
                # Send IDMEF to Prelude SIEM
                #kojoney_anubis_idmef.botjuicePHPIDMEF(phpfilename,tweet)
                
                if tweet != None:
                    if test != True:
                        twitter_funcs.addTweetToQueue(tweet)
                    else:
                        print "*** Tweet (TestMode) : " + tweet
                
            elif jobType == "ANUBIS" and DO_ANUBIS_JOB == True :
                print "\n----------------------------------------------------------------------"
                print "                   Anubis Win32 Malware Analysis" 
                print "----------------------------------------------------------------------\n"
                msg = "Detected an Anubis Malware Report may be ready, so wait for 10 minutes and then download and analyse it..."
                print "JOB = " + line
                syslog.syslog(msg)
                if test != True:
                    time.sleep(600) 
                    
                # Step 1 : Analyse the Anubis Report
                tweet,malwareFilename = analyseAnubisReport(fields[2],test) 
                
                if tweet != None:
                    if test != True:
                        kojoney_alert_client.sendAlert("Anubis Analysis",tweet,True,False)
                        twitter_funcs.addTweetToQueue(tweet)
                    else:
                        print "*** Tweet 1 : " + tweet
                else:		# There is no filename so go to next JOB
                    print "kojoney_anubis.py : main() : Tweet 1 : could not open file so aborting remaining analysis"
                    continue
                    
                # Step 2 : Run file through *NIX "file" utility
                #tweet = analyseMalwareFile(fields[2],malwareFilename,test) 
                tweet = analyseMalwareFile(malwareFilename,test) 
                
                if tweet != None:
                    if test != True:
                        kojoney_alert_client.sendAlert("File Analysis",tweet,True,False)
                        twitter_funcs.addTweetToQueue(tweet)
                    else:
                        print "*** Tweet 2 : " + tweet
                else:	# There is no filename so go to next JOB
                    print "kojoney_anubis.py : main() : Tweet 2 : could not open file so aborting remaining analysis"
                    continue
                
                # Step 3 : Run file through ClamAV
                if tweet != None:	# i.e. from Step 2
                    tweet = analyseMalwareAV(malwareFilename,test) 
                
                    if tweet != None:
                        if test != True:
                            kojoney_alert_client.sendAlert("AV Analysis",tweet,True,False)
                            twitter_funcs.addTweetToQueue(tweet)
                        else:
                            print "*** Tweet 3 : " + tweet
            
            elif jobType == "LMD" and DO_LMD_JOB == True :
                print "\n----------------------------------------------------------------------"
                print "                   LMD Malware Analysis" 
                print "----------------------------------------------------------------------\n"
                syslog_msg = "Detected that malware was detected by LMD so analyse it"
                print "JOB = " + line
                syslog.syslog(syslog_msg)
                        
                # Step 1 : Run file through *NIX "file" utility
                #tweet = analyseMalwareFile(fields[2],malwareFilename,test) 
                filepath = fields[2]
                tweet = analyseMalwareFile(filepath,test) 
                
                if tweet != None:
                    if test != True:
                        # bug : commented out since fires at 05:00 every morning
                        #kojoney_alert_client.sendAlert("LMD File Analysis",tweet,True,False)
                        twitter_funcs.addTweetToQueue(tweet)
                    else:
                        print "*** Tweet 1/2 : " + tweet
                else:	# There is no filename so go to next JOB
                    print "kojoney_anubis.py : main() : Tweet 2 : could not open file so aborting remaining analysis"
                    continue
                
                # Step 2 : Run file through ClamAV
                if tweet != None:	# i.e. from Step 2
                    tweet = analyseMalwareAV(filepath,test) 
                
                    if tweet != None:
                        if test != True:
                            # bug : commented out since fires at 05:00 every morning
                            #kojoney_alert_client.sendAlert("LMD AV Analysis",tweet,True,False)
                            twitter_funcs.addTweetToQueue(tweet)
                        else:
                            print "*** Tweet 2/2 : " + tweet
            
            elif jobType == "URL" and DO_URL_JOB == True :
                print "\n----------------------------------------------------------------------"
                print "                         URL download and Malware Analysis" 
                print "----------------------------------------------------------------------\n"
                print "JOB = " + line
                syslog_msg = "Detected that a URL has appeared in the tweet_queue.log file, so download and analyse it"
                syslog.syslog(syslog_msg)
                    
                tweetList = analyseURL(fields[2],test) 
                if tweetList != None :
                    for tweet in tweetList:
                        print "*** Tweet *** : " + tweet
                        if test != True :
                            kojoney_alert_client.sendAlert("Snarfed File Analysis",tweet,True,False)
                            twitter_funcs.addTweetToQueue(tweet,geoip=True)
                        
            elif jobType == "RECON" and DO_RECON_JOB == True :
                ip = fields[2]
                
                print "\nkojoney_anubis.py : Tracerouted IPs cache ->"
                print ipTracerouted
                if isSafeToScan(ip) == False :
                    continue				# go to top of loop i.e. next IP
                #else:
                #    continue				# force to not do traceroute until time blackhole is smarter
                        
                if ipTracerouted.has_key(ip) == False :
                #if ip not in ipList :
                    #ipList.append(ip)
                    print "\n----------------------------------------------------------------------"
                    print "                Step 1 : Reconnaissance (traceroute)                    " 
                    print "----------------------------------------------------------------------\n"
                    print "JOB = " + line
                    msg = ip + " has not been actively tracerouted Today"
                    print msg         
                    syslog.syslog(msg)
                    
                    #syslog.syslog("sleep for " + RECON_DELAY.__str__() + " seconds and then traceroute " + ip)
                    
                    if test != True:
                        print "sleeping for " + RECON_DELAY.__str__() + " seconds..."
                        time.sleep(RECON_DELAY)			# leave the host alone for a bit... 
                    
                    # Step 4 : Traceroute to the attacker
                    asPath = traceroute_matrix.traceroute("HPOT",ip,30) 
                    if asPath != None:
                        tweet = "ANALYST,TRACEROUTE "
                        tweet = tweet + '->'.join(asPath)
                        # obscure my AS !
                        #tweet = tweet.replace("BT-UK-AS","AS???")
                        #tweet = tweet.replace("->BT","->AS???")
                        tweet = tweet.replace("BT-UK-AS","ISP")
                        tweet = tweet.replace("->BT","->ISP")
                        tweet = tweet.replace("->ISP->ISP","->ISP")
                        ipTracerouted[ip] = tweet	# cache the results
                else:
                    #tweet = ipTracerouted[ip]        
                    tweet = None
                
                msg = "Number of unique IPs tracerouted to since process re-start : " + len(ipTracerouted).__str__()
                syslog.syslog(msg)
                
                # Send info to Prelude SIEM             
                #kojoney_anubis_idmef.tracerouteIDMEF(ip,tweet)
     
                if test != True :
                    if tweet != None:
                        twitter_funcs.addTweetToQueue(tweet,geoip=True)
                
                # nmap the attacker
                # =================    
                print "\nkojoney_anubis.py : Nmapped IPs cache ->"
                print ipNmapped
                
                if ipNmapped.has_key(ip) == False :
                #if True == False :	#  uncomment this to disable this function : bypass this until a way of not clogging DSL can be found
                    print "\n----------------------------------------------------------------------"
                    print "                Step 2 : Reconnaissance (nmap)                          " 
                    print "----------------------------------------------------------------------\n"
                    print ip + " has not been actively nmapped Today"
                    
                    print "kojoney_anubis.py : sleep for " + RECON_DELAY.__str__() + " seconds and then Nmap " + ip 
                    if test != True:
                        time.sleep(RECON_DELAY)			# leave the host alone for a bit... 
                    
                    openPorts,closedPorts,hops,osService,uptime,ipid,tcpSeq,hostname = kojoney_nmap.nmapScan(ip)
                    
                    # Add an entry to daily viz file for nmap scans
                    vizNmap(ip,openPorts)
                        
                    tweet = "ANALYST,NMAP " + ip + " " 
                    if len(openPorts) > 20 :
                        tweet = tweet + "open={" + len(openPorts).__str__() + " ports}" 
                    else:
                        tweet = tweet + "open={"
                        tweet = tweet + ' '.join(openPorts)
                        tweet = tweet + "}" 
                        
                    if osService != "?" :	
                        tweet = tweet + " os=" + osService
                    
                    if uptime != "?" :	
                        tweet = tweet + " up=" + uptime
                    
                    if ipid != "?" :	
                        tweet = tweet + " ipId=" + ipid
                    
                    if tcpSeq != "?" :	
                        tweet = tweet + " tcpSeq=" + tcpSeq
                    
                    if hops != None:
                        tweet = tweet + " hops=" + hops
                        
                    ipNmapped[ip] = tweet		# cache the results
                else:
                    #tweet = ipNmapped[ip]    
                    tweet = None        
                
                # Send info to Prelude SIEM             
                # kojoney_anubis_idmef.nmapIDMEF(ip,tweet)
         
                print "kojoney_anubis.py : nmap tweet = " + tweet.__str__()
                
                if test != True:
                    if tweet != None :
                        twitter_funcs.addTweetToQueue(tweet,geoip=True)
                   
        if test != True:
            time.sleep(10)	# large delay since events in this channel are rare
        
        
if __name__ == '__main__':
    main()           
