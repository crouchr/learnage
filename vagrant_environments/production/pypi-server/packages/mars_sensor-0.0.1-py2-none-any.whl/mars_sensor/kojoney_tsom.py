#!/usr/bin/python
import operator
import os
import pickle  # shelve does not work with bb_freeze
import sys
import syslog
import time
from pprint import pprint

import definitions
import ipintellib
import kojoney_syslog
import rest_api

# ATTACKER_DICT = {}
# ATTACKER_INFO = {}

WEIGHT = {'PROBING': 1, 'SCANNING': 3, 'PSCAN': 4, \
          'BHOLE': 5, 'ATTACKING': 15, 'GAINED_ACCESS': 30, \
          'MWARE': 30, 'MAINTAIN_ACCESS': 40, 'COVER_TRACKS': 50, 'HUMAN_ACTIVITY': 80}
# PROBING = any form of data received
# SCANNING = ?


# set up Syslog parameters
ident = kojoney_syslog.BR_TSOM
logopt = kojoney_syslog.BR_LOGOPT
facility = kojoney_syslog.BR_SEC_FACILITY
syslog.openlog(ident, logopt, facility)

syslog_msg = "Process started"
kojoney_syslog.ops_log(syslog_msg)


# FIXME : add exception handling
def write_event_to_mqtt_simulated(sdata):
    """
    Write to a file for debugging purposes - not required by the product
    """
    syslogFmt = "========================\n" + time.ctime() + "\n" + sdata['ip'] + "\n" + sdata[
        'type'] + "\n" + sdata.__str__()
    fpOut = open("/home/var/log/tsom_mqtt_simulated.log", "a")
    print >> fpOut, syslogFmt
    fpOut.close()

    # TODO : for ARGUS types, extract the dst_port from details and put in syslog
    # write syslog for ossec rules to be used
    # 'details': 'proto=TCP:dPort=8181:bytes=150'
    print "+++ @@ +++"
    pprint(sdata)
    if sdata['type'] == "NEW_ATTACKER":
        details = sdata['details'].split(':')
        # protocol = details[0].split("=")[1]
        # print "protocol = " + protocol.__str__()
        # syslog_msg = sdata['type'] + " ip=" + sdata['ip'] + " detected by sensor=" + sdata['sensor'] + " msg=" + sdata['sensor_msg']
        syslog_msg = "A new attacker has been detected => sensor=%s attacker_ip=%s reason=%s" % (
            sdata['sensor'], sdata['ip'], sdata['sensor_msg'])
        kojoney_syslog.sec_log(syslog_msg, syslog.LOG_WARNING)
    elif sdata['type'] == "NEW_ATTACK":
        # syslog_msg = sdata['type'] + " ip=" + sdata['ip'] + " detected by sensor=" + sdata['sensor'] + " phase=" + sdata['phase']
        syslog_msg = "A new attack has been detected  => sensor=%s attacker_ip=%s phase=%s" % (
            sdata['sensor'], sdata['ip'], sdata['phase'])
        kojoney_syslog.sec_log(syslog_msg, syslog.LOG_WARNING)
    elif sdata['type'] == "DELETE_ATTACKER":
        # syslog_msg = sdata['type'] + " ip=" + sdata['ip']
        syslog_msg = "A previously seen attacker has stopped their current attack => attacker_ip=%s" % (sdata['ip'])
        kojoney_syslog.sec_log(syslog_msg, syslog.LOG_INFO)
    else:  # what is this ?
        syslog_msg = sdata['type'] + " ip=" + sdata['ip'] + " error - what sdata type is this ?"

    # kojoney_syslog.sec_log(syslog_msg)
    # print " > syslog = " + syslog_msg

    # use REST API call to send to adpator that will push to MQTT topic
    # send_to_br_event_adapter(sdata)


# Return a string with flags in correct sequence/priority order
# Note : Not all flags may be present in the flags string 
def orderFlags(flags):
    try:
        WEIGHTLIST = ['PR', 'SC', 'PS', 'BH', 'AT', 'GA', 'MW', 'MA', 'CO', 'HU']
        # print "entered orderFlags()"
        # print "IN [" + flags + "]"
        flags = flags.rstrip(" ")
        flagList = flags.split(" ")
        # print "flagList = " + flagList.__str__()
        orderedList = []

        for phaseShort in WEIGHTLIST:
            # print phaseShort
            if phaseShort in flagList:
                orderedList.append(phaseShort)
                # myorder = [0,1,2,3,4,5,6,7,8,9]
        # orderedList = [ flagList[i] for i in myorder]
        # print orderedList
        orderedString = " ".join(orderedList) + " "
        # print "OUT [" + orderedString + "]"

        return orderedString

    except Exception, e:
        msg = "kojoney_tsom.py::orderFlags() : exception : " + e.__str__()
        kojoney_syslog.ops_log(msg)
        return None

    # add new attacks to dictionary


def process(line, ATTACKER_DICT, ATTACKER_INFO, lifetimeID):
    # global ATTACKER_DICT
    # global ATTACKER_INFO
    attack = {}  # one single attack
    attackerInfo = {}
    attackList = []
    tsom_event = {}

    try:
        line = line.rstrip("\n")
        # print "---------"
        fields = line.split(",")
        # print fields
        # print line
        # print " "
        epoch = float(fields[1])
        tstamp = fields[2]
        attackerIP = fields[3]
        phase = fields[5]  # SCANNING | ATTACKING etc
        osShort = fields[6]
        sensor = fields[7]  # OSSEC
        sensorMsg = fields[9]
        addInfo1 = fields[13]
        addInfo2 = fields[14]

        # print tstamp
        # print attackerIP
        # print phase
        # print "osShort=" + osShort

        # phaseKey   = attackerIP + "-" + phase
        # phaseKey   = attackerIP + "-" + phase + "-" + sensor

        if ATTACKER_DICT.has_key(attackerIP) == False:
            print "[+] kojoney_tsom : process() : NEW_ATTACKER : " + time.ctime() + " " + lifetimeID + " " + attackerIP + " has NOT been seen before, so create a new attacker record..."
            attack['epoch'] = epoch
            attack['tstamp'] = tstamp
            attack['phase'] = phase
            attack['sensor'] = sensor
            attack['sensorMsg'] = sensorMsg
            attack['addInfo1'] = addInfo1
            attack['addInfo2'] = addInfo2
            attackList.append(attack)
            pprint(attack)

            # Data enhancement
            # ----------------
            # GeoIP
            geoIP = ipintellib.geo_ip(attackerIP)
            attackerInfo['cc'] = geoIP['countryCode']
            attackerInfo['city'] = geoIP['city']
            attackerInfo['latitude'] = geoIP['latitude']
            attackerInfo['longitude'] = geoIP['longitude']

            # p0f
            attackerInfo['os'] = osShort

            # IP record creation time
            attackerInfo['epoch'] = epoch
            attackerInfo['tstamp'] = tstamp

            # phases the attacker has tried
            attackerInfo['flags'] = ""

            # Peak value of CTL
            attackerInfo['ctlPeak'] = 0.0
            attackerInfo['ctlSumPeak'] = 0.0

            # store details of the last attack            
            attackerInfo['lastSensor'] = sensor
            attackerInfo['lastSensorMsg'] = sensorMsg
            attackerInfo['lastSensorTime'] = time.ctime()
            attackerInfo['lastSensorAddInfo1'] = addInfo1
            attackerInfo['lastSensorAddInfo2'] = addInfo2

            # DNS info
            dnsInfo = ipintellib.ip2name(attackerIP)
            attackerInfo['rdns'] = dnsInfo['name'].rstrip('.')  # right-strip the trailing .

            # WHOIS - AS number        
            asInfo = ipintellib.ip2asn(attackerIP)
            if asInfo['as'] == "AS-none":
                asn = "Unknown"
            else:
                asn = "AS" + asInfo['as']
            attackerInfo['as'] = asn  # AS123

            # WHOIS - ISP name
            if asInfo['registeredCode'] == "whois-failed":
                isp = "Unknown"
            else:
                isp = asInfo['registeredCode']
            attackerInfo['isp'] = isp  # Short-form e.g.ARCOR

            # send info about new attacker to MQTT
            pprint(attackerInfo)
            tsom_event['type'] = "NEW_ATTACKER"
            tsom_event['ip'] = attackerIP
            tsom_event['lifetime'] = lifetimeID
            tsom_event['rdns'] = attackerInfo['rdns']  # this info does not require data files to be kept up to date
            tsom_event['sensor'] = attack[
                'sensor']  # i.e. records against IP why it has been determined to be an attacker
            tsom_event['sensor_msg'] = attack[
                'sensorMsg']  # i.e. records against IP why it has been determined to be an attacker
            tsom_event['details'] = attack['addInfo1']
            tsom_event['lat'] = round(attackerInfo['latitude'], 6)
            tsom_event['long'] = round(attackerInfo['longitude'], 6)
            tsom_event['cc'] = attackerInfo['cc']

            if tsom_event['lifetime'] == 'P1':
                print " "
                print "+++++++++++++++++++++"
                print "send to REST API"
                pprint(tsom_event)
                print "----------"
                pprint(attackerInfo)
                print "+++++++++++++++++++++"
                print " "
                write_event_to_mqtt_simulated(tsom_event)

            # print attackerInfo.__str__()
            # print attack.__str__()
            ATTACKER_DICT[attackerIP] = attackList
            ATTACKER_INFO[attackerIP] = attackerInfo
            # print ATTACKER_DICT.__str__()
            # ATTACKER_DICT[phaseKey] = time.time()

            # FIXME : initially add meta info but eventually just use ip as the key
            # print "-----------------------------------------------"
            # print "**** process() -> simulate MQTT ADD an attacker"
            # tsom_event = attackerInfo
            # tsom_event['type'] = 'add_attacker'
            # tsom_event['ip'] = attackerIP
            # pprint(tsom_event)
            # print "-----------------------------------------------"

            # print " -> " + line
        else:
            # print "[+] kojoney_tsom : process() : NEW_ATTACK : " + lifetimeID + ", IP " + attackerIP + " has been seen before so append attack to existing list of attacks"
            attack['epoch'] = epoch
            attack['tstamp'] = tstamp
            attack['phase'] = phase
            attack['sensor'] = sensor
            attack['sensorMsg'] = sensorMsg
            attack['addInfo1'] = addInfo1
            attack['addInfo2'] = addInfo2

            # print attack.__str__()
            # append the NEW attack onto the list of attacks from ths IP
            ATTACKER_DICT[attackerIP].append(attack)
            tsom_event['type'] = "NEW_ATTACK"
            tsom_event['ip'] = attackerIP
            tsom_event['lifetime'] = lifetimeID
            tsom_event['phase'] = attack['phase']
            tsom_event['sensor'] = attack['sensor']
            tsom_event['details'] = attack['addInfo1']

            if tsom_event['lifetime'] == 'P1':
                # print " "
                # print "+++++++++++++++++++++"
                # print "send to REST API"
                # pprint(tsom_event)
                # print "----------"
                # pprint(attack)
                # print "+++++++++++++++++++++"
                # print " "
                write_event_to_mqtt_simulated(tsom_event)

            # print ATTACKER_DICT.__str__()

            # p0f - update if os is not already set
            attackerInfo = ATTACKER_INFO[attackerIP]
            if osShort != "none" and attackerInfo['os'] == "none":
                # print "kojoney_tsom : " + time.ctime() + " " + lifetimeID + " " + "New information received, so update attacker OS info"
                attackerInfo['os'] = osShort
                ATTACKER_INFO[attackerIP] = attackerInfo

                # store details of the last attack
            attackerInfo = ATTACKER_INFO[attackerIP]
            attackerInfo['lastSensor'] = sensor
            attackerInfo['lastSensorMsg'] = sensorMsg
            attackerInfo['lastSensorTime'] = time.ctime()
            attackerInfo['lastSensorAddInfo1'] = addInfo1
            attackerInfo['lastSensorAddInfo2'] = addInfo2
            ATTACKER_INFO[attackerIP] = attackerInfo

    except Exception, e:
        msg = "kojoney_tsom.py::process() : exception : " + e.__str__() + " for lifetimeID=" + lifetimeID
        kojoney_syslog.ops_log(msg)
        return

    # Calculate and update CTL values


def calcCTL(ATTACKER_DICT_P1, ATTACKER_INFO_P1, ATTACKER_DICT_P2, ATTACKER_INFO_P2):
    try:

        # first two characters are the values use for the attack phase flags
        global WEIGHT
        # = { 'PROBING' : 1 , 'SCANNING' : 3 , 'PSCAN' : 4 , 'BHOLE' : 5 , 'ATTACKING' : 15 , 'GAINED_ACCESS' : 30 , 'MWARE' : 30 , 'MAINTAIN_ACCESS' : 40 , 'COVER_TRACKS' : 50 , 'HUMAN_ACTIVITY' : 80 }

        # P1
        # --
        if len(ATTACKER_DICT_P1) > 0:
            # print "P1 lifetime"
            # print "-----------"
            for ip in ATTACKER_DICT_P1:
                flags = ATTACKER_INFO_P1[ip]['flags']
                attackerWeight = 0
                attackerEvents = 0
                attackList = ATTACKER_DICT_P1[ip]
                for attack in attackList:
                    attackerEvents = attackerEvents + 1
                    attackerWeight = attackerWeight + WEIGHT[attack['phase']]
                    phaseShort = attack['phase'][0:2].upper()  # first two characters
                    if phaseShort not in flags:
                        flags = flags + phaseShort + " "

                ATTACKER_INFO_P1[ip]['flags'] = flags
                ATTACKER_INFO_P1[ip]['ctl'] = float(attackerWeight) / float(attackerEvents)
                ATTACKER_INFO_P1[ip]['eventsSum'] = attackerEvents
                ATTACKER_INFO_P1[ip]['weightSum'] = attackerWeight
                ATTACKER_INFO_P1[ip]['ctlSum'] = 0.0  # Just set to a dummy value to be overidden by the P2 calculation

                # print "calcCTL() - dump ATTACKER_INFO_P1 info about attacker ip=" + ip.__str__()
                # pprint(ATTACKER_INFO_P1[ip])

                if ATTACKER_INFO_P1[ip]['ctl'] > ATTACKER_INFO_P1[ip]['ctlPeak']:
                    ATTACKER_INFO_P1[ip]['ctlPeak'] = ATTACKER_INFO_P1[ip]['ctl']
                    # print ip + " has new P1 ctlPeak=" + "%.1f" % ATTACKER_INFO_P1[ip]['ctlPeak']

                # print "calcCTL() : P1 weightSum for " + ip + " is %.1f" % ATTACKER_INFO_P1[ip]['weightSum']
                # print "calcCTL() : P1 eventsSum for " + ip + " is %.1f" % ATTACKER_INFO_P1[ip]['eventsSum']
                # print "calcCTL() : P1       CTL for " + ip + " is %.1f" % ATTACKER_INFO_P1[ip]['ctl']
                ##print "calcCTL() : P1 Total CTL for " + ip + " is %.1f" % ATTACKER_INFO_P1[ip]['ctlSum']
                # print " "
        # P2
        # --
        if len(ATTACKER_DICT_P2) > 0:
            # print "P2 lifetime"
            # print "-----------"
            for ip in ATTACKER_DICT_P2:
                flags = ATTACKER_INFO_P2[ip]['flags']
                attackerWeight = 0
                attackerEvents = 0
                attackList = ATTACKER_DICT_P2[ip]

                # can handle multiple attacks per IP -> sum the weights of the attacks
                for attack in attackList:
                    attackerEvents = attackerEvents + 1
                    attackerWeight = attackerWeight + WEIGHT[attack['phase']]
                    phaseShort = attack['phase'][0:2].upper()  # first two characters
                    if phaseShort not in flags:
                        flags = flags + phaseShort + " "

                ATTACKER_INFO_P2[ip]['flags'] = flags
                ATTACKER_INFO_P2[ip]['eventsSum'] = attackerEvents
                ATTACKER_INFO_P2[ip]['weightSum'] = attackerWeight

                ATTACKER_INFO_P2[ip]['ctl'] = float(attackerWeight) / float(attackerEvents)

                # ctlSum = CTL for P1 + CTL for P2
                if ATTACKER_INFO_P1.has_key(ip):
                    ATTACKER_INFO_P2[ip]['ctlSum'] = float(ATTACKER_INFO_P2[ip]['ctl']) + float(
                        ATTACKER_INFO_P1[ip]['ctl'])
                    ATTACKER_INFO_P1[ip]['ctlSum'] = float(ATTACKER_INFO_P2[ip]['ctl']) + float(
                        ATTACKER_INFO_P1[ip]['ctl'])
                else:
                    ATTACKER_INFO_P2[ip]['ctlSum'] = float(ATTACKER_INFO_P2[ip]['ctl'])

                if ATTACKER_INFO_P2[ip]['ctl'] > ATTACKER_INFO_P2[ip]['ctlPeak']:
                    ATTACKER_INFO_P2[ip]['ctlPeak'] = ATTACKER_INFO_P2[ip]['ctl']
                    # print ip + " has new P2 ctlPeak=" + "%.1f" % ATTACKER_INFO_P2[ip]['ctlPeak']

                if ATTACKER_INFO_P2[ip]['ctlSum'] > ATTACKER_INFO_P2[ip]['ctlSumPeak']:
                    ATTACKER_INFO_P2[ip]['ctlSumPeak'] = ATTACKER_INFO_P2[ip]['ctlSum']
                    # print ip + " has new ctlSumPeak=" + "%.1f" % ATTACKER_INFO_P2[ip]['ctlSumPeak']

                # print "calcCTL() : P2 weightSum for " + ip + " is %.1f" % ATTACKER_INFO_P2[ip]['weightSum']
                # print "calcCTL() : P2 eventsSum for " + ip + " is %.1f" % ATTACKER_INFO_P2[ip]['eventsSum']
                # print "calcCTL() : P2       CTL for " + ip + " is %.1f" % ATTACKER_INFO_P2[ip]['ctl']
                # print "calcCTL() : P2 Total CTL for " + ip + " is %.1f" % ATTACKER_INFO_P2[ip]['ctlSum']
                # print " "

    except Exception, e:
        msg = "kojoney_tsom.py::calcCTL() : exception : " + e.__str__()
        kojoney_syslog.ops_log(msg)
        return

    # dump current state of attackers/attacks to a file for monitoring / debugging


# you have to cat this file, not tail it
def dumpFileAttackerDict(ATTACKER_DICT, ATTACKER_INFO, filename, lifetimeID):
    """
    lifetimeID : P1 or P2
    """
    try:

        if len(ATTACKER_INFO) <= 0:
            # print "dumpAttackerDict() : No attackers to dump information for, so early return for lifetimeID=" + lifetimeID
            return

        # print "dumpFileAttackerDict() : write to " + filename
        fpOut = open(filename, 'w')
        print >> fpOut, " "
        print >> fpOut, "attackerCache for " + lifetimeID
        print >> fpOut, "--------------------"
        print >> fpOut, "Last updated : " + time.ctime()
        print >> fpOut, " "
        for ip in ATTACKER_DICT:
            # pprint(ATTACKER_INFO[ip])
            # attackerWeight = 0
            # attackerEvents = 0
            print >> fpOut, " "
            print >> fpOut, "ATTACKER : " + ip + " " + "[" + ATTACKER_INFO[ip]['rdns'] + "]" + " " + "OS=" + \
                            ATTACKER_INFO[ip]['os'] + " " + "(" + ATTACKER_INFO[ip]['city'] + "," + ATTACKER_INFO[ip][
                                'cc'] + ")" + " " + "%.2f" % ATTACKER_INFO[ip]['latitude'] + "N " + "%.2f" % \
                            ATTACKER_INFO[ip]['longitude'] + "E"
            print >> fpOut, " Network : " + "AS" + ATTACKER_INFO[ip]['as'] + " " + ATTACKER_INFO[ip]['isp']

            attackList = ATTACKER_DICT[ip]
            for attack in attackList:
                # attackerEvents = attackerEvents + 1
                # attackerWeight = attackerWeight + WEIGHT[attack['phase']]
                # ATTACKER_INFO[ip]['ctl'] = float(attackerWeight) / float(attackerEvents)
                print >> fpOut, " "
                print >> fpOut, " " + attack['tstamp'].__str__() + " " + attack['phase'] + " : " + attack[
                    'sensor'] + " => " + attack['sensorMsg']
                print >> fpOut, "  " + attack['addInfo1'] + " " + attack['addInfo2']
            print >> fpOut, " "
            # print >> fpOut, "attackerWeight=" + attackerWeight.__str__() + " attackerEvents=" + attackerEvents.__str__()
            print >> fpOut, "=> " + lifetimeID + " : Attacker Compound Threat Level (CTL) : %.1f" % ATTACKER_INFO[ip][
                'ctl']

        print >> fpOut, " "
        print >> fpOut, "-------------"
        print >> fpOut, " "
        fpOut.close()

    except Exception, e:
        msg = "kojoney_tsom.py::dumpFileAttackerDict() : exception : " + e.__str__() + " for lifetimeID=" + lifetimeID
        kojoney_syslog.ops_log(msg)
        return

    # dump current state of attackers/attacks to TTY in descending order of CTL


# This is only for debug - the master is in kojoney_api.py
def dumpTTYattackerDict(ATTACKER_DICT, ATTACKER_INFO):
    try:

        X = {}

        if len(ATTACKER_INFO) <= 0:
            # print "dumpTTYattackerDict() : No attackers to dump information for, so early return"
            return

        # print " "
        # print "======================================================================================="
        # print time.ctime()
        # print "dumpTTYattackerDict() : real-time (RT) display of attacker IPs (higher severity at top)"
        # print "======================================================================================="
        for ip in ATTACKER_DICT:
            # print "RT : " + ip + " (" + ATTACKER_INFO[ip]['rdns'] + ")" + " CTL=%.1f" % ATTACKER_INFO[ip]['ctlSum'] + " " + ATTACKER_INFO[ip]['os'] + " (" + ATTACKER_INFO[ip]['cc'] + "," + ATTACKER_INFO[ip]['city'] + ")" + " %.2fN" % ATTACKER_INFO[ip]['latitude'] + " %.2fE" % ATTACKER_INFO[ip]['longitude'] + " " + ATTACKER_INFO[ip]['as'] + " " + ATTACKER_INFO[ip]['isp'] + " (P2 #W=" + ATTACKER_INFO[ip]['weightSum'].__str__() + " P2 #E=" + ATTACKER_INFO[ip]['eventsSum'].__str__() +")"
            X[ip] = ATTACKER_INFO[ip]['ctlSum']

        # print "Unsorted : " + X.__str__()

        # Sort based on ctl value, highest at head of list
        # SORTED_LIST
        # [('167.94.146.27', 6.0),
        # ('13.245.35.183', 2.0),
        # ('13.229.217.84', 2.0),
        # ('18.198.55.236', 2.0)]

        SORTED_LIST = sorted(X.iteritems(), key=operator.itemgetter(1), reverse=True)
        # print "SORTED_LIST"
        # pprint(SORTED_LIST)

        # Display in order of CTL (descending)
        for a in SORTED_LIST:
            ip = a[0]
            msg = ip + " (" + ATTACKER_INFO[ip]['rdns'] + ")" + " CTL=%.1f" % ATTACKER_INFO[ip]['ctlSum'] + " {%.1f}" % \
                  ATTACKER_INFO[ip]['ctlPeak'] + " " + ATTACKER_INFO[ip]['os'] + " (" + ATTACKER_INFO[ip]['cc'] + "," + \
                  ATTACKER_INFO[ip]['city'] + ")" + " %.2fN" % ATTACKER_INFO[ip]['latitude'] + " %.2fE" % \
                  ATTACKER_INFO[ip]['longitude'] + " " + ATTACKER_INFO[ip]['as'] + " " + ATTACKER_INFO[ip][
                      'isp'] + " (P2 #W=" + ATTACKER_INFO[ip]['weightSum'].__str__() + " P2 #E=" + ATTACKER_INFO[ip][
                      'eventsSum'].__str__() + ")" + " flags=" + ATTACKER_INFO[ip]['flags'].rstrip(" ")
            # print msg
            # pprint(ATTACKER_INFO[ip])

        # print "======================================================================================="
        # print " "
    except Exception, e:
        msg = "kojoney_tsom.py::dumpTTYattackerDict() : exception : " + e.__str__()
        kojoney_syslog.ops_log(msg)
        return

    # Pickle the Attacker Info database to file so that other programs can use it


def pickleAttackerInfo(ATTACKER_INFO):
    try:
        PICKLE_FILE = "/home/var/log/tsom_pickle.dat"
        pickle.dump(ATTACKER_INFO, open(PICKLE_FILE, "wb"))
        # print "pickleAttackerInfo() : pickled ATTACKER_INFO to " + PICKLE_FILE

    except Exception, e:
        msg = "kojoney_tsom.py::pickleAttackerInfo() : exception : " + e.__str__()
        kojoney_syslog.ops_log(msg)
        return

    # lifetime is in seconds


# Prune out expired attacks and attackers
def pruneAttackerDict(ATTACKER_DICT, ATTACKER_INFO, lifetime, test, lifetimeID):
    try:

        # print "pruneAttackerDict() called"
        tsom_event = {}
        ipRemoveList = []
        now = time.time()

        # print "lifetimeID = " + lifetimeID
        for ip in ATTACKER_DICT:
            # print "  -> Attacker : " + ip.__str__()
            attackList = ATTACKER_DICT[ip]
            for attack in attackList:
                epoch = attack['epoch']
                # print "  epoch : " + epoch.__str__()
                if now - epoch >= float(lifetime):
                    # print "[-] kojoney_tsom : " + lifetimeID + " attack record has exceeded lifetime, so DELETE attack=" + attack.__str__()
                    attackList.remove(attack)
                    ATTACKER_DICT[ip] = attackList
                    if len(attackList) == 0:
                        # print "[-] kojoney_tsom : " + lifetimeID + " attackList for attacker " + ip.__str__() + " is now empty (i.e. attacks have stopped), so mark for deletion"
                        ipRemoveList.append(ip)

        # Purge the aged out attacker IPs
        # print "Purge stale attacker IPs..."
        # TODO : How to calculate attack duration ?
        for ip in ipRemoveList:
            writeTSOMrec(ip, ATTACKER_INFO[ip], test, lifetimeID)

            # print "pruneAttackerDict() : " + lifetimeID + " : DELETE ATTACKER_DICT[] for " + ip.__str__() + " " + ATTACKER_DICT[ip].__str__()
            # pprint(ATTACKER_INFO[ip])
            # FIXME : code needs to be checked that actual timestamp from the log file is being used - this is a temporary hack
            # FIXME : timestamps need to be bullet proof e.g. UTC etc, correct format etc
            # attack_start = ATTACKER_INFO[ip]['epoch']
            # now = time.time()
            # attacker_duration = now - attack_start				# how long has this IP been attacking ?
            # print "attacker_duration = " + attacker_duration.__str__()

            tsom_event['type'] = "DELETE_ATTACKER"
            tsom_event['ip'] = ip
            tsom_event['lifetime'] = lifetimeID
            tsom_event['flags'] = ATTACKER_INFO[ip]['flags'].rstrip(" ")
            tsom_event['ctl_peak'] = ATTACKER_INFO[ip]['ctlPeak']
            tsom_event['events'] = ATTACKER_INFO[ip]['eventsSum']
            tsom_event['lat'] = round(ATTACKER_INFO[ip]['latitude'], 6)
            tsom_event['long'] = round(ATTACKER_INFO[ip]['longitude'], 6)
            tsom_event['cc'] = ATTACKER_INFO[ip]['cc']

            # tsom_event['attacker_duration'] = int(attacker_duration)
            # tsom_event['attacks_started'] = ATTACKER_INFO[ip]['tstamp']
            # tsom_event['attacks_ended'] = time.ctime()

            if tsom_event['lifetime'] == 'P1':
                # print " "
                # print "+++++++++++++++++++++"
                # print "send to REST API"
                # pprint(tsom_event)
                # print "----------"
                # pprint(ATTACKER_INFO[ip])
                # print "+++++++++++++++++++++"
                # print " "
                write_event_to_mqtt_simulated(tsom_event)

            # prune
            del ATTACKER_DICT[ip]
            # print "pruneAttackerDict() : " + lifetimeID + " : DELETE ATTACKER_INFO[] for  " + ip + " " + ATTACKER_INFO[ip].__str__()
            # pprint (ATTACKER_INFO[ip])
            del ATTACKER_INFO[ip]

    except Exception, e:
        msg = "kojoney_tsom.py : pruneAttackerDict() : exception : " + e.__str__() + " for lifetimeID=" + lifetimeID
        kojoney_syslog.ops_log(msg)
        print msg
        return

    # This file is also tailed by kojoney_tweet and is used when ctl changes


# This data should be written to a SQL database for long-term statistics
def writeTSOMrec(ip, attackerInfo, test, lifetimeID):
    try:
        # print "writeTSOMrec() called"

        deleteEpoch = time.time()
        ipLifetime = deleteEpoch - float(attackerInfo['epoch'])  # now - time that the IP was first seen attacking

        if lifetimeID == "P1":
            CTL = attackerInfo['ctlPeak']
        else:
            CTL = attackerInfo['ctlSumPeak']
        flags = attackerInfo['flags'].rstrip(" ")

        # msg = "tstamp=" + time.ctime() + ", ip=" + ip + ", " + lifetimeID + "CTLpeak=" + "%.1f" % CTL + ", createEpoch=" + "%.2f" % float(attackerInfo['epoch']) + ", pruneEpoch=" + "%.2f" % deleteEpoch + ", cc=" + attackerInfo['cc'] + ", city=" + attackerInfo['city'] + ", rdns=" + attackerInfo['rdns'] + ", net=" + "AS" + attackerInfo['as'] + ", isp=" + attackerInfo['isp'] + ", os=" + attackerInfo['os'] + ", lifetimeSecs=" + "%.1f" % ipLifetime
        # msg = "tstamp=" + time.ctime() + ", ip=" + ip + ", cc=" + attackerInfo['cc'] + ", flags=" + '"' + flags + '"' + ", " + lifetimeID + "CTLpeak=" + "%.1f" % CTL +  ", city=" + '"' + attackerInfo['city'] + '"' + ", rdns=" + attackerInfo['rdns'] + ", net=" + attackerInfo['as'] + ", isp=" + '"' + attackerInfo['isp'] + '"' + ", os=" + attackerInfo['os'] + ", createEpoch=" + time.ctime(float(attackerInfo['epoch'])) + ", pruneEpoch=" + time.ctime(deleteEpoch) + ", lifetimeSecs=" + "%.1f" % ipLifetime

        # print "-----------------------"
        msg = "tstamp=" + time.ctime() + ", ip=" + ip + ", cc=" + attackerInfo[
            'cc'] + ", flags=" + '"' + flags + '"' + ", " + lifetimeID + "CTLpeak=" + "%.1f" % CTL + ", city=" + '"' + \
              attackerInfo['city'] + '"' + ", rdns=" + attackerInfo['rdns'] + ", net=" + attackerInfo[
                  'as'] + ", isp=" + '"' + attackerInfo['isp'] + '"' + ", os=" + attackerInfo[
                  'os'] + ", createEpoch=" + time.ctime(float(attackerInfo['epoch'])) + ", pruneEpoch=" + time.ctime(
            deleteEpoch) + ", lifetimeSecs=" + "%.1f" % ipLifetime
        # print "**** dumpTSOMrec() - hook here to send to MQTT : " + lifetimeID + " dumpTSOMrec() : " + msg
        # print "-----------------------"

        if test == True:
            filename = "/home/var/log/tsom_dump_test.csv"
        else:
            filename = '/home/var/log/tsom_dump.csv'

        fpOut = open(filename, 'a')
        print >> fpOut, msg
        fpOut.close()

    except Exception, e:
        msg = "kojoney_tsom.py : writeTSOMrec() : exception : " + e.__str__() + " for lifetimeID=" + lifetimeID
        kojoney_syslog.ops_log(msg)
        return

    # FIXME : unify with kojomey_attack_event.py


# line = 'RT : 192.168.1.171 (NoDNS) CTL=1.0 {1.0} none (None,None) 999.00N 999.00E Unknown Unknown (P2 #W=1 P2 #E=1) flags=PR'
# def generate_sdata_tsom_attacker_sdata(line):
#    """
#    >>> line = 'RT : 192.168.1.171 (NoDNS) CTL=1.0 {1.0} none (None,None) 999.00N 999.00E Unknown Unknown (P2 #W=1 P2 #E=1) flags=PR'
#    >>> generate_sdata_tsom_attacker_sdata(line)
#    """
#    sdata = definitions.Sdata
#    line = 'RT : 192.168.1.171 (NoDNS) CTL=1.0 {1.0} none (None,None) 999.00N 999.00E Unknown Unknown (P2 #W=1 P2 #E=1) flags=PR'
#    
#    sdata['type'] = 'ATTACK_EVENT'
#    
#    # extract the attacker IP
#    pat = "RT : (\d+\.\d+\.\d+\.\d+)"
#    a = re.findall(pat,ip)
#    if len(a) > 0:
#        sdata['ip'] = a[0]
#    
#    return sdata


# send to br-event-adapter via REST API
# -------------------------------------
def send_to_br_event_adapter(sdata):
    url = definitions.br_exporter_endpoint + '/send_to_mqtt'
    query = sdata
    query['app_name'] = 'tsom'
    query['topic'] = definitions.attack_events_topic

    status_code, response_dict = rest_api.call_rest_api(url, query=sdata)
    if status_code != 200:
        msg = 'Failed to send attacker data to br-event-adapter, error=' + response_dict['exception']
        kojoney_syslog.ops_log(msg)  # send to ELK


# note multiple attacks of same IP make flags have more than one entry
# RT : 192.168.1.144 (NoDNS) CTL=5.1 {2.5} none (None,None) 999.00N 999.00E Unknown Unknown (P2 #W=290 P2 #E=114) flags=PR SC

if __name__ == "__main__":
    try:
        ############
        # TEST = False
        TEST = True
        ############

        ATTACKER_DICT_P1 = {}
        ATTACKER_INFO_P1 = {}

        ATTACKER_DICT_P2 = {}
        ATTACKER_INFO_P2 = {}

        if TEST == True:
            P1 = 120  # 60 seconds = TEST
            P2 = 600  # 120
            filenameAttack = '/home/var/log/attacker.log'
        else:
            P1 = 300  # 5 minutes  = PRODUCTION
            P2 = 7200  # 7200 = 2 hours
            filenameAttack = '/home/var/log/attacker_correlated.log'

        ATTACKER_CACHE_FILE_P1 = '/home/var/log/attackerCacheP1.txt'
        ATTACKER_CACHE_FILE_P2 = '/home/var/log/attackerCacheP2.txt'

        # syslog.openlog("kojoney_tsom")
        # syslog.openlog("tsom")
        msg = "Program parameters => TEST=" + TEST.__str__() + " P1=" + P1.__str__() + " P2=" + P2.__str__() + " attackerCacheFileP1=" + ATTACKER_CACHE_FILE_P1 + " attackerCacheFileP2=" + ATTACKER_CACHE_FILE_P2
        # print msg
        kojoney_syslog.ops_log(msg)
        cycle = 0

        fileAttack = open(filenameAttack, 'r')
        syslog_msg = "Opened Attacker Log file => filename=%s" % (filenameAttack)
        kojoney_syslog.ops_log(syslog_msg, syslog.LOG_INFO)
        print(syslog_msg)

        # Find the size of the Attack file and move to the end
        st_results_attack = os.stat(filenameAttack)
        st_size_attack = st_results_attack[6]
        fileAttack.seek(st_size_attack)
        # print "system     : Seek to end of Attacker Log file"

        while True:
            whereAttack = fileAttack.tell()
            lineAttack = fileAttack.readline()

            if not lineAttack:  # no data
                # print time.ctime() + " Nothing in Attack logfile to process"
                fileAttack.seek(whereAttack)
            else:  # new data has been added to log file
                # print "\n*** NEW EVENT in Attacker (Correlated) Log to process"
                # print lineAttack
                process(lineAttack, ATTACKER_DICT_P1, ATTACKER_INFO_P1, "P1")
                process(lineAttack, ATTACKER_DICT_P2, ATTACKER_INFO_P2, "P2")

            # print "sleeping..."
            # time.sleep(1)

            # Update data about the attackers / attacks etc.
            cycle = cycle + 1
            if cycle >= 50:  # every 10 seconds approx
                # print " "
                # print "**** kojoney_tsom : Updating Threat Level calculations..."
                # print time.ctime()
                # Calc individual CTL for each phase P1 and P2 and P1 + P2"
                calcCTL(ATTACKER_DICT_P1, ATTACKER_INFO_P1, ATTACKER_DICT_P2, ATTACKER_INFO_P2)

                # Dump info to file phase 
                dumpFileAttackerDict(ATTACKER_DICT_P1, ATTACKER_INFO_P1, ATTACKER_CACHE_FILE_P1, "P1")
                dumpFileAttackerDict(ATTACKER_DICT_P2, ATTACKER_INFO_P2, ATTACKER_CACHE_FILE_P2, "P2")

                # optional : Dump to TTY - useful when debugging
                dumpTTYattackerDict(ATTACKER_DICT_P2, ATTACKER_INFO_P2)

                # Write attacker info to file that can be read by remote access processes
                pickleAttackerInfo(ATTACKER_INFO_P2)

                # Prune database phase"
                pruneAttackerDict(ATTACKER_DICT_P1, ATTACKER_INFO_P1, P1, TEST, "P1")
                pruneAttackerDict(ATTACKER_DICT_P2, ATTACKER_INFO_P2, P2, TEST, "P2")

                # reset cycle counter                              
                cycle = 0

            # print "sleeping..."
            time.sleep(0.5)

    except Exception, e:
        msg = "kojoney_tsom.py : main() : exception : " + e.__str__()
        print msg
        kojoney_syslog.ops_log(msg)
        sys.exit()
