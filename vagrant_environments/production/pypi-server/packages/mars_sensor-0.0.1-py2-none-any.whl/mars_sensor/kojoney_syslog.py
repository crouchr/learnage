#!/usr/bin/python
# The fact that honeypot is made up of multiple sensors (kippo, amun) etc is to be hidden (so they can be swapped out)
# https://success.trendmicro.com/dcx/s/solution/TP000086250?language=en_US

# TODO
# ----
# add id to the parameters, default to 0

import json
import syslog

import blackrain_id
import definitions
import kojoney_read_config

# fake program names - will be used in syslog-ng to route syslogs
# Honeypots
BR_WEB_0 = "br-web-0"  # glastopf
BR_WEB_1 = "br-web-1"  # glastopfng

BR_SSH_0 = "br-ssh-0"  # kippo
BR_SSH_1 = "br-ssh-1"  # cowrie

BR_WIN32_0 = "br-win32-0"  # amun
BR_WIN32_1 = "br-win32-1"  # dionae

BR_HONEYTRAP_RAW = "honeytrap-raw"  # raw logs from honeytrap's log slight tidy up and send to syslog for code development purposes

# File analysers
BR_AV_0 = "br-av-0"  # clamav
BR_AV_1 = "br-av-1"  # Maldet - new file detection

# Flow/session probes
BR_NETFLOW = "br-netflow"  # netflow
BR_SESSION = "br-session"  # Argus

# 'Wizards'
BR_ANALYST = "br-analyst"  # Anubis
BR_TSOM = "br-tsom"  # TSOM

# Other
BR_PSMONITOR = "br-psmonitor"
BR_IPINTELLIB = 'br-ipintellib'
BR_DISCOVER = 'br-discover'

# Fix the application/box and maintenance tasks 
BR_OPS = "br-ops"  # Operations and maintenance

# Program development
BR_TEST = "br-test"

# arbitrary
# don't use LOG_LOCAL7 as Cisco routers use it
BR_OPS_FACILITY = syslog.LOG_LOCAL1
BR_SEC_FACILITY = syslog.LOG_LOCAL2

BR_LOGOPT = syslog.LOG_PID  # can easily see if two identical processes are running, each with own pid

# Read dynamic data that has been discovered by kojoney_discover
filename = definitions.sensor_environment_file
var_root = 'sensor'
var_name = 'sensor_id'
SENSOR_ID = kojoney_read_config.read_yaml_config_var(filename, var_root, var_name)


# print "SENSOR_ID=%s" % SENSOR_ID


# Severity - think OpsGenie
# Human interaction is required 24x7 - 'wakey, wakey'
# - honeypot needs to be manually shut down / has been shutdown - acive response has been activated 
# BR_P1=15

# Interrupt me during the day - it is an event of interest
# e.g. 
# - attacker is logged in and executing commands
# - some malware has been downloaded 
# BR_P2

# eveything else
# BR_P3

# priority = facility & level

# syslog.openlog("kojoney_tweet",syslog.LOG_PID,syslog.LOG_LOCAL2)
# syslog.open(BR_TEST, syslog.LOG_PID, 

# add sec_log_json(msg_json) and ops_log_json(msg_json)

def sec_log(syslog_msg, priority=syslog.LOG_INFO, id=blackrain_id.NULL_ID):
    """
    Send a blackrain security log to syslog - i.e. that security analyst would be interested in
    i.e. the 'value' syslogs
    if no priority specified then use LOG_INFO
    id is unique is identifying the syslog event
    """
    try:
        # print "id is %s" % id
        # syslog_msg = "%s [event.id=%04d] [sensor.id]=%s" % (syslog_msg,id, SENSOR_ID)
        # print syslog_msg

        json_syslog_msg = convert_syslog_to_json(syslog_msg, id)
        syslog.syslog(priority, json_syslog_msg)
    except Exception, e:
        print "kojoney_syslog.py::sec_log() : exception=%s" % e


def ops_log(syslog_msg, priority=syslog.LOG_INFO, id=blackrain_id.NULL_ID):
    """
    Send a system log that 'operations' would be interested in to syslog
    i.e. problem / maintenance with the blackrain platform
    if no priority specified then use LOG_INFO
    """
    try:
        json_syslog_msg = convert_syslog_to_json(syslog_msg, id)
        syslog.syslog(priority, json_syslog_msg)
    except Exception, e:
        print "kojoney_syslog.py::ops_log() : exception=%s" % e


def extract_type_values_as_dict(line):
    """
    Extract (type, value) as a dict from the input line
    """
    sdata = {}

    pairs = line.split(' ')
    for pair in pairs:
        # print pair
        type_part = pair.split('=')[0]
        value_part = pair.split('=')[1]
        value_part = value_part.lstrip("'")  # e.g. for ip='1.1.1.1'
        value_part = value_part.rstrip("'")
        sdata[type_part] = value_part

    return sdata


# TODO : put everything under blackrain root e.g. blackrain.sensor.id.
def convert_syslog_to_json(syslog_msg, event_id):
    """
    Extract (type, value) pairs from the unstructured syslog message
    """
    event = {}
    sensor = {}
    sdata = {}

    try:
        if '=>' not in syslog_msg:  # => signifies a new style message
            return syslog_msg

        # a=1/0 	# trigger an exception

        type_values = syslog_msg.split(' => ')[1]

        sdata = extract_type_values_as_dict(type_values)

        fixed_message = syslog_msg.split(' => ')[0]
        sdata['msg_text'] = fixed_message

        event['id'] = event_id
        sensor['id'] = SENSOR_ID

        sdata['event'] = event
        sdata['sensor'] = sensor

        sdata_as_json = json.dumps(sdata)  # convert dict{} to json

        return sdata_as_json

    except Exception, e:
        print "kojoney_syslog.py::convert_syslog_to_json() : exception=%s line=%s" % (e, syslog_msg)
        sdata['exception'] = str(e)
        sdata['line'] = syslog_msg
        return json.dumps(sdata)


# see https://docs.python.org/2.6/library/syslog.html  

# test harness / example
if __name__ == '__main__':
    try:
        ident = BR_TEST
        logopt = BR_LOGOPT

        # Send a security log
        # -------------------
        facility = BR_SEC_FACILITY
        syslog.openlog(ident, logopt, facility)

        # test case 1 : specify all parameters
        syslog_msg = "This is test case 1 SECURITY log => source=%s" % BR_TEST
        sec_log(syslog_msg, syslog.LOG_INFO)

        # test case 2 : specify minimal parameters
        syslog_msg = "This is test case 2 SECURITY log from %s" % BR_TEST
        sec_log(syslog_msg)

        # Send an ops log
        # ---------------
        facility = BR_OPS_FACILITY
        syslog.openlog(ident, logopt, facility)

        # Test case 1 : specify all parameters    
        syslog_msg = "This is test case 1 OPS log from %s" % BR_TEST
        ops_log(syslog_msg, priority=syslog.LOG_INFO, id=blackrain_id.TEST_ID)

        # Test case 2 : specify id    
        syslog_msg = "Here is a message => a=123 b=456 attacker_ip='1.1.1.2'"
        ops_log(syslog_msg, id=1234)

        # Test case 3 : specify minimal parameters - i.e. just the message
        syslog_msg = "This is test case 2 OPS log from %s" % BR_TEST
        ops_log(syslog_msg)

    except Exception, e:
        print "kojoney_syslog::main(): exception=%s" % e

    # now add json examples
