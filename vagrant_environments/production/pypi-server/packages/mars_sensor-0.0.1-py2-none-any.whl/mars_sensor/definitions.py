# variables used globally

import syslog

mars_root = '/home/mars'

# test_pc_ip='192.168.1.171'		# Amelia's Lenovo
test_pc_ip = '192.168.1.140'  # volker Lenovo
web_server_ip = '192.168.1.102'  # Fake malware delivery web server

attack_events_topic = 'blackrain/attack_events'

# br_exporter_endpoint='http://192.168.1.140:9700'
br_exporter_endpoint = 'http://192.168.1.6:9700'  # j1900

blackrain_legacy_app_name = 'blackrain-legacy'

mars_sensor_id = '0080c7886b71'

# YAML file describing sensor info
sensor_environment_file = '/etc/blackrain/sensor_environment.yml'
#sensor_environment_file = 'config/sensor_environment.yml'


template_files_dir = mars_root + '/templates/'

amun_conf_file = '/home/mars/amun/conf/amun.conf'

# Constant data sent to MQTT
Sdata = {}
Sdata['schema_version'] = '0.1'
Sdata['sensor_hostname'] = 'mars'
Sdata['sensor_id'] = mars_sensor_id
Sdata['sensor_latitude'] = 51.415
Sdata['sensor_longitude'] = 1.776
Sdata['sensor_platform'] = 'virtualbox'
Sdata['sensor_os'] = 'Slackware 12.0'  # FIXME : derive from uname ?
Sdata['sensor_description'] = 'BlackRain on mars'
Sdata['sensor_product'] = 'BlackRain Honeypot'
Sdata['sensor_location'] = 'Newbury'
Sdata['sensor_country'] = 'GB'
Sdata['sensor_version'] = '0.21'
Sdata['sensor_class'] = 'honeypot'
Sdata['sensor_environment'] = 'production'  # testing / development / staging / production
Sdata['sensor_manufacturer'] = 'BlackRain Technologies'
Sdata['tags'] = 'honeypot'
Sdata['event_timestamp'] = 'FIXME : not yet implemented'
Sdata['app_name'] = blackrain_legacy_app_name

# syslog priority
netflow_syslog_priority = syslog.LOG_LOCAL1 | syslog.LOG_INFO
tsom_syslog_priority = syslog.LOG_LOCAL3 | syslog.LOG_INFO
amun_syslog_priority = syslog.LOG_LOCAL4 | syslog.LOG_INFO
snort_syslog_priority = syslog.LOG_LOCAL5 | syslog.LOG_INFO
glastopf_syslog_priority = syslog.LOG_LOCAL6 | syslog.LOG_INFO
