#!/usr/bin/python

# discover own IP address and the local subnet/mask ?  
# eth0      Link encap:Ethernet  HWaddr 08:00:27:03:E6:91
#          inet addr:192.168.1.67  Bcast:192.168.1.255  Mask:255.255.255.0


import os
import platform
import syslog
import time

from jinja2 import Environment, FileSystemLoader

import definitions
import ipintellib
import kojoney_default_gw
import kojoney_mac
import kojoney_syslog
import rest_api

# set up Syslog parameters
ident = kojoney_syslog.BR_DISCOVER
logopt = kojoney_syslog.BR_LOGOPT
facility = kojoney_syslog.BR_SEC_FACILITY
syslog.openlog(ident, logopt, facility)

syslog_msg = "Process started"
kojoney_syslog.ops_log(syslog_msg)


def write_discovery_vars(output_filename, mac, isp_ip, sensor_asn, sensor_isp, sensor_cc):
    # environment has to be an absolute path as it is run by rc.kojoney_discover in another directory
    jinja_templates_dir = definitions.template_files_dir
    environment = Environment(loader=FileSystemLoader(jinja_templates_dir))
    template = environment.get_template("discover.jinja")

    tstamp = time.ctime()
    sensor_id = isp_ip.replace('.', ':') + ":" + mac

    node = platform.node()

    content = template.render(
        tstamp=tstamp,
        node=node,
        sensor_id=sensor_id,
        sensor_asn=sensor_asn,
        sensor_isp=sensor_isp,
        sensor_cc=sensor_cc,
        mac=mac,
        isp_ip=isp_ip
    )

    syslog_msg = "Wrote to sensor environment file => sensor_environment_file=%s" % output_filename
    kojoney_syslog.ops_log(syslog_msg)

    # print content

    fp_out = open(output_filename, "w")
    print >> fp_out, content
    fp_out.close()


#def write_amun_conf_file(output_filename, my_isp_ip):
#    # environment has to be an absolute path as it is run by rc.kojoney_discover in another directory
#    environment = Environment(loader=FileSystemLoader("/home/mars/templates/"))
#    template = environment.get_template("amun.conf.jinja")
#
#    tstamp = time.ctime()
#
#    content = template.render(
#        tstamp=tstamp,
#        ftp_nat_ip=my_isp_ip
#    )

#    syslog_msg = "Wrote to Amun Configuration File => filename=%s ftp_nat_ip=%s" % (output_filename, my_isp_ip)
#    kojoney_syslog.ops_log(syslog_msg)

 #   # print content

#    fp_out = open(output_filename, "w")
#    print >> fp_out, content
#    fp_out.close()


# mars SSL not good enougth to call direct to ip-chicken.com
def get_my_isp_ip():
    try:
        endpoint = 'http://192.168.1.6:9700/whats_my_ip'
        # endpoint = 'http://192.168.1.143:9700/whats_my_ip'
        # print "endpoint = " + endpoint
        sdata = {}

        # Mandatory fields
        sdata['app_name'] = 'kojoney_discover'

        status_code, response_dict = rest_api.call_rest_api(endpoint, sdata)
        # import pdb; pdb.set_trace()
        # print "status_code is " + str(status_code)

        return response_dict['ip']

    except Exception, e:
        syslog_msg = "Exception => file=kojoney_discovery::get_my_isp_ip() exception=%s" % e
        kojoney_syslog.ops_log(syslog_msg)
        return '0.0.0.0'


def main():
    print("Started")

    my_mac = kojoney_mac.getMacAddress()
    my_default_gw_ip, my_default_gw_iface = kojoney_default_gw.getDGIP()
    my_isp_ip = get_my_isp_ip()

    # Now get ASN information about the sensors public IP address
    asn_info = ipintellib.ip2asn(my_isp_ip)

    sensor_asn = asn_info['as']
    sensor_cc = asn_info['countryCode']
    sensor_isp = asn_info['registeredCode']

    # Now do latitude / longitude etc

    # import pdb; pdb.set_trace()
    output_filename = definitions.sensor_environment_file
    write_discovery_vars(output_filename, my_mac, my_isp_ip, sensor_asn, sensor_cc, sensor_isp)

    # Set the IP address used for FTP shellcode
    #write_amun_conf_file(definitions.amun_conf_file, my_isp_ip)
    #os.system('/home/mars/kill_amun.sh')  # kill Amun so it re-reads it's config file

    # kojoney_syslog statements are permitted after here
    # --------------------------------------------------
    syslog_msg = "Sensor local network discovery information => mac=%s gw_ip=%s via_iface=%s public_ip=%s" % (
    my_mac, my_default_gw_ip, my_default_gw_iface, my_isp_ip)
    kojoney_syslog.ops_log(syslog_msg)

    syslog_msg = "Sensor ISP discovery information => sensor_asn=%s sensor_cc=%s sensor_isp=%s" % (
    sensor_asn, sensor_cc, sensor_isp)
    kojoney_syslog.ops_log(syslog_msg)


if __name__ == '__main__':
    main()
