#!/usr/bin/python
# Make this generic so can read from any variable from and yml config file

import yaml
from pprint import pprint



def read_yaml_config_var(filename, var_root, var_name):
    config_file = open(filename, "r")
    config_vars = yaml.safe_load(config_file)
    #pprint(config_vars)
    
    #print "var_root=%s" % var_root
    #print "var_name=%s" % var_name
    if var_name == None:
        required_variable = config_vars[var_root]
    else:
      required_variable = config_vars[var_root][var_name]
    
    return required_variable


# test harness
if __name__ == '__main__':  
    import definitions
    
    # test case 1 - two levels
    filename = definitions.sensor_environment_file
    var_root = 'sensor'
    var_name = 'mac'
    mac = read_yaml_config_var(filename, var_root, var_name)
    print mac
    
    # test case 2 - single level
    filename = definitions.sensor_environment_file
    var_root = 'sensor'
    var_name = None
    sensor= read_yaml_config_var(filename, var_root, var_name)
    
    print sensor
    