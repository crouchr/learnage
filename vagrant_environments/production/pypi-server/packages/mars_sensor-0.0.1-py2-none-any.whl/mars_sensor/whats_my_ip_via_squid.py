#!/usr/bin/python
#from subprocess import run - Python3

import subprocess

def whats_my_ip():
    """
    Determine our IP (ISP allocated to us)
    """
    #command = "curl -s https://ipchicken.com | grep -E -o '([[:digit:]]{1,3}\.){3}[[:digit:]]{1,3}'"
    command = "curl --proxy http://192.168.1.103:3128 -s https://ipchicken.com"
    # | grep -E -o '([[:digit:]]{1,3}\.){3}[[:digit:]]{1,3}'"
    
    #-x "http://user:pwd@127.0.0.1:1234"
    
    command_split = command.split(" ")
    print(command_split)
     
    stdout_result = subprocess.check_output(command_split)
    print("stdout=%s" % stdout_result)
    
    #data = run(command, capture_output=True, shell=True, text=True)
    #ip = data.stdout.rstrip()
    #print("ip is %s" % ip)
                
    return '0.0.0.0'
                    
                    
# test harness
if __name__ == '__main__':
    my_ip = whats_my_ip()
    print(my_ip)
