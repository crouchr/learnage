"""
Test importing of functions to be unit tested
"""


def my_true_func():
    return True


def my_false_func():
    return False
    