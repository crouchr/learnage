#!/usr/bin/python
import time
import httplib2 			# urllib3 and requests not available
from pprint import pprint
from json import loads, dumps

# FIXME : add retries, authentication , encryption etc in the future
# returning 200 even if return data is not good - this should be 500 ?
# call ANY REST API - must be generic
# see https://howtodoinjava.com/python-modules/httplib2-http-get-post-requests/
def call_rest_api(endpoint, query):
    """
    Call REST API endpoint using POST method
    :param endpoint:e.g. 'http://127.0.0.1:9500/wind_deg_to_wind_rose'
    :param query: e.g. query = {'wind_deg': wind_deg}
    :return:
    """
    try:
      
        response_dict = {}
        response_dict ['exception'] = 'not set'
                
        print ">>> entered rest_api.call_rest_api()"
        print "request message:-"
        pprint(query)
        
        http = httplib2.Http()
        
        headers={'Content-Type': 'application/json; charset=UTF-8'}
        
        resp, content = http.request(endpoint, body=dumps(query), method='POST', headers=headers)
        if resp.status != 200:
            print "Error : Failed to send to REST API"
            pprint(response_dict)
            response_dict['exception'] = 'http_status=' + resp.status.__str__()
            return 500, response_dict
        
        response_dict = loads(content.decode('utf-8'))
        print "response message:-"
        pprint(response_dict)
        
        return resp.status, response_dict

    except Exception, e:
        print "call_rest_api() : e=" + e.__str__()
        response_dict['exception'] = e.__str__()
        return 500, response_dict

# test harness
if __name__ == '__main__':
    j1900_ip = '192.168.1.6'
    
    #endpoint = 'http://' +j1900_ip + '9700/status'
    #query = {}
    #query['app_name'] = 'test_code'
    #
    #status_code, response_dict = call_rest_api(endpoint, query)    
    #print "status_code : " + status_code.__str__()
#
#    pprint(response_dict)
#    if status_code == 200:
#      print "service_name : " + response_dict['service_name']
    
    # br-event-adaptor container runs on j1900
    endpoint = 'http://192.168.1.140:9700/send_to_mqtt'
    print "endpoint = " + endpoint
    
    sdata = {}
    # Mandatory fields
    sdata['app_name'] = 'rest_api.py test harness'
    sdata['type'] = 'TEST_MESSAGE'
    sdata['topic'] = 'blackrain/test'
    sdata['ip'] = '8.8.8.8'
    
    # Optional fields
    sdata['tag'] = 'honeypot'
    sdata['description'] = 'This is a test message sent on ' + time.ctime()
        
    status_code, response_dict = call_rest_api(endpoint, sdata)    
    print "status_code is " + str(status_code)
    