#include <string.h>
#include <iostream>
#include "AppError.h"

// AppError is an abstract class. See header file.
